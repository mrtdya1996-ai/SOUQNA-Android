import React from 'react';
import { AppShell } from './components/AppShell';
import { AppProvider, useApp } from './context/AppContext';
import { AccountView } from './views/AccountView';
import { AdminDashboardView } from './views/AdminDashboardView';
import { AuthView } from './views/AuthView';
import { CartCheckoutView } from './views/CartCheckoutView';
import { CourierDashboardView } from './views/CourierDashboardView';
import { CourierRegisterView } from './views/CourierRegisterView';
import { HomeView } from './views/HomeView';
import { MerchantDashboardView } from './views/MerchantDashboardView';
import { NotificationsView } from './views/NotificationsView';
import { OrdersView } from './views/OrdersView';
import { ProductsCatalogView } from './views/ProductsCatalogView';
import { StoreDetailView } from './views/StoreDetailView';
import { StoresDirectoryView } from './views/StoresDirectoryView';
import { SubscriptionView } from './views/SubscriptionView';
import { SupportView } from './views/SupportView';

import { Loader2 } from 'lucide-react';
import { SouqnaLogo } from './components/SouqnaLogo';

const ActiveViewRouter: React.FC = () => {
  const { activeView, authReady } = useApp();

  if (!authReady) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
        <SouqnaLogo size="lg" />
        <div className="inline-flex items-center gap-2 rounded-xl border border-sq-gold-hairline bg-sq-surface px-4 py-2.5 text-xs font-semibold text-sq-ink-muted">
          <Loader2 className="h-4 w-4 animate-spin text-sq-gold-text" />
          <span>جاري استعادة جلستك المحفوظة...</span>
        </div>
      </div>
    );
  }

  switch (activeView) {
    case 'stores':
      return <StoresDirectoryView />;
    case 'products':
      return <ProductsCatalogView />;
    case 'store':
      return <StoreDetailView />;
    case 'cart':
      return <CartCheckoutView />;
    case 'orders':
      return <OrdersView />;
    case 'merchant':
      return <MerchantDashboardView />;
    case 'courier':
      return <CourierDashboardView />;
    case 'courier_register':
      return <CourierRegisterView />;
    case 'admin':
      return <AdminDashboardView />;
    case 'account':
      return <AccountView />;
    case 'notifications':
      return <NotificationsView />;
    case 'support':
      return <SupportView />;
    case 'subscription':
      return <SubscriptionView />;
    case 'auth':
      return <AuthView />;
    case 'home':
    default:
      return <HomeView />;
  }
};

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): { hasError: boolean } {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="min-h-screen flex items-center justify-center bg-sq-canvas px-4 text-sq-ink"
        >
          <div className="max-w-md w-full rounded-3xl border border-sq-gold-hairline bg-sq-surface p-7 text-center space-y-4 shadow-xl">
            <h1 className="font-display text-xl font-extrabold text-sq-ink">
              حدث خلل مؤقت أثناء عرض الصفحة
            </h1>
            <p className="text-sm text-sq-ink-muted leading-relaxed">
              بياناتك وجلستك محفوظة بأمان. اضغط على الزر أدناه لإعادة تحميل الواجهة فوراً.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="min-h-[46px] w-full rounded-xl btn-gold px-5 text-sm font-bold"
            >
              إعادة تحميل سوقنا
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <AppErrorBoundary>
      <AppProvider>
        <AppShell>
          <ActiveViewRouter />
        </AppShell>
      </AppProvider>
    </AppErrorBoundary>
  );
}
