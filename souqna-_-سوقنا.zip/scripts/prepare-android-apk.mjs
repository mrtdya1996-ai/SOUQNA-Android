import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const CONFIG_PATH = path.join(ROOT, 'capacitor.config.json');
const rawUrl = (process.env.SOUQNA_SERVER_URL || '').trim();

const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
config.appId = 'com.souqna.marketplace';
config.appName = 'سوقنا | SOUQNA';
config.webDir = 'dist';
config.backgroundColor = '#090A0A';
config.server = {
  ...(config.server || {}),
  androidScheme: 'https',
};

if (rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error(`Invalid SOUQNA_SERVER_URL: ${rawUrl}`);
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    throw new Error('SOUQNA_SERVER_URL must start with https:// or http://');
  }
  const cleanUrl = rawUrl.replace(/\/+$/, '');
  config.server.url = cleanUrl;
  config.server.cleartext = parsed.protocol === 'http:';
  config.server.allowNavigation = [parsed.hostname];
  console.log(`Configured Android APK to connect live to: ${cleanUrl}`);
} else {
  delete config.server.url;
  delete config.server.cleartext;
  delete config.server.allowNavigation;
  console.log('Configured Android APK with bundled local dist/ assets (set SOUQNA_SERVER_URL to connect live backend).');
}

fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2) + '\n', 'utf8');
