import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
export const PRIVATE_DOCS_DIR = path.resolve(process.cwd(), 'private_uploads', 'courier_docs');
export const PRIVATE_PAYMENT_PROOFS_DIR = path.resolve(
  process.cwd(),
  'private_uploads',
  'payment_proofs'
);
const MAX_IMAGE_BYTES = 3 * 1024 * 1024; // 3 MB
const MAX_PAYMENT_PROOF_BYTES = 5 * 1024 * 1024; // 5 MB for transfer receipts
const MAX_PRIVATE_DOC_BYTES = 6 * 1024 * 1024; // 6 MB for official courier ID / driving license
const MAX_DOCUMENT_BYTES = 15 * 1024 * 1024; // 15 MB for PDF / high-res print files

export function ensureUploadsDir(): void {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
  if (!fs.existsSync(PRIVATE_DOCS_DIR)) {
    fs.mkdirSync(PRIVATE_DOCS_DIR, { recursive: true });
  }
  if (!fs.existsSync(PRIVATE_PAYMENT_PROOFS_DIR)) {
    fs.mkdirSync(PRIVATE_PAYMENT_PROOFS_DIR, { recursive: true });
  }
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  if (!salt || !keyHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const stored = Buffer.from(keyHex, 'hex');
  if (derived.length !== stored.length) return false;
  return crypto.timingSafeEqual(derived, stored);
}

export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function hashSessionToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function generateResetToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function generateTemporaryResetCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let part1 = '';
  let part2 = '';
  for (let i = 0; i < 4; i++) {
    part1 += alphabet[crypto.randomInt(0, alphabet.length)];
    part2 += alphabet[crypto.randomInt(0, alphabet.length)];
  }
  return `SQ-${part1}-${part2}`;
}

export function normalizeResetCode(code: string): string {
  return code.trim().toUpperCase().replace(/\s+/g, '');
}

export function generateId(prefix: string): string {
  return `${prefix}_${crypto.randomBytes(8).toString('hex')}`;
}

export function generateOrderNumber(): string {
  const randomDigits = crypto.randomInt(100000, 999999);
  return `SQ-${randomDigits}`;
}

export function generateDeliveryNumber(): string {
  const randomDigits = crypto.randomInt(100000, 999999);
  return `DLV-${randomDigits}`;
}

export function generateDeliveryOtp(): string {
  return String(crypto.randomInt(100000, 999999));
}

export function safeSecretEquals(provided: string, expected: string): boolean {
  if (!provided || !expected) return false;
  const a = Buffer.from(provided, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function haversineKm(
  lat1: number | null,
  lng1: number | null,
  lat2: number | null,
  lng2: number | null
): number | null {
  if (lat1 === null || lng1 === null || lat2 === null || lng2 === null) return null;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

export function sanitizeText(value: unknown, maxLength: number): string {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, maxLength);
}

export function sanitizeStringArray(value: unknown, maxItems = 30, maxLen = 60): string[] {
  if (!Array.isArray(value)) return [];
  const seen = new Set<string>();
  const result: string[] = [];
  for (const entry of value) {
    if (typeof entry !== 'string') continue;
    const cleaned = entry.trim().slice(0, maxLen);
    if (!cleaned || seen.has(cleaned)) continue;
    seen.add(cleaned);
    result.push(cleaned);
    if (result.length >= maxItems) break;
  }
  return result;
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 160;
}

export function isValidPhone(phone: string): boolean {
  const cleaned = phone.replace(/[\s\-()]/g, '');
  return /^\+?[0-9]{7,16}$/.test(cleaned);
}

export function sanitizeImageUrl(url: unknown): string {
  if (typeof url !== 'string') return '';
  const trimmed = url.trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('/uploads/') || trimmed.startsWith('/src/assets/')) {
    if (trimmed.includes('..')) return '';
    return trimmed;
  }
  return '';
}

export function verifyUploadedFileExists(url: unknown): string | null {
  if (typeof url !== 'string') return null;
  const trimmed = url.trim();
  if (!trimmed.startsWith('/uploads/') || trimmed.includes('..') || trimmed.includes('\\')) {
    return null;
  }
  const filename = trimmed.slice('/uploads/'.length);
  if (!/^[a-zA-Z0-9._-]+$/.test(filename)) return null;
  const fullPath = path.resolve(UPLOADS_DIR, filename);
  if (!fullPath.startsWith(UPLOADS_DIR + path.sep)) return null;
  if (!fs.existsSync(fullPath)) return null;
  return trimmed;
}

function detectImageType(buffer: Buffer): 'jpg' | 'png' | 'webp' | null {
  if (buffer.length < 12) return null;
  // JPEG: FF D8 FF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'jpg';
  }
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a
  ) {
    return 'png';
  }
  // WebP: RIFF....WEBP
  if (
    buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buffer.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return 'webp';
  }
  return null;
}

function detectDocumentType(
  buffer: Buffer
): { ext: 'pdf' | 'jpg' | 'png' | 'webp'; mime: string } | null {
  if (buffer.length < 5) return null;
  // PDF: %PDF-
  if (buffer.subarray(0, 5).toString('ascii') === '%PDF-') {
    return { ext: 'pdf', mime: 'application/pdf' };
  }
  const imgExt = detectImageType(buffer);
  if (imgExt === 'jpg') return { ext: 'jpg', mime: 'image/jpeg' };
  if (imgExt === 'png') return { ext: 'png', mime: 'image/png' };
  if (imgExt === 'webp') return { ext: 'webp', mime: 'image/webp' };
  return null;
}

export function saveBase64Image(dataUrl: string): { url: string } | { error: string } {
  ensureUploadsDir();

  const match = /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl);
  if (!match) {
    return { error: 'صيغة الصورة غير مدعومة. يرجى اختيار صورة بصيغة JPG أو PNG أو WebP.' };
  }

  const base64Payload = match[2].replace(/\s/g, '');
  const buffer = Buffer.from(base64Payload, 'base64');

  if (buffer.length === 0 || buffer.length > MAX_IMAGE_BYTES) {
    return { error: 'حجم الصورة يتجاوز الحد المسموح (3 ميجابايت كحد أقصى).' };
  }

  const detectedExt = detectImageType(buffer);
  if (!detectedExt) {
    return { error: 'ملف الصورة غير صالح أو تالف.' };
  }

  const filename = `${crypto.randomUUID()}.${detectedExt}`;
  const targetPath = path.resolve(UPLOADS_DIR, filename);

  // Strict directory confinement check
  if (!targetPath.startsWith(UPLOADS_DIR + path.sep)) {
    return { error: 'مسار الحفظ غير مسموح.' };
  }

  fs.writeFileSync(targetPath, buffer);
  return { url: `/uploads/${filename}` };
}

export function saveBase64Document(
  dataUrl: string,
  originalFileName?: string
):
  | { url: string; fileName: string; fileMime: string; sizeBytes: number }
  | { error: string } {
  ensureUploadsDir();

  const match =
    /^data:(application\/pdf|image\/jpeg|image\/jpg|image\/png|image\/webp);base64,([A-Za-z0-9+/=\s]+)$/.exec(
      dataUrl
    );
  if (!match) {
    return {
      error: 'نوع الملف غير مدعوم. يُسمح فقط بملفات PDF أو الصور (JPG / PNG / WebP).',
    };
  }

  const base64Payload = match[2].replace(/\s/g, '');
  const buffer = Buffer.from(base64Payload, 'base64');

  if (buffer.length === 0 || buffer.length > MAX_DOCUMENT_BYTES) {
    return { error: 'حجم الملف يتجاوز الحد المسموح (15 ميجابايت كحد أقصى).' };
  }

  const detected = detectDocumentType(buffer);
  if (!detected) {
    return { error: 'محتوى الملف غير صالح أو لا يطابق صيغة PDF أو صورة صحيحة.' };
  }

  const filename = `doc_${crypto.randomUUID()}.${detected.ext}`;
  const targetPath = path.resolve(UPLOADS_DIR, filename);

  if (!targetPath.startsWith(UPLOADS_DIR + path.sep)) {
    return { error: 'مسار الحفظ غير مسموح.' };
  }

  fs.writeFileSync(targetPath, buffer);

  const safeDisplayName =
    sanitizeText(originalFileName || '', 120).replace(/[<>:"/\\|?*\x00-\x1f]/g, '') ||
    `ملف_طباعة.${detected.ext}`;

  return {
    url: `/uploads/${filename}`,
    fileName: safeDisplayName,
    fileMime: detected.mime,
    sizeBytes: buffer.length,
  };
}

/**
 * Saves sensitive official courier documents (ID front/back, driving license)
 * into a PRIVATE non-static directory (never served under /uploads/).
 */
export function saveBase64PrivateDoc(
  dataUrl: string
): { filename: string; mime: string } | { error: string } {
  ensureUploadsDir();

  const match =
    /^data:(application\/pdf|image\/jpeg|image\/jpg|image\/png|image\/webp);base64,([A-Za-z0-9+/=\s]+)$/.exec(
      dataUrl
    );
  if (!match) {
    return {
      error: 'صيغة المستمسك غير مدعومة. يرجى رفع صورة (JPG / PNG / WebP) أو ملف PDF.',
    };
  }

  const base64Payload = match[2].replace(/\s/g, '');
  const buffer = Buffer.from(base64Payload, 'base64');

  if (buffer.length === 0 || buffer.length > MAX_PRIVATE_DOC_BYTES) {
    return { error: 'حجم ملف المستمسك يتجاوز الحد المسموح (6 ميجابايت كحد أقصى).' };
  }

  const detected = detectDocumentType(buffer);
  if (!detected) {
    return { error: 'ملف المستمسك غير صالح أو تالف.' };
  }

  const filename = `cid_${crypto.randomUUID()}.${detected.ext}`;
  const targetPath = path.resolve(PRIVATE_DOCS_DIR, filename);

  if (!targetPath.startsWith(PRIVATE_DOCS_DIR + path.sep)) {
    return { error: 'مسار الحفظ غير مسموح.' };
  }

  fs.writeFileSync(targetPath, buffer);
  return { filename, mime: detected.mime };
}

export function resolvePrivateDocPath(filename: string): string | null {
  const cleaned = filename.trim();
  if (!/^[a-zA-Z0-9._-]+$/.test(cleaned) || cleaned.includes('..') || cleaned.includes('/')) {
    return null;
  }
  const fullPath = path.resolve(PRIVATE_DOCS_DIR, cleaned);
  if (!fullPath.startsWith(PRIVATE_DOCS_DIR + path.sep)) {
    return null;
  }
  if (!fs.existsSync(fullPath)) {
    return null;
  }
  return fullPath;
}

/**
 * Saves subscription payment transfer proof images into a PRIVATE non-static directory.
 * Never exposed under /uploads/; served only via authenticated /api/private-payment-proofs/:filename.
 */
export function saveBase64PaymentProof(
  dataUrl: string
): { filename: string; mime: string } | { error: string } {
  ensureUploadsDir();

  const match = /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl);
  if (!match) {
    return { error: 'صيغة صورة إثبات التحويل غير مدعومة. يرجى اختيار صورة JPG أو PNG أو WebP.' };
  }

  const base64Payload = match[2].replace(/\s/g, '');
  const buffer = Buffer.from(base64Payload, 'base64');

  if (buffer.length === 0 || buffer.length > MAX_PAYMENT_PROOF_BYTES) {
    return { error: 'حجم صورة إثبات التحويل يتجاوز الحد المسموح (5 ميجابايت كحد أقصى).' };
  }

  const detectedExt = detectImageType(buffer);
  if (!detectedExt) {
    return { error: 'ملف صورة إثبات التحويل غير صالح أو تالف.' };
  }

  const mime =
    detectedExt === 'png' ? 'image/png' : detectedExt === 'webp' ? 'image/webp' : 'image/jpeg';
  const filename = `pay_${crypto.randomUUID()}.${detectedExt}`;
  const targetPath = path.resolve(PRIVATE_PAYMENT_PROOFS_DIR, filename);

  if (!targetPath.startsWith(PRIVATE_PAYMENT_PROOFS_DIR + path.sep)) {
    return { error: 'مسار حفظ إثبات التحويل غير مسموح.' };
  }

  fs.writeFileSync(targetPath, buffer);
  return { filename, mime };
}

export function resolvePrivatePaymentProofPath(filename: string): string | null {
  const cleaned = filename.trim();
  if (!/^[a-zA-Z0-9._-]+$/.test(cleaned) || cleaned.includes('..') || cleaned.includes('/')) {
    return null;
  }
  const fullPath = path.resolve(PRIVATE_PAYMENT_PROOFS_DIR, cleaned);
  if (!fullPath.startsWith(PRIVATE_PAYMENT_PROOFS_DIR + path.sep)) {
    return null;
  }
  if (!fs.existsSync(fullPath)) {
    return null;
  }
  return fullPath;
}
