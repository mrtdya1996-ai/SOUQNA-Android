import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const configuredPath = process.env.DATABASE_PATH?.trim() || './data/souqna.db';
const DB_PATH = path.resolve(process.cwd(), configuredPath);

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

export const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT NOT NULL,
    city TEXT NOT NULL DEFAULT '',
    governorate TEXT NOT NULL DEFAULT '',
    district TEXT NOT NULL DEFAULT '',
    neighborhood TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL DEFAULT '',
    latitude REAL,
    longitude REAL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('customer', 'merchant', 'courier', 'super_admin')),
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS stores (
    id TEXT PRIMARY KEY,
    owner_id TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    store_type TEXT NOT NULL CHECK (store_type IN ('grocery', 'supermarket', 'food_market', 'produce', 'mall', 'shop', 'construction', 'clothing', 'phone_accessories', 'printing', 'gaming_topup')),
    description TEXT NOT NULL DEFAULT '',
    city TEXT NOT NULL,
    district TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL,
    latitude REAL,
    longitude REAL,
    phone TEXT NOT NULL,
    opening_hours TEXT NOT NULL DEFAULT 'يومياً 8:00 ص - 11:00 م',
    delivery_fee REAL NOT NULL DEFAULT 0,
    min_order_amount REAL NOT NULL DEFAULT 0,
    logo_url TEXT NOT NULL DEFAULT '',
    cover_url TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'rejected', 'suspended')),
    rejection_reason TEXT NOT NULL DEFAULT '',
    is_verified INTEGER NOT NULL DEFAULT 0,
    notify_on_store_visit INTEGER NOT NULL DEFAULT 1,
    service_config TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS store_posts (
    id TEXT PRIMARY KEY,
    store_id TEXT NOT NULL,
    author_id TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    post_type TEXT NOT NULL DEFAULT 'announcement' CHECK (post_type IN ('announcement', 'offer', 'new_arrival', 'update')),
    offer_badge TEXT NOT NULL DEFAULT '',
    images_json TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'hidden')),
    moderation_reason TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    store_id TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    price REAL NOT NULL CHECK (price >= 0),
    unit TEXT NOT NULL DEFAULT 'قطعة',
    carton_price REAL NOT NULL DEFAULT 0,
    carton_units INTEGER NOT NULL DEFAULT 0,
    stock_qty INTEGER NOT NULL DEFAULT 0,
    image_url TEXT NOT NULL DEFAULT '',
    is_available INTEGER NOT NULL DEFAULT 1,
    sizes_json TEXT NOT NULL DEFAULT '[]',
    colors_json TEXT NOT NULL DEFAULT '[]',
    phone_models_json TEXT NOT NULL DEFAULT '[]',
    game_name TEXT NOT NULL DEFAULT '',
    custom_options_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS cart_items (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    product_id TEXT NOT NULL,
    pricing_type TEXT NOT NULL DEFAULT 'unit' CHECK (pricing_type IN ('unit', 'carton')),
    option_signature TEXT NOT NULL DEFAULT '',
    item_options_json TEXT NOT NULL DEFAULT '{}',
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(user_id, product_id, pricing_type, option_signature),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    order_number TEXT NOT NULL UNIQUE,
    customer_id TEXT NOT NULL,
    store_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'rejected', 'cancelled')),
    payment_method TEXT NOT NULL DEFAULT 'cash_on_delivery' CHECK (payment_method = 'cash_on_delivery'),
    fulfillment_method TEXT NOT NULL DEFAULT 'delivery' CHECK (fulfillment_method IN ('delivery', 'pickup')),
    subtotal REAL NOT NULL,
    delivery_fee REAL NOT NULL DEFAULT 0,
    total_amount REAL NOT NULL,
    governorate TEXT NOT NULL DEFAULT '',
    city TEXT NOT NULL DEFAULT '',
    district TEXT NOT NULL DEFAULT '',
    neighborhood TEXT NOT NULL DEFAULT '',
    delivery_address TEXT NOT NULL,
    latitude REAL,
    longitude REAL,
    customer_name TEXT NOT NULL,
    customer_phone TEXT NOT NULL,
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    product_id TEXT,
    product_name TEXT NOT NULL,
    unit TEXT NOT NULL,
    pricing_type TEXT NOT NULL DEFAULT 'unit' CHECK (pricing_type IN ('unit', 'carton')),
    unit_price REAL NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    line_total REAL NOT NULL,
    image_url TEXT NOT NULL DEFAULT '',
    item_options_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS platform_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS order_events (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    actor_id TEXT,
    actor_name TEXT NOT NULL DEFAULT '',
    actor_role TEXT NOT NULL DEFAULT '',
    reason TEXT NOT NULL DEFAULT '',
    previous_status TEXT NOT NULL DEFAULT '',
    new_status TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    store_id TEXT,
    order_id TEXT,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    target_view TEXT NOT NULL DEFAULT 'notifications',
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS push_subscriptions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    store_id TEXT,
    channel TEXT NOT NULL CHECK (channel IN ('web_push', 'expo', 'fcm')),
    endpoint TEXT NOT NULL,
    p256dh TEXT NOT NULL DEFAULT '',
    auth TEXT NOT NULL DEFAULT '',
    push_token TEXT NOT NULL DEFAULT '',
    device_label TEXT NOT NULL DEFAULT '',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(user_id, endpoint),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS store_visits (
    id TEXT PRIMARY KEY,
    store_id TEXT NOT NULL,
    visitor_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS couriers (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL UNIQUE,
    governorate TEXT NOT NULL DEFAULT '',
    city TEXT NOT NULL DEFAULT '',
    district TEXT NOT NULL DEFAULT '',
    neighborhood TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL DEFAULT '',
    avatar_url TEXT NOT NULL DEFAULT '',
    vehicle_type TEXT NOT NULL CHECK (vehicle_type IN ('motorcycle', 'car', 'bicycle', 'light_truck')),
    plate_number TEXT NOT NULL DEFAULT '',
    id_type TEXT NOT NULL DEFAULT '',
    id_number TEXT NOT NULL DEFAULT '',
    id_front_doc TEXT NOT NULL DEFAULT '',
    id_back_doc TEXT NOT NULL DEFAULT '',
    license_doc TEXT NOT NULL DEFAULT '',
    terms_accepted INTEGER NOT NULL DEFAULT 0,
    verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected', 'suspended')),
    rejection_reason TEXT NOT NULL DEFAULT '',
    is_available INTEGER NOT NULL DEFAULT 0,
    latitude REAL,
    longitude REAL,
    location_updated_at TEXT NOT NULL DEFAULT '',
    total_deliveries INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS deliveries (
    id TEXT PRIMARY KEY,
    delivery_number TEXT NOT NULL UNIQUE,
    order_id TEXT NOT NULL UNIQUE,
    store_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    courier_id TEXT,
    status TEXT NOT NULL DEFAULT 'waiting_courier' CHECK (status IN ('waiting_courier', 'dispatched', 'accepted', 'heading_to_store', 'picked_up', 'on_the_way', 'delivered', 'cancelled')),
    pickup_address TEXT NOT NULL DEFAULT '',
    pickup_lat REAL,
    pickup_lng REAL,
    dropoff_address TEXT NOT NULL DEFAULT '',
    dropoff_lat REAL,
    dropoff_lng REAL,
    delivery_fee REAL NOT NULL DEFAULT 0,
    cash_to_collect REAL NOT NULL DEFAULT 0,
    delivery_otp TEXT NOT NULL DEFAULT '',
    otp_verified INTEGER NOT NULL DEFAULT 0,
    distance_km REAL,
    cancel_reason TEXT NOT NULL DEFAULT '',
    requested_at TEXT NOT NULL,
    dispatched_at TEXT NOT NULL DEFAULT '',
    accepted_at TEXT NOT NULL DEFAULT '',
    picked_up_at TEXT NOT NULL DEFAULT '',
    delivered_at TEXT NOT NULL DEFAULT '',
    cancelled_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (courier_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS delivery_events (
    id TEXT PRIMARY KEY,
    delivery_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    actor_id TEXT,
    actor_name TEXT NOT NULL DEFAULT '',
    actor_role TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    previous_status TEXT NOT NULL DEFAULT '',
    new_status TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE CASCADE,
    FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS complaints (
    id TEXT PRIMARY KEY,
    reporter_id TEXT NOT NULL,
    reporter_role TEXT NOT NULL DEFAULT 'customer',
    target_type TEXT NOT NULL CHECK (target_type IN ('store', 'courier', 'order', 'user')),
    target_id TEXT NOT NULL,
    target_name TEXT NOT NULL DEFAULT '',
    order_id TEXT,
    delivery_id TEXT,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'under_review', 'resolved', 'dismissed')),
    violation_recorded INTEGER NOT NULL DEFAULT 0,
    admin_notes TEXT NOT NULL DEFAULT '',
    resolved_by_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS store_subscriptions (
    store_id TEXT PRIMARY KEY,
    plan_name TEXT NOT NULL DEFAULT 'free' CHECK (plan_name IN ('free', 'basic', 'pro', 'enterprise')),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'trial', 'expired', 'suspended')),
    monthly_fee REAL NOT NULL DEFAULT 0,
    expires_at TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS user_subscriptions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL UNIQUE,
    subscriber_type TEXT NOT NULL CHECK (subscriber_type IN ('merchant', 'courier')),
    store_id TEXT,
    plan_name TEXT NOT NULL DEFAULT 'trial_30',
    status TEXT NOT NULL DEFAULT 'trial' CHECK (status IN ('trial', 'active', 'expired', 'suspended')),
    starts_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    monthly_fee REAL NOT NULL DEFAULT 0,
    total_paid REAL NOT NULL DEFAULT 0,
    renewal_requested INTEGER NOT NULL DEFAULT 0,
    renewal_note TEXT NOT NULL DEFAULT '',
    renewal_requested_at TEXT NOT NULL DEFAULT '',
    expiring_notified_at TEXT NOT NULL DEFAULT '',
    expired_notified_at TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS subscription_logs (
    id TEXT PRIMARY KEY,
    subscription_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    action_type TEXT NOT NULL,
    amount_paid REAL NOT NULL DEFAULT 0,
    duration_days INTEGER NOT NULL DEFAULT 0,
    previous_status TEXT NOT NULL DEFAULT '',
    new_status TEXT NOT NULL DEFAULT '',
    previous_expires_at TEXT NOT NULL DEFAULT '',
    new_expires_at TEXT NOT NULL DEFAULT '',
    actor_id TEXT,
    actor_name TEXT NOT NULL DEFAULT '',
    actor_role TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (subscription_id) REFERENCES user_subscriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS complaint_messages (
    id TEXT PRIMARY KEY,
    complaint_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    sender_name TEXT NOT NULL DEFAULT '',
    sender_role TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL,
    image_url TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id TEXT PRIMARY KEY,
    admin_id TEXT NOT NULL,
    admin_name TEXT NOT NULL DEFAULT '',
    action_type TEXT NOT NULL,
    target_type TEXT NOT NULL DEFAULT '',
    target_id TEXT NOT NULL DEFAULT '',
    target_label TEXT NOT NULL DEFAULT '',
    details TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS subscription_plans (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    duration_months INTEGER NOT NULL,
    duration_days INTEGER NOT NULL,
    price_iqd REAL NOT NULL CHECK (price_iqd >= 0),
    is_active INTEGER NOT NULL DEFAULT 1,
    sort_order INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS subscription_payment_requests (
    id TEXT PRIMARY KEY,
    subscription_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    subscriber_type TEXT NOT NULL CHECK (subscriber_type IN ('merchant', 'courier')),
    store_id TEXT,
    plan_id TEXT NOT NULL,
    plan_code TEXT NOT NULL,
    plan_name TEXT NOT NULL,
    duration_days INTEGER NOT NULL,
    amount_iqd REAL NOT NULL CHECK (amount_iqd >= 0),
    payment_method TEXT NOT NULL CHECK (payment_method IN ('zaincash', 'mastercard')),
    transfer_reference TEXT NOT NULL DEFAULT '',
    transfer_details TEXT NOT NULL DEFAULT '',
    payment_proof_doc TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    rejection_reason TEXT NOT NULL DEFAULT '',
    admin_notes TEXT NOT NULL DEFAULT '',
    reviewed_by_id TEXT,
    reviewed_by_name TEXT NOT NULL DEFAULT '',
    reviewed_at TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (subscription_id) REFERENCES user_subscriptions(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE SET NULL,
    FOREIGN KEY (reviewed_by_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS account_recovery_requests (
    id TEXT PRIMARY KEY,
    matched_user_id TEXT,
    requester_name TEXT NOT NULL,
    requester_phone TEXT NOT NULL,
    requester_email TEXT NOT NULL DEFAULT '',
    account_type TEXT NOT NULL DEFAULT 'customer',
    proof_details TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'completed')),
    admin_notes TEXT NOT NULL DEFAULT '',
    rejection_reason TEXT NOT NULL DEFAULT '',
    reviewed_by_id TEXT,
    reviewed_at TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (matched_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (reviewed_by_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    recovery_request_id TEXT,
    token_hash TEXT NOT NULL UNIQUE,
    code_hash TEXT NOT NULL,
    issued_by_admin_id TEXT,
    expires_at TEXT NOT NULL,
    used_at TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (recovery_request_id) REFERENCES account_recovery_requests(id) ON DELETE SET NULL,
    FOREIGN KEY (issued_by_admin_id) REFERENCES users(id) ON DELETE SET NULL
  );
`);

function ensureColumn(table: string, column: string, definition: string): void {
  const existing = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (!existing.some((col) => col.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

// Non-destructive column additions for older databases
ensureColumn('users', 'governorate', "TEXT NOT NULL DEFAULT ''");
ensureColumn('users', 'district', "TEXT NOT NULL DEFAULT ''");
ensureColumn('users', 'neighborhood', "TEXT NOT NULL DEFAULT ''");
ensureColumn('users', 'latitude', 'REAL');
ensureColumn('users', 'longitude', 'REAL');

ensureColumn('stores', 'district', "TEXT NOT NULL DEFAULT ''");
ensureColumn('stores', 'latitude', 'REAL');
ensureColumn('stores', 'longitude', 'REAL');
ensureColumn('stores', 'rejection_reason', "TEXT NOT NULL DEFAULT ''");
ensureColumn('stores', 'notify_on_store_visit', 'INTEGER NOT NULL DEFAULT 1');
ensureColumn('stores', 'service_config', "TEXT NOT NULL DEFAULT '{}'");

ensureColumn('products', 'carton_price', 'REAL NOT NULL DEFAULT 0');
ensureColumn('products', 'carton_units', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('products', 'deleted_at', 'TEXT');
ensureColumn('products', 'sizes_json', "TEXT NOT NULL DEFAULT '[]'");
ensureColumn('products', 'colors_json', "TEXT NOT NULL DEFAULT '[]'");
ensureColumn('products', 'phone_models_json', "TEXT NOT NULL DEFAULT '[]'");
ensureColumn('products', 'game_name', "TEXT NOT NULL DEFAULT ''");
ensureColumn('products', 'custom_options_json', "TEXT NOT NULL DEFAULT '[]'");

ensureColumn('cart_items', 'option_signature', "TEXT NOT NULL DEFAULT ''");
ensureColumn('cart_items', 'item_options_json', "TEXT NOT NULL DEFAULT '{}'");

ensureColumn('orders', 'fulfillment_method', "TEXT NOT NULL DEFAULT 'delivery'");
ensureColumn('orders', 'governorate', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'city', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'district', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'neighborhood', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'latitude', 'REAL');
ensureColumn('orders', 'longitude', 'REAL');
ensureColumn('orders', 'cancel_reason', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'cancelled_by_id', 'TEXT');
ensureColumn('orders', 'cancelled_by_name', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'cancelled_by_role', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'cancelled_at', "TEXT NOT NULL DEFAULT ''");
ensureColumn('orders', 'stock_restored', 'INTEGER NOT NULL DEFAULT 0');

ensureColumn('order_items', 'pricing_type', "TEXT NOT NULL DEFAULT 'unit'");
ensureColumn('order_items', 'item_options_json', "TEXT NOT NULL DEFAULT '{}'");

ensureColumn('complaints', 'image_url', "TEXT NOT NULL DEFAULT ''");

// Safely upgrade CHECK constraints on users, stores, cart_items, orders, and complaints without losing any rows
function upgradeTableChecksSafely(): void {
  const usersMeta = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'users'")
    .get() as { sql: string } | undefined;

  if (usersMeta && !usersMeta.sql.includes("'courier'")) {
    db.pragma('foreign_keys = OFF');
    const migrateUsers = db.transaction(() => {
      db.exec(`
        CREATE TABLE users_v2 (
          id TEXT PRIMARY KEY,
          full_name TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          phone TEXT NOT NULL,
          city TEXT NOT NULL DEFAULT '',
          governorate TEXT NOT NULL DEFAULT '',
          district TEXT NOT NULL DEFAULT '',
          neighborhood TEXT NOT NULL DEFAULT '',
          address TEXT NOT NULL DEFAULT '',
          latitude REAL,
          longitude REAL,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL CHECK (role IN ('customer', 'merchant', 'courier', 'super_admin')),
          is_active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL
        );
        INSERT INTO users_v2
          (id, full_name, email, phone, city, governorate, district, neighborhood, address, latitude, longitude, password_hash, role, is_active, created_at)
        SELECT
          id, full_name, email, phone, city, governorate, district, neighborhood, address, latitude, longitude, password_hash, role, is_active, created_at
        FROM users;
        DROP TABLE users;
        ALTER TABLE users_v2 RENAME TO users;
      `);
    });
    migrateUsers();
    db.pragma('foreign_keys = ON');
  }

  const storesMeta = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'stores'")
    .get() as { sql: string } | undefined;

  if (
    storesMeta &&
    (!storesMeta.sql.includes("'rejected'") ||
      !storesMeta.sql.includes("'construction'") ||
      !storesMeta.sql.includes("'gaming_topup'") ||
      !storesMeta.sql.includes("'produce'"))
  ) {
    db.pragma('foreign_keys = OFF');
    const migrateStores = db.transaction(() => {
      db.exec(`
        CREATE TABLE stores_v4 (
          id TEXT PRIMARY KEY,
          owner_id TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          store_type TEXT NOT NULL CHECK (store_type IN ('grocery', 'supermarket', 'food_market', 'produce', 'mall', 'shop', 'construction', 'clothing', 'phone_accessories', 'printing', 'gaming_topup')),
          description TEXT NOT NULL DEFAULT '',
          city TEXT NOT NULL,
          district TEXT NOT NULL DEFAULT '',
          address TEXT NOT NULL,
          latitude REAL,
          longitude REAL,
          phone TEXT NOT NULL,
          opening_hours TEXT NOT NULL DEFAULT 'يومياً 8:00 ص - 11:00 م',
          delivery_fee REAL NOT NULL DEFAULT 0,
          min_order_amount REAL NOT NULL DEFAULT 0,
          logo_url TEXT NOT NULL DEFAULT '',
          cover_url TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'rejected', 'suspended')),
          rejection_reason TEXT NOT NULL DEFAULT '',
          is_verified INTEGER NOT NULL DEFAULT 0,
          notify_on_store_visit INTEGER NOT NULL DEFAULT 1,
          service_config TEXT NOT NULL DEFAULT '{}',
          created_at TEXT NOT NULL,
          FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
        );
        INSERT INTO stores_v4
          (id, owner_id, name, store_type, description, city, district, address, latitude, longitude, phone, opening_hours, delivery_fee, min_order_amount, logo_url, cover_url, status, rejection_reason, is_verified, notify_on_store_visit, service_config, created_at)
        SELECT
          id, owner_id, name, store_type, description, city, district, address, latitude, longitude, phone, opening_hours, delivery_fee, min_order_amount, logo_url, cover_url, status, rejection_reason, is_verified, notify_on_store_visit, service_config, created_at
        FROM stores;
        DROP TABLE stores;
        ALTER TABLE stores_v4 RENAME TO stores;
      `);
    });
    migrateStores();
    db.pragma('foreign_keys = ON');
  }

  const cartMeta = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'cart_items'")
    .get() as { sql: string } | undefined;

  if (cartMeta && !cartMeta.sql.includes('UNIQUE(user_id, product_id, pricing_type, option_signature)')) {
    db.pragma('foreign_keys = OFF');
    const migrateCart = db.transaction(() => {
      db.exec(`
        CREATE TABLE cart_items_v2 (
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          store_id TEXT NOT NULL,
          product_id TEXT NOT NULL,
          pricing_type TEXT NOT NULL DEFAULT 'unit' CHECK (pricing_type IN ('unit', 'carton')),
          option_signature TEXT NOT NULL DEFAULT '',
          item_options_json TEXT NOT NULL DEFAULT '{}',
          quantity INTEGER NOT NULL CHECK (quantity > 0),
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(user_id, product_id, pricing_type, option_signature),
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE,
          FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        INSERT INTO cart_items_v2
          (id, user_id, store_id, product_id, pricing_type, option_signature, item_options_json, quantity, created_at, updated_at)
        SELECT
          id, user_id, store_id, product_id, pricing_type, option_signature, item_options_json, quantity, created_at, updated_at
        FROM cart_items;
        DROP TABLE cart_items;
        ALTER TABLE cart_items_v2 RENAME TO cart_items;
      `);
    });
    migrateCart();
    db.pragma('foreign_keys = ON');
  }

  const ordersMeta = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'orders'")
    .get() as { sql: string } | undefined;

  if (ordersMeta && (!ordersMeta.sql.includes("'rejected'") || !ordersMeta.sql.includes("'ready'"))) {
    db.pragma('foreign_keys = OFF');
    const migrateOrders = db.transaction(() => {
      db.exec(`
        CREATE TABLE orders_v3 (
          id TEXT PRIMARY KEY,
          order_number TEXT NOT NULL UNIQUE,
          customer_id TEXT NOT NULL,
          store_id TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'ready', 'out_for_delivery', 'delivered', 'rejected', 'cancelled')),
          payment_method TEXT NOT NULL DEFAULT 'cash_on_delivery' CHECK (payment_method = 'cash_on_delivery'),
          fulfillment_method TEXT NOT NULL DEFAULT 'delivery' CHECK (fulfillment_method IN ('delivery', 'pickup')),
          subtotal REAL NOT NULL,
          delivery_fee REAL NOT NULL DEFAULT 0,
          total_amount REAL NOT NULL,
          governorate TEXT NOT NULL DEFAULT '',
          city TEXT NOT NULL DEFAULT '',
          district TEXT NOT NULL DEFAULT '',
          neighborhood TEXT NOT NULL DEFAULT '',
          delivery_address TEXT NOT NULL,
          latitude REAL,
          longitude REAL,
          customer_name TEXT NOT NULL,
          customer_phone TEXT NOT NULL,
          notes TEXT NOT NULL DEFAULT '',
          cancel_reason TEXT NOT NULL DEFAULT '',
          cancelled_by_id TEXT,
          cancelled_by_name TEXT NOT NULL DEFAULT '',
          cancelled_by_role TEXT NOT NULL DEFAULT '',
          cancelled_at TEXT NOT NULL DEFAULT '',
          stock_restored INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (store_id) REFERENCES stores(id) ON DELETE CASCADE
        );
        INSERT INTO orders_v3
          (id, order_number, customer_id, store_id, status, payment_method, fulfillment_method, subtotal, delivery_fee, total_amount, governorate, city, district, neighborhood, delivery_address, latitude, longitude, customer_name, customer_phone, notes, cancel_reason, cancelled_by_id, cancelled_by_name, cancelled_by_role, cancelled_at, stock_restored, created_at, updated_at)
        SELECT
          id, order_number, customer_id, store_id, status, payment_method, fulfillment_method, subtotal, delivery_fee, total_amount, governorate, city, district, neighborhood, delivery_address, latitude, longitude, customer_name, customer_phone, notes, cancel_reason, cancelled_by_id, cancelled_by_name, cancelled_by_role, cancelled_at, stock_restored, created_at, updated_at
        FROM orders;
        DROP TABLE orders;
        ALTER TABLE orders_v3 RENAME TO orders;
      `);
    });
    migrateOrders();
    db.pragma('foreign_keys = ON');
  }

  const complaintsMeta = db
    .prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'complaints'")
    .get() as { sql: string } | undefined;

  if (
    complaintsMeta &&
    (!complaintsMeta.sql.includes("'technical_support'") || !complaintsMeta.sql.includes("'replied'"))
  ) {
    db.pragma('foreign_keys = OFF');
    const migrateComplaints = db.transaction(() => {
      db.exec(`
        CREATE TABLE complaints_v2 (
          id TEXT PRIMARY KEY,
          reporter_id TEXT NOT NULL,
          reporter_role TEXT NOT NULL DEFAULT 'customer',
          target_type TEXT NOT NULL CHECK (target_type IN ('store', 'courier', 'order', 'user', 'technical_support', 'subscription', 'general')),
          target_id TEXT NOT NULL,
          target_name TEXT NOT NULL DEFAULT '',
          order_id TEXT,
          delivery_id TEXT,
          category TEXT NOT NULL,
          description TEXT NOT NULL,
          image_url TEXT NOT NULL DEFAULT '',
          status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'under_review', 'replied', 'resolved', 'dismissed', 'closed')),
          violation_recorded INTEGER NOT NULL DEFAULT 0,
          admin_notes TEXT NOT NULL DEFAULT '',
          resolved_by_id TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
          FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE SET NULL,
          FOREIGN KEY (resolved_by_id) REFERENCES users(id) ON DELETE SET NULL
        );
        INSERT INTO complaints_v2
          (id, reporter_id, reporter_role, target_type, target_id, target_name, order_id, delivery_id, category, description, image_url, status, violation_recorded, admin_notes, resolved_by_id, created_at, updated_at)
        SELECT
          id, reporter_id, reporter_role, target_type, target_id, target_name, order_id, delivery_id, category, description, COALESCE(image_url, ''), status, violation_recorded, admin_notes, resolved_by_id, created_at, updated_at
        FROM complaints;
        DROP TABLE complaints;
        ALTER TABLE complaints_v2 RENAME TO complaints;
      `);
    });
    migrateComplaints();
    db.pragma('foreign_keys = ON');
  }
}

upgradeTableChecksSafely();

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
  CREATE INDEX IF NOT EXISTS idx_stores_status_type ON stores(status, store_type);
  CREATE INDEX IF NOT EXISTS idx_products_store ON products(store_id, is_available);
  CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items(user_id);
  CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_orders_store ON orders(store_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_order_events_order ON order_events(order_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read, created_at);
  CREATE INDEX IF NOT EXISTS idx_push_subs_user ON push_subscriptions(user_id, is_active);
  CREATE INDEX IF NOT EXISTS idx_store_visits_lookup ON store_visits(store_id, visitor_hash, created_at);
  CREATE INDEX IF NOT EXISTS idx_couriers_status_avail ON couriers(verification_status, is_available);
  CREATE INDEX IF NOT EXISTS idx_deliveries_status ON deliveries(status, courier_id);
  CREATE INDEX IF NOT EXISTS idx_deliveries_courier ON deliveries(courier_id, status);
  CREATE INDEX IF NOT EXISTS idx_delivery_events_delivery ON delivery_events(delivery_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status, created_at);
  CREATE INDEX IF NOT EXISTS idx_complaint_messages_complaint ON complaint_messages(complaint_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_user_subs_status ON user_subscriptions(subscriber_type, status, expires_at);
  CREATE INDEX IF NOT EXISTS idx_sub_logs_sub ON subscription_logs(subscription_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_sub_logs_user ON subscription_logs(user_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_admin_audit_created ON admin_audit_logs(created_at);
  CREATE INDEX IF NOT EXISTS idx_store_posts_store ON store_posts(store_id, status, created_at);
  CREATE INDEX IF NOT EXISTS idx_sub_pay_req_status ON subscription_payment_requests(status, created_at);
  CREATE INDEX IF NOT EXISTS idx_sub_pay_req_user ON subscription_payment_requests(user_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_recovery_req_status ON account_recovery_requests(status, created_at);
  CREATE INDEX IF NOT EXISTS idx_reset_tokens_user ON password_reset_tokens(user_id, expires_at);
  CREATE INDEX IF NOT EXISTS idx_reset_tokens_code ON password_reset_tokens(code_hash);
`);

const seedSetting = db.prepare(
  'INSERT OR IGNORE INTO platform_settings (key, value) VALUES (?, ?)'
);
seedSetting.run('currency', 'د.ع');
seedSetting.run('trial_days', '30');
seedSetting.run('app_name', 'سوقنا | SOUQNA');
seedSetting.run('support_phone', '07764327688');
seedSetting.run('support_telegram', '@murtadaa1996');
seedSetting.run('announcement_text', '');
seedSetting.run('require_store_approval', 'false');
seedSetting.run('require_courier_approval', 'true');
seedSetting.run('payment_zaincash_number', '07825625699');
seedSetting.run('payment_mastercard_number', '7113775733');

// Dynamic marketplace categories table managed by Super Admin
db.exec(`
  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT '',
    store_type TEXT NOT NULL DEFAULT 'all',
    sort_order INTEGER NOT NULL DEFAULT 100,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_categories_sort ON categories(sort_order, name);
`);

const categoriesSeeded = db
  .prepare("SELECT value FROM platform_settings WHERE key = 'categories_seeded_v1'")
  .get() as { value: string } | undefined;
if (!categoriesSeeded) {
  const nowCat = new Date().toISOString();
  const seedCat = db.prepare(
    `INSERT OR IGNORE INTO categories
      (id, name, description, store_type, sort_order, is_active, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 1, ?, ?)`
  );
  const initialCategories: Array<[string, string, string, string, number]> = [
    ['cat_produce', 'خضار وفواكه', 'خضروات وفواكه طازجة يومياً', 'produce', 1],
    ['cat_grocery', 'مواد غذائية', 'السلع الغذائية الأساسية والتموينية', 'food_market', 2],
    ['cat_dairy', 'ألبان ومخبوزات', 'الألبان والأجبان والمخبوزات الطازجة', 'supermarket', 3],
    ['cat_meat', 'لحوم ودواجن', 'لحوم طازجة ودواجن ومجمدات', 'food_market', 4],
    ['cat_drinks', 'مشروبات وعصائر', 'مياه، عصائر، ومشروبات متنوعة', 'supermarket', 5],
    ['cat_cleaning', 'منظفات ومنزلية', 'مستلزمات التنظيف والمنزل اليومية', 'supermarket', 6],
    ['cat_clothing_men', 'ملابس رجالية', 'أزياء وملابس رجالية متنوعة', 'clothing', 7],
    ['cat_clothing_women', 'ملابس نسائية', 'أزياء وملابس نسائية عصرية', 'clothing', 8],
    ['cat_clothing_kids', 'ملابس أطفال', 'ملابس ومستلزمات الأطفال', 'clothing', 9],
    ['cat_shoes', 'أحذية', 'أحذية رجالية ونسائية ورياضية', 'clothing', 10],
    ['cat_phone_acc', 'إكسسوارات الهواتف', 'شواحن، سماعات، كفرات، وحماية الشاشة', 'phone_accessories', 11],
    ['cat_construction', 'مواد البناء', 'الإسمنت، الطابوق، الحديد، والدهانات', 'construction', 12],
    ['cat_printing', 'طباعة مستندات', 'طباعة المستندات والبحوث والتغليف', 'printing', 13],
    ['cat_gaming', 'شحن ألعاب وبطاقات', 'شحن PUBG و Free Fire وبطاقات المنصات', 'gaming_topup', 14],
    ['cat_electronics', 'إلكترونيات ومنوعات', 'أجهزة ومنتجات متنوعة للمتاجر والمولات', 'all', 15],
  ];
  for (const [id, name, desc, storeType, order] of initialCategories) {
    seedCat.run(id, name, desc, storeType, order, nowCat, nowCat);
  }
  seedSetting.run('categories_seeded_v1', '1');
}

// Seed default editable subscription plans (1m: 5000, 2m: 10000, 3m: 12000, 6m: 20000 IQD)
const nowPlanIso = new Date().toISOString();
const seedPlan = db.prepare(
  `INSERT OR IGNORE INTO subscription_plans
    (id, code, name, duration_months, duration_days, price_iqd, is_active, sort_order, updated_at)
   VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`
);
seedPlan.run('plan_1m', '1_month', 'اشتراك شهر واحد', 1, 30, 5000, 1, nowPlanIso);
seedPlan.run('plan_2m', '2_months', 'اشتراك شهرين', 2, 60, 10000, 2, nowPlanIso);
seedPlan.run('plan_3m', '3_months', 'اشتراك 3 أشهر', 3, 90, 12000, 3, nowPlanIso);
seedPlan.run('plan_6m', '6_months', 'اشتراك 6 أشهر', 6, 180, 20000, 4, nowPlanIso);

seedSetting.run(
  'enabled_store_types',
  JSON.stringify([
    'food_market',
    'supermarket',
    'grocery',
    'produce',
    'mall',
    'shop',
    'construction',
    'clothing',
    'phone_accessories',
    'printing',
    'gaming_topup',
  ])
);

// Unified live marketplace visibility: new stores start active immediately so their published
// products appear to all customers and the store appears immediately in Super Admin dashboard.
// Super Admin retains full control to suspend, reject, verify, delete, or re-enable pre-approval in Settings.
const autoPublishMigrated = db
  .prepare("SELECT value FROM platform_settings WHERE key = 'store_auto_publish_v5'")
  .get() as { value: string } | undefined;
if (!autoPublishMigrated) {
  db.prepare(
    "INSERT INTO platform_settings (key, value) VALUES ('require_store_approval', 'false') ON CONFLICT(key) DO UPDATE SET value = 'false'"
  ).run();
  db.prepare(
    "UPDATE stores SET status = 'active' WHERE status = 'pending'"
  ).run();
  db.prepare(
    "INSERT INTO platform_settings (key, value) VALUES ('store_auto_publish_v5', '1')"
  ).run();
}

// One-time migration to Iraqi Dinar (د.ع) default per SOUQNA marketplace specification
const iqdMigrated = db
  .prepare("SELECT value FROM platform_settings WHERE key = 'iqd_currency_default_v3'")
  .get() as { value: string } | undefined;
if (!iqdMigrated) {
  db.prepare(
    "UPDATE platform_settings SET value = 'د.ع' WHERE key = 'currency' AND value = 'ر.س'"
  ).run();
  db.prepare(
    "INSERT INTO platform_settings (key, value) VALUES ('iqd_currency_default_v3', '1')"
  ).run();
}

// One-time migration to include 'produce' (خضروات وفواكه) in enabled_store_types for existing databases
const produceMigrated = db
  .prepare("SELECT value FROM platform_settings WHERE key = 'produce_store_type_v4'")
  .get() as { value: string } | undefined;
if (!produceMigrated) {
  const existingTypesRow = db
    .prepare("SELECT value FROM platform_settings WHERE key = 'enabled_store_types'")
    .get() as { value: string } | undefined;
  if (existingTypesRow) {
    try {
      const parsed = JSON.parse(existingTypesRow.value);
      if (Array.isArray(parsed) && !parsed.includes('produce')) {
        parsed.push('produce');
        db.prepare(
          "UPDATE platform_settings SET value = ? WHERE key = 'enabled_store_types'"
        ).run(JSON.stringify(parsed));
      }
    } catch {
      // ignore malformed JSON
    }
  }
  db.prepare(
    "INSERT INTO platform_settings (key, value) VALUES ('produce_store_type_v4', '1')"
  ).run();
}

export function getPlatformSetting(key: string, fallback: string): string {
  const row = db
    .prepare('SELECT value FROM platform_settings WHERE key = ?')
    .get(key) as { value: string } | undefined;
  return row ? row.value : fallback;
}

export function setPlatformSetting(key: string, value: string): void {
  db.prepare(
    'INSERT INTO platform_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
  ).run(key, value);
}
