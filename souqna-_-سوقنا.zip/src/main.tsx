import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

function isAndroidWebViewOrCapacitor(): boolean {
  try {
    if (typeof window === 'undefined') return false;
    const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform()) {
      return true;
    }
    const proto = window.location?.protocol || '';
    if (proto === 'capacitor:' || proto === 'file:') {
      return true;
    }
    const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : '';
    // Standard Android WebView user-agent marker ("; wv)")
    if (/Android/i.test(ua) && /;\s*wv\)/i.test(ua)) {
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

// Manage PWA Service Worker safely:
// - Inside Android WebView / Capacitor: never register SW, unregister any stale SW, and clear stale Workbox caches
//   so page, store, and product loading are never blocked or broken by Service Worker interception.
// - In standard web browsers (production): register /sw.js cleanly after load.
if (typeof window !== 'undefined' && typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  try {
    if (isAndroidWebViewOrCapacitor()) {
      navigator.serviceWorker
        .getRegistrations()
        .then((regs) => {
          for (const reg of regs) {
            void reg.unregister().catch(() => {});
          }
        })
        .catch(() => {});

      if ('caches' in window && typeof window.caches?.keys === 'function') {
        window.caches
          .keys()
          .then((keys) => {
            for (const key of keys) {
              if (/workbox|precache|vite-pwa|souqna/i.test(key)) {
                void window.caches.delete(key).catch(() => {});
              }
            }
          })
          .catch(() => {});
      }
    } else if (import.meta.env.PROD) {
      window.addEventListener('load', () => {
        navigator.serviceWorker
          .register('/sw.js', { scope: '/', updateViaCache: 'none' })
          .catch(() => {});
      });
    }
  } catch {
    // Ignore restricted WebView environments where serviceWorker getter throws
  }
}

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(<App />);
}
