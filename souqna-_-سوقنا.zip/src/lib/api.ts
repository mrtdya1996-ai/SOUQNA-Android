import type {
  AccountRecoveryRequest,
  AdminAccountSummary,
  AdminAuditLog,
  BootstrapStatus,
  CartItem,
  Complaint,
  ComplaintMessage,
  ComplaintStatus,
  ComplaintTargetType,
  CourierProfile,
  CourierVehicleType,
  CourierVerificationStatus,
  Delivery,
  DeliveryStatus,
  FulfillmentMethod,
  IssuedPasswordReset,
  MarketplaceCategory,
  NotificationItem,
  Order,
  OrderItemOptions,
  OrderStatus,
  PaymentMethodCode,
  PlatformOverview,
  PricingType,
  PrintBindingType,
  PrintColorMode,
  PrintPaperSize,
  PrintSides,
  Product,
  PushConfig,
  Store,
  StorePlanName,
  StorePost,
  StorePostStatus,
  StorePostType,
  StoreServiceConfig,
  StoreStatus,
  StoreSubscription,
  StoreSubscriptionStatus,
  StoreType,
  SubscriptionLog,
  SubscriptionPaymentMethodsConfig,
  SubscriptionPaymentRequest,
  SubscriptionPlan,
  SubscriptionSummaryStats,
  User,
  UserRole,
  UserSubscription,
} from '../types';

// In-memory session token (intentionally not persisted in localStorage/sessionStorage)
let authToken: string | null = null;

export function setAuthToken(token: string | null): void {
  authToken = token;
}

export function getAuthToken(): string | null {
  return authToken;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

// Optional remote API base URL for native Android APK builds (empty string = same-origin)
const API_BASE_URL = String(import.meta.env?.VITE_API_BASE_URL || '')
  .trim()
  .replace(/\/+$/, '');

export function resolveApiUrl(path: string): string {
  if (!API_BASE_URL || /^https?:\/\//i.test(path)) return path;
  return `${API_BASE_URL}${path.startsWith('/') ? path : `/${path}`}`;
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  headers.set('X-Requested-With', 'XMLHttpRequest');
  const method = (options.method || 'GET').toUpperCase();
  if (method === 'GET' && !headers.has('Cache-Control')) {
    headers.set('Cache-Control', 'no-cache');
  }
  if (authToken) {
    headers.set('Authorization', `Bearer ${authToken}`);
  }

  const controller = !options.signal && typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timeoutId = controller
    ? window.setTimeout(() => {
        try {
          controller.abort();
        } catch {
          // ignore
        }
      }, 20000)
    : null;

  let response: Response;
  try {
    response = await fetch(resolveApiUrl(path), {
      cache: 'no-store',
      ...options,
      signal: options.signal ?? controller?.signal,
      credentials: 'include',
      headers,
    });
  } catch (err) {
    if (timeoutId !== null) window.clearTimeout(timeoutId);
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new ApiError('انتهت مهلة الاتصال بالخادم. يرجى المحاولة مرة أخرى.', 408);
    }
    throw new ApiError('تعذر الاتصال بخادم سوقنا. يرجى التحقق من اتصال الإنترنت.', 0);
  } finally {
    if (timeoutId !== null) window.clearTimeout(timeoutId);
  }

  const contentType = (response.headers.get('content-type') || '').toLowerCase();
  const rawText = await response.text().catch(() => '');
  let data: Record<string, unknown> | null = null;
  if (rawText) {
    try {
      const parsed: unknown = JSON.parse(rawText);
      if (parsed && typeof parsed === 'object') {
        data = parsed as Record<string, unknown>;
      }
    } catch {
      data = null;
    }
  }

  if (!response.ok) {
    throw new ApiError(
      typeof data?.error === 'string' ? data.error : 'حدث خطأ غير متوقع في الاتصال بالخادم.',
      response.status
    );
  }

  // Prevent silent crash if Android WebView asset server / proxy returns HTTP 200 HTML instead of JSON
  if (!data || (!contentType.includes('application/json') && rawText.trim().startsWith('<'))) {
    throw new ApiError(
      'تعذر قراءة استجابة خادم سوقنا. يرجى التأكد من اتصال الإنترنت وتحديث الصفحة.',
      502
    );
  }

  return data as T;
}

export function formatPrice(amount: number, currency = 'د.ع'): string {
  const safeAmount = Number.isFinite(Number(amount)) ? Number(amount) : 0;
  const safeCurrency = currency || 'د.ع';
  try {
    const formatted = new Intl.NumberFormat('en-US', {
      minimumFractionDigits: safeAmount % 1 === 0 ? 0 : 2,
      maximumFractionDigits: 2,
    }).format(safeAmount);
    return `${formatted} ${safeCurrency}`;
  } catch {
    return `${safeAmount} ${safeCurrency}`;
  }
}

export function formatDateAr(iso: string): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  try {
    return new Intl.DateTimeFormat('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  } catch {
    return iso;
  }
}

/**
 * Compresses mobile camera/gallery image files smoothly on-device before upload
 * so large smartphone photos (5-15MB) upload fast over cellular networks.
 */
export async function compressImageFile(file: File, maxDimension = 1200): Promise<string> {
  const isImageMime = typeof file.type === 'string' && file.type.startsWith('image/');
  const isImageName = typeof file.name === 'string' && /\.(jpe?g|png|webp|gif|bmp|heic|heif)$/i.test(file.name);
  if (!isImageMime && !isImageName) {
    throw new Error('يرجى اختيار ملف صورة صالح.');
  }

  const bitmapUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('تعذر قراءة الصورة المختارة.'));
      el.src = bitmapUrl;
    });

    let { width, height } = img;
    if (width > maxDimension || height > maxDimension) {
      if (width >= height) {
        height = Math.round((height * maxDimension) / width);
        width = maxDimension;
      } else {
        width = Math.round((width * maxDimension) / height);
        height = maxDimension;
      }
    }

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('تعذر معالجة الصورة على هذا الجهاز.');
    }
    ctx.drawImage(img, 0, 0, width, height);

    const outputType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
    const dataUrl = canvas.toDataURL(outputType, 0.84);
    return dataUrl;
  } finally {
    URL.revokeObjectURL(bitmapUrl);
  }
}

export async function readDocumentAsDataUrl(file: File): Promise<string> {
  const allowed = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  if (!allowed.includes(file.type)) {
    throw new Error('يرجى اختيار ملف PDF أو صورة بصيغة JPG أو PNG أو WebP فقط.');
  }
  if (file.size > 15 * 1024 * 1024) {
    throw new Error('حجم الملف يتجاوز 15 ميجابايت. يرجى اختيار ملف أصغر.');
  }
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('تعذر قراءة الملف المختار.'));
    };
    reader.onerror = () => reject(new Error('حدث خطأ أثناء قراءة الملف.'));
    reader.readAsDataURL(file);
  });
}

export const api = {
  getBootstrapStatus: () => request<BootstrapStatus>('/api/bootstrap-status', { cache: 'no-store' }),

  bootstrapAdmin: (payload: {
    fullName: string;
    email: string;
    phone: string;
    city: string;
    password: string;
    setupCode?: string;
  }) =>
    request<{ token: string; user: User; store: Store | null }>('/api/auth/bootstrap-admin', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  register: (payload: {
    fullName: string;
    email: string;
    phone: string;
    city?: string;
    governorate?: string;
    district?: string;
    neighborhood?: string;
    address: string;
    latitude?: number | null;
    longitude?: number | null;
    password: string;
    role: 'customer' | 'merchant';
  }) =>
    request<{ token: string; user: User; store: Store | null; subscription?: UserSubscription | null }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  login: (payload: { identifier: string; password: string }) =>
    request<{
      token: string;
      user: User;
      store: Store | null;
      courier?: CourierProfile | null;
      subscription?: UserSubscription | null;
    }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  logout: () => request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),

  getSession: () =>
    request<{
      authenticated: boolean;
      user: User | null;
      store: Store | null;
      courier?: CourierProfile | null;
      subscription?: UserSubscription | null;
      authSource?: 'bearer' | 'cookie';
    }>('/api/auth/session', { cache: 'no-store' }),

  me: () =>
    request<{
      user: User;
      store: Store | null;
      courier?: CourierProfile | null;
      subscription?: UserSubscription | null;
      authSource?: 'bearer' | 'cookie';
    }>('/api/auth/me', { cache: 'no-store' }),

  requestEmailPasswordReset: (email: string) =>
    request<{ ok: boolean; deliveryMode: 'sent' | 'not_configured'; message: string }>(
      '/api/auth/forgot-password-email',
      {
        method: 'POST',
        body: JSON.stringify({ email }),
      }
    ),

  submitAccountRecovery: (payload: {
    requesterName: string;
    requesterPhone: string;
    requesterEmail?: string;
    accountType: string;
    proofDetails: string;
  }) =>
    request<{ ok: boolean; requestId: string; message: string }>('/api/auth/recovery-requests', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  completePasswordReset: (payload: { token?: string; code?: string; newPassword: string }) =>
    request<{ ok: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  claimSuperAdmin: (setupCode: string) =>
    request<{ user: User; store: Store | null; courier: CourierProfile | null }>(
      '/api/auth/claim-super-admin',
      {
        method: 'POST',
        body: JSON.stringify({ setupCode }),
      }
    ),

  updateProfile: (payload: {
    fullName: string;
    phone: string;
    city?: string;
    governorate: string;
    district: string;
    neighborhood: string;
    address: string;
    latitude: number | null;
    longitude: number | null;
  }) =>
    request<{ user: User }>('/api/auth/profile', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  uploadImage: (dataUrl: string) =>
    request<{ url: string }>('/api/uploads', {
      method: 'POST',
      body: JSON.stringify({ dataUrl }),
    }),

  uploadDocument: (dataUrl: string, fileName: string) =>
    request<{ url: string; fileName: string; fileMime: string; sizeBytes: number }>(
      '/api/uploads/document',
      {
        method: 'POST',
        body: JSON.stringify({ dataUrl, fileName }),
      }
    ),

  getStores: (params?: { search?: string; type?: string; city?: string; district?: string }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.type && params.type !== 'all') qs.set('type', params.type);
    if (params?.city && params.city !== 'all') qs.set('city', params.city);
    if (params?.district && params.district !== 'all') qs.set('district', params.district);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ stores: Store[]; cities: string[]; districts: string[] }>(`/api/stores${suffix}`);
  },

  getStoreDetail: (storeId: string) =>
    request<{ store: Store; posts: StorePost[]; products: Product[] }>(
      `/api/stores/${encodeURIComponent(storeId)}`
    ),

  getStorePosts: (storeId: string) =>
    request<{ posts: StorePost[] }>(`/api/stores/${encodeURIComponent(storeId)}/posts`),

  recordStoreVisit: (storeId: string) =>
    request<{ notified: boolean; reason?: string }>(
      `/api/stores/${encodeURIComponent(storeId)}/visit`,
      { method: 'POST' }
    ),

  getProducts: (params?: {
    search?: string;
    category?: string;
    storeType?: string;
    city?: string;
    district?: string;
    cartonOnly?: boolean;
  }) => {
    const qs = new URLSearchParams();
    if (params?.search) qs.set('search', params.search);
    if (params?.category && params.category !== 'all') qs.set('category', params.category);
    if (params?.storeType && params.storeType !== 'all') qs.set('storeType', params.storeType);
    if (params?.city && params.city !== 'all') qs.set('city', params.city);
    if (params?.district && params.district !== 'all') qs.set('district', params.district);
    if (params?.cartonOnly) qs.set('cartonOnly', 'true');
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return request<{ products: Product[] }>(`/api/products${suffix}`);
  },

  getCategories: () => request<{ categories: MarketplaceCategory[] }>('/api/categories'),

  // Persistent DB Cart APIs
  getCart: () => request<{ items: CartItem[] }>('/api/cart'),

  addCartItem: (payload: {
    productId: string;
    pricingType: PricingType;
    quantity?: number;
    selectedOptions?: OrderItemOptions;
  }) =>
    request<{ items: CartItem[] }>('/api/cart/items', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateCartItem: (cartItemId: string, quantity: number) =>
    request<{ items: CartItem[] }>(`/api/cart/items/${encodeURIComponent(cartItemId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ quantity }),
    }),

  removeCartItem: (cartItemId: string) =>
    request<{ items: CartItem[] }>(`/api/cart/items/${encodeURIComponent(cartItemId)}`, {
      method: 'DELETE',
    }),

  clearStoreCart: (storeId: string) =>
    request<{ items: CartItem[] }>(`/api/cart/store/${encodeURIComponent(storeId)}`, {
      method: 'DELETE',
    }),

  // Merchant APIs
  createStore: (payload: {
    name: string;
    storeType: StoreType;
    description: string;
    city: string;
    district: string;
    address: string;
    latitude?: number | null;
    longitude?: number | null;
    phone: string;
    openingHours: string;
    deliveryFee: number;
    minOrderAmount: number;
    logoUrl: string;
    coverUrl: string;
    serviceConfig?: StoreServiceConfig;
  }) =>
    request<{ store: Store; user?: User; subscription?: UserSubscription | null }>(
      '/api/merchant/store',
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    ),

  updateStore: (
    payload: Partial<{
      name: string;
      storeType: StoreType;
      description: string;
      city: string;
      district: string;
      address: string;
      latitude: number | null;
      longitude: number | null;
      phone: string;
      openingHours: string;
      deliveryFee: number;
      minOrderAmount: number;
      logoUrl: string;
      coverUrl: string;
      notifyOnStoreVisit: boolean;
      serviceConfig: StoreServiceConfig;
      resubmitForReview: boolean;
    }>
  ) =>
    request<{ store: Store }>('/api/merchant/store', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getMerchantProducts: () => request<{ products: Product[] }>('/api/merchant/products'),

  createProduct: (payload: {
    name: string;
    category: string;
    description: string;
    price: number;
    unit: string;
    cartonPrice: number;
    cartonUnits: number;
    stockQty: number;
    imageUrl: string;
    isAvailable: boolean;
    availableSizes?: string[];
    availableColors?: string[];
    compatibleModels?: string[];
    gameName?: string;
    customOptions?: string[];
  }) =>
    request<{ product: Product }>('/api/merchant/products', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateProduct: (
    productId: string,
    payload: Partial<{
      name: string;
      category: string;
      description: string;
      price: number;
      unit: string;
      cartonPrice: number;
      cartonUnits: number;
      stockQty: number;
      imageUrl: string;
      isAvailable: boolean;
      availableSizes: string[];
      availableColors: string[];
      compatibleModels: string[];
      gameName: string;
      customOptions: string[];
    }>
  ) =>
    request<{ product: Product }>(`/api/merchant/products/${encodeURIComponent(productId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  deleteProduct: (productId: string) =>
    request<{ ok: boolean; restorable?: boolean }>(
      `/api/merchant/products/${encodeURIComponent(productId)}`,
      {
        method: 'DELETE',
      }
    ),

  restoreProduct: (productId: string) =>
    request<{ product: Product }>(
      `/api/merchant/products/${encodeURIComponent(productId)}/restore`,
      {
        method: 'POST',
      }
    ),

  // Merchant Store Posts & Offers APIs
  getMerchantPosts: () => request<{ posts: StorePost[] }>('/api/merchant/posts'),

  createMerchantPost: (payload: {
    title: string;
    content: string;
    postType: StorePostType;
    offerBadge?: string;
    images: string[];
  }) =>
    request<{ post: StorePost }>('/api/merchant/posts', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateMerchantPost: (
    postId: string,
    payload: Partial<{
      title: string;
      content: string;
      postType: StorePostType;
      offerBadge: string;
      images: string[];
    }>
  ) =>
    request<{ post: StorePost }>(`/api/merchant/posts/${encodeURIComponent(postId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  deleteMerchantPost: (postId: string) =>
    request<{ ok: boolean }>(`/api/merchant/posts/${encodeURIComponent(postId)}`, {
      method: 'DELETE',
    }),

  getMerchantOrders: () => request<{ orders: Order[] }>('/api/merchant/orders'),

  updateMerchantOrderStatus: (
    orderId: string,
    status: OrderStatus,
    options?: { reason?: string; restoreStock?: boolean }
  ) =>
    request<{ order: Order }>(`/api/merchant/orders/${encodeURIComponent(orderId)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({
        status,
        reason: options?.reason,
        restoreStock: options?.restoreStock,
      }),
    }),

  requestMerchantCourier: (orderId: string) =>
    request<{ order: Order; notifiedCouriersCount: number }>(
      `/api/merchant/orders/${encodeURIComponent(orderId)}/request-courier`,
      { method: 'POST' }
    ),

  cancelMerchantDelivery: (orderId: string, reason?: string) =>
    request<{ order: Order }>(
      `/api/merchant/orders/${encodeURIComponent(orderId)}/cancel-delivery`,
      {
        method: 'POST',
        body: JSON.stringify({ reason }),
      }
    ),

  // Courier Registration & Operations APIs
  registerCourier: (payload: {
    fullName: string;
    email: string;
    phone: string;
    password: string;
    governorate: string;
    city?: string;
    district: string;
    neighborhood?: string;
    address: string;
    vehicleType: CourierVehicleType;
    plateNumber?: string;
    idType: string;
    idNumber: string;
    avatarDataUrl?: string;
    idFrontDataUrl: string;
    idBackDataUrl?: string;
    licenseDataUrl?: string;
    termsAccepted: boolean;
  }) =>
    request<{
      token: string;
      user: User;
      store: Store | null;
      courier: CourierProfile;
      subscription?: UserSubscription | null;
    }>('/api/courier/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getCourierMe: () => request<{ courier: CourierProfile }>('/api/courier/me'),

  updateCourierAvailability: (payload: {
    isAvailable: boolean;
    latitude?: number | null;
    longitude?: number | null;
  }) =>
    request<{ courier: CourierProfile }>('/api/courier/availability', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getAvailableDeliveries: () =>
    request<{ deliveries: Delivery[] }>('/api/courier/deliveries/available'),

  getMyDeliveries: () => request<{ deliveries: Delivery[] }>('/api/courier/deliveries/my'),

  acceptDelivery: (deliveryId: string) =>
    request<{ delivery: Delivery }>(
      `/api/courier/deliveries/${encodeURIComponent(deliveryId)}/accept`,
      { method: 'POST' }
    ),

  updateDeliveryStatus: (
    deliveryId: string,
    payload: { status: DeliveryStatus; deliveryOtp?: string; notes?: string }
  ) =>
    request<{ delivery: Delivery }>(
      `/api/courier/deliveries/${encodeURIComponent(deliveryId)}/status`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }
    ),

  // Complaints & Technical Support APIs
  submitComplaint: (payload: {
    targetType: ComplaintTargetType;
    targetId: string;
    targetName?: string;
    orderId?: string | null;
    deliveryId?: string | null;
    category: string;
    description: string;
    imageUrl?: string;
  }) =>
    request<{ complaint: Complaint }>('/api/complaints', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getMyComplaints: () => request<{ complaints: Complaint[] }>('/api/complaints/my'),

  replyComplaintMessage: (complaintId: string, payload: { message: string; imageUrl?: string }) =>
    request<{ complaint: Complaint; message: ComplaintMessage }>(
      `/api/complaints/${encodeURIComponent(complaintId)}/messages`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    ),

  // Merchant & Courier Subscription APIs (Customers are free)
  getSubscriptionPlans: () =>
    request<{
      plans: SubscriptionPlan[];
      paymentMethods: SubscriptionPaymentMethodsConfig;
      currency: string;
    }>('/api/subscription/plans'),

  getMySubscription: () =>
    request<{
      subscription: UserSubscription | null;
      required: boolean;
      plans: SubscriptionPlan[];
      paymentMethods: SubscriptionPaymentMethodsConfig;
      paymentRequests: SubscriptionPaymentRequest[];
      message?: string;
    }>('/api/subscription/me'),

  submitSubscriptionPaymentRequest: (payload: {
    planId: string;
    paymentMethod: PaymentMethodCode;
    transferReference: string;
    transferDetails: string;
    paymentProofDataUrl: string;
  }) =>
    request<{
      ok: boolean;
      request: SubscriptionPaymentRequest;
      subscription: UserSubscription;
      paymentRequests: SubscriptionPaymentRequest[];
      message: string;
    }>('/api/subscription/payment-requests', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  requestSubscriptionRenewal: (payload?: { note?: string }) =>
    request<{ subscription: UserSubscription; message?: string }>(
      '/api/subscription/renewal-request',
      {
        method: 'POST',
        body: JSON.stringify(payload || {}),
      }
    ),

  // Authenticated Private Courier Document Blob Loader (never uses public URLs)
  fetchPrivateDocBlob: async (filename: string): Promise<{ blobUrl: string; mime: string }> => {
    const headers = new Headers();
    headers.set('X-Requested-With', 'XMLHttpRequest');
    if (authToken) {
      headers.set('Authorization', `Bearer ${authToken}`);
    }
    const resp = await fetch(`/api/private-docs/${encodeURIComponent(filename)}`, {
      credentials: 'include',
      headers,
    });
    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      throw new ApiError(
        typeof errData?.error === 'string' ? errData.error : 'تعذر تحميل المستند الآمن.',
        resp.status
      );
    }
    const blob = await resp.blob();
    return { blobUrl: URL.createObjectURL(blob), mime: blob.type };
  },

  // Authenticated Private Payment Proof Blob Loader (Super Admin or uploading user only)
  fetchPrivatePaymentProofBlob: async (
    filename: string
  ): Promise<{ blobUrl: string; mime: string }> => {
    const headers = new Headers();
    headers.set('X-Requested-With', 'XMLHttpRequest');
    if (authToken) {
      headers.set('Authorization', `Bearer ${authToken}`);
    }
    const resp = await fetch(`/api/private-payment-proofs/${encodeURIComponent(filename)}`, {
      credentials: 'include',
      headers,
    });
    if (!resp.ok) {
      const errData = await resp.json().catch(() => ({}));
      throw new ApiError(
        typeof errData?.error === 'string' ? errData.error : 'تعذر تحميل صورة إثبات التحويل.',
        resp.status
      );
    }
    const blob = await resp.blob();
    return { blobUrl: URL.createObjectURL(blob), mime: blob.type };
  },

  // Buyer Cash Orders
  createOrder: (payload: {
    storeId: string;
    fulfillmentMethod: FulfillmentMethod;
    customerName: string;
    customerPhone: string;
    governorate: string;
    city: string;
    district: string;
    neighborhood: string;
    deliveryAddress: string;
    latitude: number | null;
    longitude: number | null;
    notes: string;
    items: Array<{
      productId: string;
      quantity: number;
      pricingType: PricingType;
      selectedOptions?: OrderItemOptions;
    }>;
    printJob?: {
      serviceType: string;
      fileUrl: string;
      fileName: string;
      fileMime: string;
      copies: number;
      pages: number;
      colorMode: PrintColorMode;
      paperSize: PrintPaperSize;
      sides: PrintSides;
      binding: PrintBindingType;
      notes?: string;
    };
  }) =>
    request<{ order: Order }>('/api/orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getMyOrders: () => request<{ orders: Order[] }>('/api/orders/my'),

  cancelMyOrder: (orderId: string, reason: string) =>
    request<{
      ok: boolean;
      mode: 'cancelled' | 'request_sent';
      message: string;
      order: Order;
    }>(`/api/orders/${encodeURIComponent(orderId)}/cancel`, {
      method: 'PATCH',
      body: JSON.stringify({ reason }),
    }),

  // Notifications & Real Push APIs
  getNotifications: () =>
    request<{ notifications: NotificationItem[]; unreadCount: number }>('/api/notifications'),

  markNotificationRead: (notificationId: string) =>
    request<{ notifications: NotificationItem[]; unreadCount: number }>(
      `/api/notifications/${encodeURIComponent(notificationId)}/read`,
      { method: 'PATCH' }
    ),

  markAllNotificationsRead: () =>
    request<{ notifications: NotificationItem[]; unreadCount: number }>(
      '/api/notifications/read-all',
      { method: 'POST' }
    ),

  deleteNotification: (notificationId: string) =>
    request<{ notifications: NotificationItem[]; unreadCount: number }>(
      `/api/notifications/${encodeURIComponent(notificationId)}`,
      { method: 'DELETE' }
    ),

  clearReadNotifications: () =>
    request<{ notifications: NotificationItem[]; unreadCount: number }>(
      '/api/notifications/read',
      { method: 'DELETE' }
    ),

  getPushConfig: () => request<PushConfig>('/api/push/config'),

  subscribeWebPush: (payload: {
    endpoint: string;
    keys: { p256dh: string; auth: string };
    deviceLabel?: string;
  }) =>
    request<{ ok: boolean; activeDeviceCount: number }>('/api/push/subscribe', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  unsubscribeWebPush: (endpoint?: string) =>
    request<{ ok: boolean; activeDeviceCount: number }>('/api/push/subscribe', {
      method: 'DELETE',
      body: JSON.stringify({ endpoint }),
    }),

  registerMobilePushToken: (payload: {
    token: string;
    channel?: 'expo' | 'fcm';
    deviceLabel?: string;
  }) =>
    request<{ ok: boolean; activeDeviceCount: number }>('/api/push/register-token', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  sendTestPush: () =>
    request<{ sent: number; failed: number; totalDevices: number }>('/api/push/test', {
      method: 'POST',
    }),

  // Super Admin APIs
  getAdminOverview: () => request<{ overview: PlatformOverview }>('/api/admin/overview'),

  updateAdminSettings: (payload: {
    requireStoreApproval?: boolean;
    requireCourierApproval?: boolean;
    currency?: string;
    enabledStoreTypes?: StoreType[];
    trialDays?: number;
    appName?: string;
    supportPhone?: string;
    supportTelegram?: string;
    announcementText?: string;
  }) =>
    request<{
      currency: string;
      requireStoreApproval: boolean;
      requireCourierApproval: boolean;
      enabledStoreTypes: StoreType[];
      trialDays: number;
      appName: string;
      supportPhone: string;
      supportTelegram: string;
      announcementText: string;
    }>('/api/admin/settings', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getAdminCategories: () => request<{ categories: MarketplaceCategory[] }>('/api/admin/categories'),

  createAdminCategory: (payload: {
    name: string;
    description?: string;
    storeType?: StoreType | 'all';
    sortOrder?: number;
    isActive?: boolean;
  }) =>
    request<{ category: MarketplaceCategory }>('/api/admin/categories', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateAdminCategory: (
    categoryId: string,
    payload: Partial<{
      name: string;
      description: string;
      storeType: StoreType | 'all';
      sortOrder: number;
      isActive: boolean;
    }>
  ) =>
    request<{ category: MarketplaceCategory }>(
      `/api/admin/categories/${encodeURIComponent(categoryId)}`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }
    ),

  deleteAdminCategory: (categoryId: string) =>
    request<{ ok: boolean }>(`/api/admin/categories/${encodeURIComponent(categoryId)}`, {
      method: 'DELETE',
    }),

  getAdminAccount: () => request<{ account: AdminAccountSummary }>('/api/admin/account'),

  updateAdminAccount: (payload: {
    fullName: string;
    email: string;
    phone: string;
    governorate?: string;
    city?: string;
    address?: string;
  }) =>
    request<{ user: User }>('/api/admin/account', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  updateAdminPassword: (payload: { currentPassword: string; newPassword: string }) =>
    request<{ ok: boolean; revokedOtherSessions: number }>('/api/admin/account/password', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  revokeOtherAdminSessions: () =>
    request<{ ok: boolean; revokedCount: number }>('/api/admin/account/revoke-other-sessions', {
      method: 'POST',
    }),

  getAdminStores: () => request<{ stores: Store[] }>('/api/admin/stores'),

  updateAdminStore: (
    storeId: string,
    payload: { status?: StoreStatus; isVerified?: boolean; rejectionReason?: string }
  ) =>
    request<{ store: Store }>(`/api/admin/stores/${encodeURIComponent(storeId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  deleteAdminStore: (storeId: string) =>
    request<{ ok: boolean }>(`/api/admin/stores/${encodeURIComponent(storeId)}`, {
      method: 'DELETE',
    }),

  getAdminCouriers: () => request<{ couriers: CourierProfile[] }>('/api/admin/couriers'),

  getAdminCourierDeliveries: (courierId: string) =>
    request<{ deliveries: Delivery[] }>(
      `/api/admin/couriers/${encodeURIComponent(courierId)}/deliveries`
    ),

  updateAdminCourier: (
    courierId: string,
    payload: { verificationStatus: CourierVerificationStatus; rejectionReason?: string }
  ) =>
    request<{ courier: CourierProfile }>(`/api/admin/couriers/${encodeURIComponent(courierId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getAdminDeliveries: () => request<{ deliveries: Delivery[] }>('/api/admin/deliveries'),

  cancelAdminDelivery: (deliveryId: string, reason: string) =>
    request<{ delivery: Delivery }>(
      `/api/admin/deliveries/${encodeURIComponent(deliveryId)}/cancel`,
      {
        method: 'PATCH',
        body: JSON.stringify({ reason }),
      }
    ),

  getAdminComplaints: () => request<{ complaints: Complaint[] }>('/api/admin/complaints'),

  updateAdminComplaint: (
    complaintId: string,
    payload: {
      status?: ComplaintStatus;
      violationRecorded?: boolean;
      adminNotes?: string;
      suspendTarget?: boolean;
      replyMessage?: string;
      replyImageUrl?: string;
    }
  ) =>
    request<{ complaint: Complaint }>(`/api/admin/complaints/${encodeURIComponent(complaintId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getAdminSubscriptions: () =>
    request<{ subscriptions: StoreSubscription[] }>('/api/admin/subscriptions'),

  updateAdminSubscription: (
    storeId: string,
    payload: {
      planName: StorePlanName;
      status: StoreSubscriptionStatus;
      monthlyFee: number;
      expiresAt?: string;
      notes?: string;
    }
  ) =>
    request<{ subscription: StoreSubscription }>(
      `/api/admin/subscriptions/${encodeURIComponent(storeId)}`,
      {
        method: 'PATCH',
        body: JSON.stringify(payload),
      }
    ),

  getAdminAllSubscriptions: () =>
    request<{
      subscriptions: UserSubscription[];
      stats: SubscriptionSummaryStats;
      logs: SubscriptionLog[];
      plans: SubscriptionPlan[];
      paymentMethods: SubscriptionPaymentMethodsConfig;
      paymentRequests: SubscriptionPaymentRequest[];
    }>('/api/admin/subscriptions/all'),

  updateAdminSubscriptionPlans: (payload: {
    plans?: Array<{
      id: string;
      name?: string;
      priceIqd: number;
      durationDays?: number;
      isActive?: boolean;
    }>;
    paymentMethods?: Partial<SubscriptionPaymentMethodsConfig>;
  }) =>
    request<{
      plans: SubscriptionPlan[];
      paymentMethods: SubscriptionPaymentMethodsConfig;
    }>('/api/admin/subscriptions/plans', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  reviewAdminPaymentRequest: (
    requestId: string,
    payload: {
      decision: 'approve' | 'reject';
      rejectionReason?: string;
      adminNotes?: string;
      startsAt?: string;
      expiresAt?: string;
    }
  ) =>
    request<{
      request: SubscriptionPaymentRequest;
      subscription: UserSubscription;
      stats: SubscriptionSummaryStats;
      logs: SubscriptionLog[];
      paymentRequests: SubscriptionPaymentRequest[];
    }>(`/api/admin/subscriptions/payment-requests/${encodeURIComponent(requestId)}/review`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  notifyAdminExpiringSubscriptions: (userId?: string) =>
    request<{ ok: boolean; notifiedCount: number; message: string }>(
      '/api/admin/subscriptions/notify-expiring',
      {
        method: 'POST',
        body: JSON.stringify(userId ? { userId } : {}),
      }
    ),

  runAdminSubscriptionAction: (
    userId: string,
    payload: {
      action: 'activate' | 'extend' | 'suspend' | 'reactivate' | 'record_payment' | 'set_dates';
      durationDays?: number;
      amountPaid?: number;
      monthlyFee?: number;
      planName?: string;
      startsAt?: string;
      expiresAt?: string;
      notes?: string;
    }
  ) =>
    request<{
      subscription: UserSubscription;
      stats: SubscriptionSummaryStats;
      logs: SubscriptionLog[];
    }>(
      `/api/admin/subscriptions/user/${encodeURIComponent(userId)}/action`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    ),

  getAdminRecoveryRequests: () =>
    request<{ requests: AccountRecoveryRequest[] }>('/api/admin/recovery-requests'),

  reviewAdminRecoveryRequest: (
    requestId: string,
    payload: {
      decision: 'approve' | 'reject';
      targetUserId?: string;
      rejectionReason?: string;
      adminNotes?: string;
    }
  ) =>
    request<{
      request: AccountRecoveryRequest;
      issuedReset?: IssuedPasswordReset;
    }>(`/api/admin/recovery-requests/${encodeURIComponent(requestId)}/review`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  issueAdminPasswordReset: (userId: string, notes?: string) =>
    request<{ issuedReset: IssuedPasswordReset }>(
      `/api/admin/users/${encodeURIComponent(userId)}/issue-reset`,
      {
        method: 'POST',
        body: JSON.stringify({ notes }),
      }
    ),

  getAdminAuditLogs: () => request<{ logs: AdminAuditLog[] }>('/api/admin/audit-logs'),

  getAdminProducts: () => request<{ products: Product[] }>('/api/admin/products'),

  updateAdminProduct: (productId: string, payload: { isAvailable: boolean }) =>
    request<{ product: Product }>(`/api/admin/products/${encodeURIComponent(productId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  deleteAdminProduct: (productId: string) =>
    request<{ ok: boolean }>(`/api/admin/products/${encodeURIComponent(productId)}`, {
      method: 'DELETE',
    }),

  getAdminPosts: () => request<{ posts: StorePost[] }>('/api/admin/posts'),

  moderateAdminPost: (
    postId: string,
    payload: { status: StorePostStatus; moderationReason?: string }
  ) =>
    request<{ post: StorePost }>(`/api/admin/posts/${encodeURIComponent(postId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  deleteAdminPost: (postId: string, reason?: string) =>
    request<{ ok: boolean }>(`/api/admin/posts/${encodeURIComponent(postId)}`, {
      method: 'DELETE',
      body: JSON.stringify({ reason }),
    }),

  getAdminUsers: () => request<{ users: User[] }>('/api/admin/users'),

  updateAdminUser: (userId: string, payload: { isActive?: boolean; role?: UserRole }) =>
    request<{ user: User }>(`/api/admin/users/${encodeURIComponent(userId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  getAdminOrders: () => request<{ orders: Order[] }>('/api/admin/orders'),

  updateAdminOrderStatus: (
    orderId: string,
    status: OrderStatus,
    options?: { reason?: string; restoreStock?: boolean }
  ) =>
    request<{ order: Order }>(`/api/admin/orders/${encodeURIComponent(orderId)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({
        status,
        reason: options?.reason,
        restoreStock: options?.restoreStock,
      }),
    }),

  getAdminNotifications: () =>
    request<{ notifications: NotificationItem[] }>('/api/admin/notifications'),

  sendAdminNotification: (payload: {
    userId: string;
    title: string;
    body: string;
    orderId?: string;
    storeId?: string;
  }) =>
    request<{ notification: NotificationItem }>('/api/admin/notifications/send', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};
