import React, { useEffect, useState } from 'react';
import { Box, Gamepad2, Package, Plus, Smartphone } from 'lucide-react';
import { formatPrice } from '../lib/api';
import type { OrderItemOptions, PricingType, Product } from '../types';

interface ProductCardProps {
  product: Product;
  currency: string;
  onAdd?: (pricingType: PricingType, selectedOptions?: OrderItemOptions) => void;
  onOpenStore?: () => void;
  disableAdd?: boolean;
  disableReason?: string;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currency,
  onAdd,
  onOpenStore,
  disableAdd,
  disableReason,
}) => {
  const [imgError, setImgError] = useState(false);
  const [selectedSize, setSelectedSize] = useState<string>(product.availableSizes[0] || '');
  const [selectedColor, setSelectedColor] = useState<string>(product.availableColors[0] || '');
  const [selectedPhoneModel, setSelectedPhoneModel] = useState<string>(
    product.compatibleModels[0] || ''
  );
  const [selectedOption, setSelectedOption] = useState<string>(product.customOptions[0] || '');
  const [playerId, setPlayerId] = useState<string>('');

  useEffect(() => {
    setSelectedSize(product.availableSizes[0] || '');
    setSelectedColor(product.availableColors[0] || '');
    setSelectedPhoneModel(product.compatibleModels[0] || '');
    setSelectedOption(product.customOptions[0] || '');
  }, [
    product.id,
    product.availableSizes,
    product.availableColors,
    product.compatibleModels,
    product.customOptions,
  ]);

  const hasCarton = product.cartonPrice > 0;
  const outOfStock = product.stockQty <= 0;
  const isGamingProduct = Boolean(product.gameName || product.storeType === 'gaming_topup');
  const effectiveDisable = Boolean(disableAdd || outOfStock);
  const effectiveDisableReason = outOfStock ? 'نفدت الكمية المتوفرة حالياً' : disableReason;

  const buildCurrentOptions = (): OrderItemOptions | undefined => {
    const opts: OrderItemOptions = {};
    if (selectedSize) opts.selectedSize = selectedSize;
    if (selectedColor) opts.selectedColor = selectedColor;
    if (selectedPhoneModel) opts.selectedPhoneModel = selectedPhoneModel;
    if (selectedOption) opts.selectedOption = selectedOption;
    if (product.gameName) opts.gameName = product.gameName;
    if (isGamingProduct && playerId.trim()) opts.playerId = playerId.trim();
    return Object.keys(opts).length > 0 ? opts : undefined;
  };

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-sq-border bg-sq-surface transition-all duration-200 hover:-translate-y-0.5 hover:border-sq-gold/45 hover:shadow-lg hover:shadow-black/15">
      <div className="relative aspect-4/3 w-full overflow-hidden bg-sq-muted">
        {product.imageUrl && !imgError ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-sq-muted p-3 text-center">
            {isGamingProduct ? (
              <Gamepad2 className="mb-1.5 h-8 w-8 text-sq-gold-text/60" />
            ) : product.compatibleModels.length > 0 ? (
              <Smartphone className="mb-1.5 h-8 w-8 text-sq-gold-text/60" />
            ) : (
              <Package className="mb-1.5 h-8 w-8 text-sq-ink-muted/40" />
            )}
            <span className="text-[11px] font-medium text-sq-ink-muted/70 line-clamp-1">
              {product.gameName || product.category}
            </span>
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col p-3.5 sm:p-4">
        <div className="mb-1 flex items-center justify-between gap-1.5 text-[11px] text-sq-ink-muted">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="truncate">{product.gameName || product.category}</span>
            <span aria-hidden="true">·</span>
            <span className="shrink-0">{product.unit}</span>
          </div>
          <span
            className={`shrink-0 font-semibold tabular-nums ${
              outOfStock ? 'text-sq-danger-text' : 'text-sq-gold-text'
            }`}
          >
            {outOfStock ? 'نفدت الكمية' : `متوفر: ${product.stockQty}`}
          </span>
        </div>

        <h4 className="font-display text-sm sm:text-base font-bold text-sq-ink line-clamp-1">
          {product.name}
        </h4>

        {product.storeName && onOpenStore && (
          <button
            type="button"
            onClick={onOpenStore}
            className="mt-0.5 w-fit text-xs font-medium text-sq-gold-text hover:underline truncate max-w-full"
          >
            {product.storeName}
            {product.storeCity ? ` · ${product.storeCity}` : ''}
          </button>
        )}

        {product.description && (
          <p className="mt-1 text-xs text-sq-ink-muted line-clamp-2">{product.description}</p>
        )}

        {/* Domain-specific interactive selectors: Clothing Sizes/Colors, Phone Models, Custom Options, Gaming Player ID */}
        {(product.availableSizes.length > 0 ||
          product.availableColors.length > 0 ||
          product.compatibleModels.length > 0 ||
          product.customOptions.length > 0 ||
          isGamingProduct) && (
          <div className="mt-2.5 space-y-2 border-t border-sq-border pt-2.5">
            {product.availableSizes.length > 0 && (
              <div className="space-y-1">
                <span className="block text-[11px] font-semibold text-sq-ink-muted">المقاس:</span>
                <div className="flex flex-wrap gap-1">
                  {product.availableSizes.map((sz) => (
                    <button
                      key={sz}
                      type="button"
                      onClick={() => setSelectedSize(sz)}
                      className={`min-h-[30px] min-w-[34px] rounded-lg border px-2 text-[11px] font-bold transition ${
                        selectedSize === sz
                          ? 'border-sq-gold bg-sq-gold text-[#0B0C0C]'
                          : 'border-sq-border bg-sq-elevated text-sq-ink hover:border-sq-gold'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {product.availableColors.length > 0 && (
              <div className="space-y-1">
                <span className="block text-[11px] font-semibold text-sq-ink-muted">اللون:</span>
                <div className="flex flex-wrap gap-1">
                  {product.availableColors.map((cl) => (
                    <button
                      key={cl}
                      type="button"
                      onClick={() => setSelectedColor(cl)}
                      className={`min-h-[30px] rounded-lg border px-2 text-[11px] font-semibold transition ${
                        selectedColor === cl
                          ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                          : 'border-sq-border bg-sq-surface text-sq-ink-muted hover:border-sq-gold'
                      }`}
                    >
                      {cl}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {product.compatibleModels.length > 0 && (
              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-sq-ink-muted">
                  موديل الهاتف المناسب:
                </label>
                <select
                  value={selectedPhoneModel}
                  onChange={(e) => setSelectedPhoneModel(e.target.value)}
                  className="h-9 w-full rounded-lg border border-sq-border bg-sq-elevated px-2 text-xs font-medium text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                >
                  {product.compatibleModels.map((model) => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {product.customOptions.length > 0 && (
              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-sq-ink-muted">الخيار:</label>
                <select
                  value={selectedOption}
                  onChange={(e) => setSelectedOption(e.target.value)}
                  className="h-9 w-full rounded-lg border border-sq-border bg-sq-elevated px-2 text-xs font-medium text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                >
                  {product.customOptions.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {isGamingProduct && onAdd && (
              <div className="space-y-1">
                <label className="block text-[11px] font-semibold text-sq-gold-text">
                  معرّف اللاعب (Player ID):
                </label>
                <input
                  type="text"
                  value={playerId}
                  onChange={(e) => setPlayerId(e.target.value)}
                  placeholder="أدخل ID اللاعب للشحن"
                  dir="ltr"
                  className="h-9 w-full rounded-lg border border-sq-border bg-sq-elevated px-2.5 text-xs font-mono text-right text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            )}
          </div>
        )}

        {/* Pricing Breakdown: Single Unit + Carton Price */}
        <div className="mt-auto pt-3 space-y-2 border-t border-sq-border">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-[11px] text-sq-ink-muted">سعر {product.unit}</span>
            <span className="font-mono text-sm sm:text-base font-bold text-sq-ink tabular-nums">
              {formatPrice(product.price, currency)}
            </span>
          </div>

          {hasCarton && (
            <div className="flex items-baseline justify-between gap-2 rounded-lg bg-sq-muted px-2.5 py-1.5">
              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-sq-gold-text">
                <Box className="h-3.5 w-3.5 shrink-0" />
                <span>
                  كارتون{product.cartonUnits > 0 ? ` (${product.cartonUnits})` : ''}
                </span>
              </span>
              <span className="font-mono text-xs sm:text-sm font-bold text-sq-gold-text tabular-nums">
                {formatPrice(product.cartonPrice, currency)}
              </span>
            </div>
          )}

          {onAdd && (
            <div className={`grid gap-1.5 pt-1 ${hasCarton ? 'grid-cols-2' : 'grid-cols-1'}`}>
              <button
                type="button"
                disabled={effectiveDisable}
                title={effectiveDisableReason}
                onClick={() => onAdd('unit', buildCurrentOptions())}
                className="inline-flex min-h-[42px] items-center justify-center gap-1 rounded-xl btn-gold px-2.5 py-2 text-xs font-semibold transition-colors active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-sq-muted disabled:text-sq-ink-muted whitespace-nowrap"
              >
                <Plus className="h-3.5 w-3.5 shrink-0" />
                <span>{outOfStock ? 'غير متوفر' : isGamingProduct ? 'أضف الباقة' : `أضف ${product.unit}`}</span>
              </button>

              {hasCarton && (
                <button
                  type="button"
                  disabled={effectiveDisable}
                  title={effectiveDisableReason}
                  onClick={() => onAdd('carton', buildCurrentOptions())}
                  className="inline-flex min-h-[42px] items-center justify-center gap-1 rounded-xl border border-sq-gold bg-sq-surface px-2.5 py-2 text-xs font-semibold text-sq-gold-text transition-colors hover:bg-sq-gold-soft active:scale-[0.98] disabled:cursor-not-allowed disabled:border-sq-border disabled:text-sq-ink-muted whitespace-nowrap"
                >
                  <Box className="h-3.5 w-3.5 shrink-0" />
                  <span>أضف كارتون</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
