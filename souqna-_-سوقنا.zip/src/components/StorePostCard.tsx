import React, { useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Edit3,
  EyeOff,
  Images,
  Megaphone,
  Sparkles,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import { formatDateAr } from '../lib/api';
import { STORE_POST_TYPE_LABELS, type StorePost } from '../types';

interface StorePostCardProps {
  post: StorePost;
  canManage?: boolean;
  onEdit?: (post: StorePost) => void;
  onDelete?: (post: StorePost) => void;
  onOpenStore?: (storeId: string) => void;
}

const POST_TYPE_ICON = {
  offer: Tag,
  announcement: Megaphone,
  new_arrival: Sparkles,
  update: Calendar,
};

export const StorePostCard: React.FC<StorePostCardProps> = ({
  post,
  canManage = false,
  onEdit,
  onDelete,
  onOpenStore,
}) => {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const TypeIcon = POST_TYPE_ICON[post.postType] || Megaphone;
  const images = post.images || [];

  const openLightbox = (idx: number) => setLightboxIndex(idx);
  const closeLightbox = () => setLightboxIndex(null);

  return (
    <>
      <article className="overflow-hidden rounded-2xl border border-sq-border bg-sq-surface shadow-xs transition-all hover:border-sq-gold/45">
        {/* Top Metadata Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-sq-border bg-sq-elevated px-4 py-3 sm:px-5">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1.5 font-extrabold text-sq-gold-text">
              <TypeIcon className="h-3.5 w-3.5" />
              <span>{STORE_POST_TYPE_LABELS[post.postType]}</span>
            </span>

            {post.offerBadge && (
              <>
                <span aria-hidden="true" className="text-sq-ink-muted">·</span>
                <span className="font-extrabold text-sq-ink">{post.offerBadge}</span>
              </>
            )}

            {post.status === 'hidden' && (
              <>
                <span aria-hidden="true" className="text-sq-ink-muted">·</span>
                <span className="inline-flex items-center gap-1 font-bold text-sq-danger-text">
                  <EyeOff className="h-3.5 w-3.5" />
                  <span>مخفي من الإدارة</span>
                </span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs text-sq-ink-muted">
            <time dateTime={post.createdAt} className="inline-flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5 text-sq-gold-text" />
              <span>{formatDateAr(post.createdAt)}</span>
            </time>
            {canManage && (
              <div className="flex items-center gap-1.5 mr-1">
                {onEdit && (
                  <button
                    type="button"
                    onClick={() => onEdit(post)}
                    aria-label="تعديل المنشور"
                    className="btn-surface inline-flex min-h-[36px] items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-bold"
                  >
                    <Edit3 className="h-3.5 w-3.5 text-sq-gold-text" />
                    <span>تعديل</span>
                  </button>
                )}
                {onDelete && (
                  <button
                    type="button"
                    onClick={() => onDelete(post)}
                    aria-label="حذف المنشور"
                    className="inline-flex min-h-[36px] items-center gap-1 rounded-lg border border-sq-danger-border bg-sq-danger-bg px-2.5 py-1 text-xs font-bold text-sq-danger-text active:scale-95"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>حذف</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Hidden moderation notice */}
        {post.status === 'hidden' && post.moderationReason && (
          <div className="flex items-start gap-2 border-b border-sq-danger-border bg-sq-danger-bg px-4 py-2.5 text-xs text-sq-danger-text sm:px-5">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              <strong>سبب إخفاء المنشور:</strong> {post.moderationReason}
            </span>
          </div>
        )}

        {/* Body Content */}
        <div className="p-4 sm:p-5 space-y-3">
          {post.storeName && onOpenStore && (
            <button
              type="button"
              onClick={() => onOpenStore(post.storeId)}
              className="text-xs font-bold text-sq-gold-text hover:underline"
            >
              {post.storeName}
              {post.storeCity ? ` · ${post.storeCity}` : ''}
              {post.storeDistrict ? ` — ${post.storeDistrict}` : ''}
            </button>
          )}

          <h3 className="font-display text-lg font-extrabold leading-snug text-sq-ink">
            {post.title}
          </h3>

          {post.content && (
            <p className="whitespace-pre-line text-sm leading-relaxed text-sq-secondary">
              {post.content}
            </p>
          )}

          {/* Multi-image Gallery */}
          {images.length > 0 && (
            <div className="pt-1">
              {images.length === 1 ? (
                <button
                  type="button"
                  onClick={() => openLightbox(0)}
                  className="group relative block w-full overflow-hidden rounded-xl border border-sq-border bg-[#0C0E0D]"
                >
                  <img
                    src={images[0]}
                    alt={post.title}
                    referrerPolicy="no-referrer"
                    className="max-h-[380px] w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                  />
                </button>
              ) : images.length === 2 ? (
                <div className="grid grid-cols-2 gap-2">
                  {images.map((img, idx) => (
                    <button
                      key={`${post.id}-img-${idx}`}
                      type="button"
                      onClick={() => openLightbox(idx)}
                      className="group relative aspect-4/3 overflow-hidden rounded-xl border border-sq-border bg-[#0C0E0D]"
                    >
                      <img
                        src={img}
                        alt={`${post.title} (${idx + 1})`}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                      />
                    </button>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {images.slice(0, 3).map((img, idx) => {
                    const remaining = images.length - 3;
                    const showMoreOverlay = idx === 2 && remaining > 0;
                    return (
                      <button
                        key={`${post.id}-img-${idx}`}
                        type="button"
                        onClick={() => openLightbox(idx)}
                        className="group relative aspect-4/3 overflow-hidden rounded-xl border border-sq-border bg-[#0C0E0D]"
                      >
                        <img
                          src={img}
                          alt={`${post.title} (${idx + 1})`}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                        />
                        {showMoreOverlay && (
                          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#090A0A]/75 text-[#E8CB73] backdrop-blur-[1px]">
                            <Images className="h-5 w-5 mb-1" />
                            <span className="font-mono text-base font-extrabold">+{remaining}</span>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
              {images.length > 1 && (
                <p className="mt-1.5 text-[11px] text-sq-ink-muted">
                  اضغط على أي صورة لعرض المعرض بالحجم الكامل ({images.length} صور)
                </p>
              )}
            </div>
          )}
        </div>
      </article>

      {/* Fullscreen Image Lightbox */}
      {lightboxIndex !== null && images[lightboxIndex] && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="عرض صور المنشور"
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#070808]/94 p-4 backdrop-blur-sm"
          onClick={closeLightbox}
        >
          <div
            className="relative flex w-full max-w-4xl flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex w-full items-center justify-between text-white">
              <span className="text-sm font-bold text-[#E8CB73] truncate pl-4">{post.title}</span>
              <div className="flex items-center gap-3 shrink-0">
                <span className="font-mono text-xs text-white/75 tabular-nums">
                  {lightboxIndex + 1} / {images.length}
                </span>
                <button
                  type="button"
                  onClick={closeLightbox}
                  aria-label="إغلاق المعرض"
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/20 bg-white/10 text-white hover:bg-white/20"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="relative flex w-full items-center justify-center overflow-hidden rounded-2xl border border-[#D4AF37]/35 bg-black">
              <img
                src={images[lightboxIndex]}
                alt={`${post.title} - صورة ${lightboxIndex + 1}`}
                referrerPolicy="no-referrer"
                className="max-h-[75vh] w-auto max-w-full object-contain"
              />

              {images.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={() =>
                      setLightboxIndex((prev) =>
                        prev === null ? 0 : (prev - 1 + images.length) % images.length
                      )
                    }
                    aria-label="الصورة السابقة"
                    className="absolute right-3 flex h-11 w-11 items-center justify-center rounded-full bg-black/70 text-[#E8CB73] hover:bg-black/90"
                  >
                    <ChevronRight className="h-6 w-6" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setLightboxIndex((prev) =>
                        prev === null ? 0 : (prev + 1) % images.length
                      )
                    }
                    aria-label="الصورة التالية"
                    className="absolute left-3 flex h-11 w-11 items-center justify-center rounded-full bg-black/70 text-[#E8CB73] hover:bg-black/90"
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
