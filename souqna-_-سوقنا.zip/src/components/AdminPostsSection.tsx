import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  ExternalLink,
  Eye,
  EyeOff,
  Images,
  Loader2,
  Megaphone,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { formatDateAr } from '../lib/api';
import {
  STORE_POST_TYPE_LABELS,
  STORE_TYPE_LABELS,
  type StorePost,
  type StorePostStatus,
} from '../types';

interface AdminPostsSectionProps {
  posts: StorePost[];
  onModeratePost: (postId: string, status: StorePostStatus, reason?: string) => Promise<void>;
  onDeletePost: (postId: string, reason?: string) => Promise<void>;
  onOpenStore: (storeId: string) => void;
}

export const AdminPostsSection: React.FC<AdminPostsSectionProps> = ({
  posts,
  onModeratePost,
  onDeletePost,
  onOpenStore,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | StorePostStatus>('all');
  const [hideModalPost, setHideModalPost] = useState<StorePost | null>(null);
  const [hideReason, setHideReason] = useState('');
  const [deleteModalPost, setDeleteModalPost] = useState<StorePost | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  const filteredPosts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return posts.filter((p) => {
      if (statusFilter !== 'all' && p.status !== statusFilter) return false;
      if (!q) return true;
      return (
        p.title.toLowerCase().includes(q) ||
        p.content.toLowerCase().includes(q) ||
        (p.storeName || '').toLowerCase().includes(q) ||
        (p.storeCity || '').toLowerCase().includes(q) ||
        (p.storeDistrict || '').toLowerCase().includes(q) ||
        (p.authorName || '').toLowerCase().includes(q)
      );
    });
  }, [posts, search, statusFilter]);

  const activeCount = posts.filter((p) => p.status === 'active').length;
  const hiddenCount = posts.filter((p) => p.status === 'hidden').length;

  const confirmHide = async () => {
    if (!hideModalPost) return;
    setBusyId(hideModalPost.id);
    try {
      await onModeratePost(
        hideModalPost.id,
        'hidden',
        hideReason.trim() || 'مخالفة شروط النشر في سوقنا'
      );
      setHideModalPost(null);
      setHideReason('');
    } finally {
      setBusyId(null);
    }
  };

  const handleRestore = async (post: StorePost) => {
    setBusyId(post.id);
    try {
      await onModeratePost(post.id, 'active', '');
    } finally {
      setBusyId(null);
    }
  };

  const confirmDelete = async () => {
    if (!deleteModalPost) return;
    setBusyId(deleteModalPost.id);
    try {
      await onDeletePost(deleteModalPost.id, deleteReason.trim());
      setDeleteModalPost(null);
      setDeleteReason('');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header & Search */}
      <div className="rounded-2xl border border-sq-border bg-sq-surface p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-lg font-extrabold text-sq-ink">
              مراقبة وإدارة منشورات المتاجر ({posts.length})
            </h2>
            <p className="mt-0.5 text-xs text-sq-ink-muted">
              مراجعة الإعلانات والعروض المنشورة من قبل أصحاب المتاجر وإخفاء أو حذف أي محتوى مخالف مع إشعار فوري لصاحب المتجر.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 text-xs font-bold">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`min-h-[38px] rounded-xl px-3 py-1.5 border ${
                statusFilter === 'all'
                  ? 'border-[#121413] bg-[#121413] text-[#E5C77A]'
                  : 'border-sq-border bg-sq-elevated text-sq-ink'
              }`}
            >
              الكل ({posts.length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('active')}
              className={`min-h-[38px] rounded-xl px-3 py-1.5 border ${
                statusFilter === 'active'
                  ? 'border-sq-gold bg-sq-gold text-[#0B0C0C]'
                  : 'border-sq-border bg-sq-elevated text-sq-ink'
              }`}
            >
              ظاهر ({activeCount})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('hidden')}
              className={`min-h-[38px] rounded-xl px-3 py-1.5 border ${
                statusFilter === 'hidden'
                  ? 'border-[#B42318] bg-[#B42318] text-white'
                  : 'border-sq-border bg-sq-elevated text-sq-ink'
              }`}
            >
              مخفي ({hiddenCount})
            </button>
          </div>
        </div>

        <label className="relative block">
          <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بعنوان المنشور، نص العرض، اسم المتجر أو المنطقة..."
            className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated pr-10 pl-3 text-sm outline-none focus:border-sq-gold focus:bg-sq-surface"
          />
        </label>
      </div>

      {/* Posts List */}
      {filteredPosts.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-sq-border bg-sq-surface p-10 text-center">
          <Megaphone className="mx-auto h-10 w-10 text-[#9CA3AF]" />
          <p className="mt-3 font-display text-base font-bold text-sq-ink">
            لا توجد منشورات متاجر مطابقة حالياً
          </p>
          <p className="mt-1 text-xs text-sq-ink-muted">
            عندما ينشر أصحاب المتاجر عروضاً وإعلانات جديدة ستظهر هنا للمراجعة والإشراف.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredPosts.map((post) => {
            const isBusy = busyId === post.id;
            return (
              <div
                key={post.id}
                className="rounded-2xl border border-sq-border bg-sq-surface p-4 sm:p-5 space-y-3"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-lg bg-[#121413] px-2.5 py-0.5 text-[11px] font-bold text-[#E5C77A]">
                        {STORE_POST_TYPE_LABELS[post.postType]}
                      </span>
                      {post.offerBadge && (
                        <span className="rounded-lg bg-sq-gold-soft px-2.5 py-0.5 text-[11px] font-bold text-[#8A6518]">
                          {post.offerBadge}
                        </span>
                      )}
                      <span
                        className={`rounded-lg px-2.5 py-0.5 text-[11px] font-bold ${
                          post.status === 'active'
                            ? 'bg-sq-gold-soft text-sq-gold-text'
                            : 'bg-sq-danger-bg text-sq-danger-text'
                        }`}
                      >
                        {post.status === 'active' ? 'ظاهر للزبائن' : 'مخفي'}
                      </span>
                      {post.storeType && (
                        <span className="text-[11px] text-sq-ink-muted">
                          {STORE_TYPE_LABELS[post.storeType]}
                        </span>
                      )}
                    </div>

                    <h3 className="font-display text-base font-extrabold text-sq-ink">
                      {post.title}
                    </h3>

                    <p className="text-xs text-sq-ink-muted">
                      المتجر:{' '}
                      <button
                        type="button"
                        onClick={() => onOpenStore(post.storeId)}
                        className="font-bold text-sq-gold-text hover:underline"
                      >
                        {post.storeName || 'متجر'}
                      </button>
                      {post.storeCity ? ` · ${post.storeCity}` : ''}
                      {post.storeDistrict ? ` — ${post.storeDistrict}` : ''}
                      {post.authorName ? ` · بواسطة: ${post.authorName}` : ''}
                      {' · '}
                      <span>{formatDateAr(post.createdAt)}</span>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenStore(post.storeId)}
                      className="inline-flex min-h-[38px] items-center gap-1 rounded-xl border border-sq-border bg-sq-elevated px-3 py-1.5 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      <span>صفحة المتجر</span>
                    </button>

                    {post.status === 'active' ? (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => {
                          setHideModalPost(post);
                          setHideReason('');
                        }}
                        className="inline-flex min-h-[38px] items-center gap-1 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3 py-1.5 text-xs font-bold text-sq-warning-text hover:bg-sq-warning-bg disabled:opacity-50"
                      >
                        <EyeOff className="h-3.5 w-3.5" />
                        <span>إخفاء المنشور</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => handleRestore(post)}
                        className="inline-flex min-h-[38px] items-center gap-1 rounded-xl btn-gold px-3 py-1.5 text-xs font-bold disabled:opacity-50"
                      >
                        {isBusy ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <Eye className="h-3.5 w-3.5" />
                        )}
                        <span>إعادة إظهار</span>
                      </button>
                    )}

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => {
                        setDeleteModalPost(post);
                        setDeleteReason('');
                      }}
                      className="inline-flex min-h-[38px] items-center gap-1 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3 py-1.5 text-xs font-bold text-sq-danger-text hover:bg-sq-danger-bg disabled:opacity-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>حذف</span>
                    </button>
                  </div>
                </div>

                {post.content && (
                  <p className="text-sm leading-relaxed text-sq-secondary whitespace-pre-line">
                    {post.content}
                  </p>
                )}

                {post.moderationReason && post.status === 'hidden' && (
                  <p className="rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3 py-2 text-xs text-sq-danger-text">
                    <strong>سبب الإخفاء:</strong> {post.moderationReason}
                  </p>
                )}

                {post.images.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {post.images.map((img, idx) => (
                      <img
                        key={`${post.id}-thumb-${idx}`}
                        src={img}
                        alt={`${post.title} ${idx + 1}`}
                        className="h-20 w-24 rounded-xl border border-sq-border object-cover"
                      />
                    ))}
                    <span className="inline-flex items-center gap-1 text-[11px] text-sq-ink-muted">
                      <Images className="h-3.5 w-3.5" />
                      <span>{post.images.length} صور</span>
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Hide Post Modal */}
      {hideModalPost && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
        >
          <div className="w-full max-w-md rounded-2xl bg-sq-surface p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-extrabold text-sq-ink">
                إخفاء منشور مخالف
              </h3>
              <button
                type="button"
                onClick={() => setHideModalPost(null)}
                className="flex h-9 w-9 items-center justify-center rounded-xl hover:bg-sq-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="text-xs text-sq-ink-muted">
              سيتم إخفاء المنشور <strong>«{hideModalPost.title}»</strong> من صفحة المتجر والدليل، مع إرسال إشعار بالسبب إلى صاحب المتجر.
            </p>
            <textarea
              rows={3}
              value={hideReason}
              onChange={(e) => setHideReason(e.target.value)}
              placeholder="اكتب سبب الإخفاء (مثال: محتوى غير مطابق أو صور مخالفة)..."
              className="w-full rounded-xl border border-sq-border p-3 text-sm outline-none focus:border-sq-gold"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setHideModalPost(null)}
                className="min-h-[42px] rounded-xl border border-sq-border px-4 text-xs font-bold text-sq-ink"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={busyId === hideModalPost.id}
                onClick={confirmHide}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-[#B54708] px-4 text-xs font-bold text-white hover:bg-[#93370D] disabled:opacity-50"
              >
                {busyId === hideModalPost.id ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" />
                )}
                <span>تأكيد الإخفاء</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Post Modal */}
      {deleteModalPost && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
        >
          <div className="w-full max-w-md rounded-2xl bg-sq-surface p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-extrabold text-sq-danger-text">
                حذف المنشور نهائياً
              </h3>
              <button
                type="button"
                onClick={() => setDeleteModalPost(null)}
                className="flex h-9 w-9 items-center justify-center rounded-xl hover:bg-sq-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="text-xs text-sq-ink-muted">
              هل أنت متأكد من الحذف النهائي للمنشور <strong>«{deleteModalPost.title}»</strong>؟ سيتم إشعار صاحب المتجر تلقائياً.
            </p>
            <input
              type="text"
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              placeholder="سبب الحذف (اختياري)..."
              className="min-h-[44px] w-full rounded-xl border border-sq-border px-3 text-sm outline-none focus:border-sq-danger-border"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteModalPost(null)}
                className="min-h-[42px] rounded-xl border border-sq-border px-4 text-xs font-bold text-sq-ink"
              >
                تراجع
              </button>
              <button
                type="button"
                disabled={busyId === deleteModalPost.id}
                onClick={confirmDelete}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-[#B42318] px-4 text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-50"
              >
                {busyId === deleteModalPost.id ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Trash2 className="h-4 w-4" />
                )}
                <span>حذف نهائي</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
