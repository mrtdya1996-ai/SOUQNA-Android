import React, { useMemo, useState } from 'react';
import {
  Bike,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  History,
  Loader2,
  MapPin,
  Phone,
  Search,
  Send,
  ShieldAlert,
  XCircle,
} from 'lucide-react';
import { SecureDocPreview } from './SecureDocPreview';
import { api, formatDateAr, formatPrice } from '../lib/api';
import {
  COURIER_STATUS_LABELS,
  COURIER_VEHICLE_LABELS,
  DELIVERY_STATUS_LABELS,
  type CourierProfile,
  type CourierVerificationStatus,
  type Delivery,
} from '../types';

interface AdminCouriersSectionProps {
  couriers: CourierProfile[];
  currency: string;
  onUpdateCourier: (
    courierId: string,
    payload: { verificationStatus: CourierVerificationStatus; rejectionReason?: string }
  ) => Promise<void>;
  onSendAlert: (params: { userId: string; recipientLabel: string; defaultTitle?: string }) => void;
}

export const AdminCouriersSection: React.FC<AdminCouriersSectionProps> = ({
  couriers,
  currency,
  onUpdateCourier,
  onSendAlert,
}) => {
  const [statusFilter, setStatusFilter] = useState<CourierVerificationStatus | 'all'>('all');
  const [search, setSearch] = useState('');
  const [reasonTarget, setReasonTarget] = useState<{
    id: string;
    nextStatus: 'rejected' | 'suspended';
  } | null>(null);
  const [reasonText, setReasonText] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  // Per-courier delivery history state
  const [expandedHistoryId, setExpandedHistoryId] = useState<string | null>(null);
  const [historyCache, setHistoryCache] = useState<Record<string, Delivery[]>>({});
  const [loadingHistoryId, setLoadingHistoryId] = useState<string | null>(null);

  const filteredCouriers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return couriers.filter((c) => {
      if (statusFilter !== 'all' && c.verificationStatus !== statusFilter) return false;
      if (!q) return true;
      return (
        c.fullName.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        c.governorate.toLowerCase().includes(q) ||
        c.idNumber.toLowerCase().includes(q) ||
        c.plateNumber.toLowerCase().includes(q)
      );
    });
  }, [couriers, statusFilter, search]);

  const handleToggleHistory = async (courierId: string) => {
    if (expandedHistoryId === courierId) {
      setExpandedHistoryId(null);
      return;
    }
    setExpandedHistoryId(courierId);
    setLoadingHistoryId(courierId);
    try {
      const res = await api.getAdminCourierDeliveries(courierId);
      setHistoryCache((prev) => ({ ...prev, [courierId]: res.deliveries }));
    } catch {
      setHistoryCache((prev) => ({ ...prev, [courierId]: [] }));
    } finally {
      setLoadingHistoryId(null);
    }
  };

  const handleQuickAction = async (
    courierId: string,
    payload: { verificationStatus: CourierVerificationStatus; rejectionReason?: string }
  ) => {
    setBusyId(courierId);
    try {
      await onUpdateCourier(courierId, payload);
      if (reasonTarget?.id === courierId) {
        setReasonTarget(null);
        setReasonText('');
      }
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Search + Status Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {(['all', 'pending', 'verified', 'rejected', 'suspended'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                statusFilter === st
                  ? 'bg-sq-gold text-[#0B0C0C]'
                  : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              {st === 'all'
                ? `الكل (${couriers.length})`
                : `${COURIER_STATUS_LABELS[st]} (${couriers.filter((c) => c.verificationStatus === st).length})`}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم، الهاتف، الهوية، اللوحة..."
            className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface pr-10 pl-3 text-xs focus:border-sq-gold focus:outline-none"
          />
        </div>
      </div>

      {filteredCouriers.length === 0 ? (
        <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
          لا يوجد مندوبون مطابقون لهذا التصنيف حالياً.
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredCouriers.map((courier) => {
            const isExpanded = expandedHistoryId === courier.id;
            const historyList = historyCache[courier.id] || [];
            const isBusy = busyId === courier.id;

            return (
              <div
                key={courier.id}
                className="rounded-2xl border border-sq-border bg-sq-surface p-5 space-y-4"
              >
                {/* Header & Primary Actions */}
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="flex items-start gap-3.5">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-sq-border bg-sq-muted">
                      {courier.avatarUrl ? (
                        <img
                          src={courier.avatarUrl}
                          alt={courier.fullName}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <Bike className="h-5 w-5 text-sq-gold-text" />
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span
                          className={`font-bold ${
                            courier.verificationStatus === 'verified'
                              ? 'text-sq-gold-text'
                              : courier.verificationStatus === 'pending'
                              ? 'text-sq-warning-text'
                              : 'text-sq-danger-text'
                          }`}
                        >
                          {COURIER_STATUS_LABELS[courier.verificationStatus]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="text-sq-ink-muted">
                          {COURIER_VEHICLE_LABELS[courier.vehicleType]}
                          {courier.plateNumber ? ` (${courier.plateNumber})` : ''}
                        </span>
                        {courier.verificationStatus === 'verified' && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span
                              className={
                                courier.isAvailable
                                  ? 'font-bold text-sq-gold-text'
                                  : 'text-sq-ink-muted'
                              }
                            >
                              {courier.isAvailable ? 'متاح للعمل الآن' : 'غير متاح حالياً'}
                            </span>
                          </>
                        )}
                      </div>

                      <h3 className="font-display text-base font-bold text-sq-ink">
                        {courier.fullName}
                      </h3>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-sq-ink-muted">
                        <span className="inline-flex items-center gap-1">
                          <Phone className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span dir="ltr" className="font-mono text-sq-ink">
                            {courier.phone}
                          </span>
                        </span>
                        <span>{courier.email}</span>
                        <span>
                          الهوية: <strong>{courier.idType}</strong> (
                          <span dir="ltr" className="font-mono">
                            {courier.idNumber}
                          </span>
                          )
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-sq-ink-muted">
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>
                            {[courier.governorate, courier.city, courier.district, courier.address]
                              .filter(Boolean)
                              .join(' — ') || 'غير محدد'}
                          </span>
                        </span>
                        <span className="font-mono tabular-nums text-sq-ink">
                          توصيلات مكتملة: {courier.totalDeliveries}
                          {courier.activeDeliveriesCount
                            ? ` · نشطة حالياً: ${courier.activeDeliveriesCount}`
                            : ''}
                        </span>
                        <span>تاريخ التقديم: {formatDateAr(courier.createdAt)}</span>
                      </div>

                      {courier.isAvailable &&
                        courier.latitude !== null &&
                        courier.longitude !== null && (
                          <div dir="ltr" className="font-mono text-[11px] text-sq-gold-text">
                            Live GPS: {courier.latitude.toFixed(5)},{' '}
                            {courier.longitude.toFixed(5)}
                          </div>
                        )}

                      {courier.rejectionReason && (
                        <div className="rounded-lg border border-sq-danger-border bg-sq-danger-bg px-3 py-1.5 text-xs font-semibold text-sq-danger-text">
                          سبب الرفض / الإيقاف: {courier.rejectionReason}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Admin Decision Buttons */}
                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {courier.verificationStatus !== 'verified' && (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() =>
                          handleQuickAction(courier.id, { verificationStatus: 'verified' })
                        }
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold disabled:opacity-60"
                      >
                        {isBusy ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        )}
                        <span>
                          {courier.verificationStatus === 'pending'
                            ? 'قبول وتوثيق المندوب'
                            : 'إعادة تفعيل'}
                        </span>
                      </button>
                    )}

                    {courier.verificationStatus === 'pending' && (
                      <button
                        type="button"
                        onClick={() => {
                          setReasonTarget(
                            reasonTarget?.id === courier.id &&
                              reasonTarget.nextStatus === 'rejected'
                              ? null
                              : { id: courier.id, nextStatus: 'rejected' }
                          );
                          setReasonText('');
                        }}
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 text-xs font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
                      >
                        <XCircle className="h-3.5 w-3.5" />
                        <span>رفض الطلب</span>
                      </button>
                    )}

                    {courier.verificationStatus === 'verified' && (
                      <button
                        type="button"
                        onClick={() => {
                          setReasonTarget(
                            reasonTarget?.id === courier.id &&
                              reasonTarget.nextStatus === 'suspended'
                              ? null
                              : { id: courier.id, nextStatus: 'suspended' }
                          );
                          setReasonText('');
                        }}
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3.5 text-xs font-semibold text-sq-warning-text hover:bg-sq-warning-bg"
                      >
                        <ShieldAlert className="h-3.5 w-3.5" />
                        <span>إيقاف المندوب</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() =>
                        onSendAlert({
                          userId: courier.userId,
                          recipientLabel: `المندوب: ${courier.fullName}`,
                          defaultTitle: 'تنبيه إداري من إدارة سوقنا',
                        })
                      }
                      className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                    >
                      <Send className="h-3.5 w-3.5 text-sq-gold-text" />
                      <span>تنبيه</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => void handleToggleHistory(courier.id)}
                      className="inline-flex min-h-[40px] items-center gap-1 rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink-muted hover:bg-sq-elevated"
                    >
                      <History className="h-3.5 w-3.5 text-sq-gold-text" />
                      <span>السجل</span>
                      {isExpanded ? (
                        <ChevronUp className="h-3.5 w-3.5" />
                      ) : (
                        <ChevronDown className="h-3.5 w-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Inline Rejection / Suspension Reason Form */}
                {reasonTarget?.id === courier.id && (
                  <div className="flex flex-col gap-2 rounded-xl border border-sq-danger-border bg-sq-danger-bg p-3.5 sm:flex-row sm:items-center">
                    <input
                      type="text"
                      value={reasonText}
                      onChange={(e) => setReasonText(e.target.value)}
                      placeholder={
                        reasonTarget.nextStatus === 'rejected'
                          ? 'اكتب سبب رفض طلب المندوب (مثال: صورة الهوية غير واضحة)...'
                          : 'اكتب سبب إيقاف حساب المندوب...'
                      }
                      className="min-h-[40px] flex-1 rounded-lg border border-sq-danger-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-danger-border focus:outline-none"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() =>
                          handleQuickAction(courier.id, {
                            verificationStatus: reasonTarget.nextStatus,
                            rejectionReason: reasonText.trim(),
                          })
                        }
                        className="min-h-[40px] rounded-lg bg-[#B42318] px-4 text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
                      >
                        {reasonTarget.nextStatus === 'rejected' ? 'تأكيد الرفض' : 'تأكيد الإيقاف'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setReasonTarget(null)}
                        className="min-h-[40px] rounded-lg border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink-muted"
                      >
                        إلغاء
                      </button>
                    </div>
                  </div>
                )}

                {/* Official Private Documents Preview (Super Admin Only) */}
                <div className="grid grid-cols-1 gap-2.5 border-t border-sq-border pt-3 sm:grid-cols-3">
                  <SecureDocPreview filename={courier.idFrontDoc} label="وجه الهوية الرسمية" />
                  <SecureDocPreview filename={courier.idBackDoc} label="ظهر الهوية الرسمية" />
                  <SecureDocPreview filename={courier.licenseDoc} label="إجازة السوق / المركبة" />
                </div>

                {/* Expandable Courier Delivery History */}
                {isExpanded && (
                  <div className="rounded-xl border border-sq-border bg-sq-elevated p-4 space-y-2.5">
                    <div className="text-xs font-bold text-sq-ink">
                      سجل طلبات التوصيل للمندوب ({courier.fullName})
                    </div>
                    {loadingHistoryId === courier.id ? (
                      <div className="flex items-center gap-2 text-xs text-sq-ink-muted">
                        <Loader2 className="h-4 w-4 animate-spin text-sq-gold-text" />
                        <span>جاري تحميل السجل...</span>
                      </div>
                    ) : historyList.length === 0 ? (
                      <p className="text-xs text-sq-ink-muted">
                        لم يقم هذا المندوب بتنفيذ أي طلبات توصيل بعد.
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {historyList.map((del) => (
                          <div
                            key={del.id}
                            className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2.5 text-xs"
                          >
                            <div className="space-y-0.5">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="font-mono font-bold text-sq-ink">
                                  {del.deliveryNumber}
                                </span>
                                <span className="text-sq-ink-muted">·</span>
                                <span className="font-semibold text-sq-gold-text">
                                  {del.storeName}
                                </span>
                                <span className="text-sq-ink-muted">← {del.customerName}</span>
                              </div>
                              <div className="text-[11px] text-sq-ink-muted">
                                {formatDateAr(del.requestedAt)}
                                {del.deliveredAt
                                  ? ` · سُلّم: ${formatDateAr(del.deliveredAt)}`
                                  : ''}
                                {del.otpVerified ? ' · موثق بـ OTP' : ''}
                              </div>
                            </div>
                            <div className="text-left">
                              <div className="font-bold text-sq-ink">
                                {DELIVERY_STATUS_LABELS[del.status]}
                              </div>
                              <div className="font-mono text-[11px] font-semibold text-sq-gold-text tabular-nums">
                                {formatPrice(del.cashToCollect, currency)}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
