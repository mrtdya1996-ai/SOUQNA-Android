import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Image as ImageIcon,
  Loader2,
  MessageSquare,
  Search,
  Send,
  ShieldAlert,
  X,
  XCircle,
} from 'lucide-react';
import { formatDateAr } from '../lib/api';
import {
  COMPLAINT_STATUS_LABELS,
  COMPLAINT_TARGET_LABELS,
  ROLE_LABELS,
  type Complaint,
  type ComplaintStatus,
} from '../types';

interface AdminComplaintsSectionProps {
  complaints: Complaint[];
  onUpdateComplaint: (
    complaintId: string,
    payload: {
      status: ComplaintStatus;
      adminNotes?: string;
      violationRecorded?: boolean;
      suspendTarget?: boolean;
      replyMessage?: string;
    }
  ) => Promise<void>;
  onReplyComplaint: (complaintId: string, message: string) => Promise<void>;
}

export const AdminComplaintsSection: React.FC<AdminComplaintsSectionProps> = ({
  complaints,
  onUpdateComplaint,
  onReplyComplaint,
}) => {
  const [statusFilter, setStatusFilter] = useState<ComplaintStatus | 'all'>('all');
  const [search, setSearch] = useState('');
  const [notesDraft, setNotesDraft] = useState<Record<string, string>>({});
  const [replyDraft, setReplyDraft] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);
  const [replyingId, setReplyingId] = useState<string | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const filteredComplaints = useMemo(() => {
    const q = search.trim().toLowerCase();
    return complaints.filter((c) => {
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (!q) return true;
      return (
        c.category.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        (c.reporterName || '').toLowerCase().includes(q) ||
        (c.targetName || '').toLowerCase().includes(q)
      );
    });
  }, [complaints, statusFilter, search]);

  const handleAction = async (
    c: Complaint,
    status: ComplaintStatus,
    options?: { violationRecorded?: boolean; suspendTarget?: boolean }
  ) => {
    setBusyId(c.id);
    try {
      await onUpdateComplaint(c.id, {
        status,
        adminNotes: (notesDraft[c.id] ?? c.adminNotes ?? '').trim(),
        violationRecorded: options?.violationRecorded,
        suspendTarget: options?.suspendTarget,
      });
    } finally {
      setBusyId(null);
    }
  };

  const handleSendReply = async (c: Complaint) => {
    const text = (replyDraft[c.id] || '').trim();
    if (text.length < 2) return;
    setReplyingId(c.id);
    try {
      await onReplyComplaint(c.id, text);
      setReplyDraft((prev) => ({ ...prev, [c.id]: '' }));
    } finally {
      setReplyingId(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {(['all', 'open', 'under_review', 'replied', 'resolved', 'closed', 'dismissed'] as const).map(
            (st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                  statusFilter === st
                    ? 'bg-sq-gold text-[#0B0C0C]'
                    : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                }`}
              >
                {st === 'all'
                  ? `الكل (${complaints.length})`
                  : `${COMPLAINT_STATUS_LABELS[st]} (${complaints.filter((c) => c.status === st).length})`}
              </button>
            )
          )}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث في الشكاوى والتذاكر..."
            className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface pr-10 pl-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
          />
        </div>
      </div>

      {filteredComplaints.length === 0 ? (
        <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
          لا توجد شكاوى أو تذاكر دعم فني في هذا التصنيف حالياً.
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredComplaints.map((c) => {
            const isBusy = busyId === c.id;
            const isReplying = replyingId === c.id;
            const currentNotes = notesDraft[c.id] ?? c.adminNotes ?? '';
            const messages = c.messages || [];

            return (
              <div
                key={c.id}
                className="rounded-2xl border border-sq-border bg-sq-surface p-5 space-y-4"
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span
                        className={`font-bold ${
                          c.status === 'open'
                            ? 'text-sq-danger-text'
                            : c.status === 'under_review'
                            ? 'text-sq-warning-text'
                            : c.status === 'replied' || c.status === 'resolved'
                            ? 'text-sq-gold-text'
                            : 'text-sq-ink-muted'
                        }`}
                      >
                        {COMPLAINT_STATUS_LABELS[c.status]}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-sq-ink">
                        {COMPLAINT_TARGET_LABELS[c.targetType]}:{' '}
                        {c.targetName || c.targetId}
                      </span>
                      {c.violationRecorded && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 font-bold text-sq-danger-text">
                            <AlertTriangle className="h-3.5 w-3.5" />
                            <span>مخالفة مسجلة</span>
                          </span>
                        </>
                      )}
                    </div>

                    <h3 className="font-display text-sm sm:text-base font-bold text-sq-ink">
                      {c.category}
                    </h3>

                    <p className="text-xs leading-relaxed text-sq-ink">{c.description}</p>

                    <div className="text-[11px] text-sq-ink-muted">
                      المرسل: <strong>{c.reporterName}</strong> (
                      {ROLE_LABELS[c.reporterRole as keyof typeof ROLE_LABELS] || c.reporterRole}) ·{' '}
                      {formatDateAr(c.createdAt)}
                      {c.updatedAt && c.updatedAt !== c.createdAt
                        ? ` · آخر تحديث: ${formatDateAr(c.updatedAt)}`
                        : ''}
                    </div>
                  </div>
                </div>

                {/* Attached Image */}
                {c.imageUrl && (
                  <div>
                    <button
                      type="button"
                      onClick={() => setLightboxImage(c.imageUrl || null)}
                      className="inline-flex items-center gap-2 overflow-hidden rounded-xl border border-sq-border bg-sq-elevated p-2 hover:border-sq-gold"
                    >
                      <img
                        src={c.imageUrl}
                        alt="مرفق الشكوى"
                        className="h-16 w-24 rounded-lg object-cover"
                      />
                      <span className="flex items-center gap-1 px-2 text-xs font-semibold text-sq-gold-text">
                        <ImageIcon className="h-4 w-4" />
                        <span>معاينة الصورة المرفقة</span>
                      </span>
                    </button>
                  </div>
                )}

                {/* Conversation Thread & Direct Reply */}
                <div className="rounded-2xl border border-sq-border bg-sq-elevated/70 p-3.5 space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-sq-ink">
                    <MessageSquare className="h-3.5 w-3.5 text-sq-gold-text" />
                    <span>محادثة الدعم الفني ({messages.length})</span>
                  </div>

                  {messages.length > 0 && (
                    <div className="max-h-60 space-y-2 overflow-y-auto pl-1">
                      {messages.map((msg) => {
                        const isAdmin = msg.senderRole === 'super_admin';
                        return (
                          <div
                            key={msg.id}
                            className={`rounded-xl border p-2.5 text-xs space-y-1 ${
                              isAdmin
                                ? 'border-sq-gold/40 bg-sq-gold-soft/55 text-sq-ink'
                                : 'border-sq-border bg-sq-surface text-sq-ink'
                            }`}
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                              <span
                                className={`font-bold ${
                                  isAdmin ? 'text-sq-gold-text' : 'text-sq-ink'
                                }`}
                              >
                                {isAdmin ? `رد الإدارة (${msg.senderName})` : msg.senderName}
                              </span>
                              <span className="text-sq-ink-muted">
                                {formatDateAr(msg.createdAt)}
                              </span>
                            </div>
                            <p className="leading-relaxed whitespace-pre-wrap">{msg.message}</p>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="flex flex-col gap-2 sm:flex-row">
                    <input
                      type="text"
                      value={replyDraft[c.id] || ''}
                      onChange={(e) =>
                        setReplyDraft((prev) => ({ ...prev, [c.id]: e.target.value }))
                      }
                      placeholder="اكتب رد الدعم الفني للمستخدم (يصل كإشعار فوري ويغيّر الحالة إلى تم الرد)..."
                      className="min-h-[40px] flex-1 rounded-xl border border-sq-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                    />
                    <button
                      type="button"
                      disabled={isReplying || (replyDraft[c.id] || '').trim().length < 2}
                      onClick={() => void handleSendReply(c)}
                      className="inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold disabled:opacity-50"
                    >
                      {isReplying ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Send className="h-3.5 w-3.5" />
                      )}
                      <span>إرسال رد</span>
                    </button>
                  </div>
                </div>

                {/* Admin Notes & Resolution Actions */}
                <div className="space-y-2.5 border-t border-sq-border pt-3">
                  <textarea
                    rows={2}
                    value={currentNotes}
                    onChange={(e) =>
                      setNotesDraft((prev) => ({ ...prev, [c.id]: e.target.value }))
                    }
                    placeholder="ملاحظات داخلية أو قرار المعالجة النهائي..."
                    className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-xs text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />

                  <div className="flex flex-wrap items-center gap-2">
                    {c.status !== 'under_review' && (
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => handleAction(c, 'under_review')}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3.5 text-xs font-semibold text-sq-warning-text disabled:opacity-60"
                      >
                        <span>قيد المراجعة</span>
                      </button>
                    )}

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => handleAction(c, 'resolved', { violationRecorded: false })}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold disabled:opacity-60"
                    >
                      {isBusy ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="h-3.5 w-3.5" />
                      )}
                      <span>تمت المعالجة</span>
                    </button>

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => handleAction(c, 'closed', { violationRecorded: false })}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3.5 text-xs font-semibold text-sq-ink hover:bg-sq-elevated disabled:opacity-60"
                    >
                      <XCircle className="h-3.5 w-3.5" />
                      <span>إغلاق التذكرة</span>
                    </button>

                    {(c.targetType === 'store' ||
                      c.targetType === 'courier' ||
                      c.targetType === 'user') && (
                      <>
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => handleAction(c, 'resolved', { violationRecorded: true })}
                          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 text-xs font-semibold text-sq-danger-text disabled:opacity-60"
                        >
                          <AlertTriangle className="h-3.5 w-3.5" />
                          <span>تسجيل مخالفة وإغلاق</span>
                        </button>

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() =>
                            handleAction(c, 'resolved', {
                              violationRecorded: true,
                              suspendTarget: true,
                            })
                          }
                          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl bg-[#B42318] px-3.5 text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
                        >
                          <ShieldAlert className="h-3.5 w-3.5" />
                          <span>مخالفة + إيقاف الحساب المعني</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Lightbox */}
      {lightboxImage && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs"
        >
          <div
            className="relative max-h-[90vh] max-w-3xl overflow-hidden rounded-2xl border border-sq-gold/40 bg-sq-surface p-2"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setLightboxImage(null)}
              aria-label="إغلاق المعاينة"
              className="absolute top-3 left-3 flex h-9 w-9 items-center justify-center rounded-xl bg-black/70 text-white hover:bg-black"
            >
              <X className="h-5 w-5" />
            </button>
            <img
              src={lightboxImage}
              alt="معاينة الصورة المرفقة"
              className="max-h-[82vh] w-auto rounded-xl object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
};
