import React, { useCallback, useEffect, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Crown,
  Headphones,
  KeyRound,
  MapPin,
  Navigation,
  Package,
  Phone,
  Power,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Store as StoreIcon,
  Truck,
  X,
} from 'lucide-react';
import { api, formatDateAr, formatPrice } from '../lib/api';
import { useApp } from '../context/AppContext';
import {
  COURIER_STATUS_LABELS,
  COURIER_VEHICLE_LABELS,
  DELIVERY_STAGE_ORDER,
  DELIVERY_STATUS_LABELS,
  SUBSCRIPTION_STATUS_LABELS,
  type CourierProfile,
  type Delivery,
  type DeliveryStatus,
} from '../types';

const NEXT_COURIER_ACTION: Record<
  string,
  { nextStatus: DeliveryStatus; label: string; requiresOtp?: boolean } | undefined
> = {
  accepted: { nextStatus: 'heading_to_store', label: 'أنا متجه إلى المتجر الآن' },
  heading_to_store: { nextStatus: 'picked_up', label: 'تم استلام الطلب من المتجر' },
  picked_up: { nextStatus: 'on_the_way', label: 'في الطريق إلى الزبون' },
  on_the_way: {
    nextStatus: 'delivered',
    label: 'إتمام التسليم (إدخال رمز التحقق OTP)',
    requiresOtp: true,
  },
};

export const CourierDashboardView: React.FC = () => {
  const {
    user,
    courierProfile,
    mySubscription,
    updateCourierProfile,
    refreshMySubscription,
    bootstrapStatus,
    navigate,
    notify,
  } = useApp();
  const [profile, setProfile] = useState<CourierProfile | null>(courierProfile);
  const [availableDeliveries, setAvailableDeliveries] = useState<Delivery[]>([]);
  const [myDeliveries, setMyDeliveries] = useState<Delivery[]>([]);
  const [activeTab, setActiveTab] = useState<'available' | 'active' | 'history'>('available');
  const [loading, setLoading] = useState(true);
  const [togglingAvailability, setTogglingAvailability] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  // OTP Modal state for completing delivery securely
  const [otpModalDelivery, setOtpModalDelivery] = useState<Delivery | null>(null);
  const [otpCode, setOtpCode] = useState('');

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const meRes = await api.getCourierMe();
      setProfile(meRes.courier);
      updateCourierProfile(meRes.courier);

      if (meRes.courier.verificationStatus === 'verified') {
        const [myRes, availRes] = await Promise.all([
          api.getMyDeliveries(),
          meRes.courier.isAvailable
            ? api.getAvailableDeliveries()
            : Promise.resolve({ deliveries: [] as Delivery[] }),
        ]);
        setMyDeliveries(myRes.deliveries);
        setAvailableDeliveries(availRes.deliveries);
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحميل بيانات لوحة المندوب.', 'error');
    } finally {
      setLoading(false);
    }
  }, [notify, updateCourierProfile]);

  useEffect(() => {
    if (user?.role === 'courier') {
      void loadAll();
      void refreshMySubscription();
    }
  }, [user, loadAll, refreshMySubscription]);

  if (!user || user.role !== 'courier') {
    return (
      <div className="mx-auto max-w-lg rounded-2xl border border-sq-border bg-sq-surface p-7 text-center">
        <Truck className="mx-auto h-10 w-10 text-sq-gold-text" />
        <h2 className="mt-3 font-display text-xl font-bold text-sq-ink">
          لوحة المندوب مخصصة لحسابات المندوبين فقط
        </h2>
        <p className="mt-1.5 text-sm text-sq-ink-muted">
          هل ترغب بالعمل كمندوب توصيل معتمد في SOUQNA | سوقنا؟
        </p>
        <div className="mt-5 flex flex-wrap justify-center gap-2.5">
          <button
            type="button"
            onClick={() => navigate('courier_register')}
            className="min-h-[44px] rounded-xl btn-gold px-5 py-2.5 text-sm font-bold"
          >
            التسجيل كمندوب جديد
          </button>
          <button
            type="button"
            onClick={() => navigate('home')}
            className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface px-5 py-2.5 text-sm font-semibold text-sq-ink"
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  const handleToggleAvailability = async () => {
    if (!profile) return;
    const nextAvail = !profile.isAvailable;
    setTogglingAvailability(true);

    const submitToggle = async (lat?: number | null, lng?: number | null) => {
      try {
        const res = await api.updateCourierAvailability({
          isAvailable: nextAvail,
          latitude: lat,
          longitude: lng,
        });
        setProfile(res.courier);
        updateCourierProfile(res.courier);
        if (nextAvail) {
          notify('أنت الآن متاح لاستقبال طلبات التوصيل القريبة.', 'success');
          const availRes = await api.getAvailableDeliveries();
          setAvailableDeliveries(availRes.deliveries);
        } else {
          notify('تم إيقاف حالة التوفر وإيقاف مشاركة موقعك الجغرافي.', 'info');
          setAvailableDeliveries([]);
        }
      } catch (err) {
        notify(err instanceof Error ? err.message : 'تعذر تحديث حالة التوفر.', 'error');
      } finally {
        setTogglingAvailability(false);
      }
    };

    if (nextAvail && typeof navigator !== 'undefined' && 'geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          void submitToggle(pos.coords.latitude, pos.coords.longitude);
        },
        () => {
          // Proceed with city/governorate fallback if user declines GPS
          void submitToggle(null, null);
        },
        { enableHighAccuracy: true, timeout: 7000 }
      );
    } else {
      await submitToggle(null, null);
    }
  };

  const handleRefreshLocation = () => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      notify('المتصفح لا يدعم تحديد الموقع الجغرافي.', 'error');
      return;
    }
    setTogglingAvailability(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const res = await api.updateCourierAvailability({
            isAvailable: true,
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          });
          setProfile(res.courier);
          updateCourierProfile(res.courier);
          const availRes = await api.getAvailableDeliveries();
          setAvailableDeliveries(availRes.deliveries);
          notify('تم تحديث موقعك الجغرافي وترتيب الطلبات حسب الأقرب.', 'success');
        } catch (err) {
          notify(err instanceof Error ? err.message : 'تعذر تحديث الموقع.', 'error');
        } finally {
          setTogglingAvailability(false);
        }
      },
      () => {
        setTogglingAvailability(false);
        notify('لم يتم السماح بالوصول للموقع الجغرافي من الجهاز.', 'error');
      },
      { enableHighAccuracy: true, timeout: 7000 }
    );
  };

  const handleAcceptDelivery = async (deliveryId: string) => {
    setBusyId(deliveryId);
    try {
      const res = await api.acceptDelivery(deliveryId);
      setAvailableDeliveries((prev) => prev.filter((d) => d.id !== deliveryId));
      setMyDeliveries((prev) => [res.delivery, ...prev.filter((d) => d.id !== deliveryId)]);
      setActiveTab('active');
      notify(
        `تم إسناد التوصيل ${res.delivery.deliveryNumber} لك بنجاح! تم إشعار المتجر والزبون.`,
        'success'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر قبول التوصيل.', 'error');
      await loadAll();
    } finally {
      setBusyId(null);
    }
  };

  const handleAdvanceStatus = async (
    delivery: Delivery,
    nextStatus: DeliveryStatus,
    deliveryOtp?: string
  ) => {
    setBusyId(delivery.id);
    try {
      const res = await api.updateDeliveryStatus(delivery.id, {
        status: nextStatus,
        deliveryOtp,
      });
      setMyDeliveries((prev) => prev.map((d) => (d.id === delivery.id ? res.delivery : d)));
      if (nextStatus === 'delivered') {
        setOtpModalDelivery(null);
        setOtpCode('');
        notify('تم التحقق من رمز الاستلام وإتمام التوصيل بنجاح!', 'success');
        void loadAll();
      } else {
        notify(`تم تحديث حالة التوصيل إلى: ${DELIVERY_STATUS_LABELS[nextStatus]}`, 'success');
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث حالة التوصيل.', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const activeDeliveries = myDeliveries.filter(
    (d) => d.status !== 'delivered' && d.status !== 'cancelled'
  );
  const completedDeliveries = myDeliveries.filter(
    (d) => d.status === 'delivered' || d.status === 'cancelled'
  );

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="rounded-2xl border border-sq-border bg-sq-surface p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-xl bg-sq-gold-soft text-sq-gold-text">
              {profile?.avatarUrl ? (
                <img src={profile.avatarUrl} alt={user.fullName} className="h-full w-full object-cover" />
              ) : (
                <Truck className="h-6 w-6" />
              )}
            </div>
            <div>
              <h1 className="font-display text-lg sm:text-xl font-bold text-sq-ink">
                لوحة المندوب — {user.fullName}
              </h1>
              <p className="text-xs text-sq-ink-muted">
                {profile
                  ? `${COURIER_VEHICLE_LABELS[profile.vehicleType]}${
                      profile.plateNumber ? ` · لوحة ${profile.plateNumber}` : ''
                    } · ${profile.governorate} - ${profile.district}`
                  : 'حساب مندوب توصيل'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void loadAll()}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>تحديث</span>
          </button>
        </div>

        {/* Courier Subscription Status Bar */}
        {mySubscription && (
          <div
            className={`mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3.5 text-xs ${
              mySubscription.status === 'expired' || mySubscription.status === 'suspended'
                ? 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
                : mySubscription.isExpiringSoon
                ? 'border-sq-warning-border bg-sq-warning-bg text-sq-warning-text'
                : 'border-sq-gold/35 bg-sq-gold-soft/45 text-sq-ink'
            }`}
          >
            <div className="flex items-start gap-2.5">
              <Crown className="mt-0.5 h-4 w-4 shrink-0 text-sq-gold-text" />
              <div className="space-y-0.5">
                <p className="font-bold">
                  اشتراك المندوب: {SUBSCRIPTION_STATUS_LABELS[mySubscription.status]} · متبقي{' '}
                  <span className="font-mono">{mySubscription.daysRemaining}</span> يوم (ينتهي{' '}
                  {formatDateAr(mySubscription.expiresAt)})
                </p>
                <p className="leading-relaxed opacity-90">
                  {mySubscription.status === 'expired' || mySubscription.status === 'suspended'
                    ? 'تم إيقاف استقبال التوصيلات الجديدة مؤقتاً دون حذف بياناتك أو سجلك. أرسل طلب تجديد وتواصل مع الإدارة.'
                    : mySubscription.isExpiringSoon
                    ? 'قرب انتهاء اشتراكك — جدّد اشتراكك مبكراً لضمان استمرار العمل.'
                    : 'اشتراكك سارٍ ويمكنك استقبال التوصيلات بعد توثيق الحساب.'}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => navigate('subscription')}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-bold"
              >
                <Crown className="h-3.5 w-3.5" />
                <span>إدارة الاشتراك</span>
              </button>
              <button
                type="button"
                onClick={() => navigate('support')}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink"
              >
                <Headphones className="h-3.5 w-3.5 text-sq-gold-text" />
                <span>الدعم</span>
              </button>
            </div>
          </div>
        )}

        {/* Verification Gate Screens */}
        {profile && profile.verificationStatus !== 'verified' && (
          <div
            className={`mt-4 rounded-xl border p-4 ${
              profile.verificationStatus === 'pending'
                ? 'border-sq-warning-border bg-sq-warning-bg text-sq-warning-text'
                : 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
            }`}
          >
            <div className="flex items-start gap-2.5">
              {profile.verificationStatus === 'pending' ? (
                <Clock className="mt-0.5 h-5 w-5 shrink-0" />
              ) : (
                <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0" />
              )}
              <div className="space-y-1 text-sm">
                <p className="font-bold">
                  حالة الحساب: {COURIER_STATUS_LABELS[profile.verificationStatus]}
                </p>
                <p className="text-xs leading-relaxed">
                  {profile.verificationStatus === 'pending'
                    ? 'تم استلام بياناتك ومستمسكاتك الرسمية بنجاح. سيقوم المدير العام بمراجعتها وتوثيق حسابك؛ ولا يمكن استقبال طلبات التوصيل قبل الموافقة.'
                    : profile.verificationStatus === 'rejected'
                    ? `تم رفض طلب التوثيق.${
                        profile.rejectionReason ? ` السبب: ${profile.rejectionReason}` : ''
                      }`
                    : `تم إيقاف حساب المندوب مؤقتاً من قِبل الإدارة.${
                        profile.rejectionReason ? ` السبب: ${profile.rejectionReason}` : ''
                      }`}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Verified Courier Availability Bar */}
        {profile && profile.verificationStatus === 'verified' && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-sq-border bg-sq-elevated p-3.5">
            <div className="flex items-center gap-3">
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                  profile.isAvailable
                    ? 'bg-sq-gold text-[#0B0C0C]'
                    : 'bg-sq-muted text-sq-ink-muted'
                }`}
              >
                <Power className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-bold text-sq-ink">
                  {profile.isAvailable ? 'متاح للعمل واستقبال التوصيلات' : 'غير متاح حالياً (متوقف)'}
                </p>
                <p className="text-xs text-sq-ink-muted">
                  {profile.isAvailable
                    ? profile.latitude !== null
                      ? `الموقع مفعّل لفرز أقرب الطلبات (${profile.latitude.toFixed(4)}, ${profile.longitude?.toFixed(4)})`
                      : `التوزيع حسب منطقتك: ${profile.governorate} - ${profile.district}`
                    : 'مشاركة موقعك الجغرافي متوقفة تماماً حفاظاً على خصوصيتك.'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {profile.isAvailable && (
                <button
                  type="button"
                  disabled={togglingAvailability}
                  onClick={handleRefreshLocation}
                  className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                >
                  <Navigation className="h-3.5 w-3.5 text-sq-gold-text" />
                  <span>تحديث موقعي GPS</span>
                </button>
              )}
              <button
                type="button"
                disabled={togglingAvailability}
                onClick={() => void handleToggleAvailability()}
                className={`inline-flex min-h-[42px] items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold text-white transition-colors disabled:opacity-60 ${
                  profile.isAvailable
                    ? 'bg-[#B42318] hover:bg-[#912018]'
                    : 'btn-gold '
                }`}
              >
                <Power className="h-4 w-4" />
                <span>
                  {togglingAvailability
                    ? 'جاري التحديث...'
                    : profile.isAvailable
                    ? 'تحويل إلى غير متاح'
                    : 'تفعيل متاح للعمل'}
                </span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Verified KPI Summary + Tabs */}
      {profile?.verificationStatus === 'verified' && (
        <>
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl border border-sq-border bg-sq-surface p-3.5">
              <p className="text-[11px] font-medium text-sq-ink-muted">طلبات متاحة قريبة</p>
              <p className="mt-1 font-mono text-xl font-bold text-sq-gold-text tabular-nums">
                {availableDeliveries.length}
              </p>
            </div>
            <div className="rounded-xl border border-sq-border bg-sq-surface p-3.5">
              <p className="text-[11px] font-medium text-sq-ink-muted">توصيلاتك الجارية</p>
              <p className="mt-1 font-mono text-xl font-bold text-sq-ink tabular-nums">
                {activeDeliveries.length}
              </p>
            </div>
            <div className="rounded-xl border border-sq-border bg-sq-surface p-3.5">
              <p className="text-[11px] font-medium text-sq-ink-muted">المكتملة بنجاح</p>
              <p className="mt-1 font-mono text-xl font-bold text-sq-gold-text tabular-nums">
                {profile.totalDeliveries}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 border-b border-sq-border pb-3">
            <button
              type="button"
              onClick={() => setActiveTab('available')}
              className={`min-h-[42px] rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
                activeTab === 'available'
                  ? 'bg-sq-gold text-[#0B0C0C]'
                  : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              طلبات متاحة قريبة ({availableDeliveries.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('active')}
              className={`min-h-[42px] rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
                activeTab === 'active'
                  ? 'bg-sq-gold text-[#0B0C0C]'
                  : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              توصيلاتي الجارية ({activeDeliveries.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`min-h-[42px] rounded-xl px-4 py-2 text-xs font-bold transition-colors ${
                activeTab === 'history'
                  ? 'bg-sq-gold text-[#0B0C0C]'
                  : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              سجل التوصيلات ({completedDeliveries.length})
            </button>
          </div>

          {/* TAB 1: Available Nearby Deliveries */}
          {activeTab === 'available' && (
            <div className="space-y-3">
              {!profile.isAvailable ? (
                <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center">
                  <Power className="mx-auto h-8 w-8 text-sq-ink-muted" />
                  <p className="mt-2 font-display text-base font-bold text-sq-ink">
                    حالة التوفر متوقفة حالياً
                  </p>
                  <p className="mt-1 text-xs text-sq-ink-muted">
                    فعّل زر «تفعيل متاح للعمل» بالأعلى لعرض طلبات التوصيل القريبة وقبولها.
                  </p>
                </div>
              ) : availableDeliveries.length === 0 ? (
                <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center">
                  <Package className="mx-auto h-8 w-8 text-sq-ink-muted" />
                  <p className="mt-2 font-display text-base font-bold text-sq-ink">
                    لا توجد طلبات توصيل بانتظار مندوب حالياً
                  </p>
                  <p className="mt-1 text-xs text-sq-ink-muted">
                    ستصلك إشعارات فورية فور قيام أي متجر قريب بطلب مندوب توصيل.
                  </p>
                </div>
              ) : (
                availableDeliveries.map((dlv) => (
                  <div
                    key={dlv.id}
                    className="rounded-2xl border border-sq-border bg-sq-surface p-4 sm:p-5 space-y-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-sq-gold-text">
                            {dlv.deliveryNumber}
                          </span>
                          <span className="text-xs text-sq-ink-muted">·</span>
                          <span className="text-xs font-semibold text-sq-ink">
                            طلب {dlv.orderNumber}
                          </span>
                        </div>
                        <h3 className="mt-1 flex items-center gap-1.5 font-display text-base font-bold text-sq-ink">
                          <StoreIcon className="h-4 w-4 text-sq-gold-text" />
                          <span>{dlv.storeName}</span>
                        </h3>
                      </div>
                      <div className="text-left">
                        {dlv.distanceKm !== null && (
                          <p className="text-xs font-bold text-sq-gold-text">
                            يبعد {dlv.distanceKm} كم
                          </p>
                        )}
                        <p className="text-xs text-sq-ink-muted">
                          أجرة التوصيل:{' '}
                          <strong className="font-mono text-sq-ink">
                            {formatPrice(dlv.deliveryFee, bootstrapStatus.currency)}
                          </strong>
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-2 rounded-xl bg-sq-elevated p-3 text-xs text-sq-ink sm:grid-cols-2">
                      <div className="flex items-start gap-1.5">
                        <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sq-gold-text" />
                        <div>
                          <span className="text-sq-ink-muted">الاستلام من المتجر: </span>
                          <strong>{dlv.pickupAddress}</strong>
                        </div>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <Navigation className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sq-warning-text" />
                        <div>
                          <span className="text-sq-ink-muted">منطقة التسليم: </span>
                          <strong>{dlv.dropoffAddress || 'يظهر العنوان الكامل بعد القبول'}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                      <div className="text-xs text-sq-ink-muted">
                        المبلغ النقدي للتحصيل عند التسليم:{' '}
                        <strong className="font-mono text-sm text-sq-ink">
                          {formatPrice(dlv.cashToCollect, bootstrapStatus.currency)}
                        </strong>
                      </div>
                      <button
                        type="button"
                        disabled={busyId === dlv.id}
                        onClick={() => void handleAcceptDelivery(dlv.id)}
                        className="inline-flex min-h-[44px] items-center gap-2 rounded-xl btn-gold px-5 py-2.5 text-sm font-bold disabled:opacity-60"
                      >
                        <CheckCircle2 className="h-4 w-4" />
                        <span>{busyId === dlv.id ? 'جاري التثبيت...' : 'قبول التوصيل الآن'}</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 2: Active Assigned Deliveries */}
          {activeTab === 'active' && (
            <div className="space-y-4">
              {activeDeliveries.length === 0 ? (
                <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center">
                  <Truck className="mx-auto h-8 w-8 text-sq-ink-muted" />
                  <p className="mt-2 font-display text-base font-bold text-sq-ink">
                    لا توجد توصيلات جارية حالياً
                  </p>
                  <p className="mt-1 text-xs text-sq-ink-muted">
                    عند قبول أي طلب توصيل من القائمة المتاحة، سيظهر هنا بكامل تفاصيله ومراحله.
                  </p>
                </div>
              ) : (
                activeDeliveries.map((dlv) => {
                  const action = NEXT_COURIER_ACTION[dlv.status];
                  const stageIdx = DELIVERY_STAGE_ORDER.indexOf(dlv.status);
                  return (
                    <div
                      key={dlv.id}
                      className="rounded-2xl border border-sq-gold/30 bg-sq-surface p-4 sm:p-5 space-y-4"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-2 border-b border-sq-border pb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-sq-gold-text">
                              {dlv.deliveryNumber}
                            </span>
                            <span className="text-xs text-sq-ink-muted">· طلب {dlv.orderNumber}</span>
                          </div>
                          <p className="mt-1 text-sm font-bold text-sq-ink">
                            الحالة الحالية: {DELIVERY_STATUS_LABELS[dlv.status]}
                          </p>
                        </div>
                        <div className="text-left text-xs">
                          <p className="text-sq-ink-muted">المبلغ النقدي للتحصيل</p>
                          <p className="font-mono text-base font-extrabold text-sq-gold-text">
                            {formatPrice(dlv.cashToCollect, bootstrapStatus.currency)}
                          </p>
                        </div>
                      </div>

                      {/* 8-Stage Progress Bar */}
                      <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-5">
                        {(
                          [
                            'accepted',
                            'heading_to_store',
                            'picked_up',
                            'on_the_way',
                            'delivered',
                          ] as DeliveryStatus[]
                        ).map((st) => {
                          const idx = DELIVERY_STAGE_ORDER.indexOf(st);
                          const done = stageIdx >= idx;
                          return (
                            <div
                              key={st}
                              className={`rounded-lg border px-2.5 py-2 text-[11px] font-semibold ${
                                done
                                  ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                                  : 'border-sq-border bg-sq-elevated text-sq-ink-muted'
                              }`}
                            >
                              {DELIVERY_STATUS_LABELS[st]}
                            </div>
                          );
                        })}
                      </div>

                      {/* Pickup (Store) & Dropoff (Customer) Cards */}
                      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <div className="rounded-xl border border-sq-border bg-sq-elevated p-3.5 text-xs space-y-1.5">
                          <p className="font-bold text-sq-gold-text">1. الاستلام من المتجر</p>
                          <p className="font-bold text-sq-ink">{dlv.storeName}</p>
                          <p className="text-sq-ink-muted">{dlv.pickupAddress}</p>
                          {dlv.storePhone && (
                            <a
                              href={`tel:${dlv.storePhone}`}
                              className="inline-flex items-center gap-1 font-mono font-bold text-sq-gold-text underline"
                            >
                              <Phone className="h-3.5 w-3.5" />
                              <span dir="ltr">{dlv.storePhone}</span>
                            </a>
                          )}
                        </div>

                        <div className="rounded-xl border border-sq-border bg-sq-elevated p-3.5 text-xs space-y-1.5">
                          <p className="font-bold text-sq-warning-text">2. التسليم إلى الزبون</p>
                          <p className="font-bold text-sq-ink">{dlv.customerName}</p>
                          <p className="text-sq-ink-muted">{dlv.dropoffAddress}</p>
                          {dlv.customerPhone && (
                            <a
                              href={`tel:${dlv.customerPhone}`}
                              className="inline-flex items-center gap-1 font-mono font-bold text-sq-gold-text underline"
                            >
                              <Phone className="h-3.5 w-3.5" />
                              <span dir="ltr">{dlv.customerPhone}</span>
                            </a>
                          )}
                        </div>
                      </div>

                      {/* Next Action Button */}
                      {action && (
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                          <p className="text-[11px] text-sq-ink-muted">
                            لا يُسمح للمندوب بتعديل المنتجات أو الأسعار — التسليم النهائي يتطلب رمز
                            التحقق (OTP) من الزبون.
                          </p>
                          <button
                            type="button"
                            disabled={busyId === dlv.id}
                            onClick={() => {
                              if (action.requiresOtp) {
                                setOtpModalDelivery(dlv);
                                setOtpCode('');
                              } else {
                                void handleAdvanceStatus(dlv, action.nextStatus);
                              }
                            }}
                            className="inline-flex min-h-[46px] items-center gap-2 rounded-xl btn-gold px-5 py-2.5 text-sm font-bold disabled:opacity-60"
                          >
                            {action.requiresOtp ? (
                              <KeyRound className="h-4 w-4" />
                            ) : (
                              <ShieldCheck className="h-4 w-4" />
                            )}
                            <span>{busyId === dlv.id ? 'جاري التحديث...' : action.label}</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 3: History */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              {completedDeliveries.length === 0 ? (
                <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
                  لا توجد توصيلات منتهية في السجل بعد.
                </div>
              ) : (
                completedDeliveries.map((dlv) => (
                  <div
                    key={dlv.id}
                    className="rounded-2xl border border-sq-border bg-sq-surface p-4 text-xs space-y-2"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sq-ink">
                          {dlv.deliveryNumber}
                        </span>
                        <span className="text-sq-ink-muted">· {dlv.storeName}</span>
                      </div>
                      <span
                        className={`font-bold ${
                          dlv.status === 'delivered' ? 'text-sq-gold-text' : 'text-sq-danger-text'
                        }`}
                      >
                        {DELIVERY_STATUS_LABELS[dlv.status]}
                      </span>
                    </div>
                    <p className="text-sq-ink-muted">
                      إلى: {dlv.customerName} — {dlv.dropoffAddress}
                    </p>
                    <div className="flex flex-wrap items-center justify-between gap-2 border-t border-sq-border pt-2 text-[11px] text-sq-ink-muted">
                      <span>
                        المبلغ: {formatPrice(dlv.cashToCollect, bootstrapStatus.currency)} · أجرة
                        التوصيل: {formatPrice(dlv.deliveryFee, bootstrapStatus.currency)}
                      </span>
                      <span>
                        {dlv.deliveredAt
                          ? `سُلّم في ${formatDateAr(dlv.deliveredAt)}`
                          : dlv.cancelledAt
                          ? `أُلغي في ${formatDateAr(dlv.cancelledAt)}`
                          : formatDateAr(dlv.updatedAt)}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </>
      )}

      {/* Mandatory OTP Verification Modal before marking Delivered */}
      {otpModalDelivery && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="تأكيد تسليم الطلب برمز OTP"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 backdrop-blur-xs"
          onClick={() => setOtpModalDelivery(null)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-sq-border bg-sq-surface p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-sq-border pb-3">
              <div className="flex items-center gap-2">
                <KeyRound className="h-5 w-5 text-sq-gold-text" />
                <h3 className="font-display text-base font-bold text-sq-ink">
                  تأكيد استلام الزبون (OTP)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setOtpModalDelivery(null)}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-border text-sq-ink-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <p className="text-xs leading-relaxed text-sq-ink-muted">
                لإتمام تسليم الطلب <strong>{otpModalDelivery.orderNumber}</strong> للزبون{' '}
                <strong>{otpModalDelivery.customerName}</strong> وتوثيق التحصيل النقدي (
                {formatPrice(otpModalDelivery.cashToCollect, bootstrapStatus.currency)})، اطلب رمز
                التأكيد المكوّن من 6 أرقام الظاهر في تطبيق الزبون وأدخله أدناه:
              </p>

              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                dir="ltr"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="000000"
                className="w-full rounded-xl border border-sq-border bg-sq-elevated px-4 py-3 text-center font-mono text-2xl font-bold tracking-[0.35em] text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
              />

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setOtpModalDelivery(null)}
                  className="min-h-[42px] rounded-xl border border-sq-border bg-sq-surface px-4 py-2 text-xs font-semibold text-sq-ink-muted"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  disabled={otpCode.length < 6 || busyId === otpModalDelivery.id}
                  onClick={() =>
                    void handleAdvanceStatus(otpModalDelivery, 'delivered', otpCode)
                  }
                  className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl btn-gold px-5 py-2 text-xs font-bold disabled:opacity-50"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>تأكيد التسليم وإغلاق الطلب</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
