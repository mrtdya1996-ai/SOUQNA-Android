import React, { useEffect, useMemo, useState } from 'react';
import {
  Banknote,
  Box,
  CheckCircle2,
  Crosshair,
  Loader2,
  MapPin,
  Minus,
  Plus,
  ReceiptText,
  ShoppingBag,
  Store as StoreIcon,
  Trash2,
  Truck,
  X,
} from 'lucide-react';
import { OrderInvoiceModal } from '../components/OrderInvoiceModal';
import { useApp } from '../context/AppContext';
import { api, formatPrice } from '../lib/api';
import {
  FULFILLMENT_LABELS,
  formatOrderItemOptionsSummary,
  type CartItem,
  type FulfillmentMethod,
  type Order,
} from '../types';

export const CartCheckoutView: React.FC = () => {
  const {
    user,
    cart,
    bootstrapStatus,
    navigate,
    openStore,
    updateCartQty,
    removeFromCart,
    clearStoreFromCart,
    notify,
  } = useApp();

  const [fulfillmentMethod, setFulfillmentMethod] = useState<FulfillmentMethod>('delivery');
  const [customerName, setCustomerName] = useState(user?.fullName || '');
  const [customerPhone, setCustomerPhone] = useState(user?.phone || '');
  const [governorate, setGovernorate] = useState(user?.governorate || '');
  const [city, setCity] = useState(user?.city || '');
  const [district, setDistrict] = useState(user?.district || '');
  const [neighborhood, setNeighborhood] = useState(user?.neighborhood || '');
  const [deliveryAddress, setDeliveryAddress] = useState(user?.address || '');
  const [latitude, setLatitude] = useState<number | null>(user?.latitude ?? null);
  const [longitude, setLongitude] = useState<number | null>(user?.longitude ?? null);
  const [locating, setLocating] = useState(false);
  const [notes, setNotes] = useState('');
  const [submittingStoreId, setSubmittingStoreId] = useState<string | null>(null);
  const [confirmStoreId, setConfirmStoreId] = useState<string | null>(null);
  const [clearConfirmStore, setClearConfirmStore] = useState<{ id: string; name: string } | null>(
    null
  );
  const [confirmedOrders, setConfirmedOrders] = useState<Order[]>([]);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);

  // Sync customer form automatically whenever user signs in or updates profile
  useEffect(() => {
    if (!user) return;
    setCustomerName((prev) => prev || user.fullName);
    setCustomerPhone((prev) => prev || user.phone);
    setGovernorate((prev) => prev || user.governorate);
    setCity((prev) => prev || user.city);
    setDistrict((prev) => prev || user.district);
    setNeighborhood((prev) => prev || user.neighborhood);
    setDeliveryAddress((prev) => prev || user.address);
    if (latitude === null && user.latitude !== null) setLatitude(user.latitude);
    if (longitude === null && user.longitude !== null) setLongitude(user.longitude);
  }, [user, latitude, longitude]);

  const handleLocateMe = () => {
    if (!('geolocation' in navigator)) {
      notify('المتصفح لا يدعم تحديد الموقع الجغرافي تلقائياً.', 'error');
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(Math.round(pos.coords.latitude * 1000000) / 1000000);
        setLongitude(Math.round(pos.coords.longitude * 1000000) / 1000000);
        setLocating(false);
        notify('تم تحديد موقعك الجغرافي بنجاح.', 'success');
      },
      () => {
        setLocating(false);
        notify('تعذر الوصول إلى GPS. تأكد من السماح بصلاحية الموقع في الهاتف.', 'error');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Group cart items by store and compute automatic totals
  const storeGroups = useMemo(() => {
    const map = new Map<
      string,
      {
        storeId: string;
        storeName: string;
        storeAddress: string;
        deliveryFee: number;
        items: CartItem[];
        subtotal: number;
      }
    >();

    for (const item of cart) {
      const existing = map.get(item.storeId);
      const lineTotal = Math.round(item.appliedUnitPrice * item.quantity * 100) / 100;
      if (existing) {
        existing.items.push(item);
        existing.subtotal = Math.round((existing.subtotal + lineTotal) * 100) / 100;
      } else {
        map.set(item.storeId, {
          storeId: item.storeId,
          storeName: item.storeName,
          storeAddress: item.storeAddress,
          deliveryFee: item.storeDeliveryFee,
          items: [item],
          subtotal: lineTotal,
        });
      }
    }
    return Array.from(map.values());
  }, [cart]);

  const grandSummary = useMemo(() => {
    let itemsSubtotal = 0;
    let totalDelivery = 0;
    for (const g of storeGroups) {
      itemsSubtotal += g.subtotal;
      totalDelivery += fulfillmentMethod === 'pickup' ? 0 : g.deliveryFee;
    }
    return {
      itemsSubtotal: Math.round(itemsSubtotal * 100) / 100,
      totalDelivery: Math.round(totalDelivery * 100) / 100,
      grandTotal: Math.round((itemsSubtotal + totalDelivery) * 100) / 100,
    };
  }, [storeGroups, fulfillmentMethod]);

  const validateOrderBeforeConfirm = (storeId: string): boolean => {
    if (!user) {
      notify('يرجى تسجيل الدخول أولاً لإرسال طلبك النقدي.', 'info');
      navigate('auth');
      return false;
    }

    const group = storeGroups.find((g) => g.storeId === storeId);
    if (!group) return false;

    const finalName = (customerName || user.fullName).trim();
    const finalPhone = (customerPhone || user.phone).trim();
    const finalGov = governorate.trim();
    const finalCity = city.trim();
    const finalAddr = deliveryAddress.trim();

    if (finalName.length < 2 || finalPhone.length < 7) {
      notify('يرجى إدخال الاسم الكامل ورقم الهاتف الصحيح.', 'error');
      return false;
    }
    if (
      fulfillmentMethod === 'delivery' &&
      (finalGov.length < 2 || finalCity.length < 2 || finalAddr.length < 3)
    ) {
      notify('يرجى إكمال المحافظة والمدينة والعنوان التفصيلي لتوصيل الطلب.', 'error');
      return false;
    }
    return true;
  };

  const handleRequestConfirmation = (storeId: string) => {
    if (validateOrderBeforeConfirm(storeId)) {
      setConfirmStoreId(storeId);
    }
  };

  const handlePlaceOrder = async (storeId: string) => {
    if (!validateOrderBeforeConfirm(storeId) || !user) return;

    const group = storeGroups.find((g) => g.storeId === storeId);
    if (!group) return;

    const finalName = (customerName || user.fullName).trim();
    const finalPhone = (customerPhone || user.phone).trim();
    const finalGov = governorate.trim();
    const finalCity = city.trim();
    const finalDist = district.trim();
    const finalNeigh = neighborhood.trim();
    const finalAddr = deliveryAddress.trim();

    setSubmittingStoreId(storeId);
    try {
      const { order } = await api.createOrder({
        storeId,
        fulfillmentMethod,
        customerName: finalName,
        customerPhone: finalPhone,
        governorate: finalGov,
        city: finalCity,
        district: finalDist,
        neighborhood: finalNeigh,
        deliveryAddress: finalAddr,
        latitude,
        longitude,
        notes: notes.trim(),
        items: group.items.map((i) => ({
          productId: i.product.id,
          quantity: i.quantity,
          pricingType: i.pricingType,
          selectedOptions: i.selectedOptions,
        })),
      });
      setConfirmStoreId(null);
      clearStoreFromCart(storeId);
      setConfirmedOrders((prev) => [order, ...prev]);
      notify(`تم تأكيد الطلب النقدي رقم ${order.orderNumber} بنجاح!`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال الطلب.', 'error');
    } finally {
      setSubmittingStoreId(null);
    }
  };

  const confirmGroup = useMemo(
    () => (confirmStoreId ? storeGroups.find((g) => g.storeId === confirmStoreId) || null : null),
    [confirmStoreId, storeGroups]
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-sq-ink">
            سلة المشتريات وإتمام الطلب
          </h1>
          <p className="mt-1 text-sm text-sq-ink-muted">
            يُحسب المجموع تلقائياً للمفرد والكارتون · الدفع نقداً فقط عند التوصيل أو الاستلام من المحل
          </p>
        </div>

        {storeGroups.length > 0 && (
          <div className="rounded-xl border border-sq-border bg-sq-surface px-4 py-2.5 text-left">
            <div className="text-[11px] text-sq-ink-muted">المجموع الكلي للسلة</div>
            <div className="font-mono text-base font-extrabold text-sq-gold-text tabular-nums">
              {formatPrice(grandSummary.grandTotal, bootstrapStatus.currency)}
            </div>
          </div>
        )}
      </div>

      {/* Confirmed Order Receipts */}
      {confirmedOrders.length > 0 && (
        <div className="space-y-3">
          {confirmedOrders.map((order) => (
            <div
              key={order.id}
              className="rounded-2xl border border-sq-gold/35 bg-sq-gold-soft p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 h-6 w-6 shrink-0 text-sq-gold-text" />
                  <div>
                    <h2 className="font-display text-base font-bold text-sq-gold-text">
                      تم استلام طلبك بنجاح — رقم الطلب {order.orderNumber}
                    </h2>
                    <p className="mt-1 text-xs sm:text-sm text-sq-ink">
                      المتجر: {order.storeName} · {FULFILLMENT_LABELS[order.fulfillmentMethod]} ·
                      الإجمالي النقدي:{' '}
                      <span className="font-mono font-semibold tabular-nums">
                        {formatPrice(order.totalAmount, bootstrapStatus.currency)}
                      </span>
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => setInvoiceOrder(order)}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-gold/30 bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-gold-text hover:bg-sq-muted whitespace-nowrap"
                  >
                    <ReceiptText className="h-3.5 w-3.5" />
                    <span>عرض الفاتورة المفصلة</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate('orders')}
                    className="min-h-[40px] rounded-xl btn-gold px-4 py-2 text-xs font-semibold whitespace-nowrap"
                  >
                    متابعة طلباتي
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {storeGroups.length === 0 ? (
        <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
          <ShoppingBag className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/60" />
          <h2 className="font-display text-lg font-bold text-sq-ink">سلة المشتريات فارغة</h2>
          <p className="mt-2 text-sm text-sq-ink-muted">
            تصفح المتاجر أو صفحة المنتجات وأضف مشترياتك بالمفرد أو بالكارتون.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => navigate('stores')}
              className="min-h-[46px] rounded-xl btn-gold px-5 py-2.5 text-sm font-semibold"
            >
              تصفح المتاجر
            </button>
            <button
              type="button"
              onClick={() => navigate('products')}
              className="min-h-[46px] rounded-xl border border-sq-border bg-sq-elevated px-5 py-2.5 text-sm font-semibold text-sq-ink hover:bg-sq-muted"
            >
              تصفح المنتجات
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Cart Items Grouped by Store */}
          <div className="space-y-5 lg:col-span-7">
            {storeGroups.map((group) => {
              const appliedDeliveryFee = fulfillmentMethod === 'pickup' ? 0 : group.deliveryFee;
              const total = Math.round((group.subtotal + appliedDeliveryFee) * 100) / 100;
              return (
                <div
                  key={group.storeId}
                  className="overflow-hidden rounded-2xl border border-sq-border bg-sq-surface"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-sq-border bg-sq-elevated px-5 py-3.5">
                    <button
                      type="button"
                      onClick={() => openStore(group.storeId)}
                      className="flex items-center gap-2 font-display text-base font-bold text-sq-ink hover:text-sq-gold-text"
                    >
                      <StoreIcon className="h-4 w-4 text-sq-gold-text" />
                      <span>{group.storeName}</span>
                    </button>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-sq-ink-muted tabular-nums">
                        {group.items.reduce((s, i) => s + i.quantity, 0)} منتج
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setClearConfirmStore({ id: group.storeId, name: group.storeName })
                        }
                        className="text-xs font-semibold text-sq-danger-text hover:underline"
                      >
                        إفراغ سلة المتجر
                      </button>
                    </div>
                  </div>

                  <div className="divide-y divide-sq-border px-5">
                    {group.items.map((item) => {
                      const lineTotal =
                        Math.round(item.appliedUnitPrice * item.quantity * 100) / 100;
                      return (
                        <div key={item.key} className="flex items-center gap-3.5 py-4">
                          <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-sq-muted">
                            {item.product.imageUrl ? (
                              <img
                                src={item.product.imageUrl}
                                alt={item.product.name}
                                referrerPolicy="no-referrer"
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              <div className="flex h-full w-full items-center justify-center text-xs text-sq-ink-muted">
                                صورة
                              </div>
                            )}
                          </div>

                          <div className="min-w-0 flex-1">
                            <h3 className="font-display text-sm font-bold text-sq-ink truncate">
                              {item.product.name}
                            </h3>
                            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-sq-ink-muted">
                              {item.pricingType === 'carton' && (
                                <Box className="h-3.5 w-3.5 text-sq-gold-text" />
                              )}
                              <span>{item.appliedUnitLabel}</span>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono tabular-nums">
                                سعر الوحدة:{' '}
                                {formatPrice(item.appliedUnitPrice, bootstrapStatus.currency)}
                              </span>
                              <span aria-hidden="true">×</span>
                              <span className="font-mono font-semibold text-sq-ink tabular-nums">
                                {item.quantity}
                              </span>
                            </div>
                            {(() => {
                              const optTags = formatOrderItemOptionsSummary(item.selectedOptions);
                              if (optTags.length === 0) return null;
                              return (
                                <div className="mt-1 flex flex-wrap gap-1.5 text-[11px] font-medium text-sq-gold-text">
                                  {optTags.map((tag, idx) => (
                                    <span
                                      key={idx}
                                      className="rounded-md border border-sq-gold/35 bg-sq-gold-soft px-1.5 py-0.5"
                                    >
                                      {tag}
                                    </span>
                                  ))}
                                </div>
                              );
                            })()}
                            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                              <span className="font-mono font-bold text-sq-gold-text tabular-nums">
                                مجموع المنتج: {formatPrice(lineTotal, bootstrapStatus.currency)}
                              </span>
                              <span aria-hidden="true" className="text-sq-border">·</span>
                              <span className="text-[11px] text-sq-ink-muted tabular-nums">
                                المتوفر: {item.product.stockQty} {item.product.unit}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => updateCartQty(item.key, -1)}
                              aria-label="تقليل الكمية"
                              className="flex h-9 w-9 items-center justify-center rounded-lg border border-sq-border text-sq-ink hover:bg-sq-muted"
                            >
                              <Minus className="h-3.5 w-3.5" />
                            </button>
                            <span className="w-7 text-center font-mono text-sm font-semibold tabular-nums">
                              {item.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => updateCartQty(item.key, 1)}
                              aria-label="زيادة الكمية"
                              className="flex h-9 w-9 items-center justify-center rounded-lg border border-sq-border text-sq-ink hover:bg-sq-muted"
                            >
                              <Plus className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => removeFromCart(item.key)}
                              aria-label="حذف المنتج"
                              className="mr-1 flex h-9 w-9 items-center justify-center rounded-lg text-sq-danger-text hover:bg-sq-danger-bg"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="border-t border-sq-border bg-sq-elevated px-5 py-4 space-y-2 text-sm">
                    <div className="flex justify-between text-sq-ink-muted">
                      <span>مجموع المنتجات</span>
                      <span className="font-mono tabular-nums">
                        {formatPrice(group.subtotal, bootstrapStatus.currency)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sq-ink-muted">
                      <span>
                        {fulfillmentMethod === 'pickup' ? 'الاستلام من المحل' : 'رسوم التوصيل'}
                      </span>
                      <span className="font-mono tabular-nums">
                        {appliedDeliveryFee > 0
                          ? formatPrice(appliedDeliveryFee, bootstrapStatus.currency)
                          : 'مجاني (0)'}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-sq-border pt-2.5 text-base font-bold text-sq-ink">
                      <span>الإجمالي النقدي المطلوب</span>
                      <span className="font-mono tabular-nums text-sq-gold-text">
                        {formatPrice(total, bootstrapStatus.currency)}
                      </span>
                    </div>

                    {fulfillmentMethod === 'pickup' && group.storeAddress && (
                      <p className="text-xs text-sq-ink-muted">
                        <strong>عنوان الاستلام من المحل:</strong> {group.storeAddress}
                      </p>
                    )}

                    <button
                      type="button"
                      disabled={submittingStoreId === group.storeId}
                      onClick={() => handleRequestConfirmation(group.storeId)}
                      className="mt-3 flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold px-5 py-3 text-sm font-semibold transition-colors disabled:opacity-60"
                    >
                      {submittingStoreId === group.storeId ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span>جاري إرسال الطلب...</span>
                        </>
                      ) : (
                        <>
                          <Banknote className="h-4 w-4" />
                          <span>
                            {fulfillmentMethod === 'pickup'
                              ? 'مراجعة وتأكيد الطلب — استلام ودفع نقدي في المحل'
                              : 'مراجعة وتأكيد الطلب — توصيل ودفع نقدي عند الاستلام'}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Fulfillment Method + Customer Data Form */}
          <div className="lg:col-span-5">
            <div className="sticky top-20 rounded-2xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-5">
              {/* Step 1: Choose Delivery or Store Pickup */}
              <div className="space-y-2.5">
                <h2 className="font-display text-base font-bold text-sq-ink">
                  1. طريقة استلام الطلب
                </h2>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setFulfillmentMethod('delivery')}
                    className={`flex flex-col items-start gap-1.5 rounded-2xl border p-3.5 text-right transition-colors ${
                      fulfillmentMethod === 'delivery'
                        ? 'border-sq-gold bg-sq-gold-soft'
                        : 'border-sq-border bg-sq-elevated hover:bg-sq-surface'
                    }`}
                  >
                    <Truck
                      className={`h-5 w-5 ${
                        fulfillmentMethod === 'delivery' ? 'text-sq-gold-text' : 'text-sq-ink-muted'
                      }`}
                    />
                    <span className="font-display text-sm font-bold text-sq-ink">
                      التوصيل إلى العنوان
                    </span>
                    <span className="text-[11px] text-sq-ink-muted">يصلك الطلب وتدفع نقداً</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFulfillmentMethod('pickup')}
                    className={`flex flex-col items-start gap-1.5 rounded-2xl border p-3.5 text-right transition-colors ${
                      fulfillmentMethod === 'pickup'
                        ? 'border-sq-gold bg-sq-gold-soft'
                        : 'border-sq-border bg-sq-elevated hover:bg-sq-surface'
                    }`}
                  >
                    <StoreIcon
                      className={`h-5 w-5 ${
                        fulfillmentMethod === 'pickup' ? 'text-sq-gold-text' : 'text-sq-ink-muted'
                      }`}
                    />
                    <span className="font-display text-sm font-bold text-sq-ink">
                      الاستلام من المحل
                    </span>
                    <span className="text-[11px] text-sq-ink-muted">بدون رسوم توصيل</span>
                  </button>
                </div>
              </div>

              {/* Step 2: Customer Data */}
              <div className="space-y-3.5 border-t border-sq-border pt-4">
                <div className="flex items-center justify-between gap-2">
                  <h2 className="font-display text-base font-bold text-sq-ink">
                    2. بيانات الزبون
                  </h2>
                  {user && (
                    <button
                      type="button"
                      onClick={() => navigate('account')}
                      className="text-xs font-semibold text-sq-gold-text hover:underline"
                    >
                      تعديل بياناتي الدائمة
                    </button>
                  )}
                </div>

                {!user && (
                  <div className="rounded-xl border border-sq-border bg-sq-elevated p-4 text-xs text-sq-ink-muted space-y-2">
                    <p>يرجى تسجيل الدخول لإرسال طلبك ومتابعة حالته لحظة بلحظة.</p>
                    <button
                      type="button"
                      onClick={() => navigate('auth')}
                      className="min-h-[40px] rounded-lg bg-sq-gold px-4 py-2 font-semibold text-[#0B0C0C]"
                    >
                      تسجيل الدخول أو إنشاء حساب
                    </button>
                  </div>
                )}

                <div>
                  <label className="mb-1 block text-xs font-semibold text-sq-ink">
                    الاسم الثلاثي
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="الاسم الأول، الأب، الجد"
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold text-sq-ink">
                    رقم الهاتف
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="07XXXXXXXXX"
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>

                {fulfillmentMethod === 'delivery' && (
                  <>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label className="mb-1 block text-xs font-semibold text-sq-ink">
                          المحافظة
                        </label>
                        <input
                          type="text"
                          value={governorate}
                          onChange={(e) => setGovernorate(e.target.value)}
                          placeholder="المحافظة"
                          className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-semibold text-sq-ink">
                          المدينة
                        </label>
                        <input
                          type="text"
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          placeholder="المدينة"
                          className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-semibold text-sq-ink">
                          المنطقة
                        </label>
                        <input
                          type="text"
                          value={district}
                          onChange={(e) => setDistrict(e.target.value)}
                          placeholder="المنطقة"
                          className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-semibold text-sq-ink">
                          الحي
                        </label>
                        <input
                          type="text"
                          value={neighborhood}
                          onChange={(e) => setNeighborhood(e.target.value)}
                          placeholder="الحي"
                          className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="mb-1 block text-xs font-semibold text-sq-ink">
                        العنوان التفصيلي
                      </label>
                      <textarea
                        rows={2}
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        placeholder="الشارع، رقم الدار أو أقرب نقطة دالة"
                        className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                      />
                    </div>

                    <div className="space-y-2 rounded-xl border border-sq-border bg-sq-elevated p-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-sq-ink">
                          <MapPin className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>الموقع الجغرافي (GPS)</span>
                        </span>
                        <button
                          type="button"
                          disabled={locating}
                          onClick={handleLocateMe}
                          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg btn-gold px-3 py-1.5 text-xs font-semibold disabled:opacity-60"
                        >
                          {locating ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Crosshair className="h-3.5 w-3.5" />
                          )}
                          <span>تحديد موقعي</span>
                        </button>
                      </div>
                      {latitude !== null && longitude !== null ? (
                        <p className="font-mono text-[11px] text-sq-gold-text tabular-nums" dir="ltr">
                          {latitude.toFixed(6)}, {longitude.toFixed(6)}
                        </p>
                      ) : (
                        <p className="text-[11px] text-sq-ink-muted">
                          اختياري — يساعد المندوب على الوصول بدقة إلى موقعك.
                        </p>
                      )}
                    </div>
                  </>
                )}

                <div>
                  <label className="mb-1 block text-xs font-semibold text-sq-ink">
                    ملاحظات إضافية للمتجر (اختياري)
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="مثال: الاتصال قبل الوصول بخمس دقائق"
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>

                <div className="rounded-xl bg-sq-gold-soft p-3.5 text-xs leading-relaxed text-sq-gold-text">
                  <strong>الدفع نقداً فقط:</strong> لا يوجد دفع إلكتروني. تسدّد القيمة نقداً عند
                  {fulfillmentMethod === 'pickup' ? ' الاستلام من المحل.' : ' وصول الطلب إليك.'}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pre-Submission Full Order Review Modal (Confirm / Edit / Cancel) */}
      {confirmGroup && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="confirm-order-title"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-sq-border pb-3">
              <div>
                <h2
                  id="confirm-order-title"
                  className="font-display text-lg font-extrabold text-sq-ink"
                >
                  مراجعة الطلب قبل الإرسال
                </h2>
                <p className="text-xs text-sq-ink-muted">
                  راجع جميع المنتجات والأسعار والمجموع النهائي لطلبك من «{confirmGroup.storeName}»
                </p>
              </div>
              <button
                type="button"
                onClick={() => setConfirmStoreId(null)}
                aria-label="إغلاق"
                className="flex h-10 w-10 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-2 rounded-2xl border border-sq-border bg-sq-elevated p-4 text-xs text-sq-ink">
              <div className="font-bold text-sq-gold-text">بيانات الزبون وعنوان التوصيل</div>
              <div>
                <strong>الاسم:</strong> {customerName.trim()} ·{' '}
                <span dir="ltr" className="font-mono">
                  {customerPhone.trim()}
                </span>
              </div>
              <div>
                <strong>طريقة الاستلام:</strong> {FULFILLMENT_LABELS[fulfillmentMethod]}
              </div>
              <div>
                <strong>طريقة الدفع:</strong> الدفع نقداً عند الاستلام فقط
              </div>
              {fulfillmentMethod === 'delivery' ? (
                <div>
                  <strong>العنوان الكامل:</strong>{' '}
                  {[governorate, city, district, neighborhood, deliveryAddress]
                    .map((v) => v.trim())
                    .filter(Boolean)
                    .join(' — ')}
                </div>
              ) : (
                <div>
                  <strong>موقع الاستلام:</strong> {confirmGroup.storeAddress || confirmGroup.storeName}
                </div>
              )}
              {latitude !== null && longitude !== null && (
                <div dir="ltr" className="font-mono text-[11px] text-sq-gold-text">
                  GPS: {latitude.toFixed(6)}, {longitude.toFixed(6)}
                </div>
              )}
              {notes.trim() && (
                <div>
                  <strong>ملاحظات:</strong> {notes.trim()}
                </div>
              )}
            </div>

            {/* Itemized products table with unit price, quantity, and per-item total */}
            <div className="rounded-2xl border border-sq-border overflow-hidden">
              <div className="bg-sq-elevated border-b border-sq-border px-4 py-2 text-[11px] font-bold text-sq-ink-muted flex items-center justify-between">
                <span>المنتجات المختارة ({confirmGroup.items.length})</span>
                <span>السعر × الكمية = المجموع</span>
              </div>
              <div className="divide-y divide-sq-border px-4">
                {confirmGroup.items.map((item) => (
                  <div key={item.key} className="flex items-center justify-between gap-2 py-3 text-xs">
                    <div className="min-w-0">
                      <div className="font-bold text-sq-ink">{item.product.name}</div>
                      <div className="mt-0.5 text-[11px] text-sq-ink-muted font-mono tabular-nums">
                        {formatPrice(item.appliedUnitPrice, bootstrapStatus.currency)} × {item.quantity}{' '}
                        ({item.appliedUnitLabel})
                      </div>
                      {(() => {
                        const optTags = formatOrderItemOptionsSummary(item.selectedOptions);
                        if (optTags.length === 0) return null;
                        return (
                          <div className="mt-1 flex flex-wrap gap-1 text-[10px] font-medium text-sq-gold-text">
                            {optTags.map((tag, idx) => (
                              <span
                                key={idx}
                                className="rounded bg-sq-gold-soft px-1.5 py-0.5"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        );
                      })()}
                    </div>
                    <span className="font-mono font-bold tabular-nums text-sq-ink shrink-0">
                      {formatPrice(item.appliedUnitPrice * item.quantity, bootstrapStatus.currency)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 rounded-2xl bg-sq-gold-soft p-4 text-sm">
              <div className="flex justify-between text-xs text-sq-ink">
                <span>المجموع الفرعي للمنتجات</span>
                <span className="font-mono tabular-nums">
                  {formatPrice(confirmGroup.subtotal, bootstrapStatus.currency)}
                </span>
              </div>
              <div className="flex justify-between text-xs text-sq-ink">
                <span>
                  {fulfillmentMethod === 'pickup' ? 'رسوم الاستلام من المحل' : 'أجور التوصيل'}
                </span>
                <span className="font-mono tabular-nums">
                  {fulfillmentMethod === 'pickup' || confirmGroup.deliveryFee <= 0
                    ? 'مجاني (0)'
                    : formatPrice(confirmGroup.deliveryFee, bootstrapStatus.currency)}
                </span>
              </div>
              <div className="flex justify-between border-t border-sq-gold/35 pt-2 font-bold text-sq-gold-text">
                <span>المجموع الكلي النهائي (نقداً)</span>
                <span className="font-mono text-base tabular-nums">
                  {formatPrice(
                    confirmGroup.subtotal +
                      (fulfillmentMethod === 'pickup' ? 0 : confirmGroup.deliveryFee),
                    bootstrapStatus.currency
                  )}
                </span>
              </div>
            </div>

            {/* 3 Explicit Review Actions: Confirm / Edit / Cancel */}
            <div className="space-y-2">
              <button
                type="button"
                disabled={submittingStoreId === confirmGroup.storeId}
                onClick={() => handlePlaceOrder(confirmGroup.storeId)}
                className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold px-4 text-sm font-bold disabled:opacity-60"
              >
                {submittingStoreId === confirmGroup.storeId ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>جاري إرسال الطلب...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-4 w-4" />
                    <span>تأكيد الطلب</span>
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmStoreId(null)}
                  className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface px-4 text-xs sm:text-sm font-semibold text-sq-ink hover:bg-sq-elevated"
                >
                  تعديل الطلب
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setConfirmStoreId(null);
                    notify('تم التراجع عن إرسال الطلب. منتجاتك ما زالت محفوظة في السلة.', 'info');
                  }}
                  className="min-h-[44px] rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 text-xs sm:text-sm font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Store Cart Clear Confirmation Modal (Sensitive Action Guard + Undoable after confirm) */}
      {clearConfirmStore && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-sm rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <h2 className="font-display text-base font-extrabold text-sq-ink">
              تأكيد إفراغ سلة المتجر
            </h2>
            <p className="text-xs leading-relaxed text-sq-ink-muted">
              هل أنت متأكد من إزالة جميع منتجات «{clearConfirmStore.name}» من السلة؟ يمكنك التراجع
              فوراً بعد الإزالة إذا كان الإجراء بالخطأ.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setClearConfirmStore(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
              >
                الاحتفاظ بالمنتجات
              </button>
              <button
                type="button"
                onClick={() => {
                  const target = clearConfirmStore;
                  setClearConfirmStore(null);
                  clearStoreFromCart(target.id, { allowUndo: true });
                }}
                className="min-h-[44px] rounded-xl bg-[#B42318] text-xs font-semibold text-white hover:bg-[#912018]"
              >
                نعم، إفراغ السلة
              </button>
            </div>
          </div>
        </div>
      )}

      {invoiceOrder && (
        <OrderInvoiceModal
          order={invoiceOrder}
          currency={bootstrapStatus.currency}
          onClose={() => setInvoiceOrder(null)}
        />
      )}
    </div>
  );
};
