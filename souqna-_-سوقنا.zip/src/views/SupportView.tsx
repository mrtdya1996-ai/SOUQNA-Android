import React, { useCallback, useEffect, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  ExternalLink,
  Headphones,
  Image as ImageIcon,
  Loader2,
  MessageCircle,
  RefreshCw,
  Send,
  ShieldCheck,
  X,
} from 'lucide-react';
import { ImageUploader } from '../components/ImageUploader';
import { useApp } from '../context/AppContext';
import { api, formatDateAr } from '../lib/api';
import {
  COMPLAINT_STATUS_LABELS,
  ROLE_LABELS,
  SUPPORT_CONTACTS,
  SUPPORT_ISSUE_CATEGORIES,
  type Complaint,
  type ComplaintTargetType,
} from '../types';

const STATUS_BADGE_STYLES: Record<string, string> = {
  open: 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text',
  under_review: 'border-sq-warning-border bg-sq-warning-bg text-sq-warning-text',
  replied: 'border-sq-gold/45 bg-sq-gold-soft text-sq-gold-text',
  resolved: 'border-sq-success-border bg-sq-success-bg text-sq-success-text',
  closed: 'border-sq-border bg-sq-elevated text-sq-ink-muted',
  dismissed: 'border-sq-border bg-sq-elevated text-sq-ink-muted',
};

export const SupportView: React.FC = () => {
  const { user, ownedStore, navigate, notify } = useApp();

  const [tickets, setTickets] = useState<Complaint[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);

  // New ticket form state
  const [category, setCategory] = useState<string>(SUPPORT_ISSUE_CATEGORIES[0]);
  const [targetType, setTargetType] = useState<ComplaintTargetType>('technical_support');
  const [targetName, setTargetName] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Active reply state per ticket
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [sendingReplyId, setSendingReplyId] = useState<string | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const loadTickets = useCallback(async () => {
    if (!user) return;
    setLoadingTickets(true);
    try {
      const res = await api.getMyComplaints();
      setTickets(res.complaints);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحميل تذاكر الدعم الفني.', 'error');
    } finally {
      setLoadingTickets(false);
    }
  }, [user, notify]);

  useEffect(() => {
    void loadTickets();
  }, [loadTickets]);

  const handleCategoryChange = (nextCategory: string) => {
    setCategory(nextCategory);
    if (nextCategory.includes('اشتراك')) {
      setTargetType('subscription');
    } else if (nextCategory.includes('متجر')) {
      setTargetType('store');
    } else if (nextCategory.includes('مندوب')) {
      setTargetType('courier');
    } else if (nextCategory.includes('طلب')) {
      setTargetType('order');
    } else if (nextCategory.includes('تقنية')) {
      setTargetType('technical_support');
    } else {
      setTargetType('general');
    }
  };

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('auth');
      return;
    }
    if (description.trim().length < 5) {
      notify('يرجى كتابة وصف واضح للمشكلة أو الشكوى (5 أحرف على الأقل).', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.submitComplaint({
        targetType,
        targetId: ownedStore?.id || user.id,
        targetName: targetName.trim() || category,
        category,
        description: description.trim(),
        imageUrl: imageUrl || undefined,
      });
      setTickets((prev) => [res.complaint, ...prev]);
      setDescription('');
      setTargetName('');
      setImageUrl('');
      notify('تم إرسال رسالتك إلى فريق الدعم الفني بنجاح. سنقوم بالرد عليك قريباً.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال التذكرة.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSendReply = async (ticketId: string) => {
    const text = (replyDrafts[ticketId] || '').trim();
    if (text.length < 2) {
      notify('اكتب رسالتك قبل الإرسال.', 'error');
      return;
    }
    setSendingReplyId(ticketId);
    try {
      const res = await api.replyComplaintMessage(ticketId, { message: text });
      setTickets((prev) => prev.map((t) => (t.id === ticketId ? res.complaint : t)));
      setReplyDrafts((prev) => ({ ...prev, [ticketId]: '' }));
      notify('تم إرسال ردك بنجاح إلى فريق الدعم الفني.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال الرد.', 'error');
    } finally {
      setSendingReplyId(null);
    }
  };

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Luxury Hero Header */}
      <section className="relative overflow-hidden rounded-3xl border border-sq-gold-hairline bg-[#0C0E0D] p-6 sm:p-8 text-white shadow-xl">
        <div className="pointer-events-none absolute -top-24 -left-16 h-60 w-60 rounded-full bg-[#D4AF37]/15 blur-3xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-[#D4AF37]/45 bg-[#151817] text-[#E8CB73]">
              <Headphones className="h-7 w-7" />
            </div>
            <div>
              <p className="text-xs font-bold tracking-wide text-[#E8CB73]">
                خدمة العملاء والدعم المباشر · SOUQNA | سوقنا
              </p>
              <h1 className="mt-1 font-display text-2xl sm:text-3xl font-extrabold text-white">
                الدعم الفني والشكاوى
              </h1>
              <p className="mt-1.5 max-w-xl text-xs sm:text-sm leading-relaxed text-[#CFC8B8]">
                نحن هنا لمساعدتك على مدار الساعة. تواصل معنا مباشرة عبر تيليجرام أو واتساب، أو أرسل
                تذكرة دعم داخل التطبيق وتابع الردود الفورية من الإدارة.
              </p>
            </div>
          </div>

          {user && (
            <button
              type="button"
              onClick={() => void loadTickets()}
              disabled={loadingTickets}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-[#D4AF37]/40 bg-[#171A18] px-4 text-xs font-bold text-[#F5F2EB] hover:border-[#D4AF37]"
            >
              <RefreshCw className={`h-4 w-4 text-[#E8CB73] ${loadingTickets ? 'animate-spin' : ''}`} />
              <span>تحديث المحادثات</span>
            </button>
          )}
        </div>
      </section>

      {/* Direct Official Support Channels (Telegram + WhatsApp) */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <a
          href={SUPPORT_CONTACTS.telegramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center justify-between gap-4 rounded-2xl border border-sq-gold/35 bg-sq-surface p-5 transition-all hover:border-sq-gold hover:shadow-lg active:scale-[0.99]"
        >
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-sq-gold/40 bg-sq-gold-soft text-sq-gold-text">
              <Send className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-sq-gold-text">تيليجرام الدعم الرسمي</p>
              <h2 className="mt-0.5 font-display text-base font-extrabold text-sq-ink">
                التواصل عبر تيليجرام
              </h2>
              <p className="mt-0.5 font-mono text-xs text-sq-ink-muted" dir="ltr">
                @{SUPPORT_CONTACTS.telegramHandle}
              </p>
            </div>
          </div>
          <span className="inline-flex min-h-[38px] items-center gap-1 rounded-xl btn-gold px-3.5 text-xs font-bold shrink-0">
            <span>محادثة</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </span>
        </a>

        <a
          href={SUPPORT_CONTACTS.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center justify-between gap-4 rounded-2xl border border-sq-gold/35 bg-sq-surface p-5 transition-all hover:border-sq-gold hover:shadow-lg active:scale-[0.99]"
        >
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-sq-gold/40 bg-sq-gold-soft text-sq-gold-text">
              <MessageCircle className="h-5 w-5" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-sq-gold-text">واتساب الدعم الرسمي</p>
              <h2 className="mt-0.5 font-display text-base font-extrabold text-sq-ink">
                التواصل عبر واتساب
              </h2>
              <p className="mt-0.5 font-mono text-xs text-sq-ink-muted" dir="ltr">
                {SUPPORT_CONTACTS.whatsappDisplay}
              </p>
            </div>
          </div>
          <span className="inline-flex min-h-[38px] items-center gap-1 rounded-xl btn-gold px-3.5 text-xs font-bold shrink-0">
            <span>مراسلة</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </span>
        </a>
      </section>

      {/* In-App Ticket Form */}
      {!user ? (
        <section className="rounded-3xl border border-sq-border bg-sq-surface p-7 text-center space-y-3">
          <ShieldCheck className="mx-auto h-10 w-10 text-sq-gold-text" />
          <h2 className="font-display text-lg font-extrabold text-sq-ink">
            أرسل شكوى أو تذكرة دعم داخل التطبيق
          </h2>
          <p className="mx-auto max-w-md text-xs sm:text-sm text-sq-ink-muted">
            يمكنك التواصل مباشرة عبر تيليجرام أو واتساب أعلاه في أي وقت، أو تسجيل الدخول لفتح تذكرة
            دعم رسمية ومتابعة الردود داخل التطبيق.
          </p>
          <button
            type="button"
            onClick={() => navigate('auth')}
            className="mt-2 inline-flex min-h-[44px] items-center justify-center rounded-xl btn-gold px-6 text-sm font-bold"
          >
            تسجيل الدخول لفتح تذكرة دعم
          </button>
        </section>
      ) : (
        <>
          <form
            onSubmit={handleSubmitTicket}
            className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-sq-border pb-3">
              <div>
                <h2 className="font-display text-base sm:text-lg font-extrabold text-sq-ink">
                  تقديم شكوى أو طلب دعم فني جديد
                </h2>
                <p className="mt-0.5 text-xs text-sq-ink-muted">
                  تصل تذكرتك مباشرة إلى المدير الرئيسي مع إمكانية إرفاق صورة توضيحية والمتابعة عبر
                  المحادثة.
                </p>
              </div>
              <span className="rounded-lg border border-sq-gold/30 bg-sq-gold-soft px-3 py-1 text-[11px] font-bold text-sq-gold-text">
                {ROLE_LABELS[user.role]}
              </span>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  نوع المشكلة أو الطلب
                </label>
                <select
                  value={category}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                >
                  {SUPPORT_ISSUE_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  موضوع مختصر / اسم المتجر أو رقم الطلب (اختياري)
                </label>
                <input
                  type="text"
                  value={targetName}
                  onChange={(e) => setTargetName(e.target.value)}
                  placeholder="مثال: رقم الطلب SQ-1024 أو اسم المتجر"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                وصف المشكلة أو الشكوى بالتفصيل
              </label>
              <textarea
                rows={4}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اشرح المشكلة أو الاستفسار بوضوح حتى يتمكن فريق الدعم من مساعدتك بأسرع وقت..."
                className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3.5 text-sm text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <ImageUploader
              label="إرفاق صورة توضيحية أو لقطة شاشة (اختياري)"
              value={imageUrl}
              onChange={setImageUrl}
              aspect="wide"
            />

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <p className="text-[11px] text-sq-ink-muted">
                ستصلك إشعارات فورية فور قيام الدعم الفني بالرد على تذكرتك.
              </p>
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-xl btn-gold px-6 text-sm font-bold disabled:opacity-60"
              >
                {submitting ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
                <span>إرسال إلى الدعم الفني</span>
              </button>
            </div>
          </form>

          {/* My Tickets & Support Conversation Threads */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-extrabold text-sq-ink">
                تذاكري ومحادثات الدعم ({tickets.length})
              </h2>
            </div>

            {loadingTickets ? (
              <div className="flex min-h-[140px] items-center justify-center gap-2 rounded-2xl border border-sq-border bg-sq-surface text-sm text-sq-ink-muted">
                <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
                <span>جاري تحميل محادثات الدعم...</span>
              </div>
            ) : tickets.length === 0 ? (
              <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
                لا توجد تذاكر دعم أو شكاوى مسجلة في حسابك بعد.
              </div>
            ) : (
              <div className="space-y-4">
                {tickets.map((ticket) => {
                  const isClosed =
                    ticket.status === 'closed' ||
                    ticket.status === 'dismissed' ||
                    ticket.status === 'resolved';
                  const badgeClass =
                    STATUS_BADGE_STYLES[ticket.status] || STATUS_BADGE_STYLES.open;
                  const messages = ticket.messages || [];

                  return (
                    <article
                      key={ticket.id}
                      className="rounded-2xl border border-sq-border bg-sq-surface p-5 space-y-4"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-2 border-b border-sq-border pb-3">
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span
                              className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-0.5 text-[11px] font-bold ${badgeClass}`}
                            >
                              {ticket.status === 'replied' || ticket.status === 'resolved' ? (
                                <CheckCircle2 className="h-3 w-3" />
                              ) : (
                                <Clock className="h-3 w-3" />
                              )}
                              <span>{COMPLAINT_STATUS_LABELS[ticket.status]}</span>
                            </span>
                            <h3 className="font-display text-sm sm:text-base font-bold text-sq-ink">
                              {ticket.category}
                            </h3>
                          </div>
                          {ticket.targetName && ticket.targetName !== ticket.category && (
                            <p className="text-xs text-sq-gold-text font-semibold">
                              الموضوع: {ticket.targetName}
                            </p>
                          )}
                        </div>
                        <span className="text-[11px] text-sq-ink-muted">
                          {formatDateAr(ticket.createdAt)}
                        </span>
                      </div>

                      {/* Initial description if messages array is empty (legacy tickets) */}
                      {messages.length === 0 && (
                        <p className="text-xs sm:text-sm leading-relaxed text-sq-ink">
                          {ticket.description}
                        </p>
                      )}

                      {/* Attached Image Preview */}
                      {ticket.imageUrl && (
                        <div>
                          <button
                            type="button"
                            onClick={() => setLightboxImage(ticket.imageUrl || null)}
                            className="group relative inline-flex items-center gap-2 overflow-hidden rounded-xl border border-sq-border bg-sq-elevated p-2 hover:border-sq-gold"
                          >
                            <img
                              src={ticket.imageUrl}
                              alt="مرفق التذكرة"
                              className="h-20 w-28 rounded-lg object-cover"
                            />
                            <span className="flex items-center gap-1 px-2 text-xs font-semibold text-sq-gold-text">
                              <ImageIcon className="h-4 w-4" />
                              <span>عرض الصورة المرفقة</span>
                            </span>
                          </button>
                        </div>
                      )}

                      {/* Conversation Thread */}
                      {messages.length > 0 && (
                        <div className="space-y-2.5 rounded-2xl border border-sq-border bg-sq-elevated/70 p-3.5">
                          <p className="text-[11px] font-bold text-sq-ink-muted">
                            سجل المحادثة ({messages.length})
                          </p>
                          <div className="space-y-2.5">
                            {messages.map((msg) => {
                              const isAdmin = msg.senderRole === 'super_admin';
                              return (
                                <div
                                  key={msg.id}
                                  className={`rounded-xl border p-3 text-xs space-y-1.5 ${
                                    isAdmin
                                      ? 'border-sq-gold/40 bg-sq-gold-soft/60 text-sq-ink'
                                      : 'border-sq-border bg-sq-surface text-sq-ink'
                                  }`}
                                >
                                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                                    <span
                                      className={`font-bold ${
                                        isAdmin ? 'text-sq-gold-text' : 'text-sq-ink'
                                      }`}
                                    >
                                      {isAdmin
                                        ? `الدعم الفني والإدارة (${msg.senderName})`
                                        : msg.senderName}
                                    </span>
                                    <span className="text-sq-ink-muted">
                                      {formatDateAr(msg.createdAt)}
                                    </span>
                                  </div>
                                  <p className="leading-relaxed whitespace-pre-wrap">{msg.message}</p>
                                  {msg.imageUrl && (
                                    <button
                                      type="button"
                                      onClick={() => setLightboxImage(msg.imageUrl)}
                                      className="mt-1 inline-block overflow-hidden rounded-lg border border-sq-border"
                                    >
                                      <img
                                        src={msg.imageUrl}
                                        alt="مرفق الرد"
                                        className="h-24 w-36 object-cover"
                                      />
                                    </button>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Legacy admin notes */}
                      {ticket.adminNotes && (
                        <div className="rounded-xl border border-sq-gold/30 bg-sq-gold-soft/45 px-3.5 py-2.5 text-xs text-sq-ink">
                          <strong className="text-sq-gold-text">ملاحظة الإدارة: </strong>
                          {ticket.adminNotes}
                        </div>
                      )}

                      {/* Follow-up Reply Box */}
                      {!isClosed ? (
                        <div className="flex flex-col gap-2 pt-1 sm:flex-row">
                          <input
                            type="text"
                            value={replyDrafts[ticket.id] || ''}
                            onChange={(e) =>
                              setReplyDrafts((prev) => ({ ...prev, [ticket.id]: e.target.value }))
                            }
                            placeholder="اكتب رداً أو توضيحاً إضافياً للدعم الفني..."
                            className="min-h-[42px] flex-1 rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-xs text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                          />
                          <button
                            type="button"
                            disabled={sendingReplyId === ticket.id}
                            onClick={() => void handleSendReply(ticket.id)}
                            className="inline-flex min-h-[42px] items-center justify-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold disabled:opacity-60"
                          >
                            {sendingReplyId === ticket.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Send className="h-3.5 w-3.5" />
                            )}
                            <span>إرسال رد</span>
                          </button>
                        </div>
                      ) : (
                        <p className="text-[11px] text-sq-ink-muted">
                          تم إغلاق هذه التذكرة. إذا احتجت مساعدة إضافية يمكنك فتح تذكرة جديدة أو
                          مراسلتنا عبر تيليجرام أو واتساب.
                        </p>
                      )}
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        </>
      )}

      {/* Image Preview Lightbox */}
      {lightboxImage && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-xs"
        >
          <div
            className="relative max-h-[90vh] max-w-3xl overflow-hidden rounded-2xl border border-sq-gold/40 bg-sq-surface p-2"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setLightboxImage(null)}
              aria-label="إغلاق المعاينة"
              className="absolute top-3 left-3 flex h-9 w-9 items-center justify-center rounded-xl bg-black/70 text-white hover:bg-black"
            >
              <X className="h-5 w-5" />
            </button>
            <img
              src={lightboxImage}
              alt="معاينة الصورة المرفقة"
              className="max-h-[82vh] w-auto rounded-xl object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
};
