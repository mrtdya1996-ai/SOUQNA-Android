import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Banknote,
  BellRing,
  Bike,
  CheckCircle2,
  Clock,
  Crosshair,
  Crown,
  Download,
  Edit3,
  ExternalLink,
  Eye,
  FileText,
  Flag,
  Gamepad2,
  Headphones,
  History,
  Loader2,
  MapPin,
  Package,
  Phone,
  Plus,
  Printer,
  ReceiptText,
  RefreshCw,
  Shirt,
  ShoppingBag,
  Smartphone,
  Store as StoreIcon,
  Trash2,
  X,
  XCircle,
} from 'lucide-react';
import { ComplaintModal } from '../components/ComplaintModal';
import { ImageUploader } from '../components/ImageUploader';
import { MerchantPostsSection } from '../components/MerchantPostsSection';
import { OrderInvoiceModal } from '../components/OrderInvoiceModal';
import { useApp } from '../context/AppContext';
import { api, formatDateAr, formatPrice } from '../lib/api';
import {
  ALL_STORE_TYPES,
  CLOTHING_COLOR_PRESETS,
  CLOTHING_SIZE_PRESETS,
  COURIER_VEHICLE_LABELS,
  DEFAULT_PRINT_PRICING,
  DELIVERY_STATUS_LABELS,
  FULFILLMENT_LABELS,
  MERCHANT_CANCEL_REASON_PRESETS,
  ORDER_STATUS_LABELS,
  PHONE_MODEL_PRESETS,
  POPULAR_GAMES,
  ROLE_LABELS,
  STORE_STATUS_LABELS,
  STORE_SUBCATEGORIES,
  STORE_TYPE_LABELS,
  STORE_UNITS,
  SUBSCRIPTION_STATUS_LABELS,
  formatOrderItemOptionsSummary,
  type MarketplaceCategory,
  type Order,
  type OrderStatus,
  type PrintPricingConfig,
  type Product,
  type StorePost,
  type StoreType,
} from '../types';

type MerchantTab = 'products' | 'posts' | 'orders' | 'settings';
type MerchantOrderFilter = 'all' | 'pending' | 'in_progress' | 'delivered' | 'closed';

const STORE_TYPES: StoreType[] = ALL_STORE_TYPES;

const EVENT_TYPE_LABELS: Record<string, string> = {
  created: 'إنشاء الطلب',
  status_changed: 'تحديث الحالة',
  cancelled: 'إلغاء الطلب',
  cancel_requested: 'طلب إلغاء عاجل من الزبون',
  rejected: 'رفض الطلب',
  stock_restored: 'إعادة الكمية للمخزون',
};

export const MerchantDashboardView: React.FC = () => {
  const {
    user,
    ownedStore,
    mySubscription,
    bootstrapStatus,
    focusedOrderId,
    clearFocusedOrder,
    updateUser,
    updateOwnedStore,
    refreshMySubscription,
    navigate,
    openStore,
    notify,
  } = useApp();

  const [activeTab, setActiveTab] = useState<MerchantTab>('products');
  const [orderFilter, setOrderFilter] = useState<MerchantOrderFilter>('all');
  const [products, setProducts] = useState<Product[]>([]);
  const [posts, setPosts] = useState<StorePost[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingData, setLoadingData] = useState(false);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);

  // Sensitive confirmation & Undo modal states
  const [deleteProductTarget, setDeleteProductTarget] = useState<Product | null>(null);
  const [deletingProduct, setDeletingProduct] = useState(false);
  const [orderCloseModal, setOrderCloseModal] = useState<{
    order: Order;
    status: 'rejected' | 'cancelled';
  } | null>(null);
  const [orderCloseReason, setOrderCloseReason] = useState('');
  const [orderCloseRestoreStock, setOrderCloseRestoreStock] = useState(true);
  const [submittingOrderClose, setSubmittingOrderClose] = useState(false);

  // Store creation / settings form state
  const [storeName, setStoreName] = useState(ownedStore?.name || '');
  const [storeType, setStoreType] = useState<StoreType>(ownedStore?.storeType || 'grocery');
  const [storeDesc, setStoreDesc] = useState(ownedStore?.description || '');
  const [storeCity, setStoreCity] = useState(ownedStore?.city || user?.city || '');
  const [storeDistrict, setStoreDistrict] = useState(ownedStore?.district || user?.district || '');
  const [storeAddress, setStoreAddress] = useState(ownedStore?.address || user?.address || '');
  const [storePhone, setStorePhone] = useState(ownedStore?.phone || user?.phone || '');
  const [openingHours, setOpeningHours] = useState(
    ownedStore?.openingHours || 'يومياً 8:00 ص - 11:00 م'
  );
  const [deliveryFee, setDeliveryFee] = useState(String(ownedStore?.deliveryFee ?? 0));
  const [minOrderAmount, setMinOrderAmount] = useState(String(ownedStore?.minOrderAmount ?? 0));
  const [logoUrl, setLogoUrl] = useState(ownedStore?.logoUrl || '');
  const [coverUrl, setCoverUrl] = useState(ownedStore?.coverUrl || '');
  const [storeLat, setStoreLat] = useState(
    ownedStore?.latitude !== null && ownedStore?.latitude !== undefined
      ? String(ownedStore.latitude)
      : ''
  );
  const [storeLng, setStoreLng] = useState(
    ownedStore?.longitude !== null && ownedStore?.longitude !== undefined
      ? String(ownedStore.longitude)
      : ''
  );
  const [locatingStore, setLocatingStore] = useState(false);
  const [notifyOnStoreVisit, setNotifyOnStoreVisit] = useState<boolean>(
    ownedStore?.notifyOnStoreVisit ?? true
  );
  const [printPricing, setPrintPricing] = useState<PrintPricingConfig>({
    ...DEFAULT_PRINT_PRICING,
    ...(ownedStore?.serviceConfig?.printPricing || {}),
  });
  const [savingStore, setSavingStore] = useState(false);

  // Courier dispatch & complaint states
  const [dispatchingOrderId, setDispatchingOrderId] = useState<string | null>(null);
  const [cancellingDeliveryOrderId, setCancellingDeliveryOrderId] = useState<string | null>(null);
  const [complaintTarget, setComplaintTarget] = useState<{
    targetId: string;
    targetName: string;
    orderId: string;
    deliveryId: string;
  } | null>(null);

  // Product form modal state
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [prodName, setProdName] = useState('');
  const [prodCategory, setProdCategory] = useState(STORE_SUBCATEGORIES.grocery[0]);
  const [prodDesc, setProdDesc] = useState('');
  const [prodPrice, setProdPrice] = useState('');
  const [prodUnit, setProdUnit] = useState(STORE_UNITS.grocery[0]);
  const [prodCartonPrice, setProdCartonPrice] = useState('');
  const [prodCartonUnits, setProdCartonUnits] = useState('12');
  const [prodStock, setProdStock] = useState('20');
  const [prodImage, setProdImage] = useState('');
  const [prodAvailable, setProdAvailable] = useState(true);
  const [prodSizes, setProdSizes] = useState<string[]>([]);
  const [customSizeInput, setCustomSizeInput] = useState('');
  const [prodColors, setProdColors] = useState<string[]>([]);
  const [customColorInput, setCustomColorInput] = useState('');
  const [prodPhoneModels, setProdPhoneModels] = useState<string[]>([]);
  const [customModelInput, setCustomModelInput] = useState('');
  const [prodGameName, setProdGameName] = useState<string>(POPULAR_GAMES[0]);
  const [prodCustomOptionsText, setProdCustomOptionsText] = useState('');
  const [savingProduct, setSavingProduct] = useState(false);
  const [dynamicCategories, setDynamicCategories] = useState<MarketplaceCategory[]>([]);

  useEffect(() => {
    let active = true;
    api
      .getCategories()
      .then((res) => {
        if (active && Array.isArray(res.categories)) {
          setDynamicCategories(res.categories);
        }
      })
      .catch(() => {
        // Ignore and fall back to static vertical categories
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (ownedStore) {
      setStoreName(ownedStore.name);
      setStoreType(ownedStore.storeType);
      setStoreDesc(ownedStore.description);
      setStoreCity(ownedStore.city);
      setStoreDistrict(ownedStore.district || '');
      setStoreAddress(ownedStore.address);
      setStorePhone(ownedStore.phone);
      setOpeningHours(ownedStore.openingHours);
      setDeliveryFee(String(ownedStore.deliveryFee));
      setMinOrderAmount(String(ownedStore.minOrderAmount));
      setLogoUrl(ownedStore.logoUrl);
      setCoverUrl(ownedStore.coverUrl);
      setStoreLat(ownedStore.latitude !== null ? String(ownedStore.latitude) : '');
      setStoreLng(ownedStore.longitude !== null ? String(ownedStore.longitude) : '');
      setNotifyOnStoreVisit(ownedStore.notifyOnStoreVisit ?? true);
      setPrintPricing({
        ...DEFAULT_PRINT_PRICING,
        ...(ownedStore.serviceConfig?.printPricing || {}),
      });
    }
  }, [ownedStore]);

  const loadMerchantData = useCallback(async () => {
    if (!ownedStore) return;
    setLoadingData(true);
    try {
      const [prodRes, postRes, ordRes] = await Promise.all([
        api.getMerchantProducts(),
        api.getMerchantPosts(),
        api.getMerchantOrders(),
      ]);
      setProducts(Array.isArray(prodRes?.products) ? prodRes.products : []);
      setPosts(Array.isArray(postRes?.posts) ? postRes.posts : []);
      setOrders(Array.isArray(ordRes?.orders) ? ordRes.orders : []);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحميل بيانات المتجر.', 'error');
    } finally {
      setLoadingData(false);
    }
  }, [ownedStore, notify]);

  useEffect(() => {
    if (user?.role === 'merchant') {
      void refreshMySubscription();
      if (ownedStore) {
        loadMerchantData();
      }
    }
  }, [user, ownedStore, loadMerchantData, refreshMySubscription]);

  // Switch straight to Orders tab and scroll to order when arriving from Push/SSE notification
  useEffect(() => {
    if (!focusedOrderId) return;
    setActiveTab('orders');
    setOrderFilter('all');
    if (loadingData || orders.length === 0) return;
    const el = document.getElementById(`merchant-order-${focusedOrderId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    const timer = window.setTimeout(() => clearFocusedOrder(), 7000);
    return () => window.clearTimeout(timer);
  }, [focusedOrderId, loadingData, orders.length, clearFocusedOrder]);

  const filteredOrders = useMemo(() => {
    if (orderFilter === 'all') return orders;
    if (orderFilter === 'pending') return orders.filter((o) => o.status === 'pending');
    if (orderFilter === 'in_progress') {
      return orders.filter(
        (o) =>
          o.status === 'confirmed' ||
          o.status === 'preparing' ||
          o.status === 'ready' ||
          o.status === 'out_for_delivery'
      );
    }
    if (orderFilter === 'delivered') return orders.filter((o) => o.status === 'delivered');
    return orders.filter((o) => o.status === 'cancelled' || o.status === 'rejected');
  }, [orders, orderFilter]);

  if (!user) {
    return (
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
        <StoreIcon className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/70" />
        <h1 className="font-display text-xl font-bold text-sq-ink">لوحة تحكم صاحب المتجر</h1>
        <p className="mt-2 text-sm text-sq-ink-muted">
          سجّل الدخول بحسابك الموحّد لإدارة متجرك أو فتح متجر جديد على نفس حسابك.
        </p>
        <button
          type="button"
          onClick={() => navigate('auth')}
          className="mt-5 min-h-[46px] rounded-xl btn-gold px-6 py-2.5 text-sm font-semibold"
        >
          تسجيل الدخول الموحّد
        </button>
      </div>
    );
  }

  if (user.role !== 'merchant' && user.role !== 'customer') {
    return (
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
        <StoreIcon className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/70" />
        <h1 className="font-display text-xl font-bold text-sq-ink">لوحة تحكم صاحب المتجر</h1>
        <p className="mt-2 text-sm text-sq-ink-muted">
          حسابك الحالي مخصص لصلاحية {user.role === 'super_admin' ? 'المدير العام' : 'مندوب التوصيل'}.
        </p>
        <button
          type="button"
          onClick={() => navigate(user.role === 'super_admin' ? 'admin' : 'courier')}
          className="mt-5 min-h-[46px] rounded-xl btn-gold px-6 py-2.5 text-sm font-semibold"
        >
          الانتقال إلى لوحتي
        </button>
      </div>
    );
  }

  const handleCaptureStoreLocation = () => {
    if (!('geolocation' in navigator)) {
      notify('المتصفح لا يدعم تحديد الموقع الجغرافي تلقائياً.', 'error');
      return;
    }
    setLocatingStore(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setStoreLat((Math.round(pos.coords.latitude * 1000000) / 1000000).toString());
        setStoreLng((Math.round(pos.coords.longitude * 1000000) / 1000000).toString());
        setLocatingStore(false);
        notify('تم التقاط موقع المتجر الجغرافي (GPS). احفظ الإعدادات لتثبيته.', 'success');
      },
      () => {
        setLocatingStore(false);
        notify('تعذر التقاط موقع المتجر. تأكد من تفعيل GPS.', 'error');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSaveStore = async (e: React.FormEvent, resubmitForReview = false) => {
    e.preventDefault();
    setSavingStore(true);
    try {
      const parsedLat = storeLat.trim() !== '' ? Number(storeLat) : null;
      const parsedLng = storeLng.trim() !== '' ? Number(storeLng) : null;
      const payload = {
        name: storeName.trim(),
        storeType,
        description: storeDesc.trim(),
        city: storeCity.trim(),
        district: storeDistrict.trim(),
        address: storeAddress.trim(),
        phone: storePhone.trim(),
        openingHours: openingHours.trim(),
        deliveryFee: Math.max(0, Number(deliveryFee) || 0),
        minOrderAmount: Math.max(0, Number(minOrderAmount) || 0),
        logoUrl,
        coverUrl,
        latitude: parsedLat !== null && Number.isFinite(parsedLat) ? parsedLat : null,
        longitude: parsedLng !== null && Number.isFinite(parsedLng) ? parsedLng : null,
        serviceConfig: storeType === 'printing' ? { printPricing } : undefined,
      };

      let isPendingStore = false;
      if (ownedStore) {
        const res = await api.updateStore({ ...payload, notifyOnStoreVisit, resubmitForReview });
        isPendingStore = res.store.status === 'pending';
        updateOwnedStore(res.store);
      } else {
        const res = await api.createStore(payload);
        isPendingStore = res.store.status === 'pending';
        if (res.user) {
          updateUser(res.user);
        }
        updateOwnedStore(res.store);
        void refreshMySubscription();
      }

      notify(
        resubmitForReview
          ? 'تم إعادة إرسال متجرك للمراجعة من قِبل المدير العام.'
          : ownedStore
          ? 'تم تحديث بيانات المتجر بنجاح.'
          : isPendingStore
          ? 'تم تسجيل متجرك على حسابك الحالي بنجاح وهو الآن قيد المراجعة من قِبل المدير العام. يمكنك تجهيز منتجاتك والاستمرار بالتسوق من نفس الحساب.'
          : 'تم إنشاء متجرك على حسابك الحالي بنجاح! يمكنك الآن إضافة المنتجات والاستمرار بالتسوق كزبون من نفس الحساب.',
        'success'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حفظ بيانات المتجر.', 'error');
    } finally {
      setSavingStore(false);
    }
  };

  const activeStoreType: StoreType = ownedStore?.storeType || storeType;
  const verticalCategories = useMemo(() => {
    const base = STORE_SUBCATEGORIES[activeStoreType] || STORE_SUBCATEGORIES.grocery;
    if (dynamicCategories.length === 0) return base;
    const matchedDynamic = dynamicCategories
      .filter((c) => c.storeType === 'all' || c.storeType === activeStoreType)
      .map((c) => c.name);
    return Array.from(new Set([...matchedDynamic, ...base]));
  }, [activeStoreType, dynamicCategories]);
  const verticalUnits = STORE_UNITS[activeStoreType] || STORE_UNITS.grocery;

  const toggleChip = (list: string[], setter: React.Dispatch<React.SetStateAction<string[]>>, val: string) => {
    setter(list.includes(val) ? list.filter((x) => x !== val) : [...list, val]);
  };

  const addCustomChip = (
    input: string,
    clearInput: (v: string) => void,
    list: string[],
    setter: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    const parts = input
      .split(/[،,]/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (parts.length === 0) return;
    const merged = Array.from(new Set([...list, ...parts]));
    setter(merged);
    clearInput('');
  };

  const openNewProductModal = () => {
    setEditingProduct(null);
    setProdName('');
    setProdCategory(verticalCategories[0] || 'أخرى');
    setProdDesc('');
    setProdPrice('');
    setProdUnit(verticalUnits[0] || 'قطعة');
    setProdCartonPrice('');
    setProdCartonUnits('12');
    setProdStock(activeStoreType === 'gaming_topup' ? '999' : '20');
    setProdImage('');
    setProdAvailable(true);
    setProdSizes([]);
    setCustomSizeInput('');
    setProdColors([]);
    setCustomColorInput('');
    setProdPhoneModels([]);
    setCustomModelInput('');
    setProdGameName(POPULAR_GAMES[0]);
    setProdCustomOptionsText('');
    setShowProductForm(true);
  };

  const openEditProductModal = (product: Product) => {
    setEditingProduct(product);
    setProdName(product.name);
    setProdCategory(product.category);
    setProdDesc(product.description);
    setProdPrice(String(product.price));
    setProdUnit(product.unit);
    setProdCartonPrice(product.cartonPrice > 0 ? String(product.cartonPrice) : '');
    setProdCartonUnits(product.cartonUnits > 0 ? String(product.cartonUnits) : '12');
    setProdStock(String(product.stockQty));
    setProdImage(product.imageUrl);
    setProdAvailable(product.isAvailable);
    setProdSizes(product.availableSizes || []);
    setCustomSizeInput('');
    setProdColors(product.availableColors || []);
    setCustomColorInput('');
    setProdPhoneModels(product.compatibleModels || []);
    setCustomModelInput('');
    setProdGameName(product.gameName || POPULAR_GAMES[0]);
    setProdCustomOptionsText((product.customOptions || []).join('، '));
    setShowProductForm(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProduct(true);
    try {
      const cartonPriceVal = Math.max(0, Number(prodCartonPrice) || 0);
      const customOptions = prodCustomOptionsText
        .split(/[،,]/)
        .map((s) => s.trim())
        .filter(Boolean);

      const payload = {
        name: prodName.trim(),
        category: prodCategory,
        description: prodDesc.trim(),
        price: Number(prodPrice),
        unit: prodUnit,
        cartonPrice: cartonPriceVal,
        cartonUnits: cartonPriceVal > 0 ? Math.max(1, Math.floor(Number(prodCartonUnits) || 12)) : 0,
        stockQty: Math.max(0, Math.floor(Number(prodStock) || 0)),
        imageUrl: prodImage,
        isAvailable: prodAvailable,
        availableSizes: activeStoreType === 'clothing' ? prodSizes : [],
        availableColors: activeStoreType === 'clothing' ? prodColors : [],
        compatibleModels: activeStoreType === 'phone_accessories' ? prodPhoneModels : [],
        gameName: activeStoreType === 'gaming_topup' ? prodGameName.trim() : '',
        customOptions,
      };

      if (editingProduct) {
        await api.updateProduct(editingProduct.id, payload);
        notify('تم تحديث المنتج بنجاح.', 'success');
      } else {
        await api.createProduct(payload);
        notify('تمت إضافة المنتج إلى متجرك بنجاح.', 'success');
      }
      setShowProductForm(false);
      await loadMerchantData();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حفظ المنتج.', 'error');
    } finally {
      setSavingProduct(false);
    }
  };

  const renderPrintPricingSection = () => (
    <div className="rounded-2xl border border-sq-gold/35 bg-sq-gold-soft/55 p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Printer className="h-4 w-4 text-sq-gold-text" />
        <h3 className="font-display text-sm font-bold text-sq-ink">
          تسعير خدمات الطباعة والاستنساخ والتجليد ({bootstrapStatus.currency})
        </h3>
      </div>
      <p className="text-xs text-sq-ink-muted">
        يعتمد النظام هذه الأسعار تلقائياً لحساب تكلفة طلبات الطباعة المرفوعة من الزبائن.
      </p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {(
          [
            ['bwA4Price', 'A4 أبيض وأسود / صفحة'],
            ['colorA4Price', 'A4 ملون / صفحة'],
            ['bwA3Price', 'A3 أبيض وأسود / صفحة'],
            ['colorA3Price', 'A3 ملون / صفحة'],
            ['bwA5Price', 'A5 أبيض وأسود / صفحة'],
            ['colorA5Price', 'A5 ملون / صفحة'],
            ['photoPrice', 'طباعة صورة فوتوغرافية'],
            ['bindingSpiralPrice', 'تجليد سلك / حلزوني'],
            ['bindingThermalPrice', 'تجليد حراري فاخر'],
            ['laminationPrice', 'تغليف حراري / كبس'],
            ['doubleSidedDiscountPercent', 'خصم الطباعة وجهين (%)'],
          ] as Array<[keyof PrintPricingConfig, string]>
        ).map(([key, label]) => (
          <div key={key}>
            <label className="mb-1 block text-[11px] font-semibold text-sq-ink">{label}</label>
            <input
              type="number"
              min={0}
              max={key === 'doubleSidedDiscountPercent' ? 50 : 1000000}
              value={printPricing[key]}
              onChange={(e) =>
                setPrintPricing((prev) => ({
                  ...prev,
                  [key]: Math.max(0, Number(e.target.value) || 0),
                }))
              }
              className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs focus:border-sq-gold focus:outline-none"
            />
          </div>
        ))}
      </div>
    </div>
  );

  const handleConfirmDeleteProduct = async () => {
    if (!deleteProductTarget) return;
    const target = deleteProductTarget;
    setDeletingProduct(true);
    try {
      await api.deleteProduct(target.id);
      setProducts((prev) => prev.filter((p) => p.id !== target.id));
      setDeleteProductTarget(null);
      notify(`تم حذف المنتج "${target.name}"`, 'info', {
        label: 'تراجع (Undo)',
        onClick: () => {
          void (async () => {
            try {
              const { product: restored } = await api.restoreProduct(target.id);
              setProducts((prev) => [restored, ...prev.filter((p) => p.id !== restored.id)]);
              notify(`تم التراجع واستعادة المنتج "${restored.name}" بنجاح.`, 'success');
            } catch (err) {
              notify(err instanceof Error ? err.message : 'تعذر استعادة المنتج.', 'error');
            }
          })();
        },
      });
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حذف المنتج.', 'error');
    } finally {
      setDeletingProduct(false);
    }
  };

  const handleToggleProductAvailability = async (product: Product) => {
    try {
      const { product: updated } = await api.updateProduct(product.id, {
        isAvailable: !product.isAvailable,
      });
      setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث توفر المنتج.', 'error');
    }
  };

  const handleOrderStatus = async (
    orderId: string,
    nextStatus: OrderStatus,
    options?: { reason?: string; restoreStock?: boolean }
  ) => {
    try {
      const { order } = await api.updateMerchantOrderStatus(orderId, nextStatus, options);
      setOrders((prev) => prev.map((o) => (o.id === order.id ? order : o)));
      notify(`تم تحديث حالة الطلب إلى «${ORDER_STATUS_LABELS[nextStatus]}».`, 'success');
      if (nextStatus === 'cancelled' || nextStatus === 'rejected') {
        await loadMerchantData();
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث حالة الطلب.', 'error');
    }
  };

  const openOrderCloseDialog = (order: Order, status: 'rejected' | 'cancelled') => {
    setOrderCloseModal({ order, status });
    setOrderCloseReason('');
    setOrderCloseRestoreStock(true);
  };

  const handleConfirmOrderClose = async () => {
    if (!orderCloseModal) return;
    setSubmittingOrderClose(true);
    try {
      await handleOrderStatus(orderCloseModal.order.id, orderCloseModal.status, {
        reason: orderCloseReason.trim(),
        restoreStock: orderCloseRestoreStock,
      });
      setOrderCloseModal(null);
    } finally {
      setSubmittingOrderClose(false);
    }
  };

  const handleRequestCourier = async (order: Order) => {
    setDispatchingOrderId(order.id);
    try {
      const res = await api.requestMerchantCourier(order.id);
      setOrders((prev) => prev.map((o) => (o.id === res.order.id ? res.order : o)));
      notify(
        res.notifiedCouriersCount > 0
          ? `تم إرسال طلب التوصيل بنجاح وإشعار ${res.notifiedCouriersCount} مندوب متاح بالقرب من متجرك.`
          : 'تم إنشاء طلب التوصيل وبثه لشبكة المندوبين الموثقين بانتظار أقرب مندوب متاح.',
        'success'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر طلب مندوب توصيل.', 'error');
    } finally {
      setDispatchingOrderId(null);
    }
  };

  const handleCancelDelivery = async (order: Order) => {
    setCancellingDeliveryOrderId(order.id);
    try {
      const res = await api.cancelMerchantDelivery(order.id, 'إلغاء طلب المندوب من قِبل المتجر');
      setOrders((prev) => prev.map((o) => (o.id === res.order.id ? res.order : o)));
      notify('تم إلغاء طلب التوصيل وإشعار الأطراف المعنية.', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إلغاء طلب التوصيل.', 'error');
    } finally {
      setCancellingDeliveryOrderId(null);
    }
  };

  // First-time Store Setup Form
  if (!ownedStore) {
    return (
      <div className="mx-auto max-w-2xl space-y-6">
        <div className="rounded-3xl border border-sq-border bg-sq-surface p-6 sm:p-8">
          <h1 className="font-display text-2xl font-extrabold text-sq-ink">
            أنشئ متجرك على SOUQNA | سوقنا
          </h1>
          <p className="mt-1.5 text-sm text-sq-ink-muted">
            {user.role === 'customer'
              ? 'افتح متجرك على نفس حسابك الحالي دون إنشاء حساب ثانٍ — ستبقى قادراً على التسوق كزبون وإدارة متجرك من نفس الحساب.'
              : 'أدخل بيانات محلك أو بقالتك أو السوق الخاص بك لفتح لوحة التحكم المستقلة والبدء في عرض منتجاتك.'}
          </p>

          <form onSubmit={handleSaveStore} className="mt-6 space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  اسم المحل أو السوق أو المول
                </label>
                <input
                  type="text"
                  required
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="مثال: سوبر ماركت الخير"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  تصنيف النشاط
                </label>
                <select
                  value={storeType}
                  onChange={(e) => setStoreType(e.target.value as StoreType)}
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                >
                  {STORE_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {STORE_TYPE_LABELS[t]}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                وصف مختصر للمتجر
              </label>
              <textarea
                rows={2}
                value={storeDesc}
                onChange={(e) => setStoreDesc(e.target.value)}
                placeholder="مثال: خضار وفواكه طازجة ومواد غذائية يومية مع توصيل سريع"
                className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المدينة</label>
                <input
                  type="text"
                  required
                  value={storeCity}
                  onChange={(e) => setStoreCity(e.target.value)}
                  placeholder="المدينة"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المنطقة</label>
                <input
                  type="text"
                  required
                  value={storeDistrict}
                  onChange={(e) => setStoreDistrict(e.target.value)}
                  placeholder="المنطقة"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  رقم تواصل المتجر
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={storePhone}
                  onChange={(e) => setStorePhone(e.target.value)}
                  placeholder="07XXXXXXXXX"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                العنوان التفصيلي
              </label>
              <input
                type="text"
                required
                value={storeAddress}
                onChange={(e) => setStoreAddress(e.target.value)}
                placeholder="الحي، الشارع، رقم المحل"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  ساعات العمل
                </label>
                <input
                  type="text"
                  value={openingHours}
                  onChange={(e) => setOpeningHours(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  رسوم التوصيل ({bootstrapStatus.currency})
                </label>
                <input
                  type="number"
                  min={0}
                  step="0.5"
                  value={deliveryFee}
                  onChange={(e) => setDeliveryFee(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  الحد الأدنى للطلب ({bootstrapStatus.currency})
                </label>
                <input
                  type="number"
                  min={0}
                  step="1"
                  value={minOrderAmount}
                  onChange={(e) => setMinOrderAmount(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            </div>

            <ImageUploader
              label="صورة غلاف المتجر (اختياري)"
              value={coverUrl}
              onChange={setCoverUrl}
              aspect="wide"
            />

            {storeType === 'printing' && renderPrintPricingSection()}

            <button
              type="submit"
              disabled={savingStore}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold py-3 text-sm font-semibold disabled:opacity-60"
            >
              {savingStore && <Loader2 className="h-4 w-4 animate-spin" />}
              <span>إنشاء المتجر وفتح لوحة التحكم</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  const pendingOrdersCount = orders.filter((o) => o.status === 'pending').length;
  const deliveredOrdersCount = orders.filter((o) => o.status === 'delivered').length;
  const totalCashRevenue = orders
    .filter((o) => o.status !== 'cancelled' && o.status !== 'rejected')
    .reduce((sum, o) => sum + o.totalAmount, 0);

  return (
    <div className="space-y-6">
      {/* Merchant Dashboard Header */}
      <div className="flex flex-col gap-4 rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-sq-ink-muted">
            <span>لوحة تحكم المتجر المستقلة</span>
            <span aria-hidden="true">·</span>
            <span>{STORE_TYPE_LABELS[ownedStore.storeType]}</span>
            <span aria-hidden="true">·</span>
            <span>
              {ownedStore.city}
              {ownedStore.district ? ` — ${ownedStore.district}` : ''}
            </span>
            <span aria-hidden="true">·</span>
            <span
              className={`font-semibold ${
                ownedStore.status === 'active'
                  ? 'text-sq-gold-text'
                  : ownedStore.status === 'pending'
                  ? 'text-sq-warning-text'
                  : 'text-sq-danger-text'
              }`}
            >
              الحالة: {STORE_STATUS_LABELS[ownedStore.status]}
            </span>
          </div>
          <h1 className="mt-1 font-display text-2xl sm:text-3xl font-extrabold text-sq-ink">
            {ownedStore.name}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => navigate('notifications')}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-sq-gold/30 bg-sq-gold-soft px-4 py-2 text-xs font-semibold text-sq-gold-text hover:bg-sq-gold-soft whitespace-nowrap"
          >
            <BellRing className="h-4 w-4" />
            <span>إشعارات الطلبات</span>
          </button>

          <button
            type="button"
            onClick={() => openStore(ownedStore.id)}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-4 py-2 text-xs font-semibold text-sq-ink hover:bg-sq-muted whitespace-nowrap"
          >
            <ExternalLink className="h-4 w-4 text-sq-gold-text" />
            <span>معاينة متجري</span>
          </button>

          <button
            type="button"
            onClick={() => navigate('home')}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl btn-gold px-4 py-2 text-xs font-semibold whitespace-nowrap"
          >
            <ShoppingBag className="h-4 w-4" />
            <span>التسوق من بقية المتاجر</span>
          </button>
        </div>
      </div>

      {/* Merchant Subscription Status Bar */}
      {mySubscription && (
        <div
          className={`flex flex-wrap items-center justify-between gap-3 rounded-2xl border p-4 text-xs sm:text-sm ${
            mySubscription.status === 'expired' || mySubscription.status === 'suspended'
              ? 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
              : mySubscription.isExpiringSoon
              ? 'border-sq-warning-border bg-sq-warning-bg text-sq-warning-text'
              : 'border-sq-gold/35 bg-sq-gold-soft/50 text-sq-ink'
          }`}
        >
          <div className="flex items-start gap-2.5">
            <Crown className="mt-0.5 h-5 w-5 shrink-0 text-sq-gold-text" />
            <div className="space-y-0.5">
              <div className="font-bold">
                حالة اشتراك المتجر: {SUBSCRIPTION_STATUS_LABELS[mySubscription.status]} · متبقي{' '}
                <span className="font-mono">{mySubscription.daysRemaining}</span> يوم (ينتهي{' '}
                {formatDateAr(mySubscription.expiresAt)})
              </div>
              <p className="text-xs leading-relaxed opacity-90">
                {mySubscription.status === 'expired' || mySubscription.status === 'suspended'
                  ? 'تم إيقاف إضافة المنتجات والمنشورات واستقبال الطلبات الجديدة مؤقتاً دون حذف أي بيانات. جدّد اشتراكك لتعود للعمل فوراً.'
                  : mySubscription.isExpiringSoon
                  ? 'اقترب موعد انتهاء اشتراكك — أرسل طلب تجديد الآن لتفادي توقف متجرك مؤقتاً.'
                  : 'اشتراك متجرك سارٍ وجميع الميزات التجارية مفعّلة بالكامل.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => navigate('subscription')}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold"
            >
              <Crown className="h-3.5 w-3.5" />
              <span>تفاصيل الاشتراك والتجديد</span>
            </button>
            <button
              type="button"
              onClick={() => navigate('support')}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3.5 text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
            >
              <Headphones className="h-3.5 w-3.5 text-sq-gold-text" />
              <span>الدعم الفني</span>
            </button>
          </div>
        </div>
      )}

      {/* Store Review / Approval Status Banners */}
      {ownedStore.status === 'pending' && (
        <div className="flex items-start gap-3 rounded-2xl border border-sq-warning-border bg-sq-warning-bg p-4 text-xs sm:text-sm text-sq-warning-text">
          <Clock className="mt-0.5 h-5 w-5 shrink-0" />
          <div>
            <div className="font-bold">متجرك قيد المراجعة من قِبل المدير العام</div>
            <p className="mt-0.5 leading-relaxed">
              لن يظهر المتجر للزبائن في دليل المتاجر حتى تتم الموافقة عليه. يمكنك الآن تجهيز وإضافة
              منتجاتك وصورها وأسعارها لتكون جاهزة فور التفعيل.
            </p>
          </div>
        </div>
      )}

      {ownedStore.status === 'rejected' && (
        <div className="flex flex-col gap-3 rounded-2xl border border-sq-danger-border bg-sq-danger-bg p-4 text-xs sm:text-sm text-sq-danger-text sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
            <div>
              <div className="font-bold">تم رفض طلب تسجيل المتجر</div>
              <p className="mt-0.5 leading-relaxed">
                {ownedStore.rejectionReason
                  ? `سبب الرفض: ${ownedStore.rejectionReason}`
                  : 'يرجى مراجعة وتحديث بيانات المتجر ثم إعادة إرسال الطلب للمراجعة.'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className="inline-flex min-h-[40px] shrink-0 items-center justify-center gap-1.5 rounded-xl bg-[#B42318] px-4 text-xs font-semibold text-white hover:bg-[#912018]"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>تعديل وإعادة الإرسال</span>
          </button>
        </div>
      )}

      {ownedStore.status === 'suspended' && (
        <div className="flex items-start gap-3 rounded-2xl border border-sq-danger-border bg-sq-danger-bg p-4 text-xs sm:text-sm text-sq-danger-text">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
          <div>
            <div className="font-bold">متجرك موقوف مؤقتاً</div>
            <p className="mt-0.5 leading-relaxed">
              تم إيقاف ظهور متجرك مؤقتاً من قِبل المدير العام. يرجى التواصل مع إدارة المنصة لإعادة
              تفعيله.
            </p>
          </div>
        </div>
      )}

      {/* Real KPI Summary Strip */}
      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
          <p className="text-xs text-sq-ink-muted">إجمالي المنتجات</p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-sq-ink tabular-nums">
            {products.length}
          </p>
        </div>
        <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
          <p className="text-xs text-sq-ink-muted">طلبات جديدة (بانتظار التأكيد)</p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-sq-warning-text tabular-nums">
            {pendingOrdersCount}
          </p>
        </div>
        <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
          <p className="text-xs text-sq-ink-muted">طلبات مُسلّمة نقداً</p>
          <p className="mt-1.5 font-mono text-2xl font-bold text-sq-gold-text tabular-nums">
            {deliveredOrdersCount}
          </p>
        </div>
        <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
          <p className="text-xs text-sq-ink-muted">إجمالي الطلبات النقدية</p>
          <p className="mt-1.5 font-mono text-xl sm:text-2xl font-bold text-sq-ink tabular-nums">
            {formatPrice(totalCashRevenue, bootstrapStatus.currency)}
          </p>
        </div>
      </div>

      {/* Dashboard Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto rounded-xl bg-sq-muted p-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('products')}
            className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'products'
                ? 'bg-sq-surface text-sq-ink shadow-xs'
                : 'text-sq-ink-muted hover:text-sq-ink'
            }`}
          >
            المنتجات ({products.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('posts')}
            className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'posts'
                ? 'bg-[#121413] text-[#EBD18E] shadow-xs'
                : 'text-sq-ink-muted hover:text-sq-ink'
            }`}
          >
            المنشورات والعروض ({posts.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('orders')}
            className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'orders'
                ? 'bg-sq-surface text-sq-ink shadow-xs'
                : 'text-sq-ink-muted hover:text-sq-ink'
            }`}
          >
            الطلبات الواردة ({orders.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'settings'
                ? 'bg-sq-surface text-sq-ink shadow-xs'
                : 'text-sq-ink-muted hover:text-sq-ink'
            }`}
          >
            إعدادات المتجر
          </button>
        </div>

        {activeTab === 'products' && (
          <button
            type="button"
            onClick={openNewProductModal}
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl btn-gold px-4 py-2 text-sm font-semibold whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>إضافة منتج جديد</span>
          </button>
        )}
      </div>

      {loadingData ? (
        <div className="flex min-h-[200px] items-center justify-center gap-2 text-sm text-sq-ink-muted">
          <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
          <span>جاري تحميل بيانات المتجر...</span>
        </div>
      ) : activeTab === 'posts' ? (
        <MerchantPostsSection
          store={ownedStore}
          posts={posts}
          onRefresh={loadMerchantData}
          onOpenStore={openStore}
          notify={notify}
        />
      ) : activeTab === 'products' ? (
        products.length === 0 ? (
          <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
            <Package className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/60" />
            <h2 className="font-display text-lg font-bold text-sq-ink">
              لم تضف أي منتجات بعد
            </h2>
            <p className="mt-2 text-sm text-sq-ink-muted">
              أضف منتجات متجرك وصوّرها مباشرة من هاتفك لتظهر فوراً لجميع المتسوقين على سوقنا.
            </p>
            <button
              type="button"
              onClick={openNewProductModal}
              className="mt-5 min-h-[46px] rounded-xl btn-gold px-6 py-2.5 text-sm font-semibold"
            >
              إضافة أول منتج
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => (
              <div
                key={product.id}
                className="flex flex-col overflow-hidden rounded-2xl border border-sq-border bg-sq-surface"
              >
                <div className="aspect-4/3 w-full overflow-hidden bg-sq-muted">
                  {product.imageUrl ? (
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-sq-ink-muted/50">
                      <Package className="h-8 w-8" />
                    </div>
                  )}
                </div>

                <div className="flex flex-1 flex-col p-4">
                  <div className="flex items-center justify-between gap-2 text-xs text-sq-ink-muted">
                    <span>
                      {product.category} · {product.unit}
                    </span>
                    <span
                      className={
                        product.isAvailable
                          ? 'font-semibold text-sq-gold-text'
                          : 'font-semibold text-sq-danger-text'
                      }
                    >
                      {product.isAvailable ? 'متوفر' : 'مخفي'}
                    </span>
                  </div>

                  <h3 className="mt-1 font-display text-base font-bold text-sq-ink">
                    {product.name}
                  </h3>

                  <div className="mt-2 space-y-1 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-sq-ink-muted">سعر {product.unit}</span>
                      <span className="font-mono font-bold text-sq-ink tabular-nums">
                        {formatPrice(product.price, bootstrapStatus.currency)}
                      </span>
                    </div>
                    {product.cartonPrice > 0 && (
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-sq-gold-text">
                          سعر الكارتون ({product.cartonUnits})
                        </span>
                        <span className="font-mono font-bold text-sq-gold-text tabular-nums">
                          {formatPrice(product.cartonPrice, bootstrapStatus.currency)}
                        </span>
                      </div>
                    )}
                    <div className="text-xs text-sq-ink-muted tabular-nums">
                      المخزون: {product.stockQty}
                    </div>
                    {product.gameName && (
                      <div className="text-[11px] font-semibold text-sq-gold-text">
                        اللعبة: {product.gameName}
                      </div>
                    )}
                    {product.availableSizes && product.availableSizes.length > 0 && (
                      <div className="text-[11px] text-sq-ink-muted truncate">
                        المقاسات: {product.availableSizes.join('، ')}
                      </div>
                    )}
                    {product.availableColors && product.availableColors.length > 0 && (
                      <div className="text-[11px] text-sq-ink-muted truncate">
                        الألوان: {product.availableColors.join('، ')}
                      </div>
                    )}
                    {product.compatibleModels && product.compatibleModels.length > 0 && (
                      <div className="text-[11px] text-sq-ink-muted truncate">
                        الموديلات: {product.compatibleModels.join('، ')}
                      </div>
                    )}
                  </div>

                  <div className="mt-4 flex items-center gap-2 border-t border-sq-border pt-3">
                    <button
                      type="button"
                      onClick={() => openEditProductModal(product)}
                      className="inline-flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-xl border border-sq-border px-3 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                      <span>تعديل</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleToggleProductAvailability(product)}
                      className="inline-flex min-h-[40px] flex-1 items-center justify-center rounded-xl border border-sq-border px-3 text-xs font-semibold text-sq-ink-muted hover:bg-sq-muted"
                    >
                      {product.isAvailable ? 'إخفاء' : 'إظهار'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteProductTarget(product)}
                      aria-label="حذف المنتج"
                      className="flex h-10 w-10 items-center justify-center rounded-xl border border-sq-danger-border text-sq-danger-text hover:bg-sq-danger-bg"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : activeTab === 'orders' ? (
        orders.length === 0 ? (
          <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center text-sm text-sq-ink-muted">
            لم تصل طلبات إلى متجرك بعد. ستظهر هنا جميع الطلبات النقدية الواردة فور إرسالها من
            الزبائن.
          </div>
        ) : (
          <div className="space-y-4">
            {/* Merchant Orders Status Filter Bar */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {(
                [
                  { key: 'all', label: `الكل (${orders.length})` },
                  {
                    key: 'pending',
                    label: `الطلبات الجديدة (${orders.filter((o) => o.status === 'pending').length})`,
                  },
                  {
                    key: 'in_progress',
                    label: `قيد التنفيذ (${
                      orders.filter(
                        (o) =>
                          o.status === 'confirmed' ||
                          o.status === 'preparing' ||
                          o.status === 'ready' ||
                          o.status === 'out_for_delivery'
                      ).length
                    })`,
                  },
                  {
                    key: 'delivered',
                    label: `مكتمل (${orders.filter((o) => o.status === 'delivered').length})`,
                  },
                  {
                    key: 'closed',
                    label: `ملغي / مرفوض (${
                      orders.filter((o) => o.status === 'cancelled' || o.status === 'rejected')
                        .length
                    })`,
                  },
                ] as const
              ).map((f) => (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setOrderFilter(f.key)}
                  className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    orderFilter === f.key
                      ? 'bg-sq-gold text-[#0B0C0C]'
                      : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {filteredOrders.length === 0 ? (
              <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
                لا توجد طلبات في هذا التصنيف حالياً.
              </div>
            ) : (
              filteredOrders.map((order) => {
                const isFocused = focusedOrderId === order.id;
                const cancelRequestEvent = (order.events || [])
                  .slice()
                  .reverse()
                  .find((ev) => ev.eventType === 'cancel_requested');

              return (
                <div
                  key={order.id}
                  id={`merchant-order-${order.id}`}
                  className={`overflow-hidden rounded-2xl border bg-sq-surface transition-all ${
                    isFocused
                      ? 'border-sq-gold ring-2 ring-sq-gold/30 shadow-md'
                      : 'border-sq-border'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-sq-border bg-sq-elevated px-5 py-3.5 text-xs">
                    <div className="flex flex-wrap items-center gap-2 text-sq-ink-muted">
                      <span className="font-mono text-sm font-bold text-sq-ink">
                        {order.orderNumber}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-sq-ink">{order.customerName}</span>
                      <span aria-hidden="true">·</span>
                      <span dir="ltr" className="font-mono">
                        {order.customerPhone}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{formatDateAr(order.createdAt)}</span>
                    </div>
                    <span
                      className={`font-bold ${
                        order.status === 'cancelled' || order.status === 'rejected'
                          ? 'text-sq-danger-text'
                          : order.status === 'delivered'
                          ? 'text-sq-gold-text'
                          : 'text-sq-warning-text'
                      }`}
                    >
                      {ORDER_STATUS_LABELS[order.status]}
                    </span>
                  </div>

                  {/* Urgent Customer Cancel Request Banner */}
                  {cancelRequestEvent &&
                    order.status !== 'cancelled' &&
                    order.status !== 'rejected' &&
                    order.status !== 'delivered' && (
                      <div className="mx-5 mt-4 flex items-start gap-2.5 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-4 py-3 text-xs text-sq-warning-text">
                        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                        <div className="space-y-0.5">
                          <div className="font-bold">طلب إلغاء عاجل من الزبون بعد بدء التجهيز</div>
                          <div>السبب المسجل: {cancelRequestEvent.reason}</div>
                        </div>
                      </div>
                    )}

                  {/* Cancellation / Rejection Details */}
                  {(order.status === 'cancelled' || order.status === 'rejected') && (
                    <div className="mx-5 mt-4 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 py-3 text-xs text-sq-danger-text space-y-1">
                      <div className="font-bold">
                        {order.status === 'cancelled' ? 'طلب ملغي' : 'طلب مرفوض'} (لا يُحتسب ضمن
                        المبيعات)
                      </div>
                      {order.cancelReason && (
                        <div>
                          <strong>السبب:</strong> {order.cancelReason}
                        </div>
                      )}
                      {order.cancelledByName && (
                        <div className="text-[11px] opacity-90">
                          بواسطة: {order.cancelledByName}
                          {order.cancelledByRole &&
                          ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]
                            ? ` (${ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]})`
                            : ''}
                          {order.cancelledAt ? ` · ${formatDateAr(order.cancelledAt)}` : ''}
                          {order.stockRestored ? ' · أُعيدت الكمية إلى المخزون' : ''}
                        </div>
                      )}
                    </div>
                  )}

                  <div className="p-5 space-y-3">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-sq-gold-text">
                      <span>طريقة الاستلام: {FULFILLMENT_LABELS[order.fulfillmentMethod]}</span>
                      {order.latitude !== null && order.longitude !== null && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span dir="ltr" className="font-mono text-sq-ink-muted">
                            GPS: {order.latitude.toFixed(5)}, {order.longitude.toFixed(5)}
                          </span>
                        </>
                      )}
                    </div>

                    <p className="text-xs text-sq-ink-muted">
                      <strong>العنوان:</strong>{' '}
                      {[
                        order.governorate,
                        order.city,
                        order.district,
                        order.neighborhood,
                        order.deliveryAddress,
                      ]
                        .filter(Boolean)
                        .join(' — ')}
                      {order.notes ? ` — ملاحظة الزبون: ${order.notes}` : ''}
                    </p>

                    <div className="divide-y divide-sq-border">
                      {order.items.map((item) => {
                        const optTags = formatOrderItemOptionsSummary(item.selectedOptions);
                        const printJob = item.selectedOptions?.printJob;
                        return (
                          <div key={item.id} className="py-2.5 space-y-1.5 text-sm">
                            <div className="flex justify-between gap-2">
                              <span>
                                <strong>{item.productName}</strong> ({item.quantity} × {item.unit} ·{' '}
                                {formatPrice(item.unitPrice, bootstrapStatus.currency)})
                              </span>
                              <span className="font-mono text-xs font-semibold tabular-nums shrink-0">
                                {formatPrice(item.lineTotal, bootstrapStatus.currency)}
                              </span>
                            </div>
                            {optTags.length > 0 && (
                              <div className="flex flex-wrap gap-1.5 text-[11px] font-medium text-sq-gold-text">
                                {optTags.map((tag, idx) => (
                                  <span
                                    key={idx}
                                    className="rounded-md border border-sq-gold/35 bg-sq-gold-soft px-2 py-0.5"
                                  >
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            )}
                            {printJob?.fileUrl && (
                              <div className="pt-1">
                                <a
                                  href={printJob.fileUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  download={printJob.fileName}
                                  className="inline-flex min-h-[38px] items-center gap-2 rounded-xl btn-gold px-3.5 py-1.5 text-xs font-semibold"
                                >
                                  <FileText className="h-3.5 w-3.5" />
                                  <span className="truncate max-w-[220px]">
                                    فتح / تحميل ملف الطباعة ({printJob.fileName})
                                  </span>
                                  <Download className="h-3.5 w-3.5" />
                                </a>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Live Courier Delivery Card for Merchant */}
                    {order.delivery && (
                      <div className="rounded-2xl border border-sq-gold/35 bg-sq-gold-soft/55 p-4 space-y-2.5 text-xs">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <Bike className="h-4 w-4 text-sq-gold-text" />
                            <span className="font-display text-sm font-bold text-sq-ink">
                              طلب توصيل المندوب
                            </span>
                            <span className="font-mono text-sq-ink-muted">
                              {order.delivery.deliveryNumber}
                            </span>
                          </div>
                          <span
                            className={`font-bold ${
                              order.delivery.status === 'delivered'
                                ? 'text-sq-gold-text'
                                : order.delivery.status === 'cancelled'
                                ? 'text-sq-danger-text'
                                : 'text-sq-warning-text'
                            }`}
                          >
                            {DELIVERY_STATUS_LABELS[order.delivery.status]}
                          </span>
                        </div>

                        {order.delivery.courierName ? (
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sq-ink">
                            <span>
                              <strong>المندوب المعين:</strong> {order.delivery.courierName}
                            </span>
                            {order.delivery.courierPhone && (
                              <span className="inline-flex items-center gap-1">
                                <Phone className="h-3.5 w-3.5 text-sq-gold-text" />
                                <span dir="ltr" className="font-mono font-semibold">
                                  {order.delivery.courierPhone}
                                </span>
                              </span>
                            )}
                            {order.delivery.courierVehicleType && (
                              <span className="text-sq-ink-muted">
                                المركبة: {COURIER_VEHICLE_LABELS[order.delivery.courierVehicleType]}
                                {order.delivery.courierPlateNumber
                                  ? ` (${order.delivery.courierPlateNumber})`
                                  : ''}
                              </span>
                            )}
                            {order.delivery.distanceKm !== null && (
                              <span className="font-mono text-sq-gold-text tabular-nums">
                                المسافة: {order.delivery.distanceKm.toFixed(1)} كم
                              </span>
                            )}
                          </div>
                        ) : (
                          <p className="text-sq-ink-muted">
                            تم بث طلب التوصيل لأقرب المندوبين الموثقين والمتاحين — بانتظار قبول
                            مندوب.
                          </p>
                        )}

                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-sq-ink-muted">
                          {order.delivery.acceptedAt && (
                            <span>قُبل: {formatDateAr(order.delivery.acceptedAt)}</span>
                          )}
                          {order.delivery.pickedUpAt && (
                            <span>استُلم من المتجر: {formatDateAr(order.delivery.pickedUpAt)}</span>
                          )}
                          {order.delivery.deliveredAt && (
                            <span className="font-semibold text-sq-gold-text">
                              سُلّم للزبون برمز OTP: {formatDateAr(order.delivery.deliveredAt)}
                            </span>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2 pt-1">
                          {order.delivery.status !== 'delivered' &&
                            order.delivery.status !== 'cancelled' && (
                              <button
                                type="button"
                                disabled={cancellingDeliveryOrderId === order.id}
                                onClick={() => handleCancelDelivery(order)}
                                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-sq-danger-border bg-sq-surface px-3 text-xs font-semibold text-sq-danger-text hover:bg-sq-danger-bg disabled:opacity-60"
                              >
                                {cancellingDeliveryOrderId === order.id ? (
                                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                ) : (
                                  <XCircle className="h-3.5 w-3.5" />
                                )}
                                <span>إلغاء طلب المندوب</span>
                              </button>
                            )}

                          {order.delivery.courierId && (
                            <button
                              type="button"
                              onClick={() =>
                                setComplaintTarget({
                                  targetId: order.delivery!.courierId!,
                                  targetName: `المندوب ${order.delivery!.courierName || ''} (${order.delivery!.deliveryNumber})`,
                                  orderId: order.id,
                                  deliveryId: order.delivery!.id,
                                })
                              }
                              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink-muted hover:border-sq-danger-border hover:text-sq-danger-text"
                            >
                              <Flag className="h-3.5 w-3.5" />
                              <span>شكوى على المندوب</span>
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {order.events && order.events.length > 0 && (
                      <details className="rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2 text-xs">
                        <summary className="cursor-pointer list-none flex items-center gap-1.5 font-semibold text-sq-ink-muted">
                          <History className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>سجل حركات الطلب ({order.events.length})</span>
                        </summary>
                        <div className="mt-2 space-y-1.5 border-t border-sq-border pt-2">
                          {order.events.map((ev) => (
                            <div
                              key={ev.id}
                              className="flex flex-wrap justify-between gap-2 text-[11px]"
                            >
                              <span className="text-sq-ink">
                                <strong>{EVENT_TYPE_LABELS[ev.eventType] || ev.eventType}</strong>
                                {ev.actorName ? ` · ${ev.actorName}` : ''}
                                {ev.reason ? ` — ${ev.reason}` : ''}
                              </span>
                              <span className="text-sq-ink-muted">{formatDateAr(ev.createdAt)}</span>
                            </div>
                          ))}
                        </div>
                      </details>
                    )}

                    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-sq-border pt-3">
                      <div className="space-y-0.5">
                        <div className="text-[11px] text-sq-ink-muted tabular-nums">
                          المنتجات: {formatPrice(order.subtotal, bootstrapStatus.currency)} ·
                          التوصيل:{' '}
                          {order.deliveryFee > 0
                            ? formatPrice(order.deliveryFee, bootstrapStatus.currency)
                            : 'مجاني'}
                        </div>
                        <div className="flex items-center gap-2 text-sm font-bold text-sq-gold-text">
                          <Banknote className="h-4 w-4" />
                          <span className="font-mono tabular-nums">
                            تحصيل نقدي: {formatPrice(order.totalAmount, bootstrapStatus.currency)}
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={() => setInvoiceOrder(order)}
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                        >
                          <ReceiptText className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>الفاتورة</span>
                        </button>

                        {/* Merchant-Only Courier Dispatch Button (ONLY for delivery orders, never pickup) */}
                        {order.fulfillmentMethod === 'delivery' &&
                          (order.status === 'pending' ||
                            order.status === 'confirmed' ||
                            order.status === 'preparing' ||
                            order.status === 'ready') &&
                          (!order.delivery || order.delivery.status === 'cancelled') && (
                            <button
                              type="button"
                              disabled={dispatchingOrderId === order.id}
                              onClick={() => handleRequestCourier(order)}
                              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-gold bg-sq-gold-soft px-3.5 text-xs font-bold text-sq-gold-text hover:bg-sq-gold-soft disabled:opacity-60"
                            >
                              {dispatchingOrderId === order.id ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              ) : (
                                <Bike className="h-4 w-4" />
                              )}
                              <span>طلب مندوب للتوصيل</span>
                            </button>
                          )}

                        {order.status !== 'delivered' &&
                          order.status !== 'cancelled' &&
                          order.status !== 'rejected' && (
                            <>
                              {order.status === 'pending' && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => handleOrderStatus(order.id, 'confirmed')}
                                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold"
                                  >
                                    <CheckCircle2 className="h-3.5 w-3.5" />
                                    <span>قبول الطلب</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => openOrderCloseDialog(order, 'rejected')}
                                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 text-xs font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
                                  >
                                    <XCircle className="h-3.5 w-3.5" />
                                    <span>رفض الطلب</span>
                                  </button>
                                </>
                              )}
                              {order.status === 'confirmed' && (
                                <button
                                  type="button"
                                  onClick={() => handleOrderStatus(order.id, 'preparing')}
                                  className="min-h-[40px] rounded-xl btn-gold px-3.5 text-xs font-semibold"
                                >
                                  قيد التجهيز
                                </button>
                              )}
                              {order.status === 'preparing' && (
                                <button
                                  type="button"
                                  onClick={() => handleOrderStatus(order.id, 'ready')}
                                  className="min-h-[40px] rounded-xl btn-gold px-3.5 text-xs font-semibold"
                                >
                                  جاهز
                                </button>
                              )}
                              {order.status === 'ready' &&
                                order.fulfillmentMethod === 'delivery' &&
                                (!order.delivery || order.delivery.status === 'cancelled') && (
                                  <button
                                    type="button"
                                    onClick={() => handleOrderStatus(order.id, 'out_for_delivery')}
                                    className="min-h-[40px] rounded-xl btn-gold px-3.5 text-xs font-semibold"
                                  >
                                    قيد التوصيل (توصيل المتجر)
                                  </button>
                                )}
                              {(order.status === 'out_for_delivery' ||
                                order.status === 'ready') &&
                                (!order.delivery || order.delivery.status === 'cancelled') && (
                                  <button
                                    type="button"
                                    onClick={() => handleOrderStatus(order.id, 'delivered')}
                                    className="min-h-[40px] rounded-xl btn-gold px-3.5 text-xs font-semibold"
                                  >
                                    مكتمل (تم التسليم والتحصيل النقدي)
                                  </button>
                                )}
                              {order.status !== 'pending' && (
                                <button
                                  type="button"
                                  onClick={() => openOrderCloseDialog(order, 'cancelled')}
                                  className="min-h-[40px] rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 text-xs font-semibold text-sq-danger-text"
                                >
                                  إلغاء الطلب
                                </button>
                              )}
                            </>
                          )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
            )}
          </div>
        )
      ) : (
        /* Settings Tab */
        <form
          onSubmit={handleSaveStore}
          className="rounded-3xl border border-sq-border bg-sq-surface p-6 space-y-4 max-w-3xl"
        >
          <h2 className="font-display text-lg font-bold text-sq-ink">تعديل بيانات المتجر</h2>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">اسم المتجر</label>
              <input
                type="text"
                required
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">نوع النشاط</label>
              <select
                value={storeType}
                onChange={(e) => setStoreType(e.target.value as StoreType)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              >
                {STORE_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {STORE_TYPE_LABELS[t]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">وصف المتجر</label>
            <textarea
              rows={2}
              value={storeDesc}
              onChange={(e) => setStoreDesc(e.target.value)}
              className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المدينة</label>
              <input
                type="text"
                required
                value={storeCity}
                onChange={(e) => setStoreCity(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المنطقة</label>
              <input
                type="text"
                value={storeDistrict}
                onChange={(e) => setStoreDistrict(e.target.value)}
                placeholder="المنطقة"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">رقم الهاتف</label>
              <input
                type="tel"
                required
                dir="ltr"
                value={storePhone}
                onChange={(e) => setStorePhone(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">العنوان</label>
            <input
              type="text"
              required
              value={storeAddress}
              onChange={(e) => setStoreAddress(e.target.value)}
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">ساعات العمل</label>
              <input
                type="text"
                value={openingHours}
                onChange={(e) => setOpeningHours(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                رسوم التوصيل ({bootstrapStatus.currency})
              </label>
              <input
                type="number"
                min={0}
                step="0.5"
                value={deliveryFee}
                onChange={(e) => setDeliveryFee(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                الحد الأدنى ({bootstrapStatus.currency})
              </label>
              <input
                type="number"
                min={0}
                step="1"
                value={minOrderAmount}
                onChange={(e) => setMinOrderAmount(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <ImageUploader
              label="شعار المتجر"
              value={logoUrl}
              onChange={setLogoUrl}
              aspect="square"
            />
            <ImageUploader
              label="صورة غلاف المتجر"
              value={coverUrl}
              onChange={setCoverUrl}
              aspect="wide"
            />
          </div>

          {/* Store GPS Location for Nearest-Courier Matching */}
          <div className="rounded-2xl border border-sq-border bg-sq-elevated p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-sq-gold-text" />
                <div>
                  <div className="text-xs font-bold text-sq-ink">
                    الموقع الجغرافي للمتجر (GPS) — لتوجيه أقرب مندوب توصيل
                  </div>
                  <div className="text-[11px] text-sq-ink-muted">
                    يُستخدم تلقائياً عند الضغط على «طلب مندوب للتوصيل» لحساب أقرب المندوبين إليك
                  </div>
                </div>
              </div>
              <button
                type="button"
                disabled={locatingStore}
                onClick={handleCaptureStoreLocation}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold disabled:opacity-60"
              >
                {locatingStore ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Crosshair className="h-3.5 w-3.5" />
                )}
                <span>التقاط موقع المتجر</span>
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                dir="ltr"
                value={storeLat}
                onChange={(e) => setStoreLat(e.target.value)}
                placeholder="Latitude (مثال: 33.3152)"
                className="min-h-[40px] rounded-xl border border-sq-border bg-sq-surface px-3 text-left font-mono text-xs focus:border-sq-gold focus:outline-none"
              />
              <input
                type="text"
                dir="ltr"
                value={storeLng}
                onChange={(e) => setStoreLng(e.target.value)}
                placeholder="Longitude (مثال: 44.3661)"
                className="min-h-[40px] rounded-xl border border-sq-border bg-sq-surface px-3 text-left font-mono text-xs focus:border-sq-gold focus:outline-none"
              />
            </div>
          </div>

          {storeType === 'printing' && renderPrintPricingSection()}

          {/* Store Visit Anonymous Notification Toggle */}
          <label className="flex cursor-pointer items-start gap-3 rounded-2xl border border-sq-border bg-sq-elevated p-4">
            <input
              type="checkbox"
              checked={notifyOnStoreVisit}
              onChange={(e) => setNotifyOnStoreVisit(e.target.checked)}
              className="mt-1 h-4 w-4 accent-[#D4AF37]"
            />
            <span className="space-y-0.5 text-xs sm:text-sm">
              <span className="flex items-center gap-1.5 font-bold text-sq-ink">
                <Eye className="h-4 w-4 text-sq-gold-text" />
                <span>تفعيل إشعار زيارة المتجر (تنبيه تصفح فوري)</span>
              </span>
              <span className="block text-xs leading-relaxed text-sq-ink-muted">
                استلم إشعاراً فورياً عند دخول زبون إلى صفحة متجرك وتصفح المنتجات حالياً. يحترم
                النظام خصوصية الزبون بالكامل ولا يعرض أي بيانات شخصية عنه، مع منع التكرار المزعج.
              </span>
            </span>
          </label>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="submit"
              disabled={savingStore}
              className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl btn-gold px-6 py-3 text-sm font-semibold disabled:opacity-60"
            >
              {savingStore && <Loader2 className="h-4 w-4 animate-spin" />}
              <span>حفظ تعديلات المتجر</span>
            </button>

            {ownedStore.status === 'rejected' && (
              <button
                type="button"
                disabled={savingStore}
                onClick={(e) => handleSaveStore(e, true)}
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-sq-gold bg-sq-gold-soft px-6 py-3 text-sm font-semibold text-sq-gold-text hover:bg-sq-gold-soft disabled:opacity-60"
              >
                <RefreshCw className="h-4 w-4" />
                <span>حفظ وإعادة إرسال للمراجعة</span>
              </button>
            )}
          </div>
        </form>
      )}

      {/* Add / Edit Product Bottom Sheet / Modal */}
      {showProductForm && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs">
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-sq-ink">
                {editingProduct ? 'تعديل المنتج' : 'إضافة منتج جديد'}
              </h2>
              <button
                type="button"
                onClick={() => setShowProductForm(false)}
                aria-label="إغلاق"
                className="flex h-10 w-10 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <ImageUploader
                label="صورة المنتج (رفع من الهاتف أو الكاميرا)"
                value={prodImage}
                onChange={setProdImage}
                aspect="wide"
              />

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  {activeStoreType === 'gaming_topup'
                    ? 'اسم الباقة (مثال: شحن 660 UC أو 520 جوهرة)'
                    : 'اسم المنتج'}
                </label>
                <input
                  type="text"
                  required
                  value={prodName}
                  onChange={(e) => setProdName(e.target.value)}
                  placeholder={
                    activeStoreType === 'gaming_topup'
                      ? 'مثال: باقة 660 شدة PUBG Mobile'
                      : activeStoreType === 'construction'
                      ? 'مثال: إسمنت مقاوم 50 كغم'
                      : activeStoreType === 'clothing'
                      ? 'مثال: قميص قطن رجالي كلاسيك'
                      : activeStoreType === 'phone_accessories'
                      ? 'مثال: كفر حماية شفاف مضاد للصدمات'
                      : 'مثال: زيت زيتون بكر ممتاز 1 لتر'
                  }
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>

              {activeStoreType === 'gaming_topup' && (
                <div className="rounded-xl border border-sq-gold/35 bg-sq-gold-soft/60 p-3.5 space-y-2">
                  <label className="flex items-center gap-1.5 text-xs font-bold text-sq-gold-text">
                    <Gamepad2 className="h-4 w-4" />
                    <span>اختر اللعبة</span>
                  </label>
                  <select
                    value={POPULAR_GAMES.includes(prodGameName) ? prodGameName : '__custom'}
                    onChange={(e) => {
                      if (e.target.value !== '__custom') setProdGameName(e.target.value);
                    }}
                    className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-sm focus:border-sq-gold focus:outline-none"
                  >
                    {POPULAR_GAMES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                    <option value="__custom">لعبة أخرى (اكتب الاسم أدناه)</option>
                  </select>
                  <input
                    type="text"
                    value={prodGameName}
                    onChange={(e) => setProdGameName(e.target.value)}
                    placeholder="اسم اللعبة (مثال: PUBG Mobile أو Free Fire)"
                    className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs focus:border-sq-gold focus:outline-none"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">القسم</label>
                  <select
                    value={prodCategory}
                    onChange={(e) => setProdCategory(e.target.value)}
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  >
                    {Array.from(new Set([...verticalCategories, prodCategory].filter(Boolean))).map(
                      (cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      )
                    )}
                  </select>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">الوحدة</label>
                  <select
                    value={prodUnit}
                    onChange={(e) => setProdUnit(e.target.value)}
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  >
                    {Array.from(new Set([...verticalUnits, prodUnit].filter(Boolean))).map(
                      (unit) => (
                        <option key={unit} value={unit}>
                          {unit}
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                    {activeStoreType === 'gaming_topup'
                      ? `سعر الباقة النقدي (${bootstrapStatus.currency})`
                      : `سعر المفرد (${bootstrapStatus.currency})`}
                  </label>
                  <input
                    type="number"
                    required
                    min={0.01}
                    step="0.01"
                    value={prodPrice}
                    onChange={(e) => setProdPrice(e.target.value)}
                    placeholder="0.00"
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                    الكمية بالمخزون
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={prodStock}
                    onChange={(e) => setProdStock(e.target.value)}
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>
              </div>

              {activeStoreType !== 'gaming_topup' && (
                <div className="grid grid-cols-2 gap-3 rounded-xl border border-sq-border bg-sq-elevated p-3">
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-sq-gold-text">
                      سعر الكارتون / الجملة ({bootstrapStatus.currency}) — اختياري
                    </label>
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      value={prodCartonPrice}
                      onChange={(e) => setProdCartonPrice(e.target.value)}
                      placeholder="اتركه فارغاً إن لم يتوفر"
                      className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-sm focus:border-sq-gold focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-sq-ink">
                      عدد القطع في الكارتون
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={prodCartonUnits}
                      onChange={(e) => setProdCartonUnits(e.target.value)}
                      placeholder="12 أو 24"
                      className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-sm focus:border-sq-gold focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {/* Clothing Variants: Sizes & Colors */}
              {activeStoreType === 'clothing' && (
                <div className="space-y-3 rounded-xl border border-sq-gold/35 bg-sq-gold-soft/45 p-3.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-sq-gold-text">
                    <Shirt className="h-4 w-4" />
                    <span>المقاسات والألوان المتوفرة لهذا المنتج</span>
                  </div>

                  <div className="space-y-1.5">
                    <div className="text-[11px] font-semibold text-sq-ink">المقاسات:</div>
                    <div className="flex flex-wrap gap-1.5">
                      {Array.from(new Set([...CLOTHING_SIZE_PRESETS, ...prodSizes])).map((sz) => {
                        const active = prodSizes.includes(sz);
                        return (
                          <button
                            key={sz}
                            type="button"
                            onClick={() => toggleChip(prodSizes, setProdSizes, sz)}
                            className={`min-h-[32px] rounded-lg border px-2.5 text-xs font-semibold transition-colors ${
                              active
                                ? 'border-sq-gold bg-sq-gold text-[#0B0C0C]'
                                : 'border-sq-border bg-sq-surface text-sq-ink hover:border-sq-gold'
                            }`}
                          >
                            {sz}
                          </button>
                        );
                      })}
                    </div>
                    <div className="flex gap-1.5 pt-1">
                      <input
                        type="text"
                        value={customSizeInput}
                        onChange={(e) => setCustomSizeInput(e.target.value)}
                        placeholder="أضف مقاساً آخر (مثال: 45، 6 سنوات)"
                        className="min-h-[36px] flex-1 rounded-lg border border-sq-border bg-sq-surface px-2.5 text-xs focus:border-sq-gold focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          addCustomChip(customSizeInput, setCustomSizeInput, prodSizes, setProdSizes)
                        }
                        className="min-h-[36px] rounded-lg bg-sq-gold px-3 text-xs font-semibold text-[#0B0C0C]"
                      >
                        إضافة
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5 border-t border-sq-gold/35/70 pt-2.5">
                    <div className="text-[11px] font-semibold text-sq-ink">الألوان:</div>
                    <div className="flex flex-wrap gap-1.5">
                      {Array.from(new Set([...CLOTHING_COLOR_PRESETS, ...prodColors])).map((col) => {
                        const active = prodColors.includes(col);
                        return (
                          <button
                            key={col}
                            type="button"
                            onClick={() => toggleChip(prodColors, setProdColors, col)}
                            className={`min-h-[32px] rounded-lg border px-2.5 text-xs font-semibold transition-colors ${
                              active
                                ? 'border-sq-gold bg-sq-gold text-[#0B0C0C]'
                                : 'border-sq-border bg-sq-surface text-sq-ink hover:border-sq-gold'
                            }`}
                          >
                            {col}
                          </button>
                        );
                      })}
                    </div>
                    <div className="flex gap-1.5 pt-1">
                      <input
                        type="text"
                        value={customColorInput}
                        onChange={(e) => setCustomColorInput(e.target.value)}
                        placeholder="أضف لوناً آخر (مثال: زيتوني، سماوي)"
                        className="min-h-[36px] flex-1 rounded-lg border border-sq-border bg-sq-surface px-2.5 text-xs focus:border-sq-gold focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          addCustomChip(
                            customColorInput,
                            setCustomColorInput,
                            prodColors,
                            setProdColors
                          )
                        }
                        className="min-h-[36px] rounded-lg bg-sq-gold px-3 text-xs font-semibold text-[#0B0C0C]"
                      >
                        إضافة
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Phone Accessories: Compatible Phone Models */}
              {activeStoreType === 'phone_accessories' && (
                <div className="space-y-2.5 rounded-xl border border-sq-gold/35 bg-sq-gold-soft/45 p-3.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-sq-gold-text">
                    <Smartphone className="h-4 w-4" />
                    <span>موديلات الهواتف المتوافقة مع هذا المنتج</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {Array.from(new Set([...PHONE_MODEL_PRESETS, ...prodPhoneModels])).map((m) => {
                      const active = prodPhoneModels.includes(m);
                      return (
                        <button
                          key={m}
                          type="button"
                          onClick={() => toggleChip(prodPhoneModels, setProdPhoneModels, m)}
                          className={`min-h-[32px] rounded-lg border px-2.5 text-[11px] font-semibold transition-colors ${
                            active
                              ? 'border-sq-gold bg-sq-gold text-[#0B0C0C]'
                              : 'border-sq-border bg-sq-surface text-sq-ink hover:border-sq-gold'
                          }`}
                        >
                          {m}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={customModelInput}
                      onChange={(e) => setCustomModelInput(e.target.value)}
                      placeholder="أضف موديلاً آخر (مثال: iPhone 16 Pro، Honor 90)"
                      className="min-h-[36px] flex-1 rounded-lg border border-sq-border bg-sq-surface px-2.5 text-xs focus:border-sq-gold focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        addCustomChip(
                          customModelInput,
                          setCustomModelInput,
                          prodPhoneModels,
                          setProdPhoneModels
                        )
                      }
                      className="min-h-[36px] rounded-lg bg-sq-gold px-3 text-xs font-semibold text-[#0B0C0C]"
                    >
                      إضافة
                    </button>
                  </div>
                </div>
              )}

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  خيارات إضافية للزبون (اختياري — افصل بينها بفاصلة)
                </label>
                <input
                  type="text"
                  value={prodCustomOptionsText}
                  onChange={(e) => setProdCustomOptionsText(e.target.value)}
                  placeholder="مثال: أصلي، درجة أولى، مع كفالة"
                  className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-xs focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  وصف المنتج (اختياري)
                </label>
                <textarea
                  rows={2}
                  value={prodDesc}
                  onChange={(e) => setProdDesc(e.target.value)}
                  placeholder="تفاصيل الوزن، المنشأ، المواصفات، أو طريقة التسليم"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>

              <label className="flex items-center gap-2.5 text-sm font-medium text-sq-ink">
                <input
                  type="checkbox"
                  checked={prodAvailable}
                  onChange={(e) => setProdAvailable(e.target.checked)}
                  className="h-4 w-4 accent-[#D4AF37]"
                />
                <span>المنتج متوفر ومعروض للبيع حالياً</span>
              </label>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="submit"
                  disabled={savingProduct}
                  className="flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-xl btn-gold py-2.5 text-sm font-semibold disabled:opacity-60"
                >
                  {savingProduct && <Loader2 className="h-4 w-4 animate-spin" />}
                  <span>{editingProduct ? 'حفظ التغييرات' : 'إضافة المنتج'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowProductForm(false)}
                  className="min-h-[48px] rounded-xl border border-sq-border px-5 text-sm font-semibold text-sq-ink-muted hover:bg-sq-muted"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Product Delete Confirmation Modal (Undoable immediately after deletion) */}
      {deleteProductTarget && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-sm rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <h2 className="font-display text-base font-extrabold text-sq-ink">
              تأكيد حذف المنتج
            </h2>
            <p className="text-xs leading-relaxed text-sq-ink-muted">
              هل أنت متأكد من حذف المنتج «<strong>{deleteProductTarget.name}</strong>» من متجرك؟
              سيظهر لك زر <strong>تراجع (Undo)</strong> فور الحذف في حال قمت بالحذف بالخطأ.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setDeleteProductTarget(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={deletingProduct}
                onClick={handleConfirmDeleteProduct}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#B42318] text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
              >
                {deletingProduct && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>نعم، حذف المنتج</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Merchant Order Reject / Cancel Confirmation Modal with Reason & Stock Restoration */}
      {orderCloseModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-sq-border pb-3">
              <div>
                <h2 className="font-display text-base font-extrabold text-sq-ink">
                  {orderCloseModal.status === 'rejected' ? 'تأكيد رفض الطلب' : 'تأكيد إلغاء الطلب'}{' '}
                  {orderCloseModal.order.orderNumber}
                </h2>
                <p className="text-xs text-sq-ink-muted">
                  الزبون: {orderCloseModal.order.customerName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setOrderCloseModal(null)}
                aria-label="إغلاق"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="rounded-xl border border-sq-danger-border bg-sq-danger-bg p-3 text-xs text-sq-danger-text">
              تنبيه: هذا الإجراء نهائي ولا يمكن التراجع عنه من لوحة التاجر بعد تثبيته (إلا عبر
              المدير العام). سيتم إشعار الزبون تلقائياً.
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-semibold text-sq-ink">
                اختر سبباً سريعاً أو اكتب السبب بالتفصيل:
              </label>
              <div className="flex flex-wrap gap-1.5">
                {MERCHANT_CANCEL_REASON_PRESETS.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setOrderCloseReason(preset)}
                    className={`rounded-lg border px-2.5 py-1.5 text-[11px] font-semibold transition-colors ${
                      orderCloseReason === preset
                        ? 'border-[#B42318] bg-sq-danger-bg text-sq-danger-text'
                        : 'border-sq-border bg-sq-elevated text-sq-ink-muted hover:text-sq-ink'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                سبب {orderCloseModal.status === 'rejected' ? 'الرفض' : 'الإلغاء'} (يُحفظ في سجل
                الطلب ويُرسل للزبون)
              </label>
              <textarea
                rows={2}
                value={orderCloseReason}
                onChange={(e) => setOrderCloseReason(e.target.value)}
                placeholder="مثال: اشتباه في الطلب، نفاد أحد الأصناف، أو استجابة لطلب الزبون..."
                className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-xs focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <label className="flex items-center gap-2.5 text-xs font-semibold text-sq-ink">
              <input
                type="checkbox"
                checked={orderCloseRestoreStock}
                onChange={(e) => setOrderCloseRestoreStock(e.target.checked)}
                className="h-4 w-4 accent-[#D4AF37]"
              />
              <span>إعادة الكميات المحجوزة من هذا الطلب إلى المخزون تلقائياً</span>
            </label>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setOrderCloseModal(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
              >
                تراجع
              </button>
              <button
                type="button"
                disabled={submittingOrderClose}
                onClick={handleConfirmOrderClose}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#B42318] text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
              >
                {submittingOrderClose && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>
                  {orderCloseModal.status === 'rejected' ? 'تأكيد الرفض' : 'تأكيد الإلغاء'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {invoiceOrder && (
        <OrderInvoiceModal
          order={invoiceOrder}
          currency={bootstrapStatus.currency}
          onClose={() => setInvoiceOrder(null)}
        />
      )}

      {complaintTarget && (
        <ComplaintModal
          targetType="courier"
          targetId={complaintTarget.targetId}
          targetName={complaintTarget.targetName}
          orderId={complaintTarget.orderId}
          deliveryId={complaintTarget.deliveryId}
          onClose={() => setComplaintTarget(null)}
        />
      )}
    </div>
  );
};
