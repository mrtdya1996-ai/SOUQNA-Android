import React from 'react';
import { Loader2 } from 'lucide-react';
import { AppShell } from './components/AppShell';
import { SouqnaLogo } from './components/SouqnaLogo';
import { AppProvider, useApp } from './context/AppContext';
import { AccountView } from './views/AccountView';
import { AdminDashboardView } from './views/AdminDashboardView';
import { AuthView } from './views/AuthView';
import { CartCheckoutView } from './views/CartCheckoutView';
import { CourierDashboardView } from './views/CourierDashboardView';
import { CourierRegisterView } from './views/CourierRegisterView';
import { HomeView } from './views/HomeView';
import { MerchantDashboardView } from './views/MerchantDashboardView';
import { NotificationsView } from './views/NotificationsView';
import { OrdersView } from './views/OrdersView';
import { ProductsCatalogView } from './views/ProductsCatalogView';
import { StoreDetailView } from './views/StoreDetailView';
import { StoresDirectoryView } from './views/StoresDirectoryView';
import { SubscriptionView } from './views/SubscriptionView';
import { SupportView } from './views/SupportView';

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class ViewErrorBoundary extends React.Component<
  { resetKey: string; onGoHome: () => void; children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { resetKey: string; onGoHome: () => void; children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error instanceof Error ? error.message : 'Unexpected render error',
    };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    console.error('[SOUQNA ViewErrorBoundary]', error, info.componentStack);
  }

  componentDidUpdate(prevProps: { resetKey: string }): void {
    if (this.state.hasError && prevProps.resetKey !== this.props.resetKey) {
      this.setState({ hasError: false, errorMessage: '' });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="mx-auto max-w-md py-12 text-center">
          <div className="rounded-3xl border border-sq-gold-hairline bg-sq-surface p-7 space-y-4 shadow-xl">
            <h2 className="font-display text-lg font-extrabold text-sq-ink">
              تعذر عرض هذه الصفحة مؤقتاً
            </h2>
            <p className="text-sm text-sq-ink-muted leading-relaxed">
              حسابك وبياناتك محفوظة بأمان. يمكنك إعادة المحاولة أو العودة للرئيسية دون إغلاق التطبيق.
            </p>
            <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => this.setState({ hasError: false, errorMessage: '' })}
                className="min-h-[44px] flex-1 rounded-xl btn-gold px-4 text-sm font-bold"
              >
                إعادة المحاولة
              </button>
              <button
                type="button"
                onClick={() => {
                  this.setState({ hasError: false, errorMessage: '' });
                  this.props.onGoHome();
                }}
                className="min-h-[44px] flex-1 rounded-xl border border-sq-border bg-sq-elevated px-4 text-sm font-semibold text-sq-ink"
              >
                الصفحة الرئيسية
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const ActiveViewRouter: React.FC = () => {
  const { activeView, authReady, navigate } = useApp();

  if (!authReady) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
        <SouqnaLogo size="lg" />
        <div className="inline-flex items-center gap-2 rounded-xl border border-sq-gold-hairline bg-sq-surface px-4 py-2.5 text-xs font-semibold text-sq-ink-muted">
          <Loader2 className="h-4 w-4 animate-spin text-sq-gold-text" />
          <span>جاري استعادة جلستك المحفوظة...</span>
        </div>
      </div>
    );
  }

  let content: React.ReactNode;
  switch (activeView) {
    case 'stores':
      content = <StoresDirectoryView />;
      break;
    case 'products':
      content = <ProductsCatalogView />;
      break;
    case 'store':
      content = <StoreDetailView />;
      break;
    case 'cart':
      content = <CartCheckoutView />;
      break;
    case 'orders':
      content = <OrdersView />;
      break;
    case 'merchant':
      content = <MerchantDashboardView />;
      break;
    case 'courier':
      content = <CourierDashboardView />;
      break;
    case 'courier_register':
      content = <CourierRegisterView />;
      break;
    case 'admin':
      content = <AdminDashboardView />;
      break;
    case 'account':
      content = <AccountView />;
      break;
    case 'notifications':
      content = <NotificationsView />;
      break;
    case 'support':
      content = <SupportView />;
      break;
    case 'subscription':
      content = <SubscriptionView />;
      break;
    case 'auth':
      content = <AuthView />;
      break;
    case 'home':
    default:
      content = <HomeView />;
      break;
  }

  return (
    <ViewErrorBoundary resetKey={activeView} onGoHome={() => navigate('home')}>
      {content}
    </ViewErrorBoundary>
  );
};

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error instanceof Error ? error.message : 'Unexpected runtime error',
    };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    console.error('[SOUQNA AppErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="min-h-screen flex items-center justify-center bg-sq-canvas px-4 text-sq-ink"
        >
          <div className="max-w-md w-full rounded-3xl border border-sq-gold-hairline bg-sq-surface p-7 text-center space-y-4 shadow-xl">
            <h1 className="font-display text-xl font-extrabold text-sq-ink">
              حدث خلل مؤقت أثناء عرض الصفحة
            </h1>
            <p className="text-sm text-sq-ink-muted leading-relaxed">
              بياناتك وجلستك محفوظة بأمان. اضغط أدناه للمحاولة مجدداً أو إعادة تحميل التطبيق.
            </p>
            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => this.setState({ hasError: false, errorMessage: '' })}
                className="min-h-[46px] w-full rounded-xl btn-gold px-5 text-sm font-bold"
              >
                المحاولة مجدداً
              </button>
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-5 text-sm font-semibold text-sq-ink"
              >
                إعادة تحميل سوقنا
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <AppErrorBoundary>
      <AppProvider>
        <AppShell>
          <ActiveViewRouter />
        </AppShell>
      </AppProvider>
    </AppErrorBoundary>
  );
}
