import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { db, getPlatformSetting, setPlatformSetting } from './src/server/db.ts';
import {
  UPLOADS_DIR,
  ensureUploadsDir,
  generateDeliveryNumber,
  generateDeliveryOtp,
  generateId,
  generateOrderNumber,
  generateSessionToken,
  hashPassword,
  hashSessionToken,
  haversineKm,
  isValidEmail,
  isValidPhone,
  resolvePrivateDocPath,
  resolvePrivatePaymentProofPath,
  safeSecretEquals,
  sanitizeImageUrl,
  sanitizeStringArray,
  sanitizeText,
  saveBase64Document,
  saveBase64Image,
  saveBase64PaymentProof,
  saveBase64PrivateDoc,
  verifyPassword,
  verifyUploadedFileExists,
} from './src/server/security.ts';
import {
  createAndDispatchNotification,
  dispatchTestPush,
  formatAmountArabic,
  getUserNotifications,
  getVapidPublicKey,
  registerSseClient,
} from './src/server/notifications.ts';
import {
  ALL_STORE_TYPES,
  COMPLAINT_STATUS_LABELS,
  COURIER_STATUS_LABELS,
  DEFAULT_PRINT_PRICING,
  DELIVERY_STATUS_LABELS,
  ORDER_STATUS_LABELS,
  PRINT_COLOR_LABELS,
  PRINT_PAPER_LABELS,
  STORE_STATUS_LABELS,
  STORE_TYPE_LABELS,
  buildOptionSignature,
  calculatePrintJobPrice,
  type CartItem,
  type Complaint,
  type ComplaintMessage,
  type ComplaintStatus,
  type ComplaintTargetType,
  type CourierProfile,
  type CourierVehicleType,
  type CourierVerificationStatus,
  type Delivery,
  type DeliveryEvent,
  type DeliveryStatus,
  type FulfillmentMethod,
  type MarketplaceCategory,
  type Order,
  type OrderEvent,
  type OrderItem,
  type OrderItemOptions,
  type OrderStatus,
  type PricingType,
  type PrintBindingType,
  type PrintColorMode,
  type PrintJobDetails,
  type PrintPaperSize,
  type PrintPricingConfig,
  type PrintSides,
  type Product,
  type Store,
  type StorePlanName,
  type StorePost,
  type StorePostStatus,
  type StorePostType,
  type StoreServiceConfig,
  type StoreStatus,
  type StoreSubscription,
  type StoreSubscriptionStatus,
  type StoreType,
  type User,
  type UserRole,
} from './src/types.ts';

import crypto from 'node:crypto';
import {
  applyAdminSubscriptionAction,
  backfillMissingSubscriptions,
  checkCourierCommercialAccess,
  checkMerchantCommercialAccess,
  ensureUserSubscription,
  evaluateUserSubscription,
  getAdminAuditLogs,
  getAllAdminPaymentRequests,
  getAllAdminSubscriptions,
  getConfiguredTrialDays,
  getPaymentMethodsConfig,
  getRecentSubscriptionLogs,
  getSubscriptionPlans,
  getSubscriptionSummaryStats,
  getUserPaymentRequests,
  logAdminAction,
  logSubscriptionAction,
  reviewSubscriptionPaymentRequest,
  sendExpiringSubscriptionReminders,
  submitSubscriptionPaymentRequest,
  updateSubscriptionPlansAndMethods,
  type AdminSubscriptionActionPayload,
} from './src/server/subscriptions.ts';
import {
  completePasswordReset,
  getAllAccountRecoveryRequests,
  issueOneTimePasswordResetForUser,
  requestEmailPasswordReset,
  reviewAccountRecoveryRequest,
  submitAccountRecoveryRequest,
} from './src/server/recovery.ts';
import { isEmailDeliveryConfigured } from './src/server/mailer.ts';

const VALID_STORE_TYPES: StoreType[] = ALL_STORE_TYPES;
const VALID_POST_TYPES: StorePostType[] = ['announcement', 'offer', 'new_arrival', 'update'];
const VALID_POST_STATUSES: StorePostStatus[] = ['active', 'hidden'];
const VALID_PRINT_PAPERS: PrintPaperSize[] = ['A4', 'A3', 'A5', 'photo'];
const VALID_PRINT_COLORS: PrintColorMode[] = ['bw', 'color'];
const VALID_PRINT_SIDES: PrintSides[] = ['single', 'double'];
const VALID_PRINT_BINDINGS: PrintBindingType[] = ['none', 'spiral', 'thermal', 'lamination'];
const VALID_STORE_STATUSES: StoreStatus[] = ['pending', 'active', 'rejected', 'suspended'];
const VALID_ORDER_STATUSES: OrderStatus[] = [
  'pending',
  'confirmed',
  'preparing',
  'ready',
  'out_for_delivery',
  'delivered',
  'rejected',
  'cancelled',
];
const VALID_ROLES: UserRole[] = ['customer', 'merchant', 'courier', 'super_admin'];
const VALID_VEHICLE_TYPES: CourierVehicleType[] = ['motorcycle', 'car', 'bicycle', 'light_truck'];
const VALID_COURIER_STATUSES: CourierVerificationStatus[] = ['pending', 'verified', 'rejected', 'suspended'];
const VALID_DELIVERY_STATUSES: DeliveryStatus[] = [
  'waiting_courier',
  'dispatched',
  'accepted',
  'heading_to_store',
  'picked_up',
  'on_the_way',
  'delivered',
  'cancelled',
];
const VALID_COMPLAINT_TARGETS: ComplaintTargetType[] = [
  'store',
  'courier',
  'order',
  'user',
  'technical_support',
  'subscription',
  'general',
];
const VALID_COMPLAINT_STATUSES: ComplaintStatus[] = [
  'open',
  'under_review',
  'replied',
  'resolved',
  'dismissed',
  'closed',
];
const VALID_STORE_PLANS: StorePlanName[] = ['free', 'basic', 'pro', 'enterprise'];
const VALID_SUBSCRIPTION_STATUSES: StoreSubscriptionStatus[] = ['active', 'trial', 'expired', 'suspended'];
const ALLOWED_CURRENCIES = ['ر.س', 'د.ع', 'د.إ', 'د.أ', 'ج.م', 'د.ك', 'ر.ق', 'ل.س', '$'];
const SESSION_COOKIE_NAME = 'souqna_session';
// 90-day persistent session with sliding renewal so users sign in once until explicit logout
const SESSION_TTL_MS = 90 * 24 * 60 * 60 * 1000;
const SESSION_SLIDING_REFRESH_THRESHOLD_MS = 85 * 24 * 60 * 60 * 1000;

// Lightweight in-memory rate limiter for sensitive public auth recovery endpoints
const authRateBuckets = new Map<string, { count: number; resetAt: number }>();
function checkPublicRateLimit(key: string, maxRequests: number, windowMs: number): boolean {
  const now = Date.now();
  const entry = authRateBuckets.get(key);
  if (!entry || entry.resetAt <= now) {
    authRateBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (entry.count >= maxRequests) return false;
  entry.count += 1;
  return true;
}

interface AuthedRequest extends Request {
  user?: User;
  tokenHash?: string;
  rawToken?: string;
  sessionExpiresAt?: string;
  authSource?: 'bearer' | 'cookie';
}

function parseCoordinate(value: unknown, min: number, max: number): number | null {
  if (value === null || value === undefined || value === '') return null;
  const num = Number(value);
  if (!Number.isFinite(num) || num < min || num > max) return null;
  return Math.round(num * 1000000) / 1000000;
}

function parseCookieHeader(cookieHeader: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx <= 0) continue;
    const key = part.slice(0, idx).trim();
    const val = part.slice(idx + 1).trim();
    if (key) result[key] = decodeURIComponent(val);
  }
  return result;
}

function isRequestHttps(req: Request): boolean {
  const forwardedProto = String(req.headers['x-forwarded-proto'] || '')
    .split(',')[0]
    .trim()
    .toLowerCase();
  return (
    req.secure ||
    req.protocol === 'https' ||
    forwardedProto === 'https' ||
    process.env.NODE_ENV === 'production'
  );
}

function resolveAppOrigin(req: Request): string {
  const envUrl = process.env.APP_URL?.trim();
  if (envUrl && /^https?:\/\//i.test(envUrl) && !envUrl.includes('MY_APP_URL')) {
    return envUrl.replace(/\/+$/, '');
  }
  const proto = isRequestHttps(req) ? 'https' : 'http';
  const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || 'localhost:3000')
    .split(',')[0]
    .trim();
  const safeHost = /^[a-z0-9.\-:]+$/i.test(rawHost) ? rawHost : 'localhost:3000';
  return `${proto}://${safeHost}`;
}

function setSessionCookie(req: Request, res: Response, token: string): void {
  const isHttps = isRequestHttps(req);
  const maxAgeSec = Math.floor(SESSION_TTL_MS / 1000);
  const expiresUtc = new Date(Date.now() + SESSION_TTL_MS).toUTCString();
  const parts = [
    `${SESSION_COOKIE_NAME}=${encodeURIComponent(token)}`,
    'Path=/',
    'HttpOnly',
    `Max-Age=${maxAgeSec}`,
    `Expires=${expiresUtc}`,
  ];
  if (isHttps) {
    parts.push('SameSite=None', 'Secure', 'Partitioned');
  } else {
    parts.push('SameSite=Lax');
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

function clearSessionCookie(req: Request, res: Response): void {
  const isHttps = isRequestHttps(req);
  const parts = [
    `${SESSION_COOKIE_NAME}=`,
    'Path=/',
    'HttpOnly',
    'Max-Age=0',
    'Expires=Thu, 01 Jan 1970 00:00:00 GMT',
  ];
  if (isHttps) {
    parts.push('SameSite=None', 'Secure', 'Partitioned');
  } else {
    parts.push('SameSite=Lax');
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

function mapUser(row: Record<string, unknown>): User {
  const governorate = String(row.governorate || '');
  const city = String(row.city || '');
  return {
    id: String(row.id),
    fullName: String(row.full_name),
    email: String(row.email),
    phone: String(row.phone),
    city,
    governorate: governorate || city,
    district: String(row.district || ''),
    neighborhood: String(row.neighborhood || ''),
    address: String(row.address || ''),
    latitude: row.latitude !== null && row.latitude !== undefined ? Number(row.latitude) : null,
    longitude: row.longitude !== null && row.longitude !== undefined ? Number(row.longitude) : null,
    role: row.role as UserRole,
    isActive: Boolean(row.is_active),
    createdAt: String(row.created_at),
  };
}

function safeJsonStringArray(raw: unknown): string[] {
  if (typeof raw !== 'string' || !raw.trim()) return [];
  try {
    const parsed = JSON.parse(raw);
    return sanitizeStringArray(parsed, 40, 80);
  } catch {
    return [];
  }
}

function safeJsonOptions(raw: unknown): OrderItemOptions | undefined {
  if (typeof raw !== 'string' || !raw.trim() || raw.trim() === '{}') return undefined;
  try {
    const parsed = JSON.parse(raw) as OrderItemOptions;
    if (!parsed || typeof parsed !== 'object') return undefined;
    const hasKeys = Object.keys(parsed).length > 0;
    return hasKeys ? parsed : undefined;
  } catch {
    return undefined;
  }
}

function sanitizePrintPricing(raw: unknown, fallback?: PrintPricingConfig): PrintPricingConfig {
  const base = fallback || DEFAULT_PRINT_PRICING;
  const src = raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {};
  const positive = (v: unknown, def: number) => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 0 && n <= 10_000_000 ? Math.round(n * 100) / 100 : def;
  };
  return {
    bwA4Price: positive(src.bwA4Price, base.bwA4Price),
    colorA4Price: positive(src.colorA4Price, base.colorA4Price),
    bwA3Price: positive(src.bwA3Price, base.bwA3Price),
    colorA3Price: positive(src.colorA3Price, base.colorA3Price),
    bwA5Price: positive(src.bwA5Price, base.bwA5Price),
    colorA5Price: positive(src.colorA5Price, base.colorA5Price),
    photoPrice: positive(src.photoPrice, base.photoPrice),
    doubleSidedDiscountPercent: Math.max(
      0,
      Math.min(50, Math.round(Number(src.doubleSidedDiscountPercent ?? base.doubleSidedDiscountPercent) || 0))
    ),
    bindingSpiralPrice: positive(src.bindingSpiralPrice, base.bindingSpiralPrice),
    bindingThermalPrice: positive(src.bindingThermalPrice, base.bindingThermalPrice),
    laminationPrice: positive(src.laminationPrice, base.laminationPrice),
  };
}

function parseStoreServiceConfig(raw: unknown, storeType: StoreType): StoreServiceConfig | undefined {
  let parsed: Record<string, unknown> = {};
  if (typeof raw === 'string' && raw.trim()) {
    try {
      const obj = JSON.parse(raw);
      if (obj && typeof obj === 'object') parsed = obj as Record<string, unknown>;
    } catch {
      parsed = {};
    }
  }
  if (storeType === 'printing') {
    return {
      printPricing: sanitizePrintPricing(parsed.printPricing, DEFAULT_PRINT_PRICING),
    };
  }
  return Object.keys(parsed).length > 0 ? (parsed as StoreServiceConfig) : undefined;
}

function sanitizeOrderItemOptions(raw: unknown): OrderItemOptions | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const src = raw as Record<string, unknown>;
  const out: OrderItemOptions = {};
  const selectedSize = sanitizeText(src.selectedSize, 40);
  const selectedColor = sanitizeText(src.selectedColor, 40);
  const selectedPhoneModel = sanitizeText(src.selectedPhoneModel, 80);
  const selectedOption = sanitizeText(src.selectedOption, 80);
  const gameName = sanitizeText(src.gameName, 80);
  const playerId = sanitizeText(src.playerId, 60);

  if (selectedSize) out.selectedSize = selectedSize;
  if (selectedColor) out.selectedColor = selectedColor;
  if (selectedPhoneModel) out.selectedPhoneModel = selectedPhoneModel;
  if (selectedOption) out.selectedOption = selectedOption;
  if (gameName) out.gameName = gameName;
  if (playerId) out.playerId = playerId;

  return Object.keys(out).length > 0 ? out : undefined;
}

function getEnabledStoreTypes(): StoreType[] {
  const raw = getPlatformSetting('enabled_store_types', '');
  if (!raw) return ALL_STORE_TYPES;
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      const valid = parsed.filter((t): t is StoreType => VALID_STORE_TYPES.includes(t as StoreType));
      return valid.length > 0 ? valid : ALL_STORE_TYPES;
    }
  } catch {
    // ignore malformed json
  }
  return ALL_STORE_TYPES;
}

function mapStore(row: Record<string, unknown>): Store {
  const storeType = row.store_type as StoreType;
  const hasSub = row.sub_plan_name !== undefined && row.sub_plan_name !== null;
  return {
    id: String(row.id),
    ownerId: String(row.owner_id),
    ownerName: row.owner_name ? String(row.owner_name) : undefined,
    ownerPhone: row.owner_phone ? String(row.owner_phone) : undefined,
    name: String(row.name),
    storeType,
    description: String(row.description || ''),
    city: String(row.city),
    district: String(row.district || ''),
    address: String(row.address),
    latitude: row.latitude !== null && row.latitude !== undefined ? Number(row.latitude) : null,
    longitude: row.longitude !== null && row.longitude !== undefined ? Number(row.longitude) : null,
    phone: String(row.phone),
    openingHours: String(row.opening_hours || ''),
    deliveryFee: Number(row.delivery_fee || 0),
    minOrderAmount: Number(row.min_order_amount || 0),
    logoUrl: String(row.logo_url || ''),
    coverUrl: String(row.cover_url || ''),
    status: row.status as StoreStatus,
    rejectionReason: String(row.rejection_reason || ''),
    isVerified: Boolean(row.is_verified),
    notifyOnStoreVisit:
      row.notify_on_store_visit === undefined ? true : Boolean(row.notify_on_store_visit),
    serviceConfig: parseStoreServiceConfig(row.service_config, storeType),
    subscription: hasSub
      ? {
          storeId: String(row.id),
          planName: (row.sub_plan_name as StorePlanName) || 'free',
          status: (row.sub_status as StoreSubscriptionStatus) || 'active',
          monthlyFee: Number(row.sub_monthly_fee || 0),
          expiresAt: String(row.sub_expires_at || ''),
          notes: String(row.sub_notes || ''),
          updatedAt: String(row.sub_updated_at || ''),
        }
      : null,
    productCount: row.product_count !== undefined ? Number(row.product_count) : undefined,
    orderCount: row.order_count !== undefined ? Number(row.order_count) : undefined,
    postCount: row.post_count !== undefined ? Number(row.post_count) : undefined,
    createdAt: String(row.created_at),
  };
}

function sanitizePostImages(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  const urls: string[] = [];
  for (const item of raw) {
    if (urls.length >= 6) break;
    const cleaned = sanitizeImageUrl(item);
    if (cleaned && !urls.includes(cleaned)) {
      urls.push(cleaned);
    }
  }
  return urls;
}

function parsePostImages(raw: unknown): string[] {
  if (typeof raw !== 'string' || !raw.trim()) return [];
  try {
    const parsed = JSON.parse(raw);
    return sanitizePostImages(parsed);
  } catch {
    return [];
  }
}

function mapStorePost(row: Record<string, unknown>): StorePost {
  return {
    id: String(row.id),
    storeId: String(row.store_id),
    storeName: row.store_name ? String(row.store_name) : undefined,
    storeType: row.store_type ? (row.store_type as StoreType) : undefined,
    storeCity: row.store_city ? String(row.store_city) : undefined,
    storeDistrict: row.store_district ? String(row.store_district) : undefined,
    storeLogoUrl: row.store_logo_url ? String(row.store_logo_url) : undefined,
    storeStatus: row.store_status ? (row.store_status as StoreStatus) : undefined,
    authorId: String(row.author_id),
    authorName: row.author_name ? String(row.author_name) : undefined,
    title: String(row.title || ''),
    content: String(row.content || ''),
    postType: VALID_POST_TYPES.includes(row.post_type as StorePostType)
      ? (row.post_type as StorePostType)
      : 'announcement',
    offerBadge: String(row.offer_badge || ''),
    images: parsePostImages(row.images_json),
    status: row.status === 'hidden' ? 'hidden' : 'active',
    moderationReason: String(row.moderation_reason || ''),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at || row.created_at),
  };
}

function mapCourier(row: Record<string, unknown>): CourierProfile {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    fullName: String(row.full_name || ''),
    email: String(row.email || ''),
    phone: String(row.phone || ''),
    isUserActive: row.is_active === undefined ? true : Boolean(row.is_active),
    governorate: String(row.governorate || ''),
    city: String(row.city || ''),
    district: String(row.district || ''),
    neighborhood: String(row.neighborhood || ''),
    address: String(row.address || ''),
    avatarUrl: String(row.avatar_url || ''),
    vehicleType: row.vehicle_type as CourierVehicleType,
    plateNumber: String(row.plate_number || ''),
    idType: String(row.id_type || ''),
    idNumber: String(row.id_number || ''),
    idFrontDoc: String(row.id_front_doc || ''),
    idBackDoc: String(row.id_back_doc || ''),
    licenseDoc: String(row.license_doc || ''),
    termsAccepted: Boolean(row.terms_accepted),
    verificationStatus: row.verification_status as CourierVerificationStatus,
    rejectionReason: String(row.rejection_reason || ''),
    isAvailable: Boolean(row.is_available),
    latitude: row.latitude !== null && row.latitude !== undefined ? Number(row.latitude) : null,
    longitude: row.longitude !== null && row.longitude !== undefined ? Number(row.longitude) : null,
    locationUpdatedAt: String(row.location_updated_at || ''),
    totalDeliveries: Number(row.total_deliveries || 0),
    activeDeliveriesCount:
      row.active_deliveries_count !== undefined ? Number(row.active_deliveries_count) : undefined,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at || row.created_at),
  };
}

function getOwnedCourier(userId: string): CourierProfile | null {
  const row = db
    .prepare(
      `SELECT c.*, u.full_name, u.email, u.phone, u.is_active,
        (SELECT COUNT(*) FROM deliveries d WHERE d.courier_id = c.user_id AND d.status IN ('accepted', 'heading_to_store', 'picked_up', 'on_the_way')) AS active_deliveries_count
       FROM couriers c
       JOIN users u ON u.id = c.user_id
       WHERE c.user_id = ?`
    )
    .get(userId) as Record<string, unknown> | undefined;
  return row ? mapCourier(row) : null;
}

function logDeliveryEvent(params: {
  deliveryId: string;
  eventType: string;
  actorId?: string | null;
  actorName: string;
  actorRole: string;
  notes?: string;
  previousStatus?: string;
  newStatus?: string;
}): void {
  db.prepare(
    `INSERT INTO delivery_events (id, delivery_id, event_type, actor_id, actor_name, actor_role, notes, previous_status, new_status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    generateId('devt'),
    params.deliveryId,
    params.eventType,
    params.actorId ?? null,
    params.actorName,
    params.actorRole,
    params.notes || '',
    params.previousStatus || '',
    params.newStatus || '',
    new Date().toISOString()
  );
}

function mapDelivery(
  row: Record<string, unknown>,
  options?: { includeOtp?: boolean; includeEvents?: boolean; hideCustomerContact?: boolean }
): Delivery {
  const deliveryId = String(row.id);
  let events: DeliveryEvent[] | undefined;
  if (options?.includeEvents) {
    const evRows = db
      .prepare('SELECT * FROM delivery_events WHERE delivery_id = ? ORDER BY created_at DESC')
      .all(deliveryId) as Record<string, unknown>[];
    events = evRows.map((ev) => ({
      id: String(ev.id),
      deliveryId: String(ev.delivery_id),
      eventType: String(ev.event_type),
      actorId: ev.actor_id ? String(ev.actor_id) : null,
      actorName: String(ev.actor_name || ''),
      actorRole: String(ev.actor_role || ''),
      notes: String(ev.notes || ''),
      previousStatus: String(ev.previous_status || ''),
      newStatus: String(ev.new_status || ''),
      createdAt: String(ev.created_at),
    }));
  }

  return {
    id: deliveryId,
    deliveryNumber: String(row.delivery_number),
    orderId: String(row.order_id),
    orderNumber: row.order_number ? String(row.order_number) : undefined,
    storeId: String(row.store_id),
    storeName: row.store_name ? String(row.store_name) : undefined,
    storePhone: row.store_phone ? String(row.store_phone) : undefined,
    storeAddress: row.store_address ? String(row.store_address) : undefined,
    customerId: String(row.customer_id),
    customerName: options?.hideCustomerContact
      ? undefined
      : row.customer_name
      ? String(row.customer_name)
      : undefined,
    customerPhone: options?.hideCustomerContact
      ? undefined
      : row.customer_phone
      ? String(row.customer_phone)
      : undefined,
    courierId: row.courier_id ? String(row.courier_id) : null,
    courierName: row.courier_name ? String(row.courier_name) : undefined,
    courierPhone: row.courier_phone ? String(row.courier_phone) : undefined,
    courierVehicleType: row.courier_vehicle_type
      ? (row.courier_vehicle_type as CourierVehicleType)
      : undefined,
    courierPlateNumber: row.courier_plate_number ? String(row.courier_plate_number) : undefined,
    status: row.status as DeliveryStatus,
    pickupAddress: String(row.pickup_address || ''),
    pickupLat: row.pickup_lat !== null && row.pickup_lat !== undefined ? Number(row.pickup_lat) : null,
    pickupLng: row.pickup_lng !== null && row.pickup_lng !== undefined ? Number(row.pickup_lng) : null,
    dropoffAddress: options?.hideCustomerContact
      ? String(row.dropoff_area || row.dropoff_address || '').split('-').slice(0, 2).join(' - ')
      : String(row.dropoff_address || ''),
    dropoffLat: options?.hideCustomerContact
      ? null
      : row.dropoff_lat !== null && row.dropoff_lat !== undefined
      ? Number(row.dropoff_lat)
      : null,
    dropoffLng: options?.hideCustomerContact
      ? null
      : row.dropoff_lng !== null && row.dropoff_lng !== undefined
      ? Number(row.dropoff_lng)
      : null,
    deliveryFee: Number(row.delivery_fee || 0),
    cashToCollect: Number(row.cash_to_collect || 0),
    deliveryOtp: options?.includeOtp ? String(row.delivery_otp || '') : undefined,
    otpVerified: Boolean(row.otp_verified),
    distanceKm:
      row.distance_km !== null && row.distance_km !== undefined ? Number(row.distance_km) : null,
    cancelReason: String(row.cancel_reason || ''),
    requestedAt: String(row.requested_at || ''),
    dispatchedAt: String(row.dispatched_at || ''),
    acceptedAt: String(row.accepted_at || ''),
    pickedUpAt: String(row.picked_up_at || ''),
    deliveredAt: String(row.delivered_at || ''),
    cancelledAt: String(row.cancelled_at || ''),
    updatedAt: String(row.updated_at || ''),
    events,
  };
}

function mapComplaintMessage(row: Record<string, unknown>): ComplaintMessage {
  return {
    id: String(row.id),
    complaintId: String(row.complaint_id),
    senderId: String(row.sender_id),
    senderName: String(row.sender_name || ''),
    senderRole: String(row.sender_role || ''),
    message: String(row.message || ''),
    imageUrl: String(row.image_url || ''),
    createdAt: String(row.created_at || ''),
  };
}

function mapComplaint(row: Record<string, unknown>, messages?: ComplaintMessage[]): Complaint {
  return {
    id: String(row.id),
    reporterId: String(row.reporter_id),
    reporterName: row.reporter_name ? String(row.reporter_name) : undefined,
    reporterPhone: row.reporter_phone ? String(row.reporter_phone) : undefined,
    reporterRole: String(row.reporter_role || 'customer'),
    targetType: row.target_type as ComplaintTargetType,
    targetId: String(row.target_id),
    targetName: String(row.target_name || ''),
    orderId: row.order_id ? String(row.order_id) : null,
    orderNumber: row.order_number ? String(row.order_number) : undefined,
    deliveryId: row.delivery_id ? String(row.delivery_id) : null,
    category: String(row.category),
    description: String(row.description),
    imageUrl: String(row.image_url || ''),
    status: row.status as ComplaintStatus,
    violationRecorded: Boolean(row.violation_recorded),
    adminNotes: String(row.admin_notes || ''),
    resolvedById: row.resolved_by_id ? String(row.resolved_by_id) : null,
    messages,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function attachComplaintMessages(rows: Record<string, unknown>[]): Complaint[] {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => String(r.id));
  const placeholders = ids.map(() => '?').join(', ');
  const msgRows = db
    .prepare(
      `SELECT * FROM complaint_messages
       WHERE complaint_id IN (${placeholders})
       ORDER BY created_at ASC`
    )
    .all(...ids) as Record<string, unknown>[];

  const grouped = new Map<string, ComplaintMessage[]>();
  for (const m of msgRows) {
    const cid = String(m.complaint_id);
    const list = grouped.get(cid) || [];
    list.push(mapComplaintMessage(m));
    grouped.set(cid, list);
  }
  return rows.map((row) => mapComplaint(row, grouped.get(String(row.id)) || []));
}

function mapSubscription(row: Record<string, unknown>): StoreSubscription {
  return {
    storeId: String(row.store_id),
    storeName: row.store_name ? String(row.store_name) : undefined,
    storeStatus: row.store_status ? (row.store_status as StoreStatus) : undefined,
    ownerName: row.owner_name ? String(row.owner_name) : undefined,
    planName: (row.plan_name as StorePlanName) || 'free',
    status: (row.status as StoreSubscriptionStatus) || 'active',
    monthlyFee: Number(row.monthly_fee || 0),
    expiresAt: String(row.expires_at || ''),
    notes: String(row.notes || ''),
    updatedAt: String(row.updated_at || ''),
  };
}

function formatTimeAr(iso: string): string {
  try {
    return new Intl.DateTimeFormat('ar-IQ', {
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(iso));
  } catch {
    return iso.slice(11, 16);
  }
}

function mapProduct(row: Record<string, unknown>): Product {
  return {
    id: String(row.id),
    storeId: String(row.store_id),
    storeName: row.store_name ? String(row.store_name) : undefined,
    storeCity: row.store_city ? String(row.store_city) : undefined,
    storeDistrict: row.store_district ? String(row.store_district) : undefined,
    storeType: row.store_type ? (row.store_type as StoreType) : undefined,
    storeDeliveryFee:
      row.store_delivery_fee !== undefined ? Number(row.store_delivery_fee) : undefined,
    storeAddress: row.store_address ? String(row.store_address) : undefined,
    storePhone: row.store_phone ? String(row.store_phone) : undefined,
    name: String(row.name),
    category: String(row.category),
    description: String(row.description || ''),
    price: Number(row.price),
    unit: String(row.unit || 'قطعة'),
    cartonPrice: Number(row.carton_price || 0),
    cartonUnits: Number(row.carton_units || 0),
    stockQty: Number(row.stock_qty || 0),
    imageUrl: String(row.image_url || ''),
    isAvailable: Boolean(row.is_available),
    availableSizes: safeJsonStringArray(row.sizes_json),
    availableColors: safeJsonStringArray(row.colors_json),
    compatibleModels: safeJsonStringArray(row.phone_models_json),
    gameName: String(row.game_name || ''),
    customOptions: safeJsonStringArray(row.custom_options_json),
    createdAt: String(row.created_at),
  };
}

function logOrderEvent(params: {
  orderId: string;
  eventType: OrderEvent['eventType'];
  actorId?: string | null;
  actorName: string;
  actorRole: string;
  reason?: string;
  previousStatus?: string;
  newStatus?: string;
}): void {
  db.prepare(
    `INSERT INTO order_events (id, order_id, event_type, actor_id, actor_name, actor_role, reason, previous_status, new_status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    generateId('evt'),
    params.orderId,
    params.eventType,
    params.actorId ?? null,
    params.actorName,
    params.actorRole,
    params.reason || '',
    params.previousStatus || '',
    params.newStatus || '',
    new Date().toISOString()
  );
}

function attachOrderItems(
  orderRows: Record<string, unknown>[],
  viewer?: { role: UserRole; userId: string }
): Order[] {
  if (orderRows.length === 0) return [];
  const getItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?');
  const getEvents = db.prepare(
    'SELECT * FROM order_events WHERE order_id = ? ORDER BY created_at DESC'
  );
  const getDelivery = db.prepare(
    `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
            o.customer_name, o.customer_phone,
            cu.full_name AS courier_name, cu.phone AS courier_phone,
            cp.vehicle_type AS courier_vehicle_type, cp.plate_number AS courier_plate_number
     FROM deliveries d
     JOIN orders o ON o.id = d.order_id
     JOIN stores s ON s.id = d.store_id
     LEFT JOIN users cu ON cu.id = d.courier_id
     LEFT JOIN couriers cp ON cp.user_id = d.courier_id
     WHERE d.order_id = ?`
  );
  return orderRows.map((row) => {
    const orderId = String(row.id);
    const itemRows = getItems.all(orderId) as Record<string, unknown>[];
    const items: OrderItem[] = itemRows.map((item) => ({
      id: String(item.id),
      orderId: String(item.order_id),
      productId: item.product_id ? String(item.product_id) : null,
      productName: String(item.product_name),
      unit: String(item.unit),
      pricingType: item.pricing_type === 'carton' ? 'carton' : 'unit',
      unitPrice: Number(item.unit_price),
      quantity: Number(item.quantity),
      lineTotal: Number(item.line_total),
      imageUrl: String(item.image_url || ''),
      selectedOptions: safeJsonOptions(item.item_options_json),
    }));
    const eventRows = getEvents.all(orderId) as Record<string, unknown>[];
    const events: OrderEvent[] = eventRows.map((ev) => ({
      id: String(ev.id),
      orderId: String(ev.order_id),
      eventType: ev.event_type as OrderEvent['eventType'],
      actorId: ev.actor_id ? String(ev.actor_id) : null,
      actorName: String(ev.actor_name || ''),
      actorRole: String(ev.actor_role || ''),
      reason: String(ev.reason || ''),
      previousStatus: String(ev.previous_status || ''),
      newStatus: String(ev.new_status || ''),
      createdAt: String(ev.created_at),
    }));
    const deliveryRow = getDelivery.get(orderId) as Record<string, unknown> | undefined;
    const customerId = String(row.customer_id);
    const canSeeOtp =
      Boolean(viewer) && (viewer!.role === 'super_admin' || viewer!.userId === customerId);
    const delivery = deliveryRow
      ? mapDelivery(deliveryRow, { includeOtp: canSeeOtp, includeEvents: true })
      : null;

    const fulfillmentMethod: FulfillmentMethod =
      row.fulfillment_method === 'pickup' ? 'pickup' : 'delivery';
    return {
      id: orderId,
      orderNumber: String(row.order_number),
      customerId,
      storeId: String(row.store_id),
      storeName: String(row.store_name || ''),
      storePhone: row.store_phone ? String(row.store_phone) : undefined,
      storeAddress: row.store_address ? String(row.store_address) : undefined,
      status: row.status as OrderStatus,
      paymentMethod: 'cash_on_delivery',
      fulfillmentMethod,
      subtotal: Number(row.subtotal),
      deliveryFee: Number(row.delivery_fee),
      totalAmount: Number(row.total_amount),
      governorate: String(row.governorate || ''),
      city: String(row.city || ''),
      district: String(row.district || ''),
      neighborhood: String(row.neighborhood || ''),
      deliveryAddress: String(row.delivery_address),
      latitude: row.latitude !== null && row.latitude !== undefined ? Number(row.latitude) : null,
      longitude: row.longitude !== null && row.longitude !== undefined ? Number(row.longitude) : null,
      customerName: String(row.customer_name),
      customerPhone: String(row.customer_phone),
      notes: String(row.notes || ''),
      cancelReason: String(row.cancel_reason || ''),
      cancelledById: row.cancelled_by_id ? String(row.cancelled_by_id) : null,
      cancelledByName: String(row.cancelled_by_name || ''),
      cancelledByRole: String(row.cancelled_by_role || ''),
      cancelledAt: String(row.cancelled_at || ''),
      stockRestored: Boolean(row.stock_restored),
      items,
      events,
      delivery,
      createdAt: String(row.created_at),
      updatedAt: String(row.updated_at),
    };
  });
}

function getUserCartItems(userId: string): CartItem[] {
  const rows = db
    .prepare(
      `SELECT c.id AS cart_id, c.pricing_type, c.option_signature, c.item_options_json, c.quantity,
              p.*, s.owner_id AS store_owner_id, s.name AS store_name, s.city AS store_city, s.district AS store_district,
              s.store_type AS store_type, s.delivery_fee AS store_delivery_fee,
              s.address AS store_address, s.phone AS store_phone
       FROM cart_items c
       JOIN products p ON p.id = c.product_id
       JOIN stores s ON s.id = p.store_id
       WHERE c.user_id = ? AND s.status = 'active' AND p.is_available = 1 AND p.deleted_at IS NULL
       ORDER BY c.created_at ASC`
    )
    .all(userId) as Record<string, unknown>[];

  const activeRows = rows.filter((row) =>
    checkMerchantCommercialAccess(String(row.store_owner_id || '')).allowed
  );

  return activeRows.map((row) => {
    const product = mapProduct(row);
    const pricingType: PricingType =
      row.pricing_type === 'carton' && product.cartonPrice > 0 ? 'carton' : 'unit';
    const appliedUnitPrice = pricingType === 'carton' ? product.cartonPrice : product.price;
    const appliedUnitLabel =
      pricingType === 'carton'
        ? product.cartonUnits > 0
          ? `كارتون (${product.cartonUnits} ${product.unit})`
          : 'كارتون'
        : product.unit;
    const selectedOptions = safeJsonOptions(row.item_options_json);
    const optionSig = String(row.option_signature || buildOptionSignature(selectedOptions));
    const key = optionSig
      ? `${product.id}:${pricingType}:${optionSig}`
      : `${product.id}:${pricingType}`;
    return {
      id: String(row.cart_id),
      key,
      product,
      pricingType,
      appliedUnitPrice,
      appliedUnitLabel,
      storeId: product.storeId,
      storeName: product.storeName || 'متجر',
      storeDeliveryFee: product.storeDeliveryFee || 0,
      storeAddress: [product.storeCity, product.storeDistrict, product.storeAddress]
        .filter(Boolean)
        .join('، '),
      quantity: Number(row.quantity),
      selectedOptions,
    };
  });
}

function unitsNeededForItem(product: Product, pricingType: PricingType, quantity: number): number {
  if (pricingType === 'carton') {
    const perCarton = Math.max(1, product.cartonUnits || 1);
    return quantity * perCarton;
  }
  return quantity;
}

function createSessionForUser(userId: string): string {
  const token = generateSessionToken();
  const tokenHash = hashSessionToken(token);
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_TTL_MS);
  db.prepare(
    'INSERT INTO sessions (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)'
  ).run(tokenHash, userId, expires.toISOString(), now.toISOString());
  return token;
}

function getOwnedStore(userId: string): Store | null {
  const row = db
    .prepare(
      `SELECT s.*,
        (SELECT COUNT(*) FROM products p WHERE p.store_id = s.id AND p.deleted_at IS NULL) AS product_count,
        (SELECT COUNT(*) FROM orders o WHERE o.store_id = s.id) AS order_count
       FROM stores s WHERE s.owner_id = ?`
    )
    .get(userId) as Record<string, unknown> | undefined;
  return row ? mapStore(row) : null;
}

function extractAuthToken(req: Request): { token: string; source: 'bearer' | 'cookie' } | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    if (token.length >= 32) return { token, source: 'bearer' };
  }
  const cookies = parseCookieHeader(req.headers.cookie);
  const cookieToken = cookies[SESSION_COOKIE_NAME];
  if (cookieToken && cookieToken.length >= 32) {
    return { token: cookieToken, source: 'cookie' };
  }
  return null;
}

function verifyCsrfForCookieMutation(req: AuthedRequest): boolean {
  if (req.authSource !== 'cookie') return true;
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') return true;
  const origin = req.headers.origin;
  const rawHost =
    (req.headers['x-forwarded-host'] as string | undefined) || req.headers.host || '';
  const host = rawHost.split(',')[0].trim();
  if (origin) {
    if (!host) return false;
    try {
      const originHost = new URL(origin).host;
      if (originHost !== host) return false;
      return true;
    } catch {
      return false;
    }
  }
  if (req.headers['x-requested-with'] === 'XMLHttpRequest') return true;
  return false;
}

function optionalAuth(req: AuthedRequest, _res: Response, next: NextFunction): void {
  const extracted = extractAuthToken(req);
  if (!extracted) return next();

  const tokenHash = hashSessionToken(extracted.token);
  const row = db
    .prepare(
      `SELECT u.*, s.expires_at AS session_expires_at FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ? AND s.expires_at > ?`
    )
    .get(tokenHash, new Date().toISOString()) as Record<string, unknown> | undefined;

  if (row && Boolean(row.is_active)) {
    req.user = mapUser(row);
    req.tokenHash = tokenHash;
    req.rawToken = extracted.token;
    req.sessionExpiresAt = String(row.session_expires_at || '');
    req.authSource = extracted.source;
  }
  next();
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  optionalAuth(req, res, () => {
    if (!req.user) {
      res.status(401).json({ error: 'يرجى تسجيل الدخول للمتابعة.' });
      return;
    }
    if (!verifyCsrfForCookieMutation(req)) {
      res.status(403).json({ error: 'طلب غير مصرح به.' });
      return;
    }
    next();
  });
}

function requireRole(...roles: UserRole[]) {
  return (req: AuthedRequest, res: Response, next: NextFunction): void => {
    requireAuth(req, res, () => {
      if (!req.user || !roles.includes(req.user.role)) {
        res.status(403).json({ error: 'ليس لديك صلاحية تنفيذ هذا الإجراء.' });
        return;
      }
      next();
    });
  };
}

async function startServer() {
  ensureUploadsDir();
  backfillMissingSubscriptions();

  // Prune expired sessions and expired/used password reset tokens on startup & hourly
  const pruneExpiredAuthRecords = () => {
    try {
      const nowIso = new Date().toISOString();
      db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(nowIso);
      db.prepare("DELETE FROM password_reset_tokens WHERE expires_at <= ? OR used_at != ''").run(
        nowIso
      );
    } catch {
      // Non-fatal cleanup
    }
  };
  pruneExpiredAuthRecords();
  setInterval(pruneExpiredAuthRecords, 60 * 60 * 1000).unref();

  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(self), geolocation=(self), microphone=()');
    next();
  });
  app.use(express.json({ limit: '24mb' }));

  // Ensure shared marketplace, merchant, and admin API responses are always read fresh
  // from the central database and never served from stale browser/WebView caches on account switch.
  app.use('/api', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
  });

  // Serve uploaded product and store images safely
  app.use(
    '/uploads',
    (_req, res, next) => {
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      next();
    },
    express.static(UPLOADS_DIR)
  );

  // Fast health probe for Cloud Run / container orchestrators
  app.get('/healthz', (_req, res) => {
    res.status(200).json({ ok: true });
  });

  // Health & bootstrap status
  app.get('/api/bootstrap-status', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    const adminRow = db
      .prepare("SELECT COUNT(*) AS cnt FROM users WHERE role = 'super_admin'")
      .get() as { cnt: number };
    const setupCodeConfigured = Boolean(process.env.SUPER_ADMIN_SETUP_CODE?.trim());
    res.json({
      hasSuperAdmin: adminRow.cnt > 0,
      requireSetupCode: setupCodeConfigured,
      emailResetConfigured: isEmailDeliveryConfigured(),
      currency: getPlatformSetting('currency', 'د.ع'),
      requireStoreApproval: getPlatformSetting('require_store_approval', 'false') === 'true',
      requireCourierApproval: getPlatformSetting('require_courier_approval', 'true') === 'true',
      enabledStoreTypes: getEnabledStoreTypes(),
      trialDays: getConfiguredTrialDays(),
      appName: getPlatformSetting('app_name', 'سوقنا | SOUQNA'),
      supportPhone: getPlatformSetting('support_phone', '07764327688'),
      supportTelegram: getPlatformSetting('support_telegram', '@murtadaa1996'),
      announcementText: getPlatformSetting('announcement_text', ''),
    });
  });

  const mapCategoryRow = (row: Record<string, unknown>): MarketplaceCategory => ({
    id: String(row.id),
    name: String(row.name),
    description: String(row.description || ''),
    storeType:
      typeof row.store_type === 'string' && VALID_STORE_TYPES.includes(row.store_type as StoreType)
        ? (row.store_type as StoreType)
        : 'all',
    sortOrder: Number(row.sort_order || 0),
    isActive: Boolean(row.is_active),
    productCount: row.product_count !== undefined ? Number(row.product_count) : undefined,
    createdAt: String(row.created_at || ''),
    updatedAt: String(row.updated_at || ''),
  });

  // Public active categories list for catalog & product forms
  app.get('/api/categories', (_req, res) => {
    const rows = db
      .prepare(
        `SELECT c.*,
          (SELECT COUNT(*) FROM products p WHERE p.category = c.name AND p.deleted_at IS NULL AND p.is_available = 1) AS product_count
         FROM categories c
         WHERE c.is_active = 1
         ORDER BY c.sort_order ASC, c.name ASC`
      )
      .all() as Record<string, unknown>[];
    res.json({ categories: rows.map(mapCategoryRow) });
  });

  // First-run Super Admin bootstrap
  app.post('/api/auth/bootstrap-admin', (req, res) => {
    const fullName = sanitizeText(req.body?.fullName, 100);
    const email = sanitizeText(req.body?.email, 160).toLowerCase();
    const phone = sanitizeText(req.body?.phone, 24);
    const city = sanitizeText(req.body?.city, 80);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const setupCode = typeof req.body?.setupCode === 'string' ? req.body.setupCode.trim() : '';

    const requiredCode = process.env.SUPER_ADMIN_SETUP_CODE?.trim() || '';
    if (requiredCode && !safeSecretEquals(setupCode, requiredCode)) {
      res.status(403).json({ error: 'رمز التفعيل غير صحيح.' });
      return;
    }

    if (fullName.length < 2) {
      res.status(400).json({ error: 'يرجى إدخال الاسم الكامل.' });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني صحيح.' });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: 'يرجى إدخال رقم هاتف صحيح.' });
      return;
    }
    if (password.length < 8) {
      res.status(400).json({ error: 'كلمة المرور يجب أن لا تقل عن 8 أحرف.' });
      return;
    }

    const claimTx = db.transaction(
      ():
        | { ok: false; error: string; status: number }
        | { ok: true; user: User; token: string } => {
        const existingAdmin = db
          .prepare("SELECT COUNT(*) AS cnt FROM users WHERE role = 'super_admin'")
          .get() as { cnt: number };
        if (existingAdmin.cnt > 0) {
          return { ok: false, error: 'تم إعداد حساب المدير العام مسبقاً.', status: 409 };
        }
        const existingEmail = db
          .prepare('SELECT id FROM users WHERE email = ?')
          .get(email);
        if (existingEmail) {
          return { ok: false, error: 'البريد الإلكتروني مستخدم بالفعل.', status: 409 };
        }

        const id = generateId('usr');
        const now = new Date().toISOString();
        const passwordHash = hashPassword(password);
        db.prepare(
          `INSERT INTO users (id, full_name, email, phone, city, governorate, address, password_hash, role, is_active, created_at)
           VALUES (?, ?, ?, ?, ?, ?, '', ?, 'super_admin', 1, ?)`
        ).run(id, fullName, email, phone, city || 'المركز الرئيسي', city || 'المركز الرئيسي', passwordHash, now);

        const userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as Record<
          string,
          unknown
        >;
        const token = createSessionForUser(id);
        return { ok: true, user: mapUser(userRow), token };
      }
    );

    const result = claimTx();
    if (!result.ok) {
      res.status(result.status).json({ error: result.error });
      return;
    }

    setSessionCookie(req, res, result.token);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.status(201).json({ token: result.token, user: result.user, store: null });
  });

  // Register (customer or merchant only — never super_admin)
  app.post('/api/auth/register', (req, res) => {
    const ip = req.ip || 'unknown';
    if (!checkPublicRateLimit(`register:${ip}`, 20, 15 * 60 * 1000)) {
      res.status(429).json({ error: 'تم إرسال عدة محاولات تسجيل مؤقتاً. يرجى الانتظار قليلاً.' });
      return;
    }
    const fullName = sanitizeText(req.body?.fullName, 100);
    const email = sanitizeText(req.body?.email, 160).toLowerCase();
    const phone = sanitizeText(req.body?.phone, 24);
    const governorate = sanitizeText(req.body?.governorate, 80);
    const city = sanitizeText(req.body?.city ?? governorate, 80);
    const district = sanitizeText(req.body?.district, 80);
    const neighborhood = sanitizeText(req.body?.neighborhood, 80);
    const address = sanitizeText(req.body?.address, 250);
    const latitude = parseCoordinate(req.body?.latitude, -90, 90);
    const longitude = parseCoordinate(req.body?.longitude, -180, 180);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const requestedRole = req.body?.role === 'merchant' ? 'merchant' : 'customer';

    if (fullName.length < 2) {
      res.status(400).json({ error: 'يرجى إدخال الاسم الكامل.' });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني صحيح.' });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: 'يرجى إدخال رقم هاتف صحيح.' });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: 'كلمة المرور يجب أن لا تقل عن 6 أحرف.' });
      return;
    }

    const exists = db.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (exists) {
      res.status(409).json({ error: 'هذا البريد الإلكتروني مسجل مسبقاً. يرجى تسجيل الدخول بحسابك الحالي.' });
      return;
    }

    const normalizedPhone = phone.replace(/[\s\-()+]/g, '');
    if (normalizedPhone.length >= 7) {
      const existingPhoneUser = (
        db.prepare('SELECT id, phone FROM users').all() as Array<{ id: string; phone: string }>
      ).find((u) => String(u.phone || '').replace(/[\s\-()+]/g, '') === normalizedPhone);
      if (existingPhoneUser) {
        res.status(409).json({
          error: 'رقم الهاتف هذا مسجّل مسبقاً في حساب آخر. يرجى تسجيل الدخول بحسابك الحالي.',
        });
        return;
      }
    }

    const id = generateId('usr');
    const now = new Date().toISOString();
    const passwordHash = hashPassword(password);

    db.prepare(
      `INSERT INTO users
        (id, full_name, email, phone, city, governorate, district, neighborhood, address, latitude, longitude, password_hash, role, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    ).run(
      id,
      fullName,
      email,
      phone,
      city,
      governorate || city,
      district,
      neighborhood,
      address,
      latitude,
      longitude,
      passwordHash,
      requestedRole,
      now
    );

    if (requestedRole === 'merchant') {
      ensureUserSubscription(id, 'merchant');
    }

    const userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as Record<
      string,
      unknown
    >;
    const token = createSessionForUser(id);
    setSessionCookie(req, res, token);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');

    res.status(201).json({
      token,
      user: mapUser(userRow),
      store: null,
      subscription: requestedRole === 'merchant' ? evaluateUserSubscription(id) : null,
    });
  });

  // Login (email or phone)
  app.post('/api/auth/login', (req, res) => {
    const ip = req.ip || 'unknown';
    const identifier = sanitizeText(req.body?.identifier, 160).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!identifier || !password) {
      res.status(400).json({ error: 'يرجى إدخال البريد الإلكتروني أو رقم الهاتف وكلمة المرور.' });
      return;
    }

    if (
      !checkPublicRateLimit(`login_ip:${ip}`, 30, 15 * 60 * 1000) ||
      !checkPublicRateLimit(`login_id:${identifier}`, 15, 15 * 60 * 1000)
    ) {
      res.status(429).json({
        error: 'تم تجاوز عدد محاولات تسجيل الدخول المسموحة مؤقتاً. يرجى الانتظار بضع دقائق.',
      });
      return;
    }

    const cleanedPhone = identifier.replace(/[\s\-()]/g, '');
    let userRow = db
      .prepare(
        `SELECT * FROM users WHERE LOWER(email) = ? OR phone = ? OR REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', '') = ?`
      )
      .get(identifier, identifier, cleanedPhone) as Record<string, unknown> | undefined;

    if (!userRow && /^\+?[0-9]{7,16}$/.test(cleanedPhone)) {
      const targetDigits = cleanedPhone.replace(/^\+/, '');
      const candidates = db.prepare('SELECT * FROM users').all() as Record<string, unknown>[];
      userRow = candidates.find(
        (u) => String(u.phone || '').replace(/[\s\-()+]/g, '') === targetDigits
      );
    }

    if (!userRow || !verifyPassword(password, String(userRow.password_hash))) {
      res.status(401).json({ error: 'بيانات الدخول غير صحيحة.' });
      return;
    }

    if (!Boolean(userRow.is_active)) {
      res.status(403).json({ error: 'تم تعليق هذا الحساب من قِبل الإدارة.' });
      return;
    }

    const user = mapUser(userRow);
    const token = createSessionForUser(user.id);
    const store = user.role === 'merchant' ? getOwnedStore(user.id) : null;
    const courier = user.role === 'courier' ? getOwnedCourier(user.id) : null;
    const subscription = evaluateUserSubscription(user.id);
    setSessionCookie(req, res, token);
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');

    res.json({ token, user, store, courier, subscription });
  });

  app.post('/api/auth/logout', optionalAuth, (req: AuthedRequest, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    if (req.authSource === 'cookie' && !verifyCsrfForCookieMutation(req)) {
      res.status(403).json({ error: 'طلب غير مصرح به.' });
      return;
    }
    const hashesToRevoke = new Set<string>();
    if (req.tokenHash) {
      hashesToRevoke.add(req.tokenHash);
    }
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const bearerToken = authHeader.slice(7).trim();
      if (bearerToken.length >= 32) hashesToRevoke.add(hashSessionToken(bearerToken));
    }
    const cookies = parseCookieHeader(req.headers.cookie);
    const cookieToken = cookies[SESSION_COOKIE_NAME];
    if (cookieToken && cookieToken.length >= 32) {
      hashesToRevoke.add(hashSessionToken(cookieToken));
    }
    for (const hash of hashesToRevoke) {
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hash);
    }
    clearSessionCookie(req, res);
    res.json({ ok: true });
  });

  const handleSessionPayload = (req: AuthedRequest, res: Response) => {
    const user = req.user!;
    // Sliding session renewal: keep active users signed in seamlessly without re-login prompts
    if (req.tokenHash && req.rawToken) {
      const expMs = req.sessionExpiresAt ? new Date(req.sessionExpiresAt).getTime() : 0;
      const needsSlidingRefresh =
        !Number.isFinite(expMs) || expMs - Date.now() < SESSION_SLIDING_REFRESH_THRESHOLD_MS;
      if (needsSlidingRefresh) {
        const nextExpires = new Date(Date.now() + SESSION_TTL_MS).toISOString();
        db.prepare('UPDATE sessions SET expires_at = ? WHERE token_hash = ?').run(
          nextExpires,
          req.tokenHash
        );
      }
      if (needsSlidingRefresh || req.authSource === 'bearer') {
        setSessionCookie(req, res, req.rawToken);
      }
    }
    const store = user.role === 'merchant' ? getOwnedStore(user.id) : null;
    const courier = user.role === 'courier' ? getOwnedCourier(user.id) : null;
    const subscription = evaluateUserSubscription(user.id);
    return {
      user,
      store,
      courier,
      subscription,
      authSource: req.authSource || 'cookie',
    };
  };

  // Non-erroring session check for initial app boot (avoids noisy 401 console errors for guests)
  app.get('/api/auth/session', optionalAuth, (req: AuthedRequest, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    if (!req.user) {
      res.json({
        authenticated: false,
        user: null,
        store: null,
        courier: null,
        subscription: null,
      });
      return;
    }
    res.json({ authenticated: true, ...handleSessionPayload(req, res) });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.json(handleSessionPayload(req, res));
  });

  // Public Self-Service Email Password Reset (when user has access to their email)
  app.post('/api/auth/forgot-password-email', async (req, res) => {
    const ip = req.ip || 'unknown';
    const rawEmail = sanitizeText(req.body?.email, 160).toLowerCase();
    if (!checkPublicRateLimit(`forgot_email_ip:${ip}`, 10, 15 * 60 * 1000)) {
      res.status(429).json({
        error: 'تم إرسال عدد كبير من طلبات الاستعادة مؤقتاً. يرجى المحاولة بعد بضع دقائق.',
      });
      return;
    }
    if (rawEmail && !checkPublicRateLimit(`forgot_email_addr:${rawEmail}`, 5, 15 * 60 * 1000)) {
      res.status(429).json({
        error: 'تم إرسال عدة طلبات لهذا البريد مؤقتاً. يرجى الانتظار بضع دقائق قبل إعادة المحاولة.',
      });
      return;
    }

    const result = await requestEmailPasswordReset({
      email: rawEmail,
      appOrigin: resolveAppOrigin(req),
    });

    if (result.ok === false) {
      res.status(result.status).json({ error: result.error });
      return;
    }

    res.json({
      ok: true,
      deliveryMode: result.deliveryMode,
      message: result.message,
    });
  });

  // Public Account Recovery Request (for users who forgot password/email/lost device access)
  app.post('/api/auth/recovery-requests', (req, res) => {
    const ip = req.ip || 'unknown';
    if (!checkPublicRateLimit(`recovery:${ip}`, 10, 15 * 60 * 1000)) {
      res.status(429).json({
        error: 'تم إرسال عدد كبير من طلبات الاستعادة مؤقتاً. يرجى المحاولة بعد بضع دقائق.',
      });
      return;
    }

    const result = submitAccountRecoveryRequest({
      requesterName: typeof req.body?.requesterName === 'string' ? req.body.requesterName : '',
      requesterPhone: typeof req.body?.requesterPhone === 'string' ? req.body.requesterPhone : '',
      requesterEmail: typeof req.body?.requesterEmail === 'string' ? req.body.requesterEmail : '',
      accountType: typeof req.body?.accountType === 'string' ? req.body.accountType : 'customer',
      proofDetails: typeof req.body?.proofDetails === 'string' ? req.body.proofDetails : '',
    });

    if (result.ok === false) {
      res.status(result.status).json({ error: result.error });
      return;
    }

    res.status(201).json({
      ok: true,
      requestId: result.requestId,
      message:
        'تم استلام طلب استعادة الحساب وإرساله إلى المدير الرئيسي. سيتم التحقق من ملكية الحساب وإرسال رابط أو رمز إعادة تعيين مؤقت وآمن لك.',
    });
  });

  // Public One-Time Password Reset Completion (via Admin-issued Reset Link Token or Temporary Code)
  app.post('/api/auth/reset-password', (req, res) => {
    const ip = req.ip || 'unknown';
    if (!checkPublicRateLimit(`reset:${ip}`, 12, 15 * 60 * 1000)) {
      res.status(429).json({
        error: 'محاولات كثيرة مؤقتاً. يرجى الانتظار بضع دقائق والمحاولة مجدداً.',
      });
      return;
    }

    const result = completePasswordReset({
      token: typeof req.body?.token === 'string' ? req.body.token : undefined,
      code: typeof req.body?.code === 'string' ? req.body.code : undefined,
      newPassword: typeof req.body?.newPassword === 'string' ? req.body.newPassword : '',
    });

    if (result.ok === false) {
      res.status(result.status).json({ error: result.error });
      return;
    }

    res.json({
      ok: true,
      message: 'تمت إعادة تعيين كلمة المرور بنجاح. يمكنك تسجيل الدخول بكلمتك الجديدة الآن.',
    });
  });

  // Secure owner-only promotion to Super Admin when SUPER_ADMIN_SETUP_CODE is configured in Secrets
  app.post('/api/auth/claim-super-admin', requireAuth, (req: AuthedRequest, res) => {
    const ip = req.ip || 'unknown';
    if (!checkPublicRateLimit(`claim_admin:${ip}:${req.user!.id}`, 6, 15 * 60 * 1000)) {
      res.status(429).json({ error: 'تم تجاوز عدد محاولات التفعيل مؤقتاً. يرجى الانتظار.' });
      return;
    }
    const requiredCode = process.env.SUPER_ADMIN_SETUP_CODE?.trim() || '';
    if (!requiredCode) {
      res.status(403).json({
        error: 'تفعيل صلاحية المدير العام عبر الرمز غير مفعّل في إعدادات الخادم.',
      });
      return;
    }
    const providedCode = typeof req.body?.setupCode === 'string' ? req.body.setupCode.trim() : '';
    if (!safeSecretEquals(providedCode, requiredCode)) {
      res.status(403).json({ error: 'رمز تفعيل المدير العام غير صحيح.' });
      return;
    }
    const user = req.user!;
    db.prepare("UPDATE users SET role = 'super_admin', is_active = 1 WHERE id = ?").run(user.id);
    const updatedRow = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id) as Record<
      string,
      unknown
    >;
    res.json({ user: mapUser(updatedRow), store: null, courier: null });
  });

  app.patch('/api/auth/profile', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const fullName = sanitizeText(req.body?.fullName, 100);
    const phone = sanitizeText(req.body?.phone, 24);
    const governorate = sanitizeText(req.body?.governorate, 80);
    const city = sanitizeText(req.body?.city ?? governorate, 80);
    const district = sanitizeText(req.body?.district, 80);
    const neighborhood = sanitizeText(req.body?.neighborhood, 80);
    const address = sanitizeText(req.body?.address, 250);
    const latitude = parseCoordinate(req.body?.latitude, -90, 90);
    const longitude = parseCoordinate(req.body?.longitude, -180, 180);

    if (fullName.length < 2) {
      res.status(400).json({ error: 'الاسم الكامل مطلوب.' });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: 'رقم الهاتف غير صالح.' });
      return;
    }

    db.prepare(
      `UPDATE users
       SET full_name = ?, phone = ?, city = ?, governorate = ?, district = ?, neighborhood = ?, address = ?, latitude = ?, longitude = ?
       WHERE id = ?`
    ).run(
      fullName,
      phone,
      city,
      governorate || city,
      district,
      neighborhood,
      address,
      latitude,
      longitude,
      user.id
    );

    const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id) as Record<
      string,
      unknown
    >;
    res.json({ user: mapUser(updated) });
  });

  // Upload image from phone camera / gallery
  app.post('/api/uploads', requireAuth, (req: AuthedRequest, res) => {
    const dataUrl = typeof req.body?.dataUrl === 'string' ? req.body.dataUrl : '';
    if (!dataUrl) {
      res.status(400).json({ error: 'لم يتم إرفاق صورة.' });
      return;
    }
    const saved = saveBase64Image(dataUrl);
    if ('error' in saved) {
      res.status(400).json({ error: saved.error });
      return;
    }
    res.status(201).json(saved);
  });

  // Upload PDF or Image document for Print & Copy shops (magic-byte validated, max 15 MB)
  app.post('/api/uploads/document', requireAuth, (req: AuthedRequest, res) => {
    const dataUrl = typeof req.body?.dataUrl === 'string' ? req.body.dataUrl : '';
    const fileName = sanitizeText(req.body?.fileName, 140);
    if (!dataUrl) {
      res.status(400).json({ error: 'لم يتم اختيار ملف للرفع.' });
      return;
    }
    const saved = saveBase64Document(dataUrl, fileName);
    if ('error' in saved) {
      res.status(400).json({ error: saved.error });
      return;
    }
    res.status(201).json(saved);
  });

  // PERSISTENT DB CART APIs
  app.get('/api/cart', requireAuth, (req: AuthedRequest, res) => {
    res.json({ items: getUserCartItems(req.user!.id) });
  });

  app.post('/api/cart/items', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const productId = sanitizeText(req.body?.productId, 60);
    const pricingType: PricingType = req.body?.pricingType === 'carton' ? 'carton' : 'unit';
    const quantityDelta = Math.max(1, Math.min(99, Math.floor(Number(req.body?.quantity) || 1)));
    const selectedOptions = sanitizeOrderItemOptions(req.body?.selectedOptions);

    const productRow = db
      .prepare(
        `SELECT p.*, s.owner_id AS store_owner_id, s.status AS store_status, s.store_type AS store_type
         FROM products p
         JOIN stores s ON s.id = p.store_id
         WHERE p.id = ? AND p.deleted_at IS NULL`
      )
      .get(productId) as Record<string, unknown> | undefined;

    if (!productRow || productRow.store_status !== 'active' || !Boolean(productRow.is_available)) {
      res.status(404).json({ error: 'المنتج غير متوفر حالياً.' });
      return;
    }
    if (!checkMerchantCommercialAccess(String(productRow.store_owner_id || '')).allowed) {
      res.status(403).json({
        error: 'عذراً، هذا المتجر متوقف مؤقتاً عن استقبال الطلبات لحين تجديد اشتراكه.',
      });
      return;
    }
    if (String(productRow.store_owner_id) === user.id) {
      res.status(400).json({ error: 'لا يمكنك إضافة منتجات متجرك الخاص إلى سلة الشراء.' });
      return;
    }

    const product = mapProduct(productRow);
    if (pricingType === 'carton' && product.cartonPrice <= 0) {
      res.status(400).json({ error: 'هذا المنتج غير متوفر بسعر الكارتون حالياً.' });
      return;
    }

    // Validate game top-up Player ID when adding a game package
    if ((productRow.store_type === 'gaming_topup' || product.gameName) && !selectedOptions?.playerId) {
      res.status(400).json({ error: 'يرجى إدخال معرّف اللاعب (Player ID) قبل إضافة باقة الشحن.' });
      return;
    }

    const finalOptions: OrderItemOptions | undefined = selectedOptions
      ? {
          ...selectedOptions,
          ...(product.gameName && !selectedOptions.gameName ? { gameName: product.gameName } : {}),
        }
      : undefined;
    const optionSignature = buildOptionSignature(finalOptions);
    const optionsJson = JSON.stringify(finalOptions || {});

    const existing = db
      .prepare(
        'SELECT id, quantity FROM cart_items WHERE user_id = ? AND product_id = ? AND pricing_type = ? AND option_signature = ?'
      )
      .get(user.id, product.id, pricingType, optionSignature) as
      | { id: string; quantity: number }
      | undefined;

    const nextQty = (existing ? existing.quantity : 0) + quantityDelta;
    const requiredUnits = unitsNeededForItem(product, pricingType, nextQty);

    if (product.stockQty <= 0) {
      res.status(400).json({ error: 'عذراً، نفدت الكمية المتوفرة من هذا المنتج حالياً.' });
      return;
    }
    if (requiredUnits > product.stockQty) {
      res.status(400).json({
        error: `الكمية المطلوبة غير متوفرة. المتوفر حالياً في المخزون هو ${product.stockQty} ${product.unit}.`,
      });
      return;
    }

    const now = new Date().toISOString();
    if (existing) {
      db.prepare('UPDATE cart_items SET quantity = ?, item_options_json = ?, updated_at = ? WHERE id = ?').run(
        nextQty,
        optionsJson,
        now,
        existing.id
      );
    } else {
      db.prepare(
        `INSERT INTO cart_items (id, user_id, store_id, product_id, pricing_type, option_signature, item_options_json, quantity, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        generateId('crt'),
        user.id,
        product.storeId,
        product.id,
        pricingType,
        optionSignature,
        optionsJson,
        nextQty,
        now,
        now
      );
    }

    res.status(201).json({ items: getUserCartItems(user.id) });
  });

  app.patch('/api/cart/items/:id', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const cartItemId = sanitizeText(req.params.id, 60);
    const quantity = Math.floor(Number(req.body?.quantity));

    const existing = db
      .prepare(
        `SELECT c.*, p.stock_qty, p.unit, p.carton_units, p.carton_price, p.price, p.name, p.store_id, p.category, p.description, p.image_url, p.is_available, p.created_at AS p_created_at
         FROM cart_items c
         JOIN products p ON p.id = c.product_id
         WHERE c.id = ? AND c.user_id = ?`
      )
      .get(cartItemId, user.id) as Record<string, unknown> | undefined;

    if (!existing) {
      res.status(404).json({ error: 'العنصر غير موجود في السلة.' });
      return;
    }

    if (!Number.isFinite(quantity) || quantity <= 0) {
      db.prepare('DELETE FROM cart_items WHERE id = ? AND user_id = ?').run(cartItemId, user.id);
      res.json({ items: getUserCartItems(user.id) });
      return;
    }

    const pricingType: PricingType = existing.pricing_type === 'carton' ? 'carton' : 'unit';
    const stockQty = Number(existing.stock_qty || 0);
    const perCarton = Math.max(1, Number(existing.carton_units || 1));
    const requiredUnits = pricingType === 'carton' ? quantity * perCarton : quantity;

    if (requiredUnits > stockQty) {
      res.status(400).json({
        error: `الكمية المتوفرة في المخزون هي ${stockQty} ${String(existing.unit || 'قطعة')} فقط.`,
      });
      return;
    }

    db.prepare('UPDATE cart_items SET quantity = ?, updated_at = ? WHERE id = ? AND user_id = ?').run(
      quantity,
      new Date().toISOString(),
      cartItemId,
      user.id
    );

    res.json({ items: getUserCartItems(user.id) });
  });

  app.delete('/api/cart/items/:id', requireAuth, (req: AuthedRequest, res) => {
    const cartItemId = sanitizeText(req.params.id, 60);
    db.prepare('DELETE FROM cart_items WHERE id = ? AND user_id = ?').run(cartItemId, req.user!.id);
    res.json({ items: getUserCartItems(req.user!.id) });
  });

  app.delete('/api/cart/store/:storeId', requireAuth, (req: AuthedRequest, res) => {
    const storeId = sanitizeText(req.params.storeId, 60);
    db.prepare('DELETE FROM cart_items WHERE store_id = ? AND user_id = ?').run(
      storeId,
      req.user!.id
    );
    res.json({ items: getUserCartItems(req.user!.id) });
  });

  // Public Marketplace Directory: browse ONLY approved/active stores with search, category, city, district & latest post preview (no product dump)
  app.get('/api/stores', optionalAuth, (req: AuthedRequest, res) => {
    const search = sanitizeText(req.query.search, 100);
    const type = sanitizeText(req.query.type, 40);
    const city = sanitizeText(req.query.city, 80);
    const district = sanitizeText(req.query.district, 80);

    const conditions: string[] = ["s.status = 'active'"];
    const params: unknown[] = [];

    if (search) {
      const normalized = search.toLowerCase();
      const matchingTypes = VALID_STORE_TYPES.filter((t) =>
        STORE_TYPE_LABELS[t].toLowerCase().includes(normalized)
      );
      const like = `%${search}%`;
      if (matchingTypes.length > 0) {
        const placeholders = matchingTypes.map(() => '?').join(', ');
        conditions.push(
          `(s.name LIKE ? OR s.description LIKE ? OR s.city LIKE ? OR s.district LIKE ? OR s.address LIKE ? OR s.store_type IN (${placeholders}))`
        );
        params.push(like, like, like, like, like, ...matchingTypes);
      } else {
        conditions.push(
          '(s.name LIKE ? OR s.description LIKE ? OR s.city LIKE ? OR s.district LIKE ? OR s.address LIKE ?)'
        );
        params.push(like, like, like, like, like);
      }
    }
    if (type && VALID_STORE_TYPES.includes(type as StoreType)) {
      conditions.push('s.store_type = ?');
      params.push(type);
    }
    if (city) {
      conditions.push('s.city = ?');
      params.push(city);
    }
    if (district) {
      conditions.push('s.district = ?');
      params.push(district);
    }

    const sql = `
      SELECT s.*,
        (SELECT COUNT(*) FROM products p WHERE p.store_id = s.id AND p.is_available = 1 AND p.deleted_at IS NULL) AS product_count,
        (SELECT COUNT(*) FROM store_posts sp WHERE sp.store_id = s.id AND sp.status = 'active') AS post_count
      FROM stores s
      WHERE ${conditions.join(' AND ')}
      ORDER BY s.is_verified DESC, post_count DESC, s.created_at DESC
    `;
    const rows = db.prepare(sql).all(...params) as Record<string, unknown>[];
    const stores = rows
      .map(mapStore)
      .filter((st) => checkMerchantCommercialAccess(st.ownerId).allowed);

    // Attach latest active post preview per store in one fast query
    if (stores.length > 0) {
      const ids = stores.map((st) => st.id);
      const placeholders = ids.map(() => '?').join(', ');
      const postRows = db
        .prepare(
          `SELECT sp.*
           FROM store_posts sp
           WHERE sp.store_id IN (${placeholders}) AND sp.status = 'active'
           ORDER BY sp.created_at DESC`
        )
        .all(...ids) as Record<string, unknown>[];

      const latestByStore = new Map<string, StorePost>();
      for (const prow of postRows) {
        const sid = String(prow.store_id);
        if (!latestByStore.has(sid)) {
          latestByStore.set(sid, mapStorePost(prow));
        }
      }
      for (const st of stores) {
        st.latestPost = latestByStore.get(st.id) || null;
      }
    }

    const citiesRows = db
      .prepare("SELECT DISTINCT city FROM stores WHERE status = 'active' AND city != '' ORDER BY city ASC")
      .all() as Array<{ city: string }>;

    const districtsRows = city
      ? (db
          .prepare(
            "SELECT DISTINCT district FROM stores WHERE status = 'active' AND city = ? AND district != '' ORDER BY district ASC"
          )
          .all(city) as Array<{ district: string }>)
      : (db
          .prepare(
            "SELECT DISTINCT district FROM stores WHERE status = 'active' AND district != '' ORDER BY district ASC"
          )
          .all() as Array<{ district: string }>);

    res.json({
      stores,
      cities: citiesRows.map((c) => c.city),
      districts: districtsRows.map((d) => d.district),
    });
  });

  // Public Store detail + its posts/offers + its available products (owner or super_admin can preview non-active store)
  app.get('/api/stores/:id', optionalAuth, (req: AuthedRequest, res) => {
    const storeId = sanitizeText(req.params.id, 60);
    const row = db
      .prepare(
        `SELECT s.*,
          (SELECT COUNT(*) FROM products p WHERE p.store_id = s.id AND p.is_available = 1 AND p.deleted_at IS NULL) AS product_count,
          (SELECT COUNT(*) FROM store_posts sp WHERE sp.store_id = s.id AND sp.status = 'active') AS post_count
         FROM stores s WHERE s.id = ?`
      )
      .get(storeId) as Record<string, unknown> | undefined;

    if (!row) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }

    const store = mapStore(row);
    const isOwnerOrAdmin =
      req.user && (req.user.id === store.ownerId || req.user.role === 'super_admin');
    if (store.status !== 'active' && !isOwnerOrAdmin) {
      res.status(404).json({ error: 'المتجر غير متاح حالياً.' });
      return;
    }
    if (!isOwnerOrAdmin && !checkMerchantCommercialAccess(store.ownerId).allowed) {
      res.status(404).json({ error: 'المتجر متوقف مؤقتاً لحين تجديد اشتراكه.' });
      return;
    }

    const postRows = db
      .prepare(
        `SELECT sp.*, s.name AS store_name, s.store_type AS store_type, s.city AS store_city,
                s.district AS store_district, s.logo_url AS store_logo_url, s.status AS store_status
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         WHERE sp.store_id = ? ${isOwnerOrAdmin ? '' : "AND sp.status = 'active'"}
         ORDER BY sp.created_at DESC
         LIMIT 60`
      )
      .all(store.id) as Record<string, unknown>[];

    const productRows = db
      .prepare(
        `SELECT p.*, s.name AS store_name, s.city AS store_city, s.district AS store_district,
                s.store_type AS store_type, s.delivery_fee AS store_delivery_fee,
                s.address AS store_address, s.phone AS store_phone
         FROM products p
         JOIN stores s ON s.id = p.store_id
         WHERE p.store_id = ? AND p.is_available = 1 AND p.deleted_at IS NULL
         ORDER BY p.created_at DESC`
      )
      .all(store.id) as Record<string, unknown>[];

    const posts = postRows.map(mapStorePost);
    store.latestPost = posts.find((p) => p.status === 'active') || null;

    res.json({
      store,
      posts,
      products: productRows.map(mapProduct),
    });
  });

  // Public Store Posts endpoint
  app.get('/api/stores/:id/posts', optionalAuth, (req: AuthedRequest, res) => {
    const storeId = sanitizeText(req.params.id, 60);
    const storeRow = db
      .prepare('SELECT id, owner_id, status FROM stores WHERE id = ?')
      .get(storeId) as { id: string; owner_id: string; status: string } | undefined;
    if (!storeRow) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }
    const isOwnerOrAdmin =
      req.user && (req.user.id === storeRow.owner_id || req.user.role === 'super_admin');
    if (storeRow.status !== 'active' && !isOwnerOrAdmin) {
      res.status(404).json({ error: 'المتجر غير متاح حالياً.' });
      return;
    }
    if (!isOwnerOrAdmin && !checkMerchantCommercialAccess(storeRow.owner_id).allowed) {
      res.status(404).json({ error: 'المتجر متوقف مؤقتاً لحين تجديد اشتراكه.' });
      return;
    }
    const postRows = db
      .prepare(
        `SELECT sp.*, s.name AS store_name, s.store_type AS store_type, s.city AS store_city,
                s.district AS store_district, s.logo_url AS store_logo_url, s.status AS store_status
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         WHERE sp.store_id = ? ${isOwnerOrAdmin ? '' : "AND sp.status = 'active'"}
         ORDER BY sp.created_at DESC
         LIMIT 60`
      )
      .all(storeId) as Record<string, unknown>[];
    res.json({ posts: postRows.map(mapStorePost) });
  });

  // Privacy-preserving Store Visit Notification (Zero personal customer data sent, merchant-controlled, rate-limited per visitor)
  app.post('/api/stores/:id/visit', optionalAuth, (req: AuthedRequest, res) => {
    const storeId = sanitizeText(req.params.id, 60);
    const storeRow = db
      .prepare("SELECT * FROM stores WHERE id = ? AND status = 'active'")
      .get(storeId) as Record<string, unknown> | undefined;

    if (!storeRow) {
      res.status(404).json({ error: 'المتجر غير متاح.' });
      return;
    }

    const store = mapStore(storeRow);

    // Do not notify if merchant disabled visit notifications in settings
    if (!store.notifyOnStoreVisit) {
      res.json({ notified: false, reason: 'disabled_by_merchant' });
      return;
    }

    // Do not notify when the store owner or Super Admin previews the store
    if (req.user && (req.user.id === store.ownerId || req.user.role === 'super_admin')) {
      res.json({ notified: false, reason: 'owner_or_admin_preview' });
      return;
    }

    // Anonymous one-way visitor fingerprint (never stored or sent as personal info)
    const rawVisitorSeed = req.user
      ? `u:${req.user.id}`
      : `g:${req.ip || 'unknown'}:${String(req.headers['user-agent'] || '').slice(0, 80)}`;
    const visitorHash = crypto.createHash('sha256').update(rawVisitorSeed).digest('hex').slice(0, 32);

    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const recentVisit = db
      .prepare(
        'SELECT id FROM store_visits WHERE store_id = ? AND visitor_hash = ? AND created_at > ? LIMIT 1'
      )
      .get(store.id, visitorHash, tenMinutesAgo) as { id: string } | undefined;

    if (recentVisit) {
      res.json({ notified: false, reason: 'throttled' });
      return;
    }

    const now = new Date().toISOString();
    db.prepare(
      'INSERT INTO store_visits (id, store_id, visitor_hash, created_at) VALUES (?, ?, ?, ?)'
    ).run(generateId('vst'), store.id, visitorHash, now);

    // Dispatch anonymous store-visit notification ONLY to this store's owner
    createAndDispatchNotification({
      userId: store.ownerId,
      storeId: store.id,
      orderId: null,
      type: 'store_visit',
      title: `زائر يتصفح متجر ${store.name} الآن`,
      body: `دخل أحد الزبائن إلى صفحة متجرك ويتصفح المنتجات حالياً · الوقت: ${formatTimeAr(now)}`,
      targetView: 'merchant',
    });

    res.json({ notified: true });
  });

  // Public Marketplace: browse/search published & available products across ALL active stores in central DB
  app.get('/api/products', (req, res) => {
    const search = sanitizeText(req.query.search, 100);
    const category = sanitizeText(req.query.category, 80);
    const storeType = sanitizeText(req.query.storeType, 40);
    const city = sanitizeText(req.query.city, 80);
    const district = sanitizeText(req.query.district, 80);
    const cartonOnly = req.query.cartonOnly === 'true';

    const conditions: string[] = ["s.status = 'active'", 'p.is_available = 1', 'p.deleted_at IS NULL'];
    const params: unknown[] = [];

    if (search) {
      conditions.push(
        '(p.name LIKE ? OR p.description LIKE ? OR s.name LIKE ? OR s.city LIKE ? OR s.district LIKE ? OR p.category LIKE ? OR p.game_name LIKE ? OR p.phone_models_json LIKE ?)'
      );
      const like = `%${search}%`;
      params.push(like, like, like, like, like, like, like, like);
    }
    if (category) {
      conditions.push('p.category = ?');
      params.push(category);
    }
    if (storeType && VALID_STORE_TYPES.includes(storeType as StoreType)) {
      conditions.push('s.store_type = ?');
      params.push(storeType);
    }
    if (city) {
      conditions.push('s.city = ?');
      params.push(city);
    }
    if (district) {
      conditions.push('s.district = ?');
      params.push(district);
    }
    if (cartonOnly) {
      conditions.push('p.carton_price > 0');
    }

    const rows = db
      .prepare(
        `SELECT p.*, s.owner_id AS store_owner_id, s.name AS store_name, s.city AS store_city, s.district AS store_district,
                s.store_type AS store_type, s.delivery_fee AS store_delivery_fee,
                s.address AS store_address, s.phone AS store_phone
         FROM products p
         JOIN stores s ON s.id = p.store_id
         WHERE ${conditions.join(' AND ')}
         ORDER BY p.created_at DESC
         LIMIT 300`
      )
      .all(...params) as Record<string, unknown>[];

    const activeRows = rows.filter((r) =>
      checkMerchantCommercialAccess(String(r.store_owner_id || '')).allowed
    );
    res.json({ products: activeRows.map(mapProduct) });
  });

  // Merchant (or existing Customer upgrading their single account): register own store
  app.post(
    '/api/merchant/store',
    requireRole('merchant', 'customer'),
    (req: AuthedRequest, res) => {
      const user = req.user!;
      const existing = getOwnedStore(user.id);
      if (existing) {
        res.status(409).json({ error: 'لديك متجر مسجل بالفعل. يمكنك تعديل بياناته من الإعدادات.' });
        return;
      }

      const name = sanitizeText(req.body?.name, 120);
      const storeType = req.body?.storeType as StoreType;
      const description = sanitizeText(req.body?.description, 600);
      const city = sanitizeText(req.body?.city, 80);
      const district = sanitizeText(req.body?.district, 80);
      const address = sanitizeText(req.body?.address, 250);
      const latitude = parseCoordinate(req.body?.latitude, -90, 90);
      const longitude = parseCoordinate(req.body?.longitude, -180, 180);
      const phone = sanitizeText(req.body?.phone, 24);
      const openingHours = sanitizeText(req.body?.openingHours, 120) || 'يومياً 8:00 ص - 11:00 م';
      const deliveryFee = Math.max(0, Number(req.body?.deliveryFee) || 0);
      const minOrderAmount = Math.max(0, Number(req.body?.minOrderAmount) || 0);
      const logoUrl = sanitizeImageUrl(req.body?.logoUrl);
      const coverUrl = sanitizeImageUrl(req.body?.coverUrl);

      if (name.length < 2) {
        res.status(400).json({ error: 'اسم المتجر مطلوب.' });
        return;
      }
      if (!VALID_STORE_TYPES.includes(storeType)) {
        res.status(400).json({ error: 'نوع النشاط غير صالح.' });
        return;
      }
      if (city.length < 2 || address.length < 3) {
        res.status(400).json({ error: 'يرجى إدخال المدينة والعنوان التفصيلي.' });
        return;
      }
      if (!isValidPhone(phone)) {
        res.status(400).json({ error: 'يرجى إدخال رقم تواصل صحيح للمتجر.' });
        return;
      }

      const requireApproval = getPlatformSetting('require_store_approval', 'false') === 'true';
      const initialStatus: StoreStatus = requireApproval ? 'pending' : 'active';
      const id = generateId('str');
      const now = new Date().toISOString();
      const serviceConfigObj: StoreServiceConfig =
        storeType === 'printing'
          ? { printPricing: sanitizePrintPricing(req.body?.serviceConfig?.printPricing, DEFAULT_PRINT_PRICING) }
          : {};
      const serviceConfigJson = JSON.stringify(serviceConfigObj);

      const createTx = db.transaction(() => {
        db.prepare(
          `INSERT INTO stores
            (id, owner_id, name, store_type, description, city, district, address, latitude, longitude, phone, opening_hours, delivery_fee, min_order_amount, logo_url, cover_url, status, rejection_reason, is_verified, service_config, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', 0, ?, ?)`
        ).run(
          id,
          user.id,
          name,
          storeType,
          description,
          city,
          district,
          address,
          latitude,
          longitude,
          phone,
          openingHours,
          deliveryFee,
          minOrderAmount,
          logoUrl,
          coverUrl,
          initialStatus,
          serviceConfigJson,
          now
        );

        // Single-account model: upgrade customer's existing account to merchant without creating a second account
        if (user.role === 'customer') {
          db.prepare("UPDATE users SET role = 'merchant' WHERE id = ? AND role = 'customer'").run(
            user.id
          );
        }
      });
      createTx();

      ensureUserSubscription(user.id, 'merchant', id);

      const updatedUserRow = db
        .prepare('SELECT * FROM users WHERE id = ?')
        .get(user.id) as Record<string, unknown>;
      const updatedUser = updatedUserRow ? mapUser(updatedUserRow) : user;
      const store = getOwnedStore(user.id);
      const subscription = evaluateUserSubscription(user.id);

      // Notify all active Super Admins immediately when a new store joins SOUQNA
      const admins = db
        .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
        .all() as Array<{ id: string }>;
      for (const adm of admins) {
        createAndDispatchNotification({
          userId: adm.id,
          storeId: id,
          orderId: null,
          type: 'store_status',
          title: `متجر جديد مسجّل: ${name}`,
          body: `قام التاجر ${updatedUser.fullName} بتسجيل متجر «${name}» (${STORE_TYPE_LABELS[storeType]} · ${city}) · الحالة: ${STORE_STATUS_LABELS[initialStatus]}`,
          targetView: 'admin',
        });
      }

      res.status(201).json({ store, user: updatedUser, subscription });
    }
  );

  app.patch('/api/merchant/store', requireRole('merchant'), (req: AuthedRequest, res) => {
    const user = req.user!;
    const existing = getOwnedStore(user.id);
    if (!existing) {
      res.status(404).json({ error: 'لم تقم بإنشاء متجرك بعد.' });
      return;
    }

    const name = sanitizeText(req.body?.name ?? existing.name, 120);
    const storeType = (req.body?.storeType ?? existing.storeType) as StoreType;
    const description = sanitizeText(req.body?.description ?? existing.description, 600);
    const city = sanitizeText(req.body?.city ?? existing.city, 80);
    const district = sanitizeText(req.body?.district ?? existing.district, 80);
    const address = sanitizeText(req.body?.address ?? existing.address, 250);
    const latitude =
      req.body?.latitude !== undefined
        ? parseCoordinate(req.body.latitude, -90, 90)
        : existing.latitude ?? null;
    const longitude =
      req.body?.longitude !== undefined
        ? parseCoordinate(req.body.longitude, -180, 180)
        : existing.longitude ?? null;
    const phone = sanitizeText(req.body?.phone ?? existing.phone, 24);
    const openingHours = sanitizeText(req.body?.openingHours ?? existing.openingHours, 120);
    const deliveryFee = Math.max(0, Number(req.body?.deliveryFee ?? existing.deliveryFee) || 0);
    const minOrderAmount = Math.max(
      0,
      Number(req.body?.minOrderAmount ?? existing.minOrderAmount) || 0
    );
    const logoUrl =
      req.body?.logoUrl !== undefined ? sanitizeImageUrl(req.body.logoUrl) : existing.logoUrl;
    const coverUrl =
      req.body?.coverUrl !== undefined ? sanitizeImageUrl(req.body.coverUrl) : existing.coverUrl;
    const notifyOnStoreVisit =
      typeof req.body?.notifyOnStoreVisit === 'boolean'
        ? req.body.notifyOnStoreVisit
          ? 1
          : 0
        : existing.notifyOnStoreVisit
        ? 1
        : 0;
    const resubmit = req.body?.resubmitForReview === true && existing.status === 'rejected';

    if (name.length < 2 || !VALID_STORE_TYPES.includes(storeType) || !isValidPhone(phone)) {
      res.status(400).json({ error: 'يرجى التحقق من صحة بيانات المتجر.' });
      return;
    }

    let nextServiceConfig: StoreServiceConfig = existing.serviceConfig || {};
    if (storeType === 'printing') {
      nextServiceConfig = {
        ...nextServiceConfig,
        printPricing: sanitizePrintPricing(
          req.body?.serviceConfig?.printPricing,
          existing.serviceConfig?.printPricing || DEFAULT_PRINT_PRICING
        ),
      };
    }

    db.prepare(
      `UPDATE stores
       SET name = ?, store_type = ?, description = ?, city = ?, district = ?, address = ?, latitude = ?, longitude = ?, phone = ?, opening_hours = ?,
           delivery_fee = ?, min_order_amount = ?, logo_url = ?, cover_url = ?, notify_on_store_visit = ?,
           service_config = ?, status = ?, rejection_reason = ?
       WHERE id = ? AND owner_id = ?`
    ).run(
      name,
      storeType,
      description,
      city,
      district,
      address,
      latitude,
      longitude,
      phone,
      openingHours,
      deliveryFee,
      minOrderAmount,
      logoUrl,
      coverUrl,
      notifyOnStoreVisit,
      JSON.stringify(nextServiceConfig),
      resubmit ? 'pending' : existing.status,
      resubmit ? '' : existing.rejectionReason,
      existing.id,
      user.id
    );

    res.json({ store: getOwnedStore(user.id) });
  });

  // Merchant: CRUD own products ONLY (excludes soft-deleted items)
  app.get('/api/merchant/products', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.json({ products: [] });
      return;
    }
    const rows = db
      .prepare('SELECT * FROM products WHERE store_id = ? AND deleted_at IS NULL ORDER BY created_at DESC')
      .all(store.id) as Record<string, unknown>[];
    res.json({ products: rows.map(mapProduct) });
  });

  app.post('/api/merchant/products', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.status(400).json({ error: 'يرجى إنشاء متجرك أولاً قبل إضافة المنتجات.' });
      return;
    }
    const subCheck = checkMerchantCommercialAccess(req.user!.id);
    if (!subCheck.allowed) {
      res.status(403).json({ error: subCheck.error });
      return;
    }

    const name = sanitizeText(req.body?.name, 140);
    const category = sanitizeText(req.body?.category, 80) || 'أخرى';
    const description = sanitizeText(req.body?.description, 600);
    const price = Number(req.body?.price);
    const unit = sanitizeText(req.body?.unit, 40) || 'قطعة';
    const cartonPrice = Math.max(0, Number(req.body?.cartonPrice) || 0);
    const cartonUnits =
      cartonPrice > 0 ? Math.max(1, Math.floor(Number(req.body?.cartonUnits) || 12)) : 0;
    const stockQty = Math.max(0, Math.floor(Number(req.body?.stockQty) || 0));
    const imageUrl = sanitizeImageUrl(req.body?.imageUrl);
    const isAvailable = req.body?.isAvailable === false ? 0 : 1;
    const availableSizes = sanitizeStringArray(req.body?.availableSizes, 25, 30);
    const availableColors = sanitizeStringArray(req.body?.availableColors, 25, 30);
    const compatibleModels = sanitizeStringArray(req.body?.compatibleModels, 40, 70);
    const gameName = sanitizeText(req.body?.gameName, 80);
    const customOptions = sanitizeStringArray(req.body?.customOptions, 25, 60);

    if (name.length < 2) {
      res.status(400).json({ error: 'اسم المنتج مطلوب.' });
      return;
    }
    if (!Number.isFinite(price) || price <= 0) {
      res.status(400).json({ error: 'يرجى إدخال سعر صحيح أكبر من صفر.' });
      return;
    }

    const id = generateId('prd');
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO products (id, store_id, name, category, description, price, unit, carton_price, carton_units, stock_qty, image_url, is_available, sizes_json, colors_json, phone_models_json, game_name, custom_options_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      store.id,
      name,
      category,
      description,
      price,
      unit,
      cartonPrice,
      cartonUnits,
      stockQty,
      imageUrl,
      isAvailable,
      JSON.stringify(availableSizes),
      JSON.stringify(availableColors),
      JSON.stringify(compatibleModels),
      gameName,
      JSON.stringify(customOptions),
      now
    );

    const row = db.prepare('SELECT * FROM products WHERE id = ?').get(id) as Record<
      string,
      unknown
    >;
    res.status(201).json({ product: mapProduct(row) });
  });

  app.patch('/api/merchant/products/:id', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }
    const subCheck = checkMerchantCommercialAccess(req.user!.id);
    if (!subCheck.allowed) {
      res.status(403).json({ error: subCheck.error });
      return;
    }

    const productId = sanitizeText(req.params.id, 60);
    const existingRow = db
      .prepare('SELECT * FROM products WHERE id = ? AND store_id = ?')
      .get(productId, store.id) as Record<string, unknown> | undefined;

    if (!existingRow) {
      res.status(404).json({ error: 'المنتج غير موجود في متجرك.' });
      return;
    }

    const existing = mapProduct(existingRow);
    const name = sanitizeText(req.body?.name ?? existing.name, 140);
    const category = sanitizeText(req.body?.category ?? existing.category, 80);
    const description = sanitizeText(req.body?.description ?? existing.description, 600);
    const price = req.body?.price !== undefined ? Number(req.body.price) : existing.price;
    const unit = sanitizeText(req.body?.unit ?? existing.unit, 40);
    const cartonPrice =
      req.body?.cartonPrice !== undefined
        ? Math.max(0, Number(req.body.cartonPrice) || 0)
        : existing.cartonPrice;
    const cartonUnits =
      cartonPrice > 0
        ? Math.max(
            1,
            Math.floor(
              Number(
                req.body?.cartonUnits !== undefined ? req.body.cartonUnits : existing.cartonUnits
              ) || 12
            )
          )
        : 0;
    const stockQty =
      req.body?.stockQty !== undefined
        ? Math.max(0, Math.floor(Number(req.body.stockQty)))
        : existing.stockQty;
    const imageUrl =
      req.body?.imageUrl !== undefined ? sanitizeImageUrl(req.body.imageUrl) : existing.imageUrl;
    const isAvailable =
      req.body?.isAvailable !== undefined
        ? req.body.isAvailable
          ? 1
          : 0
        : existing.isAvailable
        ? 1
        : 0;
    const availableSizes =
      req.body?.availableSizes !== undefined
        ? sanitizeStringArray(req.body.availableSizes, 25, 30)
        : existing.availableSizes;
    const availableColors =
      req.body?.availableColors !== undefined
        ? sanitizeStringArray(req.body.availableColors, 25, 30)
        : existing.availableColors;
    const compatibleModels =
      req.body?.compatibleModels !== undefined
        ? sanitizeStringArray(req.body.compatibleModels, 40, 70)
        : existing.compatibleModels;
    const gameName =
      req.body?.gameName !== undefined ? sanitizeText(req.body.gameName, 80) : existing.gameName;
    const customOptions =
      req.body?.customOptions !== undefined
        ? sanitizeStringArray(req.body.customOptions, 25, 60)
        : existing.customOptions;

    if (name.length < 2 || !Number.isFinite(price) || price <= 0) {
      res.status(400).json({ error: 'بيانات المنتج غير صالحة.' });
      return;
    }

    db.prepare(
      `UPDATE products
       SET name = ?, category = ?, description = ?, price = ?, unit = ?, carton_price = ?, carton_units = ?, stock_qty = ?, image_url = ?, is_available = ?,
           sizes_json = ?, colors_json = ?, phone_models_json = ?, game_name = ?, custom_options_json = ?
       WHERE id = ? AND store_id = ?`
    ).run(
      name,
      category,
      description,
      price,
      unit,
      cartonPrice,
      cartonUnits,
      stockQty,
      imageUrl,
      isAvailable,
      JSON.stringify(availableSizes),
      JSON.stringify(availableColors),
      JSON.stringify(compatibleModels),
      gameName,
      JSON.stringify(customOptions),
      productId,
      store.id
    );

    const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(productId) as Record<
      string,
      unknown
    >;
    res.json({ product: mapProduct(updated) });
  });

  // Merchant: soft-delete product (enables safe Undo / restore without breaking historical order items)
  app.delete('/api/merchant/products/:id', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }

    const productId = sanitizeText(req.params.id, 60);
    const now = new Date().toISOString();
    const info = db
      .prepare('UPDATE products SET deleted_at = ?, is_available = 0 WHERE id = ? AND store_id = ? AND deleted_at IS NULL')
      .run(now, productId, store.id);

    if (info.changes === 0) {
      res.status(404).json({ error: 'المنتج غير موجود في متجرك.' });
      return;
    }
    db.prepare('DELETE FROM cart_items WHERE product_id = ?').run(productId);
    res.json({ ok: true, restorable: true });
  });

  // Merchant: Undo product deletion
  app.post('/api/merchant/products/:id/restore', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }
    const subCheck = checkMerchantCommercialAccess(req.user!.id);
    if (!subCheck.allowed) {
      res.status(403).json({ error: subCheck.error });
      return;
    }

    const productId = sanitizeText(req.params.id, 60);
    const info = db
      .prepare('UPDATE products SET deleted_at = NULL, is_available = 1 WHERE id = ? AND store_id = ? AND deleted_at IS NOT NULL')
      .run(productId, store.id);

    if (info.changes === 0) {
      res.status(404).json({ error: 'تعذر استعادة المنتج.' });
      return;
    }
    const restored = db.prepare('SELECT * FROM products WHERE id = ?').get(productId) as Record<
      string,
      unknown
    >;
    res.json({ product: mapProduct(restored) });
  });

  // Merchant: Store Posts & Offers Management (strict ownership enforced)
  app.get('/api/merchant/posts', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.json({ posts: [] });
      return;
    }
    const rows = db
      .prepare(
        `SELECT sp.*, s.name AS store_name, s.store_type AS store_type, s.city AS store_city,
                s.district AS store_district, s.logo_url AS store_logo_url, s.status AS store_status
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         WHERE sp.store_id = ?
         ORDER BY sp.created_at DESC`
      )
      .all(store.id) as Record<string, unknown>[];
    res.json({ posts: rows.map(mapStorePost) });
  });

  app.post('/api/merchant/posts', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.status(400).json({ error: 'يرجى إنشاء ملف متجرك أولاً قبل نشر المنشورات.' });
      return;
    }
    const subCheck = checkMerchantCommercialAccess(req.user!.id);
    if (!subCheck.allowed) {
      res.status(403).json({ error: subCheck.error });
      return;
    }

    const title = sanitizeText(req.body?.title, 140);
    const content = sanitizeText(req.body?.content, 1600);
    const postType: StorePostType = VALID_POST_TYPES.includes(req.body?.postType)
      ? (req.body.postType as StorePostType)
      : 'announcement';
    const offerBadge = sanitizeText(req.body?.offerBadge, 60);
    const images = sanitizePostImages(req.body?.images);

    if (title.length < 3) {
      res.status(400).json({ error: 'يرجى إدخال عنوان واضح للمنشور (3 أحرف على الأقل).' });
      return;
    }
    if (!content && images.length === 0) {
      res.status(400).json({ error: 'يرجى إضافة وصف للمنشور أو إرفاق صورة واحدة على الأقل.' });
      return;
    }

    const postId = generateId('post');
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO store_posts
        (id, store_id, author_id, title, content, post_type, offer_badge, images_json, status, moderation_reason, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', '', ?, ?)`
    ).run(
      postId,
      store.id,
      req.user!.id,
      title,
      content,
      postType,
      offerBadge,
      JSON.stringify(images),
      now,
      now
    );

    const created = db
      .prepare(
        `SELECT sp.*, s.name AS store_name, s.store_type AS store_type, s.city AS store_city,
                s.district AS store_district, s.logo_url AS store_logo_url, s.status AS store_status
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         WHERE sp.id = ?`
      )
      .get(postId) as Record<string, unknown>;

    res.status(201).json({ post: mapStorePost(created) });
  });

  app.patch('/api/merchant/posts/:id', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }
    const subCheck = checkMerchantCommercialAccess(req.user!.id);
    if (!subCheck.allowed) {
      res.status(403).json({ error: subCheck.error });
      return;
    }
    const postId = sanitizeText(req.params.id, 60);
    const existing = db
      .prepare('SELECT * FROM store_posts WHERE id = ? AND store_id = ?')
      .get(postId, store.id) as Record<string, unknown> | undefined;
    if (!existing) {
      res.status(404).json({ error: 'المنشور غير موجود في متجرك.' });
      return;
    }

    const title =
      req.body?.title !== undefined ? sanitizeText(req.body.title, 140) : String(existing.title);
    const content =
      req.body?.content !== undefined
        ? sanitizeText(req.body.content, 1600)
        : String(existing.content);
    const postType: StorePostType =
      req.body?.postType !== undefined && VALID_POST_TYPES.includes(req.body.postType)
        ? (req.body.postType as StorePostType)
        : (existing.post_type as StorePostType);
    const offerBadge =
      req.body?.offerBadge !== undefined
        ? sanitizeText(req.body.offerBadge, 60)
        : String(existing.offer_badge || '');
    const images =
      req.body?.images !== undefined
        ? sanitizePostImages(req.body.images)
        : parsePostImages(existing.images_json);

    if (title.length < 3) {
      res.status(400).json({ error: 'عنوان المنشور يجب أن يكون 3 أحرف على الأقل.' });
      return;
    }

    const now = new Date().toISOString();
    db.prepare(
      `UPDATE store_posts
       SET title = ?, content = ?, post_type = ?, offer_badge = ?, images_json = ?, updated_at = ?
       WHERE id = ? AND store_id = ?`
    ).run(title, content, postType, offerBadge, JSON.stringify(images), now, postId, store.id);

    const updated = db
      .prepare(
        `SELECT sp.*, s.name AS store_name, s.store_type AS store_type, s.city AS store_city,
                s.district AS store_district, s.logo_url AS store_logo_url, s.status AS store_status
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         WHERE sp.id = ?`
      )
      .get(postId) as Record<string, unknown>;

    res.json({ post: mapStorePost(updated) });
  });

  app.delete('/api/merchant/posts/:id', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }
    const postId = sanitizeText(req.params.id, 60);
    const info = db
      .prepare('DELETE FROM store_posts WHERE id = ? AND store_id = ?')
      .run(postId, store.id);
    if (info.changes === 0) {
      res.status(404).json({ error: 'المنشور غير موجود في متجرك.' });
      return;
    }
    res.json({ ok: true });
  });

  // Helper to restore stock safely ONCE when an order is rejected or cancelled
  function restoreOrderStock(orderId: string): boolean {
    const orderRow = db
      .prepare('SELECT stock_restored FROM orders WHERE id = ?')
      .get(orderId) as { stock_restored: number } | undefined;
    if (!orderRow || Number(orderRow.stock_restored) === 1) {
      return false;
    }

    const items = db
      .prepare('SELECT product_id, pricing_type, quantity FROM order_items WHERE order_id = ?')
      .all(orderId) as Array<{ product_id: string | null; pricing_type: string; quantity: number }>;

    const restoreStmt = db.prepare('UPDATE products SET stock_qty = stock_qty + ? WHERE id = ?');
    for (const item of items) {
      if (!item.product_id) continue;
      const prod = db
        .prepare('SELECT carton_units FROM products WHERE id = ?')
        .get(item.product_id) as { carton_units: number } | undefined;
      if (!prod) continue;
      const units =
        item.pricing_type === 'carton'
          ? item.quantity * Math.max(1, prod.carton_units || 1)
          : item.quantity;
      restoreStmt.run(units, item.product_id);
    }

    db.prepare('UPDATE orders SET stock_restored = 1 WHERE id = ?').run(orderId);
    return true;
  }

  // Merchant: incoming cash orders
  app.get('/api/merchant/orders', requireRole('merchant'), (req: AuthedRequest, res) => {
    const store = getOwnedStore(req.user!.id);
    if (!store) {
      res.json({ orders: [] });
      return;
    }
    const rows = db
      .prepare(
        `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
         FROM orders o
         JOIN stores s ON s.id = o.store_id
         WHERE o.store_id = ?
         ORDER BY o.created_at DESC`
      )
      .all(store.id) as Record<string, unknown>[];
    res.json({
      orders: attachOrderItems(rows, { role: req.user!.role, userId: req.user!.id }),
    });
  });

  // Merchant-only: Request a verified nearby courier for a delivery order (never allowed for customers or pickup orders)
  app.post(
    '/api/merchant/orders/:id/request-courier',
    requireRole('merchant'),
    (req: AuthedRequest, res) => {
      const merchant = req.user!;
      const store = getOwnedStore(merchant.id);
      if (!store) {
        res.status(404).json({ error: 'المتجر غير موجود.' });
        return;
      }

      const orderId = sanitizeText(req.params.id, 60);
      const orderRow = db
        .prepare('SELECT * FROM orders WHERE id = ? AND store_id = ?')
        .get(orderId, store.id) as Record<string, unknown> | undefined;

      if (!orderRow) {
        res.status(404).json({ error: 'الطلب غير موجود ضمن طلبات متجرك.' });
        return;
      }

      if (String(orderRow.fulfillment_method) !== 'delivery') {
        res.status(400).json({
          error: 'هذا الطلب مخصص للاستلام من المحل وليس للتوصيل — لا يمكن طلب مندوب له.',
        });
        return;
      }

      const orderStatus = String(orderRow.status) as OrderStatus;
      if (orderStatus === 'cancelled' || orderStatus === 'rejected' || orderStatus === 'delivered') {
        res.status(400).json({ error: 'لا يمكن طلب مندوب لطلب مكتمل أو ملغي أو مرفوض.' });
        return;
      }

      const existingDelivery = db
        .prepare('SELECT * FROM deliveries WHERE order_id = ?')
        .get(orderId) as Record<string, unknown> | undefined;

      if (existingDelivery && existingDelivery.status !== 'cancelled') {
        res.status(409).json({ error: 'تم إنشاء طلب توصيل لهذا الطلب بالفعل.' });
        return;
      }

      // Find verified & currently available couriers with active user accounts
      const candidateCouriers = db
        .prepare(
          `SELECT c.user_id, c.governorate, c.city, c.latitude, c.longitude, u.full_name
           FROM couriers c
           JOIN users u ON u.id = c.user_id
           WHERE c.verification_status = 'verified' AND c.is_available = 1 AND u.is_active = 1`
        )
        .all() as Array<{
        user_id: string;
        governorate: string;
        city: string;
        latitude: number | null;
        longitude: number | null;
        full_name: string;
      }>;

      const storeLat = store.latitude ?? null;
      const storeLng = store.longitude ?? null;
      const storeCityNorm = (store.city || '').trim().toLowerCase();

      const rankedCouriers = candidateCouriers
        .map((c) => {
          const dist = haversineKm(storeLat, storeLng, c.latitude, c.longitude);
          const sameCity =
            storeCityNorm &&
            ((c.city || '').trim().toLowerCase() === storeCityNorm ||
              (c.governorate || '').trim().toLowerCase() === storeCityNorm);
          return {
            ...c,
            distanceKm: dist,
            sortScore: dist !== null ? dist : sameCity ? 25 : 9999,
          };
        })
        .sort((a, b) => a.sortScore - b.sortScore)
        .slice(0, 12);

      const now = new Date().toISOString();
      const deliveryId = existingDelivery ? String(existingDelivery.id) : generateId('dlv');
      const deliveryNumber = existingDelivery
        ? String(existingDelivery.delivery_number)
        : generateDeliveryNumber();
      const deliveryOtp = generateDeliveryOtp();
      const initialDeliveryStatus: DeliveryStatus =
        rankedCouriers.length > 0 ? 'dispatched' : 'waiting_courier';
      const pickupAddress = [store.city, store.district, store.address].filter(Boolean).join(' - ');
      const dropoffAddress = String(orderRow.delivery_address || '');
      const dropoffLat =
        orderRow.latitude !== null && orderRow.latitude !== undefined
          ? Number(orderRow.latitude)
          : null;
      const dropoffLng =
        orderRow.longitude !== null && orderRow.longitude !== undefined
          ? Number(orderRow.longitude)
          : null;
      const deliveryFee = Number(orderRow.delivery_fee || 0);
      const cashToCollect = Number(orderRow.total_amount || 0);

      const dispatchTx = db.transaction(() => {
        if (existingDelivery) {
          db.prepare(
            `UPDATE deliveries
             SET courier_id = NULL, status = ?, pickup_address = ?, pickup_lat = ?, pickup_lng = ?,
                 dropoff_address = ?, dropoff_lat = ?, dropoff_lng = ?, delivery_fee = ?, cash_to_collect = ?,
                 delivery_otp = ?, otp_verified = 0, distance_km = NULL, cancel_reason = '',
                 requested_at = ?, dispatched_at = ?, accepted_at = '', picked_up_at = '', delivered_at = '', cancelled_at = '', updated_at = ?
             WHERE id = ?`
          ).run(
            initialDeliveryStatus,
            pickupAddress,
            storeLat,
            storeLng,
            dropoffAddress,
            dropoffLat,
            dropoffLng,
            deliveryFee,
            cashToCollect,
            deliveryOtp,
            now,
            rankedCouriers.length > 0 ? now : '',
            now,
            deliveryId
          );
        } else {
          db.prepare(
            `INSERT INTO deliveries
              (id, delivery_number, order_id, store_id, customer_id, courier_id, status, pickup_address, pickup_lat, pickup_lng, dropoff_address, dropoff_lat, dropoff_lng, delivery_fee, cash_to_collect, delivery_otp, otp_verified, distance_km, cancel_reason, requested_at, dispatched_at, accepted_at, picked_up_at, delivered_at, cancelled_at, updated_at)
             VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, NULL, '', ?, ?, '', '', '', '', ?)`
          ).run(
            deliveryId,
            deliveryNumber,
            orderId,
            store.id,
            String(orderRow.customer_id),
            initialDeliveryStatus,
            pickupAddress,
            storeLat,
            storeLng,
            dropoffAddress,
            dropoffLat,
            dropoffLng,
            deliveryFee,
            cashToCollect,
            deliveryOtp,
            now,
            rankedCouriers.length > 0 ? now : '',
            now
          );
        }

        if (orderStatus === 'pending') {
          db.prepare("UPDATE orders SET status = 'confirmed', updated_at = ? WHERE id = ?").run(
            now,
            orderId
          );
        }

        logDeliveryEvent({
          deliveryId,
          eventType: 'requested',
          actorId: merchant.id,
          actorName: merchant.fullName,
          actorRole: 'merchant',
          notes:
            rankedCouriers.length > 0
              ? `تم إرسال طلب التوصيل إلى أقرب ${rankedCouriers.length} مندوب متاح`
              : 'تم إنشاء طلب التوصيل وبانتظار توفر مندوب موثق قريب',
          previousStatus: existingDelivery ? 'cancelled' : '',
          newStatus: initialDeliveryStatus,
        });
      });
      dispatchTx();

      const currency = getPlatformSetting('currency', 'د.ع');
      for (const courier of rankedCouriers) {
        const distLabel =
          courier.distanceKm !== null ? ` · يبعد ${courier.distanceKm} كم` : '';
        createAndDispatchNotification({
          userId: courier.user_id,
          storeId: store.id,
          orderId,
          type: 'delivery_new',
          title: `طلب توصيل قريب جديد من ${store.name}`,
          body: `استلام من: ${pickupAddress}${distLabel} · التحصيل النقدي: ${formatAmountArabic(
            cashToCollect,
            currency
          )} — اضغط لقبول التوصيل قبل غيرك`,
          targetView: 'courier',
        });
      }

      const updatedOrderRow = db
        .prepare(
          `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
           FROM orders o JOIN stores s ON s.id = o.store_id WHERE o.id = ?`
        )
        .get(orderId) as Record<string, unknown>;

      res.status(201).json({
        order: attachOrderItems([updatedOrderRow], { role: merchant.role, userId: merchant.id })[0],
        notifiedCouriersCount: rankedCouriers.length,
      });
    }
  );

  app.post(
    '/api/merchant/orders/:id/cancel-delivery',
    requireRole('merchant'),
    (req: AuthedRequest, res) => {
      const merchant = req.user!;
      const store = getOwnedStore(merchant.id);
      if (!store) {
        res.status(404).json({ error: 'المتجر غير موجود.' });
        return;
      }
      const orderId = sanitizeText(req.params.id, 60);
      const reason = sanitizeText(req.body?.reason, 300) || 'تم إلغاء طلب التوصيل من قِبل المتجر';

      const deliveryRow = db
        .prepare('SELECT * FROM deliveries WHERE order_id = ? AND store_id = ?')
        .get(orderId, store.id) as Record<string, unknown> | undefined;

      if (!deliveryRow) {
        res.status(404).json({ error: 'لا يوجد طلب توصيل مرتبط بهذا الطلب.' });
        return;
      }
      if (deliveryRow.status === 'delivered' || deliveryRow.status === 'cancelled') {
        res.status(400).json({ error: 'لا يمكن إلغاء توصيل مكتمل أو ملغي مسبقاً.' });
        return;
      }

      const now = new Date().toISOString();
      db.prepare(
        `UPDATE deliveries SET status = 'cancelled', cancel_reason = ?, cancelled_at = ?, updated_at = ? WHERE id = ?`
      ).run(reason, now, now, String(deliveryRow.id));

      logDeliveryEvent({
        deliveryId: String(deliveryRow.id),
        eventType: 'cancelled',
        actorId: merchant.id,
        actorName: merchant.fullName,
        actorRole: 'merchant',
        notes: reason,
        previousStatus: String(deliveryRow.status),
        newStatus: 'cancelled',
      });

      if (deliveryRow.courier_id) {
        createAndDispatchNotification({
          userId: String(deliveryRow.courier_id),
          storeId: store.id,
          orderId,
          type: 'delivery_cancelled',
          title: `تم إلغاء التوصيل ${String(deliveryRow.delivery_number)}`,
          body: `قام متجر ${store.name} بإلغاء طلب التوصيل · السبب: ${reason}`,
          targetView: 'courier',
        });
      }

      const updatedOrderRow = db
        .prepare(
          `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
           FROM orders o JOIN stores s ON s.id = o.store_id WHERE o.id = ?`
        )
        .get(orderId) as Record<string, unknown>;

      res.json({
        order: attachOrderItems([updatedOrderRow], { role: merchant.role, userId: merchant.id })[0],
      });
    }
  );

  app.patch('/api/merchant/orders/:id/status', requireRole('merchant'), (req: AuthedRequest, res) => {
    const merchant = req.user!;
    const store = getOwnedStore(merchant.id);
    if (!store) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }
    const orderId = sanitizeText(req.params.id, 60);
    const nextStatus = req.body?.status as OrderStatus;
    const reason = sanitizeText(req.body?.reason, 300);
    const restoreStockFlag = req.body?.restoreStock !== false;

    if (!VALID_ORDER_STATUSES.includes(nextStatus)) {
      res.status(400).json({ error: 'حالة الطلب غير صالحة.' });
      return;
    }

    const existing = db
      .prepare('SELECT id, order_number, customer_id, status FROM orders WHERE id = ? AND store_id = ?')
      .get(orderId, store.id) as
      | { id: string; order_number: string; customer_id: string; status: OrderStatus }
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'الطلب غير موجود ضمن طلبات متجرك.' });
      return;
    }
    if (
      existing.status === 'cancelled' ||
      existing.status === 'rejected' ||
      existing.status === 'delivered'
    ) {
      res.status(400).json({ error: 'لا يمكن تعديل طلب مكتمل أو مرفوض أو ملغي.' });
      return;
    }

    const now = new Date().toISOString();
    const isClosing = nextStatus === 'rejected' || nextStatus === 'cancelled';

    const updateTx = db.transaction(() => {
      if (isClosing) {
        db.prepare(
          `UPDATE orders
           SET status = ?, cancel_reason = ?, cancelled_by_id = ?, cancelled_by_name = ?, cancelled_by_role = 'merchant', cancelled_at = ?, updated_at = ?
           WHERE id = ?`
        ).run(
          nextStatus,
          reason || (nextStatus === 'rejected' ? 'تم رفض الطلب من قِبل المتجر' : 'تم إلغاء الطلب من قِبل المتجر'),
          merchant.id,
          merchant.fullName,
          now,
          now,
          orderId
        );
        logOrderEvent({
          orderId,
          eventType: nextStatus === 'rejected' ? 'rejected' : 'cancelled',
          actorId: merchant.id,
          actorName: merchant.fullName,
          actorRole: 'merchant',
          reason: reason || (nextStatus === 'rejected' ? 'رفض من المتجر' : 'إلغاء من المتجر'),
          previousStatus: existing.status,
          newStatus: nextStatus,
        });
        if (restoreStockFlag) {
          const didRestore = restoreOrderStock(orderId);
          if (didRestore) {
            logOrderEvent({
              orderId,
              eventType: 'stock_restored',
              actorId: merchant.id,
              actorName: merchant.fullName,
              actorRole: 'merchant',
              reason: 'إعادة الكمية المحجوزة إلى المخزون تلقائياً',
              previousStatus: existing.status,
              newStatus: nextStatus,
            });
          }
        }
      } else {
        db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?').run(
          nextStatus,
          now,
          orderId
        );
        logOrderEvent({
          orderId,
          eventType: 'status_changed',
          actorId: merchant.id,
          actorName: merchant.fullName,
          actorRole: 'merchant',
          reason,
          previousStatus: existing.status,
          newStatus: nextStatus,
        });
      }
    });
    updateTx();

    // Real Push + SSE + DB Notification to the Customer
    createAndDispatchNotification({
      userId: existing.customer_id,
      storeId: store.id,
      orderId,
      type:
        nextStatus === 'rejected'
          ? 'order_rejected'
          : nextStatus === 'cancelled'
          ? 'order_cancelled'
          : 'order_updated',
      title: `تحديث حالة طلبك ${existing.order_number} من ${store.name}`,
      body:
        nextStatus === 'rejected' || nextStatus === 'cancelled'
          ? `أصبحت حالة الطلب: ${ORDER_STATUS_LABELS[nextStatus]}${reason ? ` · السبب: ${reason}` : ''}`
          : `أصبحت حالة طلبك الآن: ${ORDER_STATUS_LABELS[nextStatus]}`,
      targetView: 'orders',
    });

    const updated = db
      .prepare(
        `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
         FROM orders o JOIN stores s ON s.id = o.store_id
         WHERE o.id = ?`
      )
      .get(orderId) as Record<string, unknown>;
    res.json({ order: attachOrderItems([updated])[0] });
  });

  // Cash-Only Order Creation (Server-side Price & Stock Verification + Atomic Stock Decrement)
  app.post('/api/orders', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const storeId = sanitizeText(req.body?.storeId, 60);
    const fulfillmentMethod: FulfillmentMethod =
      req.body?.fulfillmentMethod === 'pickup' ? 'pickup' : 'delivery';
    const customerName = sanitizeText(req.body?.customerName, 100);
    const customerPhone = sanitizeText(req.body?.customerPhone, 24);
    const governorate = sanitizeText(req.body?.governorate, 80);
    const city = sanitizeText(req.body?.city, 80);
    const district = sanitizeText(req.body?.district, 80);
    const neighborhood = sanitizeText(req.body?.neighborhood, 80);
    const addressLine = sanitizeText(req.body?.deliveryAddress, 300);
    const latitude = parseCoordinate(req.body?.latitude, -90, 90);
    const longitude = parseCoordinate(req.body?.longitude, -180, 180);
    const notes = sanitizeText(req.body?.notes, 400);
    const rawItems = Array.isArray(req.body?.items) ? req.body.items : [];
    const rawPrintJob =
      req.body?.printJob && typeof req.body.printJob === 'object'
        ? (req.body.printJob as Record<string, unknown>)
        : null;

    if (!storeId || (rawItems.length === 0 && !rawPrintJob)) {
      res.status(400).json({ error: 'يرجى اختيار متجر ومنتج أو ملف طباعة واحد على الأقل.' });
      return;
    }
    if (customerName.length < 2 || !isValidPhone(customerPhone)) {
      res.status(400).json({ error: 'يرجى إدخال الاسم الكامل ورقم هاتف صحيح.' });
      return;
    }
    if (
      fulfillmentMethod === 'delivery' &&
      (governorate.length < 2 || city.length < 2 || addressLine.length < 3)
    ) {
      res.status(400).json({
        error: 'يرجى إدخال المحافظة والمدينة والعنوان التفصيلي لإتمام التوصيل.',
      });
      return;
    }

    const storeRow = db
      .prepare("SELECT * FROM stores WHERE id = ? AND status = 'active'")
      .get(storeId) as Record<string, unknown> | undefined;

    if (!storeRow) {
      res.status(404).json({ error: 'المتجر غير متاح لاستقبال الطلبات حالياً.' });
      return;
    }

    const store = mapStore(storeRow);
    const merchantSub = checkMerchantCommercialAccess(store.ownerId);
    if (!merchantSub.allowed) {
      res.status(403).json({ error: 'عذراً، هذا المتجر متوقف مؤقتاً عن استقبال الطلبات لحين تجديد اشتراكه.' });
      return;
    }
    if (store.ownerId === user.id) {
      res.status(400).json({
        error: 'لا يمكنك إرسال طلب شراء إلى متجرك الخاص؛ يمكنك التسوق من بقية المتاجر.',
      });
      return;
    }

    const composedAddress =
      fulfillmentMethod === 'pickup'
        ? `استلام مباشر من المحل — ${[store.city, store.district, store.address].filter(Boolean).join('، ')}`
        : [governorate, city, district, neighborhood, addressLine].filter(Boolean).join(' - ');

    const createOrderTx = db.transaction(() => {
      const verifiedItems: Array<{
        productId: string | null;
        productName: string;
        unit: string;
        pricingType: PricingType;
        unitPrice: number;
        quantity: number;
        unitsToDeduct: number;
        lineTotal: number;
        imageUrl: string;
        selectedOptions?: OrderItemOptions;
      }> = [];

      let subtotal = 0;
      const productTotals = new Map<string, { name: string; unit: string; stock: number; needed: number }>();

      for (const item of rawItems) {
        const productId = sanitizeText(item?.productId, 60);
        const quantity = Math.floor(Number(item?.quantity));
        const pricingType: PricingType = item?.pricingType === 'carton' ? 'carton' : 'unit';
        const selectedOptions = sanitizeOrderItemOptions(item?.selectedOptions);
        if (!productId || !Number.isFinite(quantity) || quantity < 1 || quantity > 999) {
          throw new Error('كمية المنتج غير صالحة.');
        }

        const productRow = db
          .prepare('SELECT * FROM products WHERE id = ? AND store_id = ? AND is_available = 1 AND deleted_at IS NULL')
          .get(productId, store.id) as Record<string, unknown> | undefined;

        if (!productRow) {
          throw new Error('أحد المنتجات المختارة غير متوفر حالياً في هذا المتجر.');
        }

        const product = mapProduct(productRow);

        // Enforce mandatory Player ID for gaming top-up orders
        if ((store.storeType === 'gaming_topup' || product.gameName) && !selectedOptions?.playerId) {
          throw new Error(`يرجى إدخال معرّف اللاعب (Player ID) لباقة "${product.name}".`);
        }

        const mergedOptions: OrderItemOptions | undefined = selectedOptions
          ? {
              ...selectedOptions,
              ...(product.gameName && !selectedOptions.gameName
                ? { gameName: product.gameName }
                : {}),
            }
          : undefined;

        let unitPrice = product.price;
        let unitLabel = product.unit || 'قطعة';
        let unitsToDeduct = quantity;

        if (pricingType === 'carton') {
          if (product.cartonPrice <= 0) {
            throw new Error(`المنتج "${product.name}" غير متوفر بسعر الكارتون حالياً.`);
          }
          unitPrice = product.cartonPrice;
          const perCarton = Math.max(1, product.cartonUnits || 1);
          unitLabel = `كارتون (${perCarton} ${product.unit})`;
          unitsToDeduct = quantity * perCarton;
        }

        const tracked = productTotals.get(product.id) || {
          name: product.name,
          unit: product.unit,
          stock: product.stockQty,
          needed: 0,
        };
        tracked.needed += unitsToDeduct;
        productTotals.set(product.id, tracked);

        const lineTotal = Math.round(unitPrice * quantity * 100) / 100;
        subtotal += lineTotal;

        verifiedItems.push({
          productId,
          productName: product.name,
          unit: unitLabel,
          pricingType,
          unitPrice,
          quantity,
          unitsToDeduct,
          lineTotal,
          imageUrl: product.imageUrl,
          selectedOptions: mergedOptions,
        });
      }

      // Direct Print & Copy Job order (strictly server-priced from store.serviceConfig.printPricing)
      if (rawPrintJob) {
        if (store.storeType !== 'printing') {
          throw new Error('هذا المتجر لا يدعم طلبات طباعة الملفات المباشرة.');
        }
        const verifiedFileUrl = verifyUploadedFileExists(rawPrintJob.fileUrl);
        if (!verifiedFileUrl) {
          throw new Error('يرجى رفع ملف PDF أو صورة صالحة قبل إرسال طلب الطباعة.');
        }
        const fileName = sanitizeText(rawPrintJob.fileName, 140) || 'ملف للطباعة';
        const fileMime = sanitizeText(rawPrintJob.fileMime, 60) || 'application/pdf';
        const serviceType = sanitizeText(rawPrintJob.serviceType, 80) || 'طباعة مستندات';
        const copies = Math.floor(Number(rawPrintJob.copies));
        const pages = Math.floor(Number(rawPrintJob.pages));
        const colorMode = VALID_PRINT_COLORS.includes(rawPrintJob.colorMode as PrintColorMode)
          ? (rawPrintJob.colorMode as PrintColorMode)
          : 'bw';
        const paperSize = VALID_PRINT_PAPERS.includes(rawPrintJob.paperSize as PrintPaperSize)
          ? (rawPrintJob.paperSize as PrintPaperSize)
          : 'A4';
        const sides = VALID_PRINT_SIDES.includes(rawPrintJob.sides as PrintSides)
          ? (rawPrintJob.sides as PrintSides)
          : 'single';
        const binding = VALID_PRINT_BINDINGS.includes(rawPrintJob.binding as PrintBindingType)
          ? (rawPrintJob.binding as PrintBindingType)
          : 'none';
        const jobNotes = sanitizeText(rawPrintJob.notes, 300);

        if (!Number.isFinite(copies) || copies < 1 || copies > 500) {
          throw new Error('عدد النسخ يجب أن يكون بين 1 و 500.');
        }
        if (!Number.isFinite(pages) || pages < 1 || pages > 2000) {
          throw new Error('عدد الصفحات يجب أن يكون بين 1 و 2000.');
        }

        const pricing = store.serviceConfig?.printPricing || DEFAULT_PRINT_PRICING;
        const calc = calculatePrintJobPrice(pricing, {
          pages,
          copies,
          colorMode,
          paperSize,
          sides,
          binding,
        });

        const printJob: PrintJobDetails = {
          serviceType,
          fileUrl: verifiedFileUrl,
          fileName,
          fileMime,
          copies,
          pages,
          colorMode,
          paperSize,
          sides,
          binding,
          unitPagePrice: calc.unitPagePrice,
          bindingPricePerCopy: calc.bindingPricePerCopy,
          ...(jobNotes ? { notes: jobNotes } : {}),
        };

        subtotal += calc.grandTotal;
        verifiedItems.push({
          productId: null,
          productName: `${serviceType} — ${fileName}`,
          unit: `نسخة (${pages} صفحة · ${PRINT_PAPER_LABELS[paperSize]})`,
          pricingType: 'unit',
          unitPrice: calc.perCopyTotal,
          quantity: copies,
          unitsToDeduct: 0,
          lineTotal: calc.grandTotal,
          imageUrl: fileMime.startsWith('image/') ? verifiedFileUrl : '',
          selectedOptions: { printJob },
        });
      }

      // Enforce stock availability across combined unit/carton lines
      for (const [, info] of productTotals) {
        if (info.stock <= 0) {
          throw new Error(`نفدت الكمية المتوفرة من المنتج "${info.name}".`);
        }
        if (info.needed > info.stock) {
          throw new Error(
            `الكمية المطلوبة من "${info.name}" تتجاوز المخزون المتوفر (${info.stock} ${info.unit}).`
          );
        }
      }

      subtotal = Math.round(subtotal * 100) / 100;
      if (store.minOrderAmount > 0 && subtotal < store.minOrderAmount) {
        throw new Error(`الحد الأدنى للطلب في هذا المتجر هو ${store.minOrderAmount}.`);
      }

      const deliveryFee =
        fulfillmentMethod === 'pickup' ? 0 : Math.round(store.deliveryFee * 100) / 100;
      const totalAmount = Math.round((subtotal + deliveryFee) * 100) / 100;
      const orderId = generateId('ord');
      const orderNumber = generateOrderNumber();
      const now = new Date().toISOString();

      db.prepare(
        `INSERT INTO orders
          (id, order_number, customer_id, store_id, status, payment_method, fulfillment_method, subtotal, delivery_fee, total_amount, governorate, city, district, neighborhood, delivery_address, latitude, longitude, customer_name, customer_phone, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, 'pending', 'cash_on_delivery', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        orderId,
        orderNumber,
        user.id,
        store.id,
        fulfillmentMethod,
        subtotal,
        deliveryFee,
        totalAmount,
        governorate,
        city,
        district,
        neighborhood,
        composedAddress,
        latitude,
        longitude,
        customerName,
        customerPhone,
        notes,
        now,
        now
      );

      const insertItem = db.prepare(
        `INSERT INTO order_items (id, order_id, product_id, product_name, unit, pricing_type, unit_price, quantity, line_total, image_url, item_options_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      );
      const deductStock = db.prepare(
        'UPDATE products SET stock_qty = MAX(0, stock_qty - ?) WHERE id = ?'
      );

      for (const item of verifiedItems) {
        insertItem.run(
          generateId('oit'),
          orderId,
          item.productId,
          item.productName,
          item.unit,
          item.pricingType,
          item.unitPrice,
          item.quantity,
          item.lineTotal,
          item.imageUrl,
          JSON.stringify(item.selectedOptions || {})
        );
        if (item.productId && item.unitsToDeduct > 0) {
          deductStock.run(item.unitsToDeduct, item.productId);
        }
      }

      // Clear purchased store's items from user's persisted cart atomically (only if cart products were ordered)
      if (rawItems.length > 0) {
        db.prepare('DELETE FROM cart_items WHERE user_id = ? AND store_id = ?').run(
          user.id,
          store.id
        );
      }

      // Log order creation in audit trail
      logOrderEvent({
        orderId,
        eventType: 'created',
        actorId: user.id,
        actorName: customerName,
        actorRole: user.role,
        reason: rawPrintJob ? 'إنشاء طلب طباعة واستنساخ نقدي جديد' : 'إنشاء طلب نقدي جديد',
        previousStatus: '',
        newStatus: 'pending',
      });

      const createdRow = db
        .prepare(
          `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
           FROM orders o JOIN stores s ON s.id = o.store_id
           WHERE o.id = ?`
        )
        .get(orderId) as Record<string, unknown>;
      return attachOrderItems([createdRow])[0];
    });

    try {
      const order = createOrderTx();
      const currency = getPlatformSetting('currency', 'د.ع');
      const totalItemsCount = order.items.reduce((sum, item) => sum + item.quantity, 0);
      const firstItem = order.items[0];
      const firstPrint = firstItem?.selectedOptions?.printJob;
      const firstPlayerId = firstItem?.selectedOptions?.playerId;
      const productSummary = firstPrint
        ? `${firstPrint.serviceType} (${firstPrint.pages} صفحة × ${firstPrint.copies} نسخة · ${PRINT_COLOR_LABELS[firstPrint.colorMode]})`
        : firstItem
        ? order.items.length > 1
          ? `${firstItem.productName} (×${firstItem.quantity}) و${order.items.length - 1} منتجات أخرى`
          : `${firstItem.productName} (الكمية: ${firstItem.quantity})${firstPlayerId ? ` · ID: ${firstPlayerId}` : ''}`
        : `عدد المنتجات: ${totalItemsCount}`;

      // Dispatch REAL Push + SSE + DB Notification strictly to the target store's owner ONLY
      createAndDispatchNotification({
        userId: store.ownerId,
        storeId: store.id,
        orderId: order.id,
        type: 'order_new',
        title: firstPrint
          ? `طلب طباعة جديد من ${order.customerName}`
          : firstPlayerId
          ? `طلب شحن ألعاب جديد من ${order.customerName}`
          : `طلب جديد من الزبون ${order.customerName}`,
        body: `متجر ${store.name} · ${productSummary} · المبلغ: ${formatAmountArabic(
          order.totalAmount,
          currency
        )} · الوقت: ${formatTimeAr(order.createdAt)}`,
        targetView: 'merchant',
      });

      res.status(201).json({ order });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'تعذر إنشاء الطلب.' });
    }
  });

  // Buyer's personal orders
  app.get('/api/orders/my', requireAuth, (req: AuthedRequest, res) => {
    const rows = db
      .prepare(
        `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
         FROM orders o
         JOIN stores s ON s.id = o.store_id
         WHERE o.customer_id = ?
         ORDER BY o.created_at DESC`
      )
      .all(req.user!.id) as Record<string, unknown>[];
    res.json({
      orders: attachOrderItems(rows, { role: req.user!.role, userId: req.user!.id }),
    });
  });

  // Customer Order Cancellation with mandatory reason, stage-based policy, audit log, stock restoration & real Push Notification
  app.patch('/api/orders/:id/cancel', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const orderId = sanitizeText(req.params.id, 60);
    const reason = sanitizeText(req.body?.reason, 300);

    if (reason.length < 2) {
      res.status(400).json({ error: 'يرجى تحديد أو كتابة سبب إلغاء الطلب.' });
      return;
    }

    const existing = db
      .prepare(
        `SELECT o.id, o.order_number, o.status, o.store_id, o.customer_name, o.total_amount,
                s.name AS store_name, s.owner_id AS store_owner_id
         FROM orders o
         JOIN stores s ON s.id = o.store_id
         WHERE o.id = ? AND o.customer_id = ?`
      )
      .get(orderId, user.id) as
      | {
          id: string;
          order_number: string;
          status: OrderStatus;
          store_id: string;
          customer_name: string;
          total_amount: number;
          store_name: string;
          store_owner_id: string;
        }
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'الطلب غير موجود.' });
      return;
    }

    if (
      existing.status === 'delivered' ||
      existing.status === 'cancelled' ||
      existing.status === 'rejected'
    ) {
      res.status(400).json({ error: 'لا يمكن إلغاء طلب مكتمل أو ملغي أو مرفوض بالفعل.' });
      return;
    }

    const now = new Date().toISOString();

    // Stage 1: Pending or Confirmed (before preparation starts) -> immediate safe cancellation + stock restore
    if (existing.status === 'pending' || existing.status === 'confirmed') {
      const cancelTx = db.transaction(() => {
        db.prepare(
          `UPDATE orders
           SET status = 'cancelled', cancel_reason = ?, cancelled_by_id = ?, cancelled_by_name = ?, cancelled_by_role = 'customer', cancelled_at = ?, updated_at = ?
           WHERE id = ?`
        ).run(reason, user.id, user.fullName, now, now, orderId);

        logOrderEvent({
          orderId,
          eventType: 'cancelled',
          actorId: user.id,
          actorName: user.fullName,
          actorRole: 'customer',
          reason,
          previousStatus: existing.status,
          newStatus: 'cancelled',
        });

        const restored = restoreOrderStock(orderId);
        if (restored) {
          logOrderEvent({
            orderId,
            eventType: 'stock_restored',
            actorId: user.id,
            actorName: user.fullName,
            actorRole: 'customer',
            reason: 'إعادة الكمية المحجوزة إلى المخزون بعد إلغاء الطلب',
            previousStatus: existing.status,
            newStatus: 'cancelled',
          });
        }
      });
      cancelTx();

      // Notify store owner ONLY via Push + SSE + DB
      createAndDispatchNotification({
        userId: existing.store_owner_id,
        storeId: existing.store_id,
        orderId,
        type: 'order_cancelled',
        title: `إلغاء طلب من الزبون ${existing.customer_name}`,
        body: `تم إلغاء الطلب ${existing.order_number} لمتجر ${existing.store_name} · السبب: ${reason} · تمت إعادة الكمية للمخزون`,
        targetView: 'merchant',
      });

      const updatedRow = db
        .prepare(
          `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
           FROM orders o JOIN stores s ON s.id = o.store_id WHERE o.id = ?`
        )
        .get(orderId) as Record<string, unknown>;

      res.json({
        ok: true,
        mode: 'cancelled',
        message: 'تم إلغاء الطلب بنجاح وإعادة الكميات المحجوزة إلى المخزون وإشعار صاحب المتجر.',
        order: attachOrderItems([updatedRow])[0],
      });
      return;
    }

    // Stage 2: Already preparing or out_for_delivery -> log urgent cancellation request & notify merchant + Super Admins
    logOrderEvent({
      orderId,
      eventType: 'cancel_requested',
      actorId: user.id,
      actorName: user.fullName,
      actorRole: 'customer',
      reason,
      previousStatus: existing.status,
      newStatus: existing.status,
    });

    createAndDispatchNotification({
      userId: existing.store_owner_id,
      storeId: existing.store_id,
      orderId,
      type: 'order_cancel_requested',
      title: `طلب إلغاء عاجل للطلب ${existing.order_number}`,
      body: `الزبون ${existing.customer_name} يطلب إلغاء الطلب (${ORDER_STATUS_LABELS[existing.status]}) · السبب: ${reason}`,
      targetView: 'merchant',
    });

    const admins = db
      .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
      .all() as Array<{ id: string }>;
    for (const adm of admins) {
      createAndDispatchNotification({
        userId: adm.id,
        storeId: existing.store_id,
        orderId,
        type: 'order_cancel_requested',
        title: `طلب إلغاء بعد بدء التجهيز — ${existing.order_number}`,
        body: `الزبون ${existing.customer_name} يطلب إلغاء طلب من متجر ${existing.store_name} · السبب: ${reason}`,
        targetView: 'admin',
      });
    }

    const currentRow = db
      .prepare(
        `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
         FROM orders o JOIN stores s ON s.id = o.store_id WHERE o.id = ?`
      )
      .get(orderId) as Record<string, unknown>;

    res.json({
      ok: true,
      mode: 'request_sent',
      message:
        'الطلب بدأ تجهيزه حالياً؛ تم تسجيل سببك وإرسال إشعار عاجل لصاحب المتجر والمدير العام للبت في الإلغاء.',
      order: attachOrderItems([currentRow], { role: user.role, userId: user.id })[0],
    });
  });

  // =========================================================================
  // NOTIFICATIONS & REAL PUSH SUBSCRIPTION ROUTES
  // =========================================================================
  app.get('/api/notifications', requireAuth, (req: AuthedRequest, res) => {
    res.json(getUserNotifications(req.user!.id));
  });

  app.get('/api/notifications/stream', requireAuth, (req: AuthedRequest, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const unregister = registerSseClient(req.user!.id, res);
    res.write(`event: connected\ndata: ${JSON.stringify({ ok: true })}\n\n`);

    const keepAlive = setInterval(() => {
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(keepAlive);
      }
    }, 25000);

    req.on('close', () => {
      clearInterval(keepAlive);
      unregister();
    });
  });

  app.patch('/api/notifications/:id/read', requireAuth, (req: AuthedRequest, res) => {
    const id = sanitizeText(req.params.id, 60);
    db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?').run(
      id,
      req.user!.id
    );
    res.json(getUserNotifications(req.user!.id));
  });

  app.post('/api/notifications/read-all', requireAuth, (req: AuthedRequest, res) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.user!.id);
    res.json(getUserNotifications(req.user!.id));
  });

  app.delete('/api/notifications/read', requireAuth, (req: AuthedRequest, res) => {
    db.prepare('DELETE FROM notifications WHERE user_id = ? AND is_read = 1').run(req.user!.id);
    res.json(getUserNotifications(req.user!.id));
  });

  app.delete('/api/notifications/:id', requireAuth, (req: AuthedRequest, res) => {
    const id = sanitizeText(req.params.id, 60);
    db.prepare('DELETE FROM notifications WHERE id = ? AND user_id = ?').run(id, req.user!.id);
    res.json(getUserNotifications(req.user!.id));
  });

  app.get('/api/push/config', requireAuth, (req: AuthedRequest, res) => {
    const countRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM push_subscriptions WHERE user_id = ? AND is_active = 1')
      .get(req.user!.id) as { cnt: number };
    res.json({
      vapidPublicKey: getVapidPublicKey(),
      webPushEnabled: Boolean(getVapidPublicKey()),
      activeDeviceCount: Number(countRow.cnt || 0),
      expoConfigured: Boolean(process.env.EXPO_ACCESS_TOKEN?.trim()),
    });
  });

  app.post('/api/push/subscribe', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const endpoint = sanitizeText(req.body?.endpoint, 1000);
    const p256dh = sanitizeText(req.body?.keys?.p256dh, 300);
    const auth = sanitizeText(req.body?.keys?.auth, 300);
    const deviceLabel = sanitizeText(req.body?.deviceLabel, 120) || 'متصفح الهاتف / الويب';

    if (!endpoint || !endpoint.startsWith('https://') || !p256dh || !auth) {
      res.status(400).json({ error: 'بيانات اشتراك الإشعارات غير صالحة.' });
      return;
    }

    const ownedStore = user.role === 'merchant' ? getOwnedStore(user.id) : null;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO push_subscriptions (id, user_id, store_id, channel, endpoint, p256dh, auth, push_token, device_label, is_active, created_at, updated_at)
       VALUES (?, ?, ?, 'web_push', ?, ?, ?, '', ?, 1, ?, ?)
       ON CONFLICT(user_id, endpoint) DO UPDATE SET
         store_id = excluded.store_id,
         p256dh = excluded.p256dh,
         auth = excluded.auth,
         device_label = excluded.device_label,
         is_active = 1,
         updated_at = excluded.updated_at`
    ).run(generateId('psh'), user.id, ownedStore?.id ?? null, endpoint, p256dh, auth, deviceLabel, now, now);

    const countRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM push_subscriptions WHERE user_id = ? AND is_active = 1')
      .get(user.id) as { cnt: number };
    res.status(201).json({ ok: true, activeDeviceCount: Number(countRow.cnt || 0) });
  });

  app.delete('/api/push/subscribe', requireAuth, (req: AuthedRequest, res) => {
    const endpoint = sanitizeText(req.body?.endpoint, 1000);
    if (endpoint) {
      db.prepare('DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint = ?').run(
        req.user!.id,
        endpoint
      );
    } else {
      db.prepare("DELETE FROM push_subscriptions WHERE user_id = ? AND channel = 'web_push'").run(
        req.user!.id
      );
    }
    const countRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM push_subscriptions WHERE user_id = ? AND is_active = 1')
      .get(req.user!.id) as { cnt: number };
    res.json({ ok: true, activeDeviceCount: Number(countRow.cnt || 0) });
  });

  // Register Expo / React Native or FCM native mobile push token securely
  app.post('/api/push/register-token', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const token = sanitizeText(req.body?.token, 400);
    const channel = req.body?.channel === 'fcm' ? 'fcm' : 'expo';
    const deviceLabel = sanitizeText(req.body?.deviceLabel, 120) || 'تطبيق الهاتف';

    if (token.length < 10) {
      res.status(400).json({ error: 'رمز إشعارات الجهاز غير صالح.' });
      return;
    }

    const ownedStore = user.role === 'merchant' ? getOwnedStore(user.id) : null;
    const now = new Date().toISOString();
    const syntheticEndpoint = `${channel}://${token}`;

    db.prepare(
      `INSERT INTO push_subscriptions (id, user_id, store_id, channel, endpoint, p256dh, auth, push_token, device_label, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, '', '', ?, ?, 1, ?, ?)
       ON CONFLICT(user_id, endpoint) DO UPDATE SET
         store_id = excluded.store_id,
         push_token = excluded.push_token,
         device_label = excluded.device_label,
         is_active = 1,
         updated_at = excluded.updated_at`
    ).run(
      generateId('psh'),
      user.id,
      ownedStore?.id ?? null,
      channel,
      syntheticEndpoint,
      token,
      deviceLabel,
      now,
      now
    );

    const countRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM push_subscriptions WHERE user_id = ? AND is_active = 1')
      .get(user.id) as { cnt: number };
    res.status(201).json({ ok: true, activeDeviceCount: Number(countRow.cnt || 0) });
  });

  app.post('/api/push/test', requireAuth, async (req: AuthedRequest, res) => {
    const user = req.user!;
    const ownedStore = user.role === 'merchant' ? getOwnedStore(user.id) : null;
    const title = ownedStore
      ? `اختبار إشعارات متجر ${ownedStore.name}`
      : 'اختبار إشعارات SOUQNA | سوقنا';
    const body = ownedStore
      ? 'نظام الإشعارات الفورية يعمل بنجاح — ستصلك طلبات متجرك فور إرسالها.'
      : 'نظام الإشعارات الفورية يعمل بنجاح على جهازك.';
    const result = await dispatchTestPush(
      user.id,
      title,
      body,
      user.role === 'merchant' ? 'merchant' : user.role === 'super_admin' ? 'admin' : 'orders'
    );
    res.json(result);
  });

  // =========================================================================
  // PRIVATE COURIER OFFICIAL DOCUMENTS (Strictly Super Admin or owning Courier)
  // =========================================================================
  app.get('/api/private-docs/:filename', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const filename = sanitizeText(req.params.filename, 120);
    const fullPath = resolvePrivateDocPath(filename);
    if (!fullPath) {
      res.status(404).json({ error: 'المستند غير موجود.' });
      return;
    }

    if (user.role !== 'super_admin') {
      if (user.role !== 'courier') {
        res.status(403).json({ error: 'ليس لديك صلاحية الاطلاع على المستمسكات الرسمية.' });
        return;
      }
      const ownCourier = db
        .prepare(
          'SELECT id FROM couriers WHERE user_id = ? AND (id_front_doc = ? OR id_back_doc = ? OR license_doc = ?)'
        )
        .get(user.id, filename, filename, filename);
      if (!ownCourier) {
        res.status(403).json({ error: 'ليس لديك صلاحية الاطلاع على هذا المستند.' });
        return;
      }
    }

    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-store, max-age=0');
    res.sendFile(fullPath);
  });

  // =========================================================================
  // PRIVATE SUBSCRIPTION PAYMENT PROOFS (Strictly Super Admin or uploading user)
  // =========================================================================
  app.get('/api/private-payment-proofs/:filename', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const filename = sanitizeText(req.params.filename, 120);
    const fullPath = resolvePrivatePaymentProofPath(filename);
    if (!fullPath) {
      res.status(404).json({ error: 'صورة إثبات التحويل غير موجودة.' });
      return;
    }

    if (user.role !== 'super_admin') {
      const ownReq = db
        .prepare(
          'SELECT id FROM subscription_payment_requests WHERE user_id = ? AND payment_proof_doc = ?'
        )
        .get(user.id, filename);
      if (!ownReq) {
        res.status(403).json({ error: 'ليس لديك صلاحية الاطلاع على صورة إثبات التحويل هذه.' });
        return;
      }
    }

    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-store, max-age=0');
    res.sendFile(fullPath);
  });

  // =========================================================================
  // COURIER REGISTRATION & DELIVERY OPERATIONS
  // =========================================================================
  app.post('/api/courier/register', (req, res) => {
    const ip = req.ip || 'unknown';
    if (!checkPublicRateLimit(`courier_register:${ip}`, 15, 15 * 60 * 1000)) {
      res.status(429).json({ error: 'تم إرسال عدة طلبات تسجيل مندوب مؤقتاً. يرجى المحاولة لاحقاً.' });
      return;
    }
    const fullName = sanitizeText(req.body?.fullName, 100);
    const email = sanitizeText(req.body?.email, 160).toLowerCase();
    const phone = sanitizeText(req.body?.phone, 24);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const governorate = sanitizeText(req.body?.governorate, 80);
    const city = sanitizeText(req.body?.city ?? governorate, 80);
    const district = sanitizeText(req.body?.district, 80);
    const neighborhood = sanitizeText(req.body?.neighborhood, 80);
    const address = sanitizeText(req.body?.address, 250);
    const vehicleType = req.body?.vehicleType as CourierVehicleType;
    const plateNumber = sanitizeText(req.body?.plateNumber, 40);
    const idType = sanitizeText(req.body?.idType, 80);
    const idNumber = sanitizeText(req.body?.idNumber, 60);
    const termsAccepted = req.body?.termsAccepted === true;
    const avatarDataUrl = typeof req.body?.avatarDataUrl === 'string' ? req.body.avatarDataUrl : '';
    const idFrontDataUrl =
      typeof req.body?.idFrontDataUrl === 'string' ? req.body.idFrontDataUrl : '';
    const idBackDataUrl =
      typeof req.body?.idBackDataUrl === 'string' ? req.body.idBackDataUrl : '';
    const licenseDataUrl =
      typeof req.body?.licenseDataUrl === 'string' ? req.body.licenseDataUrl : '';

    if (fullName.length < 3) {
      res.status(400).json({ error: 'يرجى إدخال الاسم الكامل للمندوب.' });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني صحيح.' });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: 'يرجى إدخال رقم هاتف صحيح.' });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: 'كلمة المرور يجب أن لا تقل عن 6 أحرف.' });
      return;
    }
    if (governorate.length < 2 || district.length < 2 || address.length < 3) {
      res.status(400).json({ error: 'يرجى إدخال المحافظة والمنطقة وعنوان السكن.' });
      return;
    }
    if (!VALID_VEHICLE_TYPES.includes(vehicleType)) {
      res.status(400).json({ error: 'يرجى اختيار نوع المركبة.' });
      return;
    }
    if (idType.length < 2 || idNumber.length < 4) {
      res.status(400).json({ error: 'يرجى إدخال نوع ورقم الهوية الرسمية.' });
      return;
    }
    if (!idFrontDataUrl) {
      res.status(400).json({ error: 'يرجى رفع صورة الوجه الأمامي للهوية الرسمية.' });
      return;
    }
    if (!termsAccepted) {
      res.status(400).json({ error: 'يجب الموافقة على شروط العمل وسياسة الخصوصية لإتمام التسجيل.' });
      return;
    }

    const exists = db.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(email);
    if (exists) {
      res.status(409).json({ error: 'هذا البريد الإلكتروني مسجل مسبقاً. يرجى تسجيل الدخول بحسابك الحالي.' });
      return;
    }
    const normalizedCourierPhone = phone.replace(/[\s\-()+]/g, '');
    if (normalizedCourierPhone.length >= 7) {
      const existingCourierPhone = (
        db.prepare('SELECT id, phone FROM users').all() as Array<{ id: string; phone: string }>
      ).find((u) => String(u.phone || '').replace(/[\s\-()+]/g, '') === normalizedCourierPhone);
      if (existingCourierPhone) {
        res.status(409).json({
          error: 'رقم الهاتف هذا مسجّل مسبقاً في حساب آخر. يرجى تسجيل الدخول بحسابك الحالي.',
        });
        return;
      }
    }

    // Save private ID/license documents securely outside /uploads/
    const savedFront = saveBase64PrivateDoc(idFrontDataUrl);
    if ('error' in savedFront) {
      res.status(400).json({ error: `الوجه الأمامي للهوية: ${savedFront.error}` });
      return;
    }

    let idBackDoc = '';
    if (idBackDataUrl) {
      const savedBack = saveBase64PrivateDoc(idBackDataUrl);
      if ('error' in savedBack) {
        res.status(400).json({ error: `الوجه الخلفي للهوية: ${savedBack.error}` });
        return;
      }
      idBackDoc = savedBack.filename;
    }

    let licenseDoc = '';
    if (licenseDataUrl) {
      const savedLic = saveBase64PrivateDoc(licenseDataUrl);
      if ('error' in savedLic) {
        res.status(400).json({ error: `رخصة القيادة: ${savedLic.error}` });
        return;
      }
      licenseDoc = savedLic.filename;
    }

    let avatarUrl = '';
    if (avatarDataUrl) {
      const savedAvatar = saveBase64Image(avatarDataUrl);
      if ('error' in savedAvatar) {
        res.status(400).json({ error: `الصورة الشخصية: ${savedAvatar.error}` });
        return;
      }
      avatarUrl = savedAvatar.url;
    }

    const requireCourierApproval =
      getPlatformSetting('require_courier_approval', 'true') === 'true';
    const initialStatus: CourierVerificationStatus = requireCourierApproval ? 'pending' : 'verified';

    const userId = generateId('usr');
    const courierId = generateId('cur');
    const now = new Date().toISOString();
    const passwordHash = hashPassword(password);

    const createTx = db.transaction(() => {
      db.prepare(
        `INSERT INTO users
          (id, full_name, email, phone, city, governorate, district, neighborhood, address, latitude, longitude, password_hash, role, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, 'courier', 1, ?)`
      ).run(
        userId,
        fullName,
        email,
        phone,
        city || governorate,
        governorate,
        district,
        neighborhood,
        address,
        passwordHash,
        now
      );

      db.prepare(
        `INSERT INTO couriers
          (id, user_id, governorate, city, district, neighborhood, address, avatar_url, vehicle_type, plate_number, id_type, id_number, id_front_doc, id_back_doc, license_doc, terms_accepted, verification_status, rejection_reason, is_available, latitude, longitude, location_updated_at, total_deliveries, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, '', 0, NULL, NULL, '', 0, ?, ?)`
      ).run(
        courierId,
        userId,
        governorate,
        city || governorate,
        district,
        neighborhood,
        address,
        avatarUrl,
        vehicleType,
        plateNumber,
        idType,
        idNumber,
        savedFront.filename,
        idBackDoc,
        licenseDoc,
        initialStatus,
        now,
        now
      );
    });
    createTx();

    // Notify all Super Admins about the new courier registration
    const admins = db
      .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
      .all() as Array<{ id: string }>;
    for (const adm of admins) {
      createAndDispatchNotification({
        userId: adm.id,
        storeId: null,
        orderId: null,
        type: 'courier_status',
        title: `طلب تسجيل مندوب جديد: ${fullName}`,
        body: `المحافظة: ${governorate} · المنطقة: ${district} · الحالة: ${COURIER_STATUS_LABELS[initialStatus]} — يرجى مراجعة المستمسكات من لوحة المدير.`,
        targetView: 'admin',
      });
    }

    ensureUserSubscription(userId, 'courier');

    const userRow = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as Record<
      string,
      unknown
    >;
    const token = createSessionForUser(userId);
    setSessionCookie(req, res, token);

    res.status(201).json({
      token,
      user: mapUser(userRow),
      store: null,
      courier: getOwnedCourier(userId),
      subscription: evaluateUserSubscription(userId),
    });
  });

  app.get('/api/courier/me', requireRole('courier'), (req: AuthedRequest, res) => {
    const courier = getOwnedCourier(req.user!.id);
    if (!courier) {
      res.status(404).json({ error: 'ملف المندوب غير موجود.' });
      return;
    }
    res.json({ courier });
  });

  // Verified courier availability toggle with privacy-preserving location handling
  app.patch('/api/courier/availability', requireRole('courier'), (req: AuthedRequest, res) => {
    const courier = getOwnedCourier(req.user!.id);
    if (!courier) {
      res.status(404).json({ error: 'ملف المندوب غير موجود.' });
      return;
    }
    if (courier.verificationStatus !== 'verified') {
      res.status(403).json({
        error: 'لا يمكنك تفعيل حالة التوفر أو استلام الطلبات قبل موافقة وتوثيق حسابك من قِبل المدير العام.',
      });
      return;
    }

    const isAvailable = req.body?.isAvailable === true;
    const now = new Date().toISOString();

    if (isAvailable) {
      const subCheck = checkCourierCommercialAccess(req.user!.id);
      if (!subCheck.allowed) {
        res.status(403).json({ error: subCheck.error });
        return;
      }
      const latitude =
        req.body?.latitude !== undefined
          ? parseCoordinate(req.body.latitude, -90, 90)
          : courier.latitude;
      const longitude =
        req.body?.longitude !== undefined
          ? parseCoordinate(req.body.longitude, -180, 180)
          : courier.longitude;

      db.prepare(
        `UPDATE couriers
         SET is_available = 1, latitude = ?, longitude = ?, location_updated_at = ?, updated_at = ?
         WHERE user_id = ?`
      ).run(latitude, longitude, latitude !== null ? now : courier.locationUpdatedAt, now, req.user!.id);
    } else {
      // Stop live location sharing when courier goes offline
      db.prepare(
        `UPDATE couriers
         SET is_available = 0, latitude = NULL, longitude = NULL, location_updated_at = '', updated_at = ?
         WHERE user_id = ?`
      ).run(now, req.user!.id);
    }

    res.json({ courier: getOwnedCourier(req.user!.id) });
  });

  // Available nearby unassigned deliveries (verified + available couriers only)
  app.get('/api/courier/deliveries/available', requireRole('courier'), (req: AuthedRequest, res) => {
    const courier = getOwnedCourier(req.user!.id);
    if (!courier) {
      res.status(404).json({ error: 'ملف المندوب غير موجود.' });
      return;
    }
    if (courier.verificationStatus !== 'verified') {
      res.status(403).json({ error: 'حسابك كمندوب قيد المراجعة أو غير موثق بعد.' });
      return;
    }
    const courierSub = checkCourierCommercialAccess(req.user!.id);
    if (!courierSub.allowed || !courier.isAvailable) {
      res.json({ deliveries: [] });
      return;
    }

    const rows = db
      .prepare(
        `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
                s.city AS store_city, o.governorate AS dropoff_area
         FROM deliveries d
         JOIN orders o ON o.id = d.order_id
         JOIN stores s ON s.id = d.store_id
         WHERE d.courier_id IS NULL AND d.status IN ('waiting_courier', 'dispatched')
         ORDER BY d.requested_at DESC
         LIMIT 40`
      )
      .all() as Record<string, unknown>[];

    const mapped = rows
      .map((row) => {
        const delivery = mapDelivery(row, { includeOtp: false, hideCustomerContact: true });
        const dist = haversineKm(
          courier.latitude,
          courier.longitude,
          delivery.pickupLat,
          delivery.pickupLng
        );
        return { ...delivery, distanceKm: dist };
      })
      .sort((a, b) => {
        const da = a.distanceKm ?? 9999;
        const dbVal = b.distanceKm ?? 9999;
        return da - dbVal;
      });

    res.json({ deliveries: mapped });
  });

  // Courier's own assigned active and historical deliveries
  app.get('/api/courier/deliveries/my', requireRole('courier'), (req: AuthedRequest, res) => {
    const rows = db
      .prepare(
        `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
                o.customer_name, o.customer_phone,
                cu.full_name AS courier_name, cu.phone AS courier_phone,
                cp.vehicle_type AS courier_vehicle_type, cp.plate_number AS courier_plate_number
         FROM deliveries d
         JOIN orders o ON o.id = d.order_id
         JOIN stores s ON s.id = d.store_id
         LEFT JOIN users cu ON cu.id = d.courier_id
         LEFT JOIN couriers cp ON cp.user_id = d.courier_id
         WHERE d.courier_id = ?
         ORDER BY d.updated_at DESC
         LIMIT 80`
      )
      .all(req.user!.id) as Record<string, unknown>[];

    // NEVER include deliveryOtp for courier — courier must receive OTP from customer upon handover!
    res.json({
      deliveries: rows.map((row) =>
        mapDelivery(row, { includeOtp: false, includeEvents: true, hideCustomerContact: false })
      ),
    });
  });

  // Atomic First-Come-First-Served Courier Acceptance (prevents double acceptance / race conditions)
  app.post(
    '/api/courier/deliveries/:id/accept',
    requireRole('courier'),
    (req: AuthedRequest, res) => {
      const user = req.user!;
      const courier = getOwnedCourier(user.id);
      if (!courier || courier.verificationStatus !== 'verified') {
        res.status(403).json({ error: 'يجب أن يكون حساب المندوب موثقاً ومعتمداً لقبول التوصيلات.' });
        return;
      }
      const subCheck = checkCourierCommercialAccess(user.id);
      if (!subCheck.allowed) {
        res.status(403).json({ error: subCheck.error });
        return;
      }
      if (!courier.isAvailable) {
        res.status(400).json({ error: 'يرجى تفعيل حالة (متاح للعمل) قبل قبول طلب التوصيل.' });
        return;
      }

      const deliveryId = sanitizeText(req.params.id, 60);
      const now = new Date().toISOString();

      const acceptTx = db.transaction(
        ():
          | { ok: false; status: number; error: string }
          | { ok: true; deliveryRow: Record<string, unknown>; storeOwnerId: string } => {
          const existing = db
            .prepare(
              `SELECT d.*, s.owner_id AS store_owner_id, s.name AS store_name, o.order_number
               FROM deliveries d
               JOIN stores s ON s.id = d.store_id
               JOIN orders o ON o.id = d.order_id
               WHERE d.id = ?`
            )
            .get(deliveryId) as Record<string, unknown> | undefined;

          if (!existing) {
            return { ok: false, status: 404, error: 'طلب التوصيل غير موجود.' };
          }
          if (existing.courier_id !== null || !['waiting_courier', 'dispatched'].includes(String(existing.status))) {
            return {
              ok: false,
              status: 409,
              error: 'عذراً، تم قبول هذا التوصيل من قِبل مندوب آخر أو لم يعد متاحاً.',
            };
          }

          const dist = haversineKm(
            courier.latitude,
            courier.longitude,
            existing.pickup_lat !== null && existing.pickup_lat !== undefined
              ? Number(existing.pickup_lat)
              : null,
            existing.pickup_lng !== null && existing.pickup_lng !== undefined
              ? Number(existing.pickup_lng)
              : null
          );

          const info = db
            .prepare(
              `UPDATE deliveries
               SET courier_id = ?, status = 'accepted', distance_km = ?, accepted_at = ?, updated_at = ?
               WHERE id = ? AND courier_id IS NULL AND status IN ('waiting_courier', 'dispatched')`
            )
            .run(user.id, dist, now, now, deliveryId);

          if (info.changes !== 1) {
            return {
              ok: false,
              status: 409,
              error: 'عذراً، تم قبول هذا التوصيل من قِبل مندوب آخر للتو.',
            };
          }

          logDeliveryEvent({
            deliveryId,
            eventType: 'accepted',
            actorId: user.id,
            actorName: user.fullName,
            actorRole: 'courier',
            notes: `وافق المندوب ${user.fullName} على التوصيل${dist !== null ? ` (${dist} كم)` : ''}`,
            previousStatus: String(existing.status),
            newStatus: 'accepted',
          });

          const updated = db
            .prepare(
              `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
                      o.customer_name, o.customer_phone,
                      cu.full_name AS courier_name, cu.phone AS courier_phone,
                      cp.vehicle_type AS courier_vehicle_type, cp.plate_number AS courier_plate_number
               FROM deliveries d
               JOIN orders o ON o.id = d.order_id
               JOIN stores s ON s.id = d.store_id
               LEFT JOIN users cu ON cu.id = d.courier_id
               LEFT JOIN couriers cp ON cp.user_id = d.courier_id
               WHERE d.id = ?`
            )
            .get(deliveryId) as Record<string, unknown>;

          return {
            ok: true,
            deliveryRow: updated,
            storeOwnerId: String(existing.store_owner_id),
          };
        }
      );

      const result = acceptTx();
      if (!result.ok) {
        res.status(result.status).json({ error: result.error });
        return;
      }

      const dRow = result.deliveryRow;
      // Notify Merchant with courier details
      createAndDispatchNotification({
        userId: result.storeOwnerId,
        storeId: String(dRow.store_id),
        orderId: String(dRow.order_id),
        type: 'delivery_accepted',
        title: `وافق المندوب ${user.fullName} على توصيل الطلب ${String(dRow.order_number)}`,
        body: `المندوب: ${user.fullName} · الهاتف: ${user.phone} · سيتوجه لاستلام الطلب من متجرك الآن.`,
        targetView: 'merchant',
      });

      // Notify Customer with courier name & their private 6-digit delivery verification OTP
      createAndDispatchNotification({
        userId: String(dRow.customer_id),
        storeId: String(dRow.store_id),
        orderId: String(dRow.order_id),
        type: 'delivery_accepted',
        title: `تم تعيين مندوب توصيل لطلبك ${String(dRow.order_number)}`,
        body: `المندوب: ${user.fullName} (${user.phone}) · رمز تأكيد الاستلام الخاص بك: ${String(
          dRow.delivery_otp
        )} (أعطِ الرمز للمندوب عند استلام الطلب فقط).`,
        targetView: 'orders',
      });

      res.json({
        delivery: mapDelivery(dRow, { includeOtp: false, includeEvents: true }),
      });
    }
  );

  // Courier Delivery Lifecycle Status Update (strict ownership + forward transitions + mandatory OTP for 'delivered')
  app.patch(
    '/api/courier/deliveries/:id/status',
    requireRole('courier'),
    (req: AuthedRequest, res) => {
      const user = req.user!;
      const deliveryId = sanitizeText(req.params.id, 60);
      const nextStatus = req.body?.status as DeliveryStatus;
      const providedOtp = sanitizeText(req.body?.deliveryOtp ?? req.body?.otp, 16);
      const notes = sanitizeText(req.body?.notes, 240);

      const allowedCourierTargets: DeliveryStatus[] = [
        'heading_to_store',
        'picked_up',
        'on_the_way',
        'delivered',
      ];
      if (!allowedCourierTargets.includes(nextStatus)) {
        res.status(400).json({ error: 'حالة التوصيل المطلوبة غير صالحة.' });
        return;
      }

      const existing = db
        .prepare(
          `SELECT d.*, s.owner_id AS store_owner_id, s.name AS store_name, o.order_number
           FROM deliveries d
           JOIN stores s ON s.id = d.store_id
           JOIN orders o ON o.id = d.order_id
           WHERE d.id = ?`
        )
        .get(deliveryId) as Record<string, unknown> | undefined;

      if (!existing) {
        res.status(404).json({ error: 'سجل التوصيل غير موجود.' });
        return;
      }
      if (String(existing.courier_id || '') !== user.id) {
        res.status(403).json({ error: 'هذا التوصيل غير مسند إلى حسابك.' });
        return;
      }

      const currentStatus = String(existing.status) as DeliveryStatus;
      const validNextMap: Record<string, DeliveryStatus[]> = {
        accepted: ['heading_to_store', 'picked_up'],
        heading_to_store: ['picked_up'],
        picked_up: ['on_the_way', 'delivered'],
        on_the_way: ['delivered'],
      };

      if (!validNextMap[currentStatus]?.includes(nextStatus)) {
        res.status(400).json({
          error: `لا يمكن الانتقال من حالة (${DELIVERY_STATUS_LABELS[currentStatus]}) إلى (${DELIVERY_STATUS_LABELS[nextStatus]}).`,
        });
        return;
      }

      // Mandatory OTP verification when completing delivery
      if (nextStatus === 'delivered') {
        const expectedOtp = String(existing.delivery_otp || '');
        if (!providedOtp || !safeSecretEquals(providedOtp, expectedOtp)) {
          res.status(400).json({
            error: 'رمز تأكيد التسليم (OTP) غير صحيح. يرجى طلب الرمز المكوّن من 6 أرقام من الزبون لإتمام التسليم.',
          });
          return;
        }
      }

      const now = new Date().toISOString();
      const orderId = String(existing.order_id);

      const updateTx = db.transaction(() => {
        if (nextStatus === 'picked_up') {
          db.prepare(
            `UPDATE deliveries SET status = ?, picked_up_at = ?, updated_at = ? WHERE id = ?`
          ).run(nextStatus, now, now, deliveryId);
          db.prepare("UPDATE orders SET status = 'out_for_delivery', updated_at = ? WHERE id = ?").run(
            now,
            orderId
          );
          logOrderEvent({
            orderId,
            eventType: 'status_changed',
            actorId: user.id,
            actorName: user.fullName,
            actorRole: 'courier',
            reason: 'استلم المندوب الطلب من المتجر',
            previousStatus: '',
            newStatus: 'out_for_delivery',
          });
        } else if (nextStatus === 'on_the_way') {
          db.prepare(`UPDATE deliveries SET status = ?, updated_at = ? WHERE id = ?`).run(
            nextStatus,
            now,
            deliveryId
          );
          db.prepare("UPDATE orders SET status = 'out_for_delivery', updated_at = ? WHERE id = ?").run(
            now,
            orderId
          );
        } else if (nextStatus === 'delivered') {
          db.prepare(
            `UPDATE deliveries SET status = 'delivered', otp_verified = 1, delivered_at = ?, updated_at = ? WHERE id = ?`
          ).run(now, now, deliveryId);
          db.prepare("UPDATE orders SET status = 'delivered', updated_at = ? WHERE id = ?").run(
            now,
            orderId
          );
          db.prepare(
            'UPDATE couriers SET total_deliveries = total_deliveries + 1, updated_at = ? WHERE user_id = ?'
          ).run(now, user.id);
          logOrderEvent({
            orderId,
            eventType: 'status_changed',
            actorId: user.id,
            actorName: user.fullName,
            actorRole: 'courier',
            reason: 'تم تسليم الطلب للزبون بعد التحقق من رمز الاستلام OTP',
            previousStatus: 'out_for_delivery',
            newStatus: 'delivered',
          });
        } else {
          db.prepare(`UPDATE deliveries SET status = ?, updated_at = ? WHERE id = ?`).run(
            nextStatus,
            now,
            deliveryId
          );
        }

        logDeliveryEvent({
          deliveryId,
          eventType: 'status_changed',
          actorId: user.id,
          actorName: user.fullName,
          actorRole: 'courier',
          notes:
            notes ||
            (nextStatus === 'delivered'
              ? 'تم التحقق من رمز الاستلام OTP وتسليم الطلب بنجاح'
              : DELIVERY_STATUS_LABELS[nextStatus]),
          previousStatus: currentStatus,
          newStatus: nextStatus,
        });
      });
      updateTx();

      const notifType = nextStatus === 'delivered' ? 'delivery_completed' : 'delivery_updated';
      const label = DELIVERY_STATUS_LABELS[nextStatus];

      // Notify merchant
      createAndDispatchNotification({
        userId: String(existing.store_owner_id),
        storeId: String(existing.store_id),
        orderId,
        type: notifType,
        title: `تحديث توصيل الطلب ${String(existing.order_number)}`,
        body: `${label} · المندوب: ${user.fullName}`,
        targetView: 'merchant',
      });

      // Notify customer
      createAndDispatchNotification({
        userId: String(existing.customer_id),
        storeId: String(existing.store_id),
        orderId,
        type: notifType,
        title: `تحديث توصيل طلبك ${String(existing.order_number)}`,
        body:
          nextStatus === 'delivered'
            ? `تم تسليم طلبك من ${String(existing.store_name)} بنجاح. شكراً لاستخدامك سوقنا!`
            : `${label} · المندوب: ${user.fullName} (${user.phone})`,
        targetView: 'orders',
      });

      const updatedRow = db
        .prepare(
          `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
                  o.customer_name, o.customer_phone,
                  cu.full_name AS courier_name, cu.phone AS courier_phone,
                  cp.vehicle_type AS courier_vehicle_type, cp.plate_number AS courier_plate_number
           FROM deliveries d
           JOIN orders o ON o.id = d.order_id
           JOIN stores s ON s.id = d.store_id
           LEFT JOIN users cu ON cu.id = d.courier_id
           LEFT JOIN couriers cp ON cp.user_id = d.courier_id
           WHERE d.id = ?`
        )
        .get(deliveryId) as Record<string, unknown>;

      res.json({
        delivery: mapDelivery(updatedRow, { includeOtp: false, includeEvents: true }),
      });
    }
  );

  // =========================================================================
  // USER SUBSCRIPTION STATUS, DYNAMIC PLANS & PAYMENT PROOF REQUESTS
  // =========================================================================
  app.get('/api/subscription/plans', (_req, res) => {
    res.json({
      plans: getSubscriptionPlans({ onlyActive: true }),
      paymentMethods: getPaymentMethodsConfig(),
      currency: getPlatformSetting('currency', 'د.ع'),
    });
  });

  app.get('/api/subscription/me', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const plans = getSubscriptionPlans({ onlyActive: true });
    const paymentMethods = getPaymentMethodsConfig();
    if (user.role !== 'merchant' && user.role !== 'courier') {
      res.json({
        subscription: null,
        required: false,
        plans,
        paymentMethods,
        paymentRequests: [],
      });
      return;
    }
    const subscription = evaluateUserSubscription(user.id, { includeLogs: true });
    const paymentRequests = getUserPaymentRequests(user.id);
    res.json({
      subscription,
      required: true,
      plans,
      paymentMethods,
      paymentRequests,
    });
  });

  app.post(
    '/api/subscription/payment-requests',
    requireRole('merchant', 'courier'),
    (req: AuthedRequest, res) => {
      const user = req.user!;
      const planId = sanitizeText(req.body?.planId, 60);
      const paymentMethod = req.body?.paymentMethod === 'mastercard' ? 'mastercard' : req.body?.paymentMethod === 'zaincash' ? 'zaincash' : null;
      const transferReference = sanitizeText(req.body?.transferReference, 120);
      const transferDetails = sanitizeText(req.body?.transferDetails, 500);
      const proofDataUrl = typeof req.body?.paymentProofDataUrl === 'string' ? req.body.paymentProofDataUrl : '';

      if (!planId) {
        res.status(400).json({ error: 'يرجى اختيار باقة ومدة الاشتراك المطلوبة.' });
        return;
      }
      if (!paymentMethod) {
        res.status(400).json({ error: 'يرجى اختيار وسيلة الدفع (زين كاش أو ماستر كارد).' });
        return;
      }
      if (!proofDataUrl) {
        res.status(400).json({ error: 'يرجى رفع صورة واضحة لإثبات التحويل المالي قبل إرسال الطلب.' });
        return;
      }

      const savedProof = saveBase64PaymentProof(proofDataUrl);
      if ('error' in savedProof) {
        res.status(400).json({ error: savedProof.error });
        return;
      }

      const result = submitSubscriptionPaymentRequest({
        user,
        planId,
        paymentMethod,
        transferReference,
        transferDetails,
        paymentProofFilename: savedProof.filename,
        currency: getPlatformSetting('currency', 'د.ع'),
      });

      if (result.ok === false) {
        res.status(result.status).json({ error: result.error });
        return;
      }

      res.status(201).json({
        ok: true,
        request: result.request,
        subscription: result.subscription,
        paymentRequests: getUserPaymentRequests(user.id),
        message:
          'تم إرسال طلب الاشتراك وصورة إثبات التحويل بنجاح. الطلب قيد المراجعة ولن يتم تفعيل الاشتراك إلا بعد موافقة المدير الرئيسي.',
      });
    }
  );

  app.post(
    '/api/subscription/renewal-request',
    requireRole('merchant', 'courier'),
    (req: AuthedRequest, res) => {
      const user = req.user!;
      const sub = evaluateUserSubscription(user.id);
      if (!sub) {
        res.status(404).json({ error: 'تعذر العثور على ملف الاشتراك.' });
        return;
      }

      const note = sanitizeText(req.body?.note, 350) || 'طلب تجديد الاشتراك والتنسيق اليدوي مع الإدارة';
      const now = new Date().toISOString();

      db.prepare(
        `UPDATE user_subscriptions
         SET renewal_requested = 1, renewal_note = ?, renewal_requested_at = ?, updated_at = ?
         WHERE id = ?`
      ).run(note, now, now, sub.id);

      logSubscriptionAction({
        subscriptionId: sub.id,
        userId: user.id,
        actionType: 'renewal_requested',
        previousStatus: sub.status,
        newStatus: sub.status,
        previousExpiresAt: sub.expiresAt,
        newExpiresAt: sub.expiresAt,
        actorId: user.id,
        actorName: user.fullName,
        actorRole: user.role,
        notes: note,
      });

      const admins = db
        .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
        .all() as Array<{ id: string }>;
      const roleAr = user.role === 'merchant' ? 'صاحب متجر' : 'مندوب توصيل';
      for (const adm of admins) {
        createAndDispatchNotification({
          userId: adm.id,
          storeId: sub.storeId,
          orderId: null,
          type: 'subscription_alert',
          title: `طلب تجديد اشتراك جديد — ${sub.storeName || user.fullName}`,
          body: `${roleAr}: ${user.fullName} (${user.phone}) · ${note}`,
          targetView: 'admin',
        });
      }

      res.json({
        ok: true,
        subscription: evaluateUserSubscription(user.id, { includeLogs: true }),
      });
    }
  );

  // =========================================================================
  // TECHNICAL SUPPORT & COMPLAINTS SYSTEM (Customer, Merchant, Courier)
  // =========================================================================
  app.post('/api/complaints', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const rawTargetType = req.body?.targetType as ComplaintTargetType;
    const targetType: ComplaintTargetType = VALID_COMPLAINT_TARGETS.includes(rawTargetType)
      ? rawTargetType
      : 'technical_support';
    const targetId =
      sanitizeText(req.body?.targetId, 60) ||
      (targetType === 'technical_support' || targetType === 'subscription' || targetType === 'general'
        ? targetType
        : '');
    let targetName = sanitizeText(req.body?.targetName, 140);
    const orderId = sanitizeText(req.body?.orderId, 60) || null;
    const deliveryId = sanitizeText(req.body?.deliveryId, 60) || null;
    const category = sanitizeText(req.body?.category, 120);
    const description = sanitizeText(req.body?.description, 1500);
    const imageUrl = sanitizeImageUrl(req.body?.imageUrl);

    if (!targetId) {
      res.status(400).json({ error: 'يرجى تحديد الجهة أو نوع الطلب.' });
      return;
    }
    if (category.length < 2 || description.length < 5) {
      res.status(400).json({ error: 'يرجى اختيار نوع المشكلة أو الشكوى وكتابة تفاصيل واضحة.' });
      return;
    }

    if (!targetName) {
      if (targetType === 'store') {
        const s = db.prepare('SELECT name FROM stores WHERE id = ?').get(targetId) as
          | { name: string }
          | undefined;
        targetName = s?.name || targetId;
      } else if (targetType === 'technical_support') {
        targetName = 'الدعم الفني لمنصة سوقنا';
      } else if (targetType === 'subscription') {
        targetName = 'قسم الاشتراكات والتجديد';
      } else if (targetType === 'general') {
        targetName = 'الإدارة العامة لسوقنا';
      } else {
        const u = db.prepare('SELECT full_name FROM users WHERE id = ?').get(targetId) as
          | { full_name: string }
          | undefined;
        targetName = u?.full_name || targetId;
      }
    }

    const id = generateId('cmp');
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO complaints (id, reporter_id, reporter_role, target_type, target_id, target_name, order_id, delivery_id, category, description, image_url, status, violation_recorded, admin_notes, resolved_by_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', 0, '', NULL, ?, ?)`
    ).run(
      id,
      user.id,
      user.role,
      targetType,
      targetId,
      targetName,
      orderId,
      deliveryId,
      category,
      description,
      imageUrl,
      now,
      now
    );

    // Seed initial message in the conversation log
    db.prepare(
      `INSERT INTO complaint_messages (id, complaint_id, sender_id, sender_name, sender_role, message, image_url, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(generateId('cmsg'), id, user.id, user.fullName, user.role, description, imageUrl, now);

    const admins = db
      .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
      .all() as Array<{ id: string }>;
    for (const adm of admins) {
      createAndDispatchNotification({
        userId: adm.id,
        storeId: targetType === 'store' ? targetId : null,
        orderId,
        type: 'complaint_new',
        title: `تذكرة دعم / شكوى جديدة: ${category}`,
        body: `المرسل: ${user.fullName} · ${targetName} · ${description.slice(0, 120)}`,
        targetView: 'admin',
      });
    }

    const created = db
      .prepare(
        `SELECT c.*, u.full_name AS reporter_name, u.phone AS reporter_phone, o.order_number
         FROM complaints c
         JOIN users u ON u.id = c.reporter_id
         LEFT JOIN orders o ON o.id = c.order_id
         WHERE c.id = ?`
      )
      .get(id) as Record<string, unknown>;

    res.status(201).json({ complaint: attachComplaintMessages([created])[0] });
  });

  app.get('/api/complaints/my', requireAuth, (req: AuthedRequest, res) => {
    const rows = db
      .prepare(
        `SELECT c.*, u.full_name AS reporter_name, u.phone AS reporter_phone, o.order_number
         FROM complaints c
         JOIN users u ON u.id = c.reporter_id
         LEFT JOIN orders o ON o.id = c.order_id
         WHERE c.reporter_id = ?
         ORDER BY c.updated_at DESC, c.created_at DESC`
      )
      .all(req.user!.id) as Record<string, unknown>[];
    res.json({ complaints: attachComplaintMessages(rows) });
  });

  // Conversation reply on a complaint/support ticket (strictly reporter or super_admin)
  app.post('/api/complaints/:id/messages', requireAuth, (req: AuthedRequest, res) => {
    const user = req.user!;
    const complaintId = sanitizeText(req.params.id, 60);
    const existing = db.prepare('SELECT * FROM complaints WHERE id = ?').get(complaintId) as
      | Record<string, unknown>
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'الشكوى أو تذكرة الدعم غير موجودة.' });
      return;
    }

    const isAdmin = user.role === 'super_admin';
    const isOwner = String(existing.reporter_id) === user.id;
    if (!isAdmin && !isOwner) {
      res.status(403).json({ error: 'ليس لديك صلاحية الوصول إلى هذه المحادثة.' });
      return;
    }

    if (!isAdmin && (existing.status === 'closed' || existing.status === 'dismissed')) {
      res.status(400).json({ error: 'هذه التذكرة مغلقة حالياً. يمكنك فتح شكوى أو تذكرة دعم جديدة.' });
      return;
    }

    const message = sanitizeText(req.body?.message, 1500);
    const imageUrl = sanitizeImageUrl(req.body?.imageUrl);
    if (message.length < 1 && !imageUrl) {
      res.status(400).json({ error: 'يرجى كتابة نص الرد أو إرفاق صورة.' });
      return;
    }

    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO complaint_messages (id, complaint_id, sender_id, sender_name, sender_role, message, image_url, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      generateId('cmsg'),
      complaintId,
      user.id,
      user.fullName,
      user.role,
      message || 'صورة مرفقة',
      imageUrl,
      now
    );

    const currentStatus = String(existing.status) as ComplaintStatus;
    let nextStatus = currentStatus;
    if (isAdmin && (currentStatus === 'open' || currentStatus === 'under_review')) {
      nextStatus = 'replied';
    } else if (!isAdmin && currentStatus === 'replied') {
      nextStatus = 'under_review';
    }

    db.prepare(
      `UPDATE complaints SET status = ?, updated_at = ? WHERE id = ?`
    ).run(nextStatus, now, complaintId);

    if (isAdmin) {
      logAdminAction({
        admin: user,
        actionType: 'complaint_replied',
        targetType: 'complaint',
        targetId: complaintId,
        targetLabel: String(existing.category || complaintId),
        details: message.slice(0, 200),
      });
      createAndDispatchNotification({
        userId: String(existing.reporter_id),
        storeId: null,
        orderId: existing.order_id ? String(existing.order_id) : null,
        type: 'complaint_reply',
        title: `رد جديد من الدعم الفني: ${String(existing.category)}`,
        body: message ? message.slice(0, 140) : 'أرفق الدعم الفني صورة في الرد على تذكرتك.',
        targetView: 'support',
      });
    } else {
      const admins = db
        .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
        .all() as Array<{ id: string }>;
      for (const adm of admins) {
        createAndDispatchNotification({
          userId: adm.id,
          storeId: null,
          orderId: existing.order_id ? String(existing.order_id) : null,
          type: 'complaint_reply',
          title: `رد من المستخدم على تذكرة: ${String(existing.category)}`,
          body: `${user.fullName}: ${message.slice(0, 120)}`,
          targetView: 'admin',
        });
      }
    }

    const updated = db
      .prepare(
        `SELECT c.*, u.full_name AS reporter_name, u.phone AS reporter_phone, o.order_number
         FROM complaints c
         JOIN users u ON u.id = c.reporter_id
         LEFT JOIN orders o ON o.id = c.order_id
         WHERE c.id = ?`
      )
      .get(complaintId) as Record<string, unknown>;

    res.status(201).json({ complaint: attachComplaintMessages([updated])[0] });
  });

  // SUPER ADMIN ROUTES (Strictly blocked for customer, merchant & courier)
  app.get('/api/admin/overview', requireRole('super_admin'), (_req, res) => {
    const userCounts = db
      .prepare(
        `SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN role = 'customer' THEN 1 ELSE 0 END) AS customers,
          SUM(CASE WHEN role = 'merchant' THEN 1 ELSE 0 END) AS merchants
         FROM users`
      )
      .get() as { total: number; customers: number; merchants: number };

    const courierCounts = db
      .prepare(
        `SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN verification_status = 'pending' THEN 1 ELSE 0 END) AS pending,
          SUM(CASE WHEN verification_status = 'verified' THEN 1 ELSE 0 END) AS verified,
          SUM(CASE WHEN verification_status = 'verified' AND is_available = 1 THEN 1 ELSE 0 END) AS available
         FROM couriers`
      )
      .get() as { total: number; pending: number; verified: number; available: number };

    const storeCounts = db
      .prepare(
        `SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active,
          SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
          SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected,
          SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspended
         FROM stores`
      )
      .get() as {
      total: number;
      active: number;
      pending: number;
      rejected: number;
      suspended: number;
    };

    const productCount = db
      .prepare('SELECT COUNT(*) AS cnt FROM products WHERE deleted_at IS NULL')
      .get() as { cnt: number };

    const postStats = db
      .prepare(
        `SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN status = 'hidden' THEN 1 ELSE 0 END) AS hidden
         FROM store_posts`
      )
      .get() as { total: number; hidden: number };

    const orderStats = db
      .prepare(
        `SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_orders,
          SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) AS delivered,
          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
          COALESCE(SUM(CASE WHEN status NOT IN ('cancelled', 'rejected') THEN total_amount ELSE 0 END), 0) AS volume
         FROM orders`
      )
      .get() as {
      total: number;
      pending_orders: number;
      delivered: number;
      cancelled: number;
      volume: number;
    };

    const deliveryStats = db
      .prepare(
        `SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN status IN ('waiting_courier', 'dispatched', 'accepted', 'heading_to_store', 'picked_up', 'on_the_way') THEN 1 ELSE 0 END) AS active,
          SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) AS delivered
         FROM deliveries`
      )
      .get() as { total: number; active: number; delivered: number };

    const openComplaints = db
      .prepare("SELECT COUNT(*) AS cnt FROM complaints WHERE status IN ('open', 'under_review', 'replied')")
      .get() as { cnt: number };

    const pendingRecoveryRow = db
      .prepare("SELECT COUNT(*) AS cnt FROM account_recovery_requests WHERE status = 'pending'")
      .get() as { cnt: number };

    const subscriptionStats = getSubscriptionSummaryStats();
    const categoryStats = db
      .prepare(
        `SELECT COUNT(*) AS total,
          SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) AS active_count
         FROM categories`
      )
      .get() as { total: number; active_count: number };

    res.json({
      overview: {
        totalUsers: Number(userCounts.total || 0),
        totalCustomers: Number(userCounts.customers || 0),
        totalMerchants: Number(userCounts.merchants || 0),
        totalCouriers: Number(courierCounts.total || 0),
        pendingCouriers: Number(courierCounts.pending || 0),
        verifiedCouriers: Number(courierCounts.verified || 0),
        availableCouriers: Number(courierCounts.available || 0),
        totalStores: Number(storeCounts.total || 0),
        activeStores: Number(storeCounts.active || 0),
        pendingStores: Number(storeCounts.pending || 0),
        rejectedStores: Number(storeCounts.rejected || 0),
        suspendedStores: Number(storeCounts.suspended || 0),
        totalProducts: Number(productCount.cnt || 0),
        totalCategories: Number(categoryStats?.total || 0),
        activeCategories: Number(categoryStats?.active_count || 0),
        totalStorePosts: Number(postStats.total || 0),
        hiddenStorePosts: Number(postStats.hidden || 0),
        totalOrders: Number(orderStats.total || 0),
        pendingOrders: Number(orderStats.pending_orders || 0),
        deliveredOrders: Number(orderStats.delivered || 0),
        cancelledOrders: Number(orderStats.cancelled || 0),
        totalDeliveries: Number(deliveryStats.total || 0),
        activeDeliveries: Number(deliveryStats.active || 0),
        deliveredDeliveries: Number(deliveryStats.delivered || 0),
        openComplaints: Number(openComplaints.cnt || 0),
        pendingRecoveryRequests: Number(pendingRecoveryRow.cnt || 0),
        pendingPaymentRequests: subscriptionStats.pendingPaymentRequestsCount,
        totalCashVolume: Math.round(Number(orderStats.volume || 0) * 100) / 100,
        subscriptionStats,
        currency: getPlatformSetting('currency', 'د.ع'),
        requireStoreApproval: getPlatformSetting('require_store_approval', 'false') === 'true',
        requireCourierApproval: getPlatformSetting('require_courier_approval', 'true') === 'true',
        enabledStoreTypes: getEnabledStoreTypes(),
        trialDays: getConfiguredTrialDays(),
        appName: getPlatformSetting('app_name', 'سوقنا | SOUQNA'),
        supportPhone: getPlatformSetting('support_phone', '07764327688'),
        supportTelegram: getPlatformSetting('support_telegram', '@murtadaa1996'),
        announcementText: getPlatformSetting('announcement_text', ''),
      },
    });
  });

  app.patch('/api/admin/settings', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const changes: string[] = [];
    if (typeof req.body?.requireStoreApproval === 'boolean') {
      setPlatformSetting(
        'require_store_approval',
        req.body.requireStoreApproval ? 'true' : 'false'
      );
      changes.push(`موافقة المتاجر: ${req.body.requireStoreApproval ? 'مطلوبة' : 'تلقائية'}`);
    }
    if (typeof req.body?.requireCourierApproval === 'boolean') {
      setPlatformSetting(
        'require_courier_approval',
        req.body.requireCourierApproval ? 'true' : 'false'
      );
      changes.push(`موافقة المندوبين: ${req.body.requireCourierApproval ? 'مطلوبة' : 'تلقائية'}`);
    }
    if (typeof req.body?.currency === 'string' && ALLOWED_CURRENCIES.includes(req.body.currency)) {
      setPlatformSetting('currency', req.body.currency);
      changes.push(`العملة: ${req.body.currency}`);
    }
    if (Array.isArray(req.body?.enabledStoreTypes)) {
      const validTypes = req.body.enabledStoreTypes.filter((t: unknown): t is StoreType =>
        VALID_STORE_TYPES.includes(t as StoreType)
      );
      if (validTypes.length > 0) {
        setPlatformSetting('enabled_store_types', JSON.stringify(Array.from(new Set(validTypes))));
        changes.push(`الأنشطة المفعّلة: ${validTypes.length}`);
      }
    }
    if (req.body?.trialDays !== undefined) {
      const parsedDays = Math.floor(Number(req.body.trialDays));
      if (!Number.isFinite(parsedDays) || parsedDays < 0 || parsedDays > 365) {
        res.status(400).json({ error: 'مدة التجربة المجانية يجب أن تكون بين 0 و 365 يوماً.' });
        return;
      }
      setPlatformSetting('trial_days', String(parsedDays));
      changes.push(`التجربة المجانية: ${parsedDays} يوم`);
    }
    if (typeof req.body?.appName === 'string') {
      const nextAppName = sanitizeText(req.body.appName, 80);
      if (nextAppName.length >= 2) {
        setPlatformSetting('app_name', nextAppName);
        changes.push(`اسم التطبيق: ${nextAppName}`);
      }
    }
    if (typeof req.body?.supportPhone === 'string') {
      const nextPhone = sanitizeText(req.body.supportPhone, 32);
      setPlatformSetting('support_phone', nextPhone);
      changes.push(`هاتف الدعم: ${nextPhone || 'غير محدد'}`);
    }
    if (typeof req.body?.supportTelegram === 'string') {
      const nextTelegram = sanitizeText(req.body.supportTelegram, 64);
      setPlatformSetting('support_telegram', nextTelegram);
      changes.push(`تيليجرام الدعم: ${nextTelegram || 'غير محدد'}`);
    }
    if (typeof req.body?.announcementText === 'string') {
      const nextNote = sanitizeText(req.body.announcementText, 240);
      setPlatformSetting('announcement_text', nextNote);
      changes.push('تحديث إعلان المنصة');
    }

    if (req.user && changes.length > 0) {
      logAdminAction({
        admin: req.user,
        actionType: 'platform_settings_updated',
        targetType: 'settings',
        targetId: 'platform',
        targetLabel: 'إعدادات المنصة',
        details: changes.join(' · '),
      });
    }

    res.json({
      currency: getPlatformSetting('currency', 'د.ع'),
      requireStoreApproval: getPlatformSetting('require_store_approval', 'false') === 'true',
      requireCourierApproval: getPlatformSetting('require_courier_approval', 'true') === 'true',
      enabledStoreTypes: getEnabledStoreTypes(),
      trialDays: getConfiguredTrialDays(),
      appName: getPlatformSetting('app_name', 'سوقنا | SOUQNA'),
      supportPhone: getPlatformSetting('support_phone', '07764327688'),
      supportTelegram: getPlatformSetting('support_telegram', '@murtadaa1996'),
      announcementText: getPlatformSetting('announcement_text', ''),
    });
  });

  // Super Admin: Marketplace Categories CRUD
  app.get('/api/admin/categories', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT c.*,
          (SELECT COUNT(*) FROM products p WHERE p.category = c.name AND p.deleted_at IS NULL) AS product_count
         FROM categories c
         ORDER BY c.sort_order ASC, c.name ASC`
      )
      .all() as Record<string, unknown>[];
    res.json({ categories: rows.map(mapCategoryRow) });
  });

  app.post('/api/admin/categories', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const name = sanitizeText(req.body?.name, 80);
    const description = sanitizeText(req.body?.description, 240);
    const rawStoreType = typeof req.body?.storeType === 'string' ? req.body.storeType.trim() : 'all';
    const storeType: StoreType | 'all' =
      rawStoreType !== 'all' && VALID_STORE_TYPES.includes(rawStoreType as StoreType)
        ? (rawStoreType as StoreType)
        : 'all';
    const sortOrder = Number.isFinite(Number(req.body?.sortOrder))
      ? Math.max(0, Math.min(9999, Math.floor(Number(req.body.sortOrder))))
      : 100;
    const isActive = req.body?.isActive === false ? 0 : 1;

    if (name.length < 2) {
      res.status(400).json({ error: 'يرجى إدخال اسم قسم صحيح (حرفان على الأقل).' });
      return;
    }

    const existing = db.prepare('SELECT id FROM categories WHERE name = ?').get(name) as
      | { id: string }
      | undefined;
    if (existing) {
      res.status(409).json({ error: 'يوجد قسم مسجل بنفس الاسم مسبقاً.' });
      return;
    }

    const id = generateId('cat');
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO categories (id, name, description, store_type, sort_order, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, name, description, storeType, sortOrder, isActive, now, now);

    const created = db
      .prepare(
        `SELECT c.*,
          (SELECT COUNT(*) FROM products p WHERE p.category = c.name AND p.deleted_at IS NULL) AS product_count
         FROM categories c WHERE c.id = ?`
      )
      .get(id) as Record<string, unknown>;

    if (req.user) {
      logAdminAction({
        admin: req.user,
        actionType: 'category_created',
        targetType: 'category',
        targetId: id,
        targetLabel: name,
        details: `نشاط مرتبط: ${storeType === 'all' ? 'الكل' : STORE_TYPE_LABELS[storeType]} · الترتيب: ${sortOrder}`,
      });
    }

    res.status(201).json({ category: mapCategoryRow(created) });
  });

  app.patch('/api/admin/categories/:id', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const categoryId = sanitizeText(req.params.id, 60);
    const existing = db.prepare('SELECT * FROM categories WHERE id = ?').get(categoryId) as
      | Record<string, unknown>
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'القسم غير موجود.' });
      return;
    }

    const oldName = String(existing.name);
    const nextName =
      typeof req.body?.name === 'string' ? sanitizeText(req.body.name, 80) : oldName;
    if (nextName.length < 2) {
      res.status(400).json({ error: 'اسم القسم يجب أن لا يقل عن حرفين.' });
      return;
    }
    if (nextName !== oldName) {
      const dup = db
        .prepare('SELECT id FROM categories WHERE name = ? AND id != ?')
        .get(nextName, categoryId) as { id: string } | undefined;
      if (dup) {
        res.status(409).json({ error: 'يوجد قسم آخر بنفس هذا الاسم.' });
        return;
      }
    }

    const nextDesc =
      typeof req.body?.description === 'string'
        ? sanitizeText(req.body.description, 240)
        : String(existing.description || '');
    const rawStoreType =
      typeof req.body?.storeType === 'string'
        ? req.body.storeType.trim()
        : String(existing.store_type || 'all');
    const nextStoreType: StoreType | 'all' =
      rawStoreType !== 'all' && VALID_STORE_TYPES.includes(rawStoreType as StoreType)
        ? (rawStoreType as StoreType)
        : 'all';
    const nextSortOrder =
      req.body?.sortOrder !== undefined && Number.isFinite(Number(req.body.sortOrder))
        ? Math.max(0, Math.min(9999, Math.floor(Number(req.body.sortOrder))))
        : Number(existing.sort_order || 0);
    const nextIsActive =
      typeof req.body?.isActive === 'boolean'
        ? req.body.isActive
          ? 1
          : 0
        : Number(existing.is_active);
    const now = new Date().toISOString();

    const updateTx = db.transaction(() => {
      db.prepare(
        `UPDATE categories
         SET name = ?, description = ?, store_type = ?, sort_order = ?, is_active = ?, updated_at = ?
         WHERE id = ?`
      ).run(nextName, nextDesc, nextStoreType, nextSortOrder, nextIsActive, now, categoryId);
      if (nextName !== oldName) {
        db.prepare('UPDATE products SET category = ? WHERE category = ?').run(nextName, oldName);
      }
    });
    updateTx();

    const updated = db
      .prepare(
        `SELECT c.*,
          (SELECT COUNT(*) FROM products p WHERE p.category = c.name AND p.deleted_at IS NULL) AS product_count
         FROM categories c WHERE c.id = ?`
      )
      .get(categoryId) as Record<string, unknown>;

    if (req.user) {
      logAdminAction({
        admin: req.user,
        actionType: 'category_updated',
        targetType: 'category',
        targetId: categoryId,
        targetLabel: nextName,
        details: `مفعّل: ${nextIsActive ? 'نعم' : 'لا'} · الترتيب: ${nextSortOrder}${
          nextName !== oldName ? ` · الاسم السابق: ${oldName}` : ''
        }`,
      });
    }

    res.json({ category: mapCategoryRow(updated) });
  });

  app.delete('/api/admin/categories/:id', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const categoryId = sanitizeText(req.params.id, 60);
    const existing = db.prepare('SELECT * FROM categories WHERE id = ?').get(categoryId) as
      | Record<string, unknown>
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'القسم غير موجود.' });
      return;
    }

    db.prepare('DELETE FROM categories WHERE id = ?').run(categoryId);

    if (req.user) {
      logAdminAction({
        admin: req.user,
        actionType: 'category_deleted',
        targetType: 'category',
        targetId: categoryId,
        targetLabel: String(existing.name),
        details: 'حذف قسم من قائمة الأقسام الرئيسية',
      });
    }

    res.json({ ok: true });
  });

  // Super Admin Dedicated Account & Security Routes (Strictly super_admin only)
  app.get('/api/admin/account', requireRole('super_admin'), (req: AuthedRequest, res) => {
    if (!req.user) {
      res.status(401).json({ error: 'غير مصرح.' });
      return;
    }
    const nowIso = new Date().toISOString();
    const sessionsRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM sessions WHERE user_id = ? AND expires_at > ?')
      .get(req.user.id, nowIso) as { cnt: number };
    const auditStats = db
      .prepare(
        'SELECT COUNT(*) AS cnt, MAX(created_at) AS last_at FROM admin_audit_logs WHERE admin_id = ?'
      )
      .get(req.user.id) as { cnt: number; last_at: string | null };

    res.json({
      account: {
        user: req.user,
        activeSessionsCount: Number(sessionsRow?.cnt || 1),
        totalAuditActions: Number(auditStats?.cnt || 0),
        lastAuditAt: auditStats?.last_at || null,
      },
    });
  });

  app.patch('/api/admin/account', requireRole('super_admin'), (req: AuthedRequest, res) => {
    if (!req.user) {
      res.status(401).json({ error: 'غير مصرح.' });
      return;
    }
    const fullName = sanitizeText(req.body?.fullName, 100);
    const email = sanitizeText(req.body?.email, 160).toLowerCase();
    const phone = sanitizeText(req.body?.phone, 24);
    const governorate = sanitizeText(req.body?.governorate, 80);
    const city = sanitizeText(req.body?.city, 80);
    const address = sanitizeText(req.body?.address, 260);

    if (fullName.length < 2) {
      res.status(400).json({ error: 'يرجى إدخال اسم المدير الكامل.' });
      return;
    }
    if (!isValidEmail(email)) {
      res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني صحيح.' });
      return;
    }
    if (!isValidPhone(phone)) {
      res.status(400).json({ error: 'يرجى إدخال رقم هاتف صحيح.' });
      return;
    }

    const emailOwner = db
      .prepare('SELECT id FROM users WHERE email = ? AND id != ?')
      .get(email, req.user.id) as { id: string } | undefined;
    if (emailOwner) {
      res.status(409).json({ error: 'البريد الإلكتروني مستخدم في حساب آخر.' });
      return;
    }

    db.prepare(
      `UPDATE users
       SET full_name = ?, email = ?, phone = ?, governorate = ?, city = ?, address = ?
       WHERE id = ? AND role = 'super_admin'`
    ).run(
      fullName,
      email,
      phone,
      governorate || req.user.governorate || '',
      city || governorate || req.user.city || '',
      address,
      req.user.id
    );

    const updatedRow = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id) as Record<
      string,
      unknown
    >;
    const updatedUser = mapUser(updatedRow);

    logAdminAction({
      admin: updatedUser,
      actionType: 'admin_account_updated',
      targetType: 'user',
      targetId: updatedUser.id,
      targetLabel: updatedUser.fullName,
      details: `تحديث بيانات حساب المدير العام (${updatedUser.email})`,
    });

    res.json({ user: updatedUser });
  });

  app.patch('/api/admin/account/password', requireRole('super_admin'), (req: AuthedRequest, res) => {
    if (!req.user) {
      res.status(401).json({ error: 'غير مصرح.' });
      return;
    }
    const currentPassword =
      typeof req.body?.currentPassword === 'string' ? req.body.currentPassword : '';
    const newPassword = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';

    if (!currentPassword) {
      res.status(400).json({ error: 'يرجى إدخال كلمة المرور الحالية.' });
      return;
    }
    if (newPassword.length < 8) {
      res.status(400).json({ error: 'كلمة المرور الجديدة يجب أن لا تقل عن 8 أحرف.' });
      return;
    }

    const row = db
      .prepare("SELECT password_hash FROM users WHERE id = ? AND role = 'super_admin'")
      .get(req.user.id) as { password_hash: string } | undefined;
    if (!row || !verifyPassword(currentPassword, row.password_hash)) {
      res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة.' });
      return;
    }

    const nextHash = hashPassword(newPassword);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(nextHash, req.user.id);

    let revokedOtherSessions = 0;
    if (req.tokenHash) {
      const del = db
        .prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?')
        .run(req.user.id, req.tokenHash);
      revokedOtherSessions = Number(del.changes || 0);
    }

    logAdminAction({
      admin: req.user,
      actionType: 'admin_password_changed',
      targetType: 'user',
      targetId: req.user.id,
      targetLabel: req.user.fullName,
      details: `تغيير كلمة مرور المدير العام · إنهاء ${revokedOtherSessions} جلسة أخرى`,
    });

    res.json({ ok: true, revokedOtherSessions });
  });

  app.post(
    '/api/admin/account/revoke-other-sessions',
    requireRole('super_admin'),
    (req: AuthedRequest, res) => {
      if (!req.user || !req.tokenHash) {
        res.status(401).json({ error: 'غير مصرح.' });
        return;
      }
      const del = db
        .prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?')
        .run(req.user.id, req.tokenHash);
      const revokedCount = Number(del.changes || 0);

      logAdminAction({
        admin: req.user,
        actionType: 'admin_sessions_revoked',
        targetType: 'session',
        targetId: req.user.id,
        targetLabel: req.user.fullName,
        details: `تم إنهاء ${revokedCount} جلسة نشطة على الأجهزة الأخرى`,
      });

      res.json({ ok: true, revokedCount });
    }
  );

  app.get('/api/admin/stores', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT s.*, u.full_name AS owner_name, u.phone AS owner_phone,
          COALESCE(sub.plan_name, CASE WHEN usub.status = 'trial' THEN 'free' ELSE 'basic' END) AS sub_plan_name,
          COALESCE(sub.status, usub.status) AS sub_status,
          COALESCE(sub.monthly_fee, usub.monthly_fee, 0) AS sub_monthly_fee,
          COALESCE(sub.expires_at, usub.expires_at) AS sub_expires_at,
          COALESCE(sub.notes, usub.notes, '') AS sub_notes,
          COALESCE(sub.updated_at, usub.updated_at) AS sub_updated_at,
          (SELECT COUNT(*) FROM products p WHERE p.store_id = s.id AND p.deleted_at IS NULL) AS product_count,
          (SELECT COUNT(*) FROM orders o WHERE o.store_id = s.id) AS order_count,
          (SELECT COUNT(*) FROM store_posts sp WHERE sp.store_id = s.id) AS post_count
         FROM stores s
         LEFT JOIN users u ON u.id = s.owner_id
         LEFT JOIN store_subscriptions sub ON sub.store_id = s.id
         LEFT JOIN user_subscriptions usub ON usub.user_id = s.owner_id
         ORDER BY CASE s.status WHEN 'pending' THEN 0 WHEN 'active' THEN 1 WHEN 'suspended' THEN 2 ELSE 3 END, s.created_at DESC`
      )
      .all() as Record<string, unknown>[];
    res.json({ stores: rows.map(mapStore) });
  });

  app.patch('/api/admin/stores/:id', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const storeId = sanitizeText(req.params.id, 60);
    const existing = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId) as
      | Record<string, unknown>
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }

    const nextStatus =
      req.body?.status && VALID_STORE_STATUSES.includes(req.body.status)
        ? (req.body.status as StoreStatus)
        : (existing.status as StoreStatus);
    const nextVerified =
      typeof req.body?.isVerified === 'boolean'
        ? req.body.isVerified
          ? 1
          : 0
        : Number(existing.is_verified);
    const nextRejectionReason =
      nextStatus === 'rejected'
        ? sanitizeText(req.body?.rejectionReason ?? existing.rejection_reason, 300)
        : '';

    db.prepare(
      'UPDATE stores SET status = ?, is_verified = ?, rejection_reason = ? WHERE id = ?'
    ).run(nextStatus, nextVerified, nextRejectionReason, storeId);

    const updated = db
      .prepare(
        `SELECT s.*, u.full_name AS owner_name, u.phone AS owner_phone,
          (SELECT COUNT(*) FROM products p WHERE p.store_id = s.id AND p.deleted_at IS NULL) AS product_count,
          (SELECT COUNT(*) FROM orders o WHERE o.store_id = s.id) AS order_count
         FROM stores s JOIN users u ON u.id = s.owner_id WHERE s.id = ?`
      )
      .get(storeId) as Record<string, unknown>;

    const mappedStore = mapStore(updated);
    if (existing.status !== nextStatus) {
      createAndDispatchNotification({
        userId: mappedStore.ownerId,
        storeId: mappedStore.id,
        orderId: null,
        type: 'store_status',
        title: `تحديث حالة متجرك: ${mappedStore.name}`,
        body: `أصبحت حالة المتجر الآن: ${STORE_STATUS_LABELS[nextStatus]}${
          nextRejectionReason ? ` · السبب: ${nextRejectionReason}` : ''
        }`,
        targetView: 'merchant',
      });
    }

    if (req.user) {
      logAdminAction({
        admin: req.user,
        actionType: 'store_updated',
        targetType: 'store',
        targetId: mappedStore.id,
        targetLabel: mappedStore.name,
        details: `الحالة: ${STORE_STATUS_LABELS[nextStatus]} · موثق: ${nextVerified ? 'نعم' : 'لا'}${
          nextRejectionReason ? ` · السبب: ${nextRejectionReason}` : ''
        }`,
      });
    }

    res.json({ store: mappedStore });
  });

  app.delete('/api/admin/stores/:id', requireRole('super_admin'), (req, res) => {
    const storeId = sanitizeText(req.params.id, 60);
    const info = db.prepare('DELETE FROM stores WHERE id = ?').run(storeId);
    if (info.changes === 0) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }
    res.json({ ok: true });
  });

  // Super Admin: manage all products across all stores
  app.get('/api/admin/products', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT p.*, s.name AS store_name, s.city AS store_city, s.district AS store_district, s.store_type AS store_type
         FROM products p
         LEFT JOIN stores s ON s.id = p.store_id
         WHERE p.deleted_at IS NULL
         ORDER BY p.created_at DESC
         LIMIT 500`
      )
      .all() as Record<string, unknown>[];
    res.json({ products: rows.map(mapProduct) });
  });

  app.patch('/api/admin/products/:id', requireRole('super_admin'), (req, res) => {
    const productId = sanitizeText(req.params.id, 60);
    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(productId) as
      | Record<string, unknown>
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'المنتج غير موجود.' });
      return;
    }
    const nextAvailable =
      typeof req.body?.isAvailable === 'boolean'
        ? req.body.isAvailable
          ? 1
          : 0
        : Number(existing.is_available);

    db.prepare('UPDATE products SET is_available = ? WHERE id = ?').run(nextAvailable, productId);
    const updated = db
      .prepare(
        `SELECT p.*, s.name AS store_name, s.city AS store_city, s.district AS store_district, s.store_type AS store_type
         FROM products p JOIN stores s ON s.id = p.store_id WHERE p.id = ?`
      )
      .get(productId) as Record<string, unknown>;
    res.json({ product: mapProduct(updated) });
  });

  app.delete('/api/admin/products/:id', requireRole('super_admin'), (req, res) => {
    const productId = sanitizeText(req.params.id, 60);
    const info = db.prepare('DELETE FROM products WHERE id = ?').run(productId);
    if (info.changes === 0) {
      res.status(404).json({ error: 'المنتج غير موجود.' });
      return;
    }
    res.json({ ok: true });
  });

  app.get('/api/admin/users', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare('SELECT * FROM users ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];
    res.json({ users: rows.map(mapUser) });
  });

  app.patch('/api/admin/users/:id', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const targetId = sanitizeText(req.params.id, 60);
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(targetId) as
      | Record<string, unknown>
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'المستخدم غير موجود.' });
      return;
    }

    if (targetId === req.user!.id) {
      res.status(400).json({ error: 'لا يمكنك تعديل حالة أو صلاحية حسابك الإداري من هنا.' });
      return;
    }

    const nextActive =
      typeof req.body?.isActive === 'boolean'
        ? req.body.isActive
          ? 1
          : 0
        : Number(existing.is_active);
    const nextRole =
      req.body?.role && VALID_ROLES.includes(req.body.role)
        ? (req.body.role as UserRole)
        : (existing.role as UserRole);

    db.prepare('UPDATE users SET is_active = ?, role = ? WHERE id = ?').run(
      nextActive,
      nextRole,
      targetId
    );
    if (nextRole === 'merchant' || nextRole === 'courier') {
      ensureUserSubscription(targetId, nextRole);
    }
    if (nextActive === 0) {
      db.prepare('DELETE FROM sessions WHERE user_id = ?').run(targetId);
    }

    const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(targetId) as Record<
      string,
      unknown
    >;
    const mappedUser = mapUser(updated);
    logAdminAction({
      admin: req.user!,
      actionType: 'user_updated',
      targetType: 'user',
      targetId: mappedUser.id,
      targetLabel: `${mappedUser.fullName} (${mappedUser.email})`,
      details: `نشط: ${mappedUser.isActive ? 'نعم' : 'موقوف'} · الصلاحية: ${mappedUser.role}`,
    });
    res.json({ user: mappedUser });
  });

  app.get('/api/admin/orders', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const rows = db
      .prepare(
        `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
         FROM orders o
         JOIN stores s ON s.id = o.store_id
         ORDER BY o.created_at DESC
         LIMIT 150`
      )
      .all() as Record<string, unknown>[];
    res.json({
      orders: attachOrderItems(rows, { role: req.user!.role, userId: req.user!.id }),
    });
  });

  app.patch('/api/admin/orders/:id/status', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const admin = req.user!;
    const orderId = sanitizeText(req.params.id, 60);
    const nextStatus = req.body?.status as OrderStatus;
    const reason = sanitizeText(req.body?.reason, 300);
    const restoreStockFlag = req.body?.restoreStock !== false;

    if (!VALID_ORDER_STATUSES.includes(nextStatus)) {
      res.status(400).json({ error: 'حالة الطلب غير صالحة.' });
      return;
    }
    const existing = db
      .prepare(
        `SELECT o.id, o.order_number, o.status, o.customer_id, o.store_id,
                s.name AS store_name, s.owner_id AS store_owner_id
         FROM orders o JOIN stores s ON s.id = o.store_id WHERE o.id = ?`
      )
      .get(orderId) as
      | {
          id: string;
          order_number: string;
          status: OrderStatus;
          customer_id: string;
          store_id: string;
          store_name: string;
          store_owner_id: string;
        }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'الطلب غير موجود.' });
      return;
    }

    const now = new Date().toISOString();
    const wasClosed = existing.status === 'cancelled' || existing.status === 'rejected';
    const closingNow = nextStatus === 'cancelled' || nextStatus === 'rejected';

    const tx = db.transaction(() => {
      if (closingNow) {
        db.prepare(
          `UPDATE orders
           SET status = ?, cancel_reason = ?, cancelled_by_id = ?, cancelled_by_name = ?, cancelled_by_role = 'super_admin', cancelled_at = ?, updated_at = ?
           WHERE id = ?`
        ).run(
          nextStatus,
          reason || 'إجراء من المدير العام',
          admin.id,
          admin.fullName,
          now,
          now,
          orderId
        );
      } else {
        db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?').run(
          nextStatus,
          now,
          orderId
        );
      }

      logOrderEvent({
        orderId,
        eventType:
          nextStatus === 'cancelled'
            ? 'cancelled'
            : nextStatus === 'rejected'
            ? 'rejected'
            : 'status_changed',
        actorId: admin.id,
        actorName: admin.fullName,
        actorRole: 'super_admin',
        reason: reason || `تحديث إداري إلى ${ORDER_STATUS_LABELS[nextStatus]}`,
        previousStatus: existing.status,
        newStatus: nextStatus,
      });

      if (!wasClosed && closingNow && restoreStockFlag) {
        const restored = restoreOrderStock(orderId);
        if (restored) {
          logOrderEvent({
            orderId,
            eventType: 'stock_restored',
            actorId: admin.id,
            actorName: admin.fullName,
            actorRole: 'super_admin',
            reason: 'إعادة الكمية إلى المخزون بقرار إداري',
            previousStatus: existing.status,
            newStatus: nextStatus,
          });
        }
      }
    });
    tx();

    // Notify both customer and store owner on admin order action
    createAndDispatchNotification({
      userId: existing.customer_id,
      storeId: existing.store_id,
      orderId,
      type: nextStatus === 'cancelled' ? 'order_cancelled' : 'order_updated',
      title: `تحديث إداري للطلب ${existing.order_number}`,
      body: `تم تحديث حالة طلبك من ${existing.store_name} إلى: ${ORDER_STATUS_LABELS[nextStatus]}${
        reason ? ` · السبب: ${reason}` : ''
      }`,
      targetView: 'orders',
    });

    createAndDispatchNotification({
      userId: existing.store_owner_id,
      storeId: existing.store_id,
      orderId,
      type: nextStatus === 'cancelled' ? 'order_cancelled' : 'order_updated',
      title: `تحديث إداري لطلب متجرك ${existing.order_number}`,
      body: `قامت الإدارة بتحديث حالة الطلب إلى: ${ORDER_STATUS_LABELS[nextStatus]}${
        reason ? ` · السبب: ${reason}` : ''
      }`,
      targetView: 'merchant',
    });

    const updated = db
      .prepare(
        `SELECT o.*, s.name AS store_name, s.phone AS store_phone, s.address AS store_address
         FROM orders o JOIN stores s ON s.id = o.store_id WHERE o.id = ?`
      )
      .get(orderId) as Record<string, unknown>;
    res.json({ order: attachOrderItems([updated])[0] });
  });

  // Super Admin: Platform-wide Notifications Monitoring & Direct Intervention
  app.get('/api/admin/notifications', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT n.*, u.full_name AS recipient_name, u.role AS recipient_role,
                s.name AS store_name, o.order_number AS order_number
         FROM notifications n
         JOIN users u ON u.id = n.user_id
         LEFT JOIN stores s ON s.id = n.store_id
         LEFT JOIN orders o ON o.id = n.order_id
         ORDER BY n.created_at DESC
         LIMIT 120`
      )
      .all() as Record<string, unknown>[];

    const notifications = rows.map((row) => ({
      id: String(row.id),
      userId: String(row.user_id),
      recipientName: String(row.recipient_name || ''),
      recipientRole: String(row.recipient_role || ''),
      storeId: row.store_id ? String(row.store_id) : null,
      storeName: row.store_name ? String(row.store_name) : undefined,
      orderId: row.order_id ? String(row.order_id) : null,
      orderNumber: row.order_number ? String(row.order_number) : undefined,
      type: String(row.type),
      title: String(row.title),
      body: String(row.body),
      targetView: String(row.target_view || 'notifications'),
      isRead: Boolean(row.is_read),
      createdAt: String(row.created_at),
    }));

    res.json({ notifications });
  });

  app.post('/api/admin/notifications/send', requireRole('super_admin'), (req, res) => {
    const userId = sanitizeText(req.body?.userId, 60);
    const title = sanitizeText(req.body?.title, 160);
    const body = sanitizeText(req.body?.body, 500);
    const orderId = sanitizeText(req.body?.orderId, 60) || null;
    const storeId = sanitizeText(req.body?.storeId, 60) || null;

    if (!userId || title.length < 2 || body.length < 2) {
      res.status(400).json({ error: 'يرجى تحديد المستلم وعنوان ومحتوى التنبيه الإداري.' });
      return;
    }

    const targetUser = db
      .prepare('SELECT id, role FROM users WHERE id = ?')
      .get(userId) as { id: string; role: UserRole } | undefined;
    if (!targetUser) {
      res.status(404).json({ error: 'المستخدم المستهدف غير موجود.' });
      return;
    }

    const created = createAndDispatchNotification({
      userId: targetUser.id,
      storeId,
      orderId,
      type: 'system',
      title,
      body,
      targetView:
        targetUser.role === 'merchant'
          ? 'merchant'
          : targetUser.role === 'courier'
          ? 'courier'
          : 'orders',
    });

    res.status(201).json({ notification: created });
  });

  // Super Admin: Couriers Management & Delivery History
  app.get('/api/admin/couriers', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT c.*, u.full_name, u.email, u.phone, u.is_active,
          (SELECT COUNT(*) FROM deliveries d WHERE d.courier_id = c.user_id AND d.status IN ('accepted', 'heading_to_store', 'picked_up', 'on_the_way')) AS active_deliveries_count
         FROM couriers c
         JOIN users u ON u.id = c.user_id
         ORDER BY CASE c.verification_status WHEN 'pending' THEN 0 WHEN 'verified' THEN 1 WHEN 'suspended' THEN 2 ELSE 3 END, c.created_at DESC`
      )
      .all() as Record<string, unknown>[];
    res.json({ couriers: rows.map(mapCourier) });
  });

  app.get('/api/admin/couriers/:id/deliveries', requireRole('super_admin'), (req, res) => {
    const idOrUserId = sanitizeText(req.params.id, 60);
    const courierRow = db
      .prepare('SELECT user_id FROM couriers WHERE id = ? OR user_id = ?')
      .get(idOrUserId, idOrUserId) as { user_id: string } | undefined;
    if (!courierRow) {
      res.status(404).json({ error: 'المندوب غير موجود.' });
      return;
    }

    const rows = db
      .prepare(
        `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
                o.customer_name, o.customer_phone,
                cu.full_name AS courier_name, cu.phone AS courier_phone,
                cp.vehicle_type AS courier_vehicle_type, cp.plate_number AS courier_plate_number
         FROM deliveries d
         JOIN orders o ON o.id = d.order_id
         JOIN stores s ON s.id = d.store_id
         LEFT JOIN users cu ON cu.id = d.courier_id
         LEFT JOIN couriers cp ON cp.user_id = d.courier_id
         WHERE d.courier_id = ?
         ORDER BY d.updated_at DESC
         LIMIT 100`
      )
      .all(courierRow.user_id) as Record<string, unknown>[];

    res.json({
      deliveries: rows.map((row) => mapDelivery(row, { includeOtp: true, includeEvents: true })),
    });
  });

  app.patch('/api/admin/couriers/:id', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const courierId = sanitizeText(req.params.id, 60);
    const existing = db
      .prepare('SELECT * FROM couriers WHERE id = ? OR user_id = ?')
      .get(courierId, courierId) as Record<string, unknown> | undefined;

    if (!existing) {
      res.status(404).json({ error: 'المندوب غير موجود.' });
      return;
    }

    const nextStatus =
      req.body?.verificationStatus && VALID_COURIER_STATUSES.includes(req.body.verificationStatus)
        ? (req.body.verificationStatus as CourierVerificationStatus)
        : (existing.verification_status as CourierVerificationStatus);
    const rejectionReason =
      nextStatus === 'rejected' || nextStatus === 'suspended'
        ? sanitizeText(req.body?.rejectionReason ?? existing.rejection_reason, 300)
        : '';
    const now = new Date().toISOString();

    if (nextStatus === 'suspended' || nextStatus === 'rejected') {
      db.prepare(
        `UPDATE couriers
         SET verification_status = ?, rejection_reason = ?, is_available = 0, latitude = NULL, longitude = NULL, location_updated_at = '', updated_at = ?
         WHERE id = ?`
      ).run(nextStatus, rejectionReason, now, String(existing.id));
    } else {
      db.prepare(
        `UPDATE couriers
         SET verification_status = ?, rejection_reason = '', updated_at = ?
         WHERE id = ?`
      ).run(nextStatus, now, String(existing.id));
    }

    const updatedCourier = getOwnedCourier(String(existing.user_id));
    if (updatedCourier && existing.verification_status !== nextStatus) {
      createAndDispatchNotification({
        userId: updatedCourier.userId,
        storeId: null,
        orderId: null,
        type: 'courier_status',
        title: `تحديث حالة حساب المندوب: ${COURIER_STATUS_LABELS[nextStatus]}`,
        body:
          nextStatus === 'verified'
            ? 'تهانينا! تم توثيق حسابك كمندوب توصيل في سوقنا — يمكنك الآن تفعيل حالة (متاح للعمل) واستقبال طلبات التوصيل.'
            : `أصبحت حالة حسابك كمندوب: ${COURIER_STATUS_LABELS[nextStatus]}${
                rejectionReason ? ` · السبب: ${rejectionReason}` : ''
              }`,
        targetView: 'courier',
      });
    }

    if (updatedCourier && req.user) {
      logAdminAction({
        admin: req.user,
        actionType: 'courier_updated',
        targetType: 'courier',
        targetId: updatedCourier.id,
        targetLabel: updatedCourier.fullName,
        details: `حالة التوثيق: ${COURIER_STATUS_LABELS[nextStatus]}${
          rejectionReason ? ` · السبب: ${rejectionReason}` : ''
        }`,
      });
    }

    res.json({ courier: updatedCourier });
  });

  // Super Admin: All Deliveries Monitoring & Intervention
  app.get('/api/admin/deliveries', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
                o.customer_name, o.customer_phone,
                cu.full_name AS courier_name, cu.phone AS courier_phone,
                cp.vehicle_type AS courier_vehicle_type, cp.plate_number AS courier_plate_number
         FROM deliveries d
         JOIN orders o ON o.id = d.order_id
         JOIN stores s ON s.id = d.store_id
         LEFT JOIN users cu ON cu.id = d.courier_id
         LEFT JOIN couriers cp ON cp.user_id = d.courier_id
         ORDER BY d.updated_at DESC
         LIMIT 150`
      )
      .all() as Record<string, unknown>[];
    res.json({
      deliveries: rows.map((row) => mapDelivery(row, { includeOtp: true, includeEvents: true })),
    });
  });

  app.patch('/api/admin/deliveries/:id/cancel', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const admin = req.user!;
    const deliveryId = sanitizeText(req.params.id, 60);
    const reason = sanitizeText(req.body?.reason, 300) || 'تم إلغاء التوصيل بقرار إداري';
    const existing = db
      .prepare(
        `SELECT d.*, s.owner_id AS store_owner_id, s.name AS store_name, o.order_number
         FROM deliveries d JOIN stores s ON s.id = d.store_id JOIN orders o ON o.id = d.order_id
         WHERE d.id = ?`
      )
      .get(deliveryId) as Record<string, unknown> | undefined;

    if (!existing) {
      res.status(404).json({ error: 'سجل التوصيل غير موجود.' });
      return;
    }

    const now = new Date().toISOString();
    db.prepare(
      `UPDATE deliveries SET status = 'cancelled', cancel_reason = ?, cancelled_at = ?, updated_at = ? WHERE id = ?`
    ).run(reason, now, now, deliveryId);

    logDeliveryEvent({
      deliveryId,
      eventType: 'cancelled',
      actorId: admin.id,
      actorName: admin.fullName,
      actorRole: 'super_admin',
      notes: reason,
      previousStatus: String(existing.status),
      newStatus: 'cancelled',
    });

    if (existing.courier_id) {
      createAndDispatchNotification({
        userId: String(existing.courier_id),
        storeId: String(existing.store_id),
        orderId: String(existing.order_id),
        type: 'delivery_cancelled',
        title: `إلغاء إداري للتوصيل ${String(existing.delivery_number)}`,
        body: `تم إلغاء توصيل الطلب ${String(existing.order_number)} من الإدارة · السبب: ${reason}`,
        targetView: 'courier',
      });
    }

    const updated = db
      .prepare(
        `SELECT d.*, o.order_number, s.name AS store_name, s.phone AS store_phone, s.address AS store_address,
                o.customer_name, o.customer_phone,
                cu.full_name AS courier_name, cu.phone AS courier_phone,
                cp.vehicle_type AS courier_vehicle_type, cp.plate_number AS courier_plate_number
         FROM deliveries d
         JOIN orders o ON o.id = d.order_id
         JOIN stores s ON s.id = d.store_id
         LEFT JOIN users cu ON cu.id = d.courier_id
         LEFT JOIN couriers cp ON cp.user_id = d.courier_id
         WHERE d.id = ?`
      )
      .get(deliveryId) as Record<string, unknown>;
    res.json({ delivery: mapDelivery(updated, { includeOtp: true, includeEvents: true }) });
  });

  // Super Admin: Complaints & Technical Support Tickets (with full conversation threads)
  app.get('/api/admin/complaints', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT c.*, u.full_name AS reporter_name, u.phone AS reporter_phone, o.order_number
         FROM complaints c
         JOIN users u ON u.id = c.reporter_id
         LEFT JOIN orders o ON o.id = c.order_id
         ORDER BY CASE c.status WHEN 'open' THEN 0 WHEN 'under_review' THEN 1 WHEN 'replied' THEN 2 ELSE 3 END, c.updated_at DESC
         LIMIT 200`
      )
      .all() as Record<string, unknown>[];
    res.json({ complaints: attachComplaintMessages(rows) });
  });

  app.patch('/api/admin/complaints/:id', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const admin = req.user!;
    const complaintId = sanitizeText(req.params.id, 60);
    const existing = db.prepare('SELECT * FROM complaints WHERE id = ?').get(complaintId) as
      | Record<string, unknown>
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'الشكوى غير موجودة.' });
      return;
    }

    const replyMessage = sanitizeText(req.body?.replyMessage, 1500);
    const replyImageUrl = sanitizeImageUrl(req.body?.replyImageUrl);

    const nextStatus =
      req.body?.status && VALID_COMPLAINT_STATUSES.includes(req.body.status)
        ? (req.body.status as ComplaintStatus)
        : replyMessage
        ? 'replied'
        : (existing.status as ComplaintStatus);
    const violationRecorded =
      typeof req.body?.violationRecorded === 'boolean'
        ? req.body.violationRecorded
          ? 1
          : 0
        : Number(existing.violation_recorded);
    const adminNotes =
      req.body?.adminNotes !== undefined
        ? sanitizeText(req.body.adminNotes, 500)
        : String(existing.admin_notes || '');
    const suspendTarget = req.body?.suspendTarget === true;
    const now = new Date().toISOString();

    db.prepare(
      `UPDATE complaints
       SET status = ?, violation_recorded = ?, admin_notes = ?, resolved_by_id = ?, updated_at = ?
       WHERE id = ?`
    ).run(nextStatus, violationRecorded, adminNotes, admin.id, now, complaintId);

    if (replyMessage || replyImageUrl) {
      db.prepare(
        `INSERT INTO complaint_messages (id, complaint_id, sender_id, sender_name, sender_role, message, image_url, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        generateId('cmsg'),
        complaintId,
        admin.id,
        admin.fullName,
        admin.role,
        replyMessage || 'صورة مرفقة من الدعم الفني',
        replyImageUrl,
        now
      );
    }

    // Optional one-click suspension of violating store, courier, or user account
    if (suspendTarget) {
      const tType = String(existing.target_type) as ComplaintTargetType;
      const tId = String(existing.target_id);
      if (tType === 'store') {
        db.prepare("UPDATE stores SET status = 'suspended', rejection_reason = ? WHERE id = ?").run(
          adminNotes || 'تم إيقاف المتجر بناءً على شكوى ومخالفة مسجلة',
          tId
        );
      } else if (tType === 'courier') {
        db.prepare(
          "UPDATE couriers SET verification_status = 'suspended', rejection_reason = ?, is_available = 0, latitude = NULL, longitude = NULL, updated_at = ? WHERE id = ? OR user_id = ?"
        ).run(adminNotes || 'تم إيقاف المندوب بناءً على شكوى ومخالفة مسجلة', now, tId, tId);
      } else if (tType === 'user') {
        db.prepare('UPDATE users SET is_active = 0 WHERE id = ? AND role != ?').run(tId, 'super_admin');
        db.prepare('DELETE FROM sessions WHERE user_id = ?').run(tId);
      }
    }

    logAdminAction({
      admin,
      actionType: 'complaint_updated',
      targetType: 'complaint',
      targetId: complaintId,
      targetLabel: String(existing.category || complaintId),
      details: `الحالة: ${COMPLAINT_STATUS_LABELS[nextStatus]}${
        violationRecorded ? ' · مخالفة مسجلة' : ''
      }${suspendTarget ? ' · تم إيقاف الحساب المعني' : ''}${
        replyMessage ? ` · الرد: ${replyMessage.slice(0, 120)}` : ''
      }`,
    });

    createAndDispatchNotification({
      userId: String(existing.reporter_id),
      storeId: null,
      orderId: existing.order_id ? String(existing.order_id) : null,
      type: 'complaint_reply',
      title: `تحديث على تذكرتك: ${String(existing.category)}`,
      body: replyMessage
        ? replyMessage.slice(0, 150)
        : `أصبحت حالة التذكرة الآن: ${COMPLAINT_STATUS_LABELS[nextStatus]}${
            adminNotes ? ` · ${adminNotes.slice(0, 100)}` : ''
          }`,
      targetView: 'support',
    });

    const updated = db
      .prepare(
        `SELECT c.*, u.full_name AS reporter_name, u.phone AS reporter_phone, o.order_number
         FROM complaints c
         JOIN users u ON u.id = c.reporter_id
         LEFT JOIN orders o ON o.id = c.order_id
         WHERE c.id = ?`
      )
      .get(complaintId) as Record<string, unknown>;

    res.json({ complaint: attachComplaintMessages([updated])[0] });
  });

  // Super Admin: Unified Subscriptions Management (Merchants & Couriers + Plans + Payment Proofs + Ledger)
  app.get('/api/admin/subscriptions/all', requireRole('super_admin'), (_req, res) => {
    const subscriptions = getAllAdminSubscriptions();
    const stats = getSubscriptionSummaryStats();
    const logs = getRecentSubscriptionLogs(120);
    const plans = getSubscriptionPlans();
    const paymentMethods = getPaymentMethodsConfig();
    const paymentRequests = getAllAdminPaymentRequests(150);
    res.json({ subscriptions, stats, logs, plans, paymentMethods, paymentRequests });
  });

  app.patch('/api/admin/subscriptions/plans', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const updated = updateSubscriptionPlansAndMethods({
      admin: req.user!,
      plans: Array.isArray(req.body?.plans) ? req.body.plans : undefined,
      paymentMethods:
        req.body?.paymentMethods && typeof req.body.paymentMethods === 'object'
          ? req.body.paymentMethods
          : undefined,
    });
    res.json(updated);
  });

  app.post(
    '/api/admin/subscriptions/payment-requests/:requestId/review',
    requireRole('super_admin'),
    (req: AuthedRequest, res) => {
      const requestId = sanitizeText(req.params.requestId, 60);
      const decision =
        req.body?.decision === 'approve'
          ? 'approve'
          : req.body?.decision === 'reject'
          ? 'reject'
          : null;
      if (!decision) {
        res.status(400).json({ error: 'يرجى اختيار قرار صحيح (قبول أو رفض).' });
        return;
      }

      const result = reviewSubscriptionPaymentRequest({
        admin: req.user!,
        requestId,
        decision,
        rejectionReason: typeof req.body?.rejectionReason === 'string' ? req.body.rejectionReason : '',
        adminNotes: typeof req.body?.adminNotes === 'string' ? req.body.adminNotes : '',
        startsAt: typeof req.body?.startsAt === 'string' ? req.body.startsAt : undefined,
        expiresAt: typeof req.body?.expiresAt === 'string' ? req.body.expiresAt : undefined,
        currency: getPlatformSetting('currency', 'د.ع'),
      });

      if (result.ok === false) {
        res.status(result.status).json({ error: result.error });
        return;
      }

      res.json({
        request: result.request,
        subscription: result.subscription,
        stats: getSubscriptionSummaryStats(),
        logs: getRecentSubscriptionLogs(120),
        paymentRequests: getAllAdminPaymentRequests(150),
      });
    }
  );

  app.post(
    '/api/admin/subscriptions/notify-expiring',
    requireRole('super_admin'),
    (req: AuthedRequest, res) => {
      const targetUserId = sanitizeText(req.body?.userId, 60) || undefined;
      const result = sendExpiringSubscriptionReminders({
        admin: req.user!,
        targetUserId,
      });
      res.json({
        ok: true,
        notifiedCount: result.notifiedCount,
        message:
          result.notifiedCount > 0
            ? `تم إرسال ${result.notifiedCount} إشعار تذكير بتجديد الاشتراك بنجاح.`
            : 'لا توجد حسابات قريبة من الانتهاء أو منتهية لإرسال التذكير حالياً.',
      });
    }
  );

  app.post(
    '/api/admin/subscriptions/user/:userId/action',
    requireRole('super_admin'),
    (req: AuthedRequest, res) => {
      const targetUserId = sanitizeText(req.params.userId, 60);
      const action = req.body?.action as AdminSubscriptionActionPayload['action'];
      const validActions: AdminSubscriptionActionPayload['action'][] = [
        'activate',
        'extend',
        'suspend',
        'reactivate',
        'record_payment',
        'set_dates',
      ];
      if (!validActions.includes(action)) {
        res.status(400).json({ error: 'إجراء الاشتراك المطلوب غير صالح.' });
        return;
      }

      const result = applyAdminSubscriptionAction({
        admin: req.user!,
        targetUserId,
        currency: getPlatformSetting('currency', 'د.ع'),
        payload: {
          action,
          durationDays: req.body?.durationDays !== undefined ? Number(req.body.durationDays) : undefined,
          amountPaid: req.body?.amountPaid !== undefined ? Number(req.body.amountPaid) : undefined,
          monthlyFee: req.body?.monthlyFee !== undefined ? Number(req.body.monthlyFee) : undefined,
          planName: typeof req.body?.planName === 'string' ? req.body.planName : undefined,
          startsAt: typeof req.body?.startsAt === 'string' ? req.body.startsAt : undefined,
          expiresAt: typeof req.body?.expiresAt === 'string' ? req.body.expiresAt : undefined,
          notes: typeof req.body?.notes === 'string' ? req.body.notes : undefined,
        },
      });

      if (result.ok === false) {
        res.status(result.status).json({ error: result.error });
        return;
      }

      res.json({
        subscription: result.subscription,
        stats: getSubscriptionSummaryStats(),
        logs: getRecentSubscriptionLogs(120),
      });
    }
  );

  // Super Admin: Account Recovery Requests & Secure One-Time Reset Link/Code Issuance
  app.get('/api/admin/recovery-requests', requireRole('super_admin'), (_req, res) => {
    res.json({ requests: getAllAccountRecoveryRequests(150) });
  });

  app.post(
    '/api/admin/recovery-requests/:requestId/review',
    requireRole('super_admin'),
    (req: AuthedRequest, res) => {
      const requestId = sanitizeText(req.params.requestId, 60);
      const decision =
        req.body?.decision === 'approve'
          ? 'approve'
          : req.body?.decision === 'reject'
          ? 'reject'
          : null;
      if (!decision) {
        res.status(400).json({ error: 'يرجى تحديد قرار صحيح (موافقة أو رفض).' });
        return;
      }

      const result = reviewAccountRecoveryRequest({
        admin: req.user!,
        requestId,
        decision,
        targetUserId: typeof req.body?.targetUserId === 'string' ? req.body.targetUserId : undefined,
        rejectionReason: typeof req.body?.rejectionReason === 'string' ? req.body.rejectionReason : '',
        adminNotes: typeof req.body?.adminNotes === 'string' ? req.body.adminNotes : '',
      });

      if (result.ok === false) {
        res.status(result.status).json({ error: result.error });
        return;
      }

      res.json({
        request: result.request,
        issuedReset: result.issuedReset,
      });
    }
  );

  app.post(
    '/api/admin/users/:userId/issue-reset',
    requireRole('super_admin'),
    (req: AuthedRequest, res) => {
      const targetUserId = sanitizeText(req.params.userId, 60);
      const notes = typeof req.body?.notes === 'string' ? req.body.notes : '';
      const result = issueOneTimePasswordResetForUser({
        admin: req.user!,
        targetUserId,
        notes,
      });
      if (result.ok === false) {
        res.status(result.status).json({ error: result.error });
        return;
      }
      res.json({ issuedReset: result.issued });
    }
  );

  // Super Admin: Audit Logs
  app.get('/api/admin/audit-logs', requireRole('super_admin'), (_req, res) => {
    res.json({ logs: getAdminAuditLogs(150) });
  });

  // Super Admin: Legacy Store Subscriptions Management (preserved for compatibility)
  app.get('/api/admin/subscriptions', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT s.id AS store_id, s.name AS store_name, s.status AS store_status, u.full_name AS owner_name,
                COALESCE(sub.plan_name, 'free') AS plan_name,
                COALESCE(sub.status, 'active') AS status,
                COALESCE(sub.monthly_fee, 0) AS monthly_fee,
                COALESCE(sub.expires_at, '') AS expires_at,
                COALESCE(sub.notes, '') AS notes,
                COALESCE(sub.updated_at, s.created_at) AS updated_at
         FROM stores s
         JOIN users u ON u.id = s.owner_id
         LEFT JOIN store_subscriptions sub ON sub.store_id = s.id
         ORDER BY s.created_at DESC`
      )
      .all() as Record<string, unknown>[];
    res.json({ subscriptions: rows.map(mapSubscription) });
  });

  app.patch('/api/admin/subscriptions/:storeId', requireRole('super_admin'), (req: AuthedRequest, res) => {
    const storeId = sanitizeText(req.params.storeId, 60);
    const storeExists = db.prepare('SELECT id, name, owner_id FROM stores WHERE id = ?').get(storeId) as
      | { id: string; name: string; owner_id: string }
      | undefined;
    if (!storeExists) {
      res.status(404).json({ error: 'المتجر غير موجود.' });
      return;
    }

    const planName = VALID_STORE_PLANS.includes(req.body?.planName)
      ? (req.body.planName as StorePlanName)
      : 'free';
    const status = VALID_SUBSCRIPTION_STATUSES.includes(req.body?.status)
      ? (req.body.status as StoreSubscriptionStatus)
      : 'active';
    const monthlyFee = Math.max(0, Number(req.body?.monthlyFee) || 0);
    const expiresAt = sanitizeText(req.body?.expiresAt, 40);
    const notes = sanitizeText(req.body?.notes, 300);
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO store_subscriptions (store_id, plan_name, status, monthly_fee, expires_at, notes, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(store_id) DO UPDATE SET
         plan_name = excluded.plan_name,
         status = excluded.status,
         monthly_fee = excluded.monthly_fee,
         expires_at = excluded.expires_at,
         notes = excluded.notes,
         updated_at = excluded.updated_at`
    ).run(storeId, planName, status, monthlyFee, expiresAt, notes, now);

    // Sync unified user_subscriptions record as well
    ensureUserSubscription(storeExists.owner_id, 'merchant', storeId);
    if (expiresAt) {
      db.prepare(
        `UPDATE user_subscriptions
         SET plan_name = ?, status = ?, monthly_fee = ?, expires_at = ?, notes = ?, updated_at = ?
         WHERE user_id = ?`
      ).run(planName, status, monthlyFee, expiresAt, notes, now, storeExists.owner_id);
    } else {
      db.prepare(
        `UPDATE user_subscriptions
         SET plan_name = ?, status = ?, monthly_fee = ?, notes = ?, updated_at = ?
         WHERE user_id = ?`
      ).run(planName, status, monthlyFee, notes, now, storeExists.owner_id);
    }

    const updated = db
      .prepare(
        `SELECT s.id AS store_id, s.name AS store_name, s.status AS store_status, u.full_name AS owner_name,
                sub.plan_name, sub.status, sub.monthly_fee, sub.expires_at, sub.notes, sub.updated_at
         FROM stores s
         JOIN users u ON u.id = s.owner_id
         JOIN store_subscriptions sub ON sub.store_id = s.id
         WHERE s.id = ?`
      )
      .get(storeId) as Record<string, unknown>;

    res.json({ subscription: mapSubscription(updated) });
  });

  // Super Admin: Store Posts Moderation (list, hide/restore with reason, permanently delete)
  app.get('/api/admin/posts', requireRole('super_admin'), (_req, res) => {
    const rows = db
      .prepare(
        `SELECT sp.*, s.name AS store_name, s.store_type AS store_type, s.city AS store_city,
                s.district AS store_district, s.logo_url AS store_logo_url, s.status AS store_status,
                u.full_name AS author_name
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         JOIN users u ON u.id = sp.author_id
         ORDER BY sp.created_at DESC
         LIMIT 250`
      )
      .all() as Record<string, unknown>[];
    res.json({ posts: rows.map(mapStorePost) });
  });

  app.patch('/api/admin/posts/:id', requireRole('super_admin'), (req, res) => {
    const postId = sanitizeText(req.params.id, 60);
    const existing = db
      .prepare(
        `SELECT sp.*, s.owner_id, s.name AS store_name
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         WHERE sp.id = ?`
      )
      .get(postId) as Record<string, unknown> | undefined;
    if (!existing) {
      res.status(404).json({ error: 'المنشور غير موجود.' });
      return;
    }

    const nextStatus = VALID_POST_STATUSES.includes(req.body?.status)
      ? (req.body.status as StorePostStatus)
      : (existing.status as StorePostStatus);
    const moderationReason =
      nextStatus === 'hidden'
        ? sanitizeText(req.body?.moderationReason, 300) || 'مخالفة شروط النشر في سوقنا'
        : '';

    const now = new Date().toISOString();
    db.prepare(
      'UPDATE store_posts SET status = ?, moderation_reason = ?, updated_at = ? WHERE id = ?'
    ).run(nextStatus, moderationReason, now, postId);

    const ownerId = String(existing.owner_id);
    const storeId = String(existing.store_id);
    const postTitle = String(existing.title || '');
    if (nextStatus === 'hidden') {
      createAndDispatchNotification({
        userId: ownerId,
        storeId,
        orderId: null,
        type: 'store_status',
        title: `تم إخفاء منشور في متجر ${String(existing.store_name || '')}`,
        body: `تم إخفاء المنشور "${postTitle}" بواسطة الإدارة. السبب: ${moderationReason}`,
        targetView: 'merchant',
      });
    } else if (existing.status === 'hidden' && nextStatus === 'active') {
      createAndDispatchNotification({
        userId: ownerId,
        storeId,
        orderId: null,
        type: 'store_status',
        title: `تم إعادة تفعيل منشور في متجر ${String(existing.store_name || '')}`,
        body: `أصبح المنشور "${postTitle}" ظاهراً مجدداً لزبائن المتجر.`,
        targetView: 'merchant',
      });
    }

    const updated = db
      .prepare(
        `SELECT sp.*, s.name AS store_name, s.store_type AS store_type, s.city AS store_city,
                s.district AS store_district, s.logo_url AS store_logo_url, s.status AS store_status,
                u.full_name AS author_name
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         JOIN users u ON u.id = sp.author_id
         WHERE sp.id = ?`
      )
      .get(postId) as Record<string, unknown>;

    res.json({ post: mapStorePost(updated) });
  });

  app.delete('/api/admin/posts/:id', requireRole('super_admin'), (req, res) => {
    const postId = sanitizeText(req.params.id, 60);
    const existing = db
      .prepare(
        `SELECT sp.id, sp.title, sp.store_id, s.owner_id, s.name AS store_name
         FROM store_posts sp
         JOIN stores s ON s.id = sp.store_id
         WHERE sp.id = ?`
      )
      .get(postId) as
      | { id: string; title: string; store_id: string; owner_id: string; store_name: string }
      | undefined;
    if (!existing) {
      res.status(404).json({ error: 'المنشور غير موجود.' });
      return;
    }

    const reason = sanitizeText(req.body?.reason, 240);
    db.prepare('DELETE FROM store_posts WHERE id = ?').run(postId);

    createAndDispatchNotification({
      userId: existing.owner_id,
      storeId: existing.store_id,
      orderId: null,
      type: 'store_status',
      title: `تم حذف منشور مخالف من متجر ${existing.store_name}`,
      body: reason
        ? `قامت الإدارة بحذف المنشور "${existing.title}". السبب: ${reason}`
        : `قامت الإدارة بحذف المنشور "${existing.title}" لمخالفته سياسات النشر.`,
      targetView: 'merchant',
    });

    res.json({ ok: true });
  });

  // Super Admin only: download the pre-built SOUQNA-Android-Ready.zip archive if present in the workspace
  app.get('/api/admin/download-project-zip', requireRole('super_admin'), (_req, res) => {
    const projectRoot = path.resolve(process.cwd());
    const archiveFilename = 'SOUQNA-Android-Ready.zip';
    const archivePath = path.resolve(projectRoot, archiveFilename);

    if (!archivePath.startsWith(projectRoot + path.sep) || !fs.existsSync(archivePath)) {
      res.status(404).json({ error: 'ملف الأرشيف غير متوفر في هذه البيئة.' });
      return;
    }

    let stat: fs.Stats;
    try {
      stat = fs.statSync(archivePath);
    } catch {
      res.status(404).json({ error: 'تعذر قراءة ملف الأرشيف.' });
      return;
    }
    if (!stat.isFile()) {
      res.status(404).json({ error: 'ملف الأرشيف غير صالح.' });
      return;
    }

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${archiveFilename}"`);
    res.setHeader('Content-Length', String(stat.size));
    res.setHeader('X-Content-Type-Options', 'nosniff');

    const stream = fs.createReadStream(archivePath);
    stream.on('error', () => {
      if (!res.headersSent) {
        res.status(500).json({ error: 'حدث خطأ أثناء تنزيل ملف الأرشيف.' });
      } else {
        res.end();
      }
    });
    stream.pipe(res);
  });

  // Catch-all for unknown API routes
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'المسار غير موجود.' });
  });

  // Frontend serving (Vite dev middleware or built dist/)
  const distDir = path.resolve(process.cwd(), 'dist');
  const isProd =
    process.env.NODE_ENV === 'production' ||
    (!process.env.NODE_ENV && !process.env.NGINX_PORT && fs.existsSync(distDir));
  const disableHmr = process.env.DISABLE_HMR === 'true';
  let viteServer: { close: () => Promise<void> } | null = null;

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const devVite = await createViteServer({
      optimizeDeps: {
        entries: ['index.html'],
      },
      server: {
        middlewareMode: true,
        hmr: !disableHmr,
        ...(disableHmr ? { ws: false as const } : {}),
        watch: disableHmr
          ? null
          : {
              ignored: [
                '**/android/**',
                '**/dist/**',
                '**/dev-dist/**',
                '**/data/**',
                '**/uploads/**',
                '**/private_uploads/**',
                '**/private_payment_proofs/**',
              ],
            },
      },
      appType: 'spa',
    });
    viteServer = devVite;
    app.use(devVite.middlewares);
  } else if (fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const readCliArg = (flag: string): string | undefined => {
    const args = process.argv.slice(2);
    for (let i = 0; i < args.length; i += 1) {
      const arg = args[i];
      if (arg === flag && args[i + 1]) return args[i + 1];
      if (arg.startsWith(`${flag}=`)) return arg.slice(flag.length + 1);
    }
    return undefined;
  };

  const cliPort = Number(readCliArg('--port') ?? readCliArg('-p'));
  const envPort = Number(process.env.PORT);
  const nginxPort = Number(process.env.NGINX_PORT || 8080);
  const defaultDevPort = Number(process.env.DEFAULT_APP_PORT) || 3000;

  let port = defaultDevPort;
  if (Number.isInteger(cliPort) && cliPort > 0) {
    port = cliPort;
  } else if (isProd && Number.isInteger(envPort) && envPort > 0) {
    port = envPort;
  } else if (!isProd && Number.isInteger(envPort) && envPort > 0 && envPort !== nginxPort) {
    port = envPort;
  }

  const host = readCliArg('--host') || '0.0.0.0';
  const httpServer = app.listen(port, host, () => {
    console.log(`SOUQNA server listening on http://${host}:${port}`);
  });

  const shutdown = async () => {
    try {
      await viteServer?.close();
    } catch {
      // ignore close errors during shutdown
    }
    httpServer.close(() => {
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 1500).unref();
  };

  process.once('SIGTERM', () => {
    void shutdown();
  });
  process.once('SIGINT', () => {
    void shutdown();
  });
}

startServer().catch((err) => {
  console.error('Failed to start SOUQNA server:', err);
  process.exit(1);
});
