import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Box, Loader2, Package, Search, SlidersHorizontal } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import {
  ALL_STORE_TYPES,
  PRODUCT_CATEGORIES,
  STORE_SUBCATEGORIES,
  STORE_TYPE_LABELS,
  type MarketplaceCategory,
  type Product,
  type StoreType,
} from '../types';

type ProductSort = 'newest' | 'price_asc' | 'price_desc';

export const ProductsCatalogView: React.FC = () => {
  const { user, ownedStore, bootstrapStatus, openStore, addToCart, navigate } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [dynamicCategories, setDynamicCategories] = useState<MarketplaceCategory[]>([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [storeType, setStoreType] = useState<'all' | StoreType>('all');
  const [cartonOnly, setCartonOnly] = useState(false);
  const [sortBy, setSortBy] = useState<ProductSort>('newest');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    api
      .getCategories()
      .then((res) => {
        if (active && Array.isArray(res.categories)) {
          setDynamicCategories(res.categories);
        }
      })
      .catch(() => {
        // Fallback to default static categories if request fails
      });
    return () => {
      active = false;
    };
  }, []);

  const visibleCategories = useMemo(() => {
    if (dynamicCategories.length > 0) {
      const matched = dynamicCategories
        .filter((c) => storeType === 'all' || c.storeType === 'all' || c.storeType === storeType)
        .map((c) => c.name);
      if (storeType === 'all') {
        return Array.from(new Set(matched));
      }
      return Array.from(new Set([...matched, ...(STORE_SUBCATEGORIES[storeType] || [])]));
    }
    return storeType === 'all' ? PRODUCT_CATEGORIES : STORE_SUBCATEGORIES[storeType];
  }, [dynamicCategories, storeType]);

  useEffect(() => {
    if (category !== 'all' && !visibleCategories.includes(category)) {
      setCategory('all');
    }
  }, [category, visibleCategories]);

  const loadSeqRef = useRef(0);

  const loadProducts = useCallback(async () => {
    const seq = ++loadSeqRef.current;
    setLoading(true);
    setError(null);
    try {
      const res = await api.getProducts({
        search: search.trim(),
        category,
        storeType,
        cartonOnly,
      });
      if (seq !== loadSeqRef.current) return;
      setProducts(Array.isArray(res?.products) ? res.products : []);
    } catch (err) {
      if (seq !== loadSeqRef.current) return;
      setError(err instanceof Error ? err.message : 'تعذر تحميل المنتجات.');
    } finally {
      if (seq === loadSeqRef.current) {
        setLoading(false);
      }
    }
  }, [search, category, storeType, cartonOnly]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadProducts();
    }, 280);
    return () => window.clearTimeout(timer);
  }, [loadProducts, user?.id]);

  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        void loadProducts();
      }
    };
    const onOnline = () => {
      void loadProducts();
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', onOnline);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', onOnline);
    };
  }, [loadProducts]);

  const sortedProducts = useMemo(() => {
    const copy = [...products];
    if (sortBy === 'price_asc') {
      copy.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price_desc') {
      copy.sort((a, b) => b.price - a.price);
    } else {
      copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    }
    return copy;
  }, [products, sortBy]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold text-sq-gold-text">البيع بالمفرد والكارتون · نقداً فقط</p>
          <h1 className="mt-1 font-display text-2xl sm:text-3xl font-extrabold text-sq-ink">
            المنتجات والأسعار وسعر الكارتون
          </h1>
          <p className="mt-1 text-sm text-sq-ink-muted">
            قارن الأسعار بالمفرد وسعر الكارتون عبر جميع المحلات والأسواق والمواد الإنشائية والملابس
            وإكسسوارات الهواتف وباقات الألعاب
          </p>
        </div>

        <div className="text-xs font-semibold text-sq-ink-muted tabular-nums">
          {loading ? 'جاري التحميل...' : `${sortedProducts.length} منتج متوفر`}
        </div>
      </div>

      {/* Filters Bar */}
      <div className="rounded-2xl border border-sq-border bg-sq-surface p-4 sm:p-5 space-y-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
          <div className="relative md:col-span-5">
            <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث عن منتج، موديل هاتف، لعبة، أو اسم متجر..."
              className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated pr-10 pl-4 text-sm text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>

          <div className="md:col-span-3">
            <select
              value={storeType}
              onChange={(e) => setStoreType(e.target.value as 'all' | StoreType)}
              aria-label="تصفية حسب نوع المتجر"
              className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs sm:text-sm font-medium text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            >
              <option value="all">كل أنواع المتاجر والأنشطة</option>
              {ALL_STORE_TYPES.map((type) => (
                <option key={type} value={type}>
                  {STORE_TYPE_LABELS[type]}
                </option>
              ))}
            </select>
          </div>

          <div className="relative md:col-span-2">
            <SlidersHorizontal className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as ProductSort)}
              aria-label="ترتيب المنتجات"
              className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated pr-9 pl-2 text-xs sm:text-sm font-medium text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            >
              <option value="newest">الأحدث</option>
              <option value="price_asc">الأقل سعراً</option>
              <option value="price_desc">الأعلى سعراً</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <button
              type="button"
              onClick={() => setCartonOnly((prev) => !prev)}
              className={`flex min-h-[46px] w-full items-center justify-center gap-1.5 rounded-xl border px-3 text-xs font-semibold transition-colors whitespace-nowrap ${
                cartonOnly
                  ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                  : 'border-sq-border bg-sq-elevated text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              <Box className="h-4 w-4 shrink-0" />
              <span>بسعر الكارتون</span>
            </button>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
          <button
            type="button"
            onClick={() => setCategory('all')}
            className={`min-h-[40px] rounded-xl px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
              category === 'all'
                ? 'bg-sq-gold text-[#0B0C0C]'
                : 'border border-sq-border bg-sq-elevated text-sq-ink-muted hover:text-sq-ink'
            }`}
          >
            جميع الأقسام
          </button>
          {visibleCategories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategory(cat)}
              className={`min-h-[40px] rounded-xl px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                category === cat
                  ? 'bg-sq-gold text-[#0B0C0C]'
                  : 'border border-sq-border bg-sq-elevated text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      {loading ? (
        <div className="flex min-h-[240px] items-center justify-center gap-2 rounded-2xl border border-sq-border bg-sq-surface text-sm text-sq-ink-muted">
          <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
          <span>جاري تحميل المنتجات والأسعار...</span>
        </div>
      ) : error ? (
        <div className="rounded-2xl border border-sq-danger-border bg-sq-danger-bg p-6 text-center">
          <p className="text-sm font-semibold text-sq-danger-text">{error}</p>
          <button
            type="button"
            onClick={loadProducts}
            className="mt-3 min-h-[44px] rounded-xl bg-[#B42318] px-4 py-2 text-xs font-semibold text-white"
          >
            إعادة المحاولة
          </button>
        </div>
      ) : sortedProducts.length === 0 ? (
        <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
          <Package className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/60" />
          <h2 className="font-display text-lg font-bold text-sq-ink">
            {search || category !== 'all' || storeType !== 'all' || cartonOnly
              ? 'لا توجد منتجات مطابقة للفلتر المحدد'
              : 'لم يتم إضافة منتجات بعد'}
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-sq-ink-muted">
            {search || category !== 'all' || storeType !== 'all' || cartonOnly
              ? 'جرّب تغيير البحث أو إلغاء فلتر الكارتون لعرض جميع المنتجات المتوفرة.'
              : 'جميع المنتجات تُعرض مباشرة من قاعدة البيانات فور إضافتها من أصحاب المتاجر بصورها وأسعارها وخياراتها.'}
          </p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
            {(search || category !== 'all' || storeType !== 'all' || cartonOnly) && (
              <button
                type="button"
                onClick={() => {
                  setSearch('');
                  setCategory('all');
                  setStoreType('all');
                  setCartonOnly(false);
                }}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-elevated px-4 py-2 text-sm font-semibold text-sq-ink"
              >
                عرض كل المنتجات
              </button>
            )}
            {user?.role === 'merchant' && (
              <button
                type="button"
                onClick={() => navigate('merchant')}
                className="min-h-[44px] rounded-xl btn-gold px-5 py-2 text-sm font-semibold"
              >
                إضافة منتجات إلى متجري
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {sortedProducts.map((product) => {
            const isOwn = ownedStore?.id === product.storeId;
            return (
              <ProductCard
                key={product.id}
                product={product}
                currency={bootstrapStatus.currency}
                disableAdd={isOwn}
                disableReason={isOwn ? 'منتج من متجرك الخاص' : undefined}
                onOpenStore={() => openStore(product.storeId)}
                onAdd={(pricingType, selectedOptions) =>
                  addToCart(
                    product,
                    {
                      id: product.storeId,
                      name: product.storeName || 'متجر',
                      deliveryFee: product.storeDeliveryFee || 0,
                      address: product.storeAddress,
                    },
                    pricingType,
                    selectedOptions
                  )
                }
              />
            );
          })}
        </div>
      )}
    </div>
  );
};
