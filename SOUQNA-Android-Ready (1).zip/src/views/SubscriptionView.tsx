import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  Clock,
  Copy,
  CreditCard,
  Crown,
  ExternalLink,
  Headphones,
  History,
  Loader2,
  MessageCircle,
  Receipt,
  RefreshCw,
  Send,
  ShieldCheck,
  Sparkles,
  Upload,
  Wallet,
  XCircle,
} from 'lucide-react';
import { PrivatePaymentProofImage } from '../components/PrivatePaymentProofImage';
import { useApp } from '../context/AppContext';
import { api, compressImageFile, formatDateAr, formatPrice } from '../lib/api';
import {
  DEFAULT_PAYMENT_METHODS,
  PAYMENT_METHOD_LABELS,
  PAYMENT_REQUEST_STATUS_LABELS,
  SUBSCRIPTION_ACTION_LABELS,
  SUBSCRIPTION_PLAN_LABELS,
  SUBSCRIPTION_STATUS_LABELS,
  SUPPORT_CONTACTS,
  type PaymentMethodCode,
  type SubscriptionLog,
  type SubscriptionPaymentMethodsConfig,
  type SubscriptionPaymentRequest,
  type SubscriptionPlan,
  type UserSubscription,
} from '../types';

export const SubscriptionView: React.FC = () => {
  const { user, ownedStore, bootstrapStatus, navigate, notify, refreshMySubscription } = useApp();

  const [subscription, setSubscription] = useState<UserSubscription | null>(null);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [paymentMethods, setPaymentMethods] =
    useState<SubscriptionPaymentMethodsConfig>(DEFAULT_PAYMENT_METHODS);
  const [paymentRequests, setPaymentRequests] = useState<SubscriptionPaymentRequest[]>([]);
  const [logs, setLogs] = useState<SubscriptionLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Payment submission form state
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethodCode>('zaincash');
  const [transferReference, setTransferReference] = useState('');
  const [transferDetails, setTransferDetails] = useState('');
  const [proofPreview, setProofPreview] = useState<string>('');
  const [compressing, setCompressing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const loadSubscription = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await api.getMySubscription();
      setSubscription(res.subscription);
      setPlans(res.plans || []);
      setPaymentMethods(res.paymentMethods || DEFAULT_PAYMENT_METHODS);
      setPaymentRequests(res.paymentRequests || []);
      setLogs(res.subscription?.logs || []);
      if (res.plans && res.plans.length > 0) {
        setSelectedPlanId((prev) =>
          prev && res.plans.some((p) => p.id === prev) ? prev : res.plans[0].id
        );
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحميل بيانات الاشتراك.', 'error');
    } finally {
      setLoading(false);
    }
  }, [user, notify]);

  useEffect(() => {
    void loadSubscription();
  }, [loadSubscription]);

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      notify(`تم نسخ رقم ${label}: ${text}`, 'success');
    } catch {
      notify(`رقم ${label}: ${text}`, 'info');
    }
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-lg rounded-3xl border border-sq-border bg-sq-surface p-8 text-center space-y-4">
        <Crown className="mx-auto h-11 w-11 text-sq-gold-text" />
        <h1 className="font-display text-xl font-extrabold text-sq-ink">
          نظام الاشتراكات لأصحاب المتاجر والمندوبين
        </h1>
        <p className="text-sm text-sq-ink-muted">
          سجّل دخولك بحسابك كصاحب متجر أو مندوب توصيل لعرض حالة اشتراكك والباقات المتاحة ورفع إثبات
          التحويل. أما الزبائن فاستخدام التطبيق لهم مجاني بالكامل دائماً.
        </p>
        <button
          type="button"
          onClick={() => navigate('auth')}
          className="min-h-[46px] rounded-xl btn-gold px-6 text-sm font-bold"
        >
          تسجيل الدخول
        </button>
      </div>
    );
  }

  // Customers are 100% free forever
  if (user.role === 'customer') {
    return (
      <div className="mx-auto max-w-2xl space-y-5">
        <div className="relative overflow-hidden rounded-3xl border border-sq-gold/45 bg-[#0C0E0D] p-7 sm:p-9 text-center text-white shadow-xl">
          <div className="pointer-events-none absolute -top-20 left-1/2 h-56 w-56 -translate-x-1/2 rounded-full bg-[#D4AF37]/15 blur-3xl" />
          <div className="relative space-y-4">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-[#D4AF37]/50 bg-[#151817] text-[#E8CB73]">
              <Sparkles className="h-7 w-7" />
            </div>
            <h1 className="font-display text-2xl font-extrabold text-white">
              حساب الزبون مجاني 100% مدى الحياة
            </h1>
            <p className="mx-auto max-w-lg text-sm leading-relaxed text-[#CFC8B8]">
              لا يتطلب حساب الزبون أي اشتراك مدفوع على الإطلاق. يمكنك تصفح جميع المحلات والأسواق
              والمولات وإرسال طلباتك النقدية بحرية كاملة ومجاناً دائماً.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => navigate('stores')}
                className="min-h-[46px] rounded-xl btn-gold px-6 text-sm font-bold"
              >
                تصفح المتاجر والأسواق
              </button>
              <button
                type="button"
                onClick={() => navigate('support')}
                className="inline-flex min-h-[46px] items-center gap-2 rounded-xl border border-[#D4AF37]/40 bg-[#171A18] px-5 text-sm font-semibold text-white hover:border-[#D4AF37]"
              >
                <Headphones className="h-4 w-4 text-[#E8CB73]" />
                <span>الدعم الفني</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (user.role === 'super_admin') {
    return (
      <div className="mx-auto max-w-lg rounded-3xl border border-sq-gold-hairline bg-sq-surface p-8 text-center space-y-4">
        <ShieldCheck className="mx-auto h-11 w-11 text-sq-gold-text" />
        <h1 className="font-display text-xl font-extrabold text-sq-ink">
          حساب المدير الرئيسي (Super Admin)
        </h1>
        <p className="text-sm text-sq-ink-muted">
          يمكنك مراجعة طلبات الاشتراك وصور إثبات التحويل وتعديل أسعار الباقات وتفعيل أو تمديد
          الاشتراكات من تبويب «الاشتراكات» داخل لوحة المدير العام.
        </p>
        <button
          type="button"
          onClick={() => navigate('admin')}
          className="min-h-[46px] rounded-xl btn-gold px-6 text-sm font-bold"
        >
          فتح لوحة المدير العام
        </button>
      </div>
    );
  }

  const handleSelectProofFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCompressing(true);
    try {
      const dataUrl = await compressImageFile(file, 1400);
      setProofPreview(dataUrl);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر قراءة صورة إثبات التحويل.', 'error');
    } finally {
      setCompressing(false);
      e.target.value = '';
    }
  };

  const handleSubmitPaymentRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlanId) {
      notify('يرجى اختيار باقة الاشتراك المطلوبة.', 'error');
      return;
    }
    if (!proofPreview) {
      notify('يرجى رفع صورة واضحة لإثبات التحويل المالي قبل الإرسال.', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.submitSubscriptionPaymentRequest({
        planId: selectedPlanId,
        paymentMethod,
        transferReference: transferReference.trim(),
        transferDetails: transferDetails.trim(),
        paymentProofDataUrl: proofPreview,
      });
      setSubscription(res.subscription);
      setPaymentRequests(res.paymentRequests || []);
      setLogs(res.subscription?.logs || []);
      setTransferReference('');
      setTransferDetails('');
      setProofPreview('');
      await refreshMySubscription();
      notify(res.message, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال طلب الاشتراك.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const currency = bootstrapStatus.currency || 'د.ع';
  const selectedPlan = plans.find((p) => p.id === selectedPlanId) || plans[0] || null;
  const progressPct = subscription
    ? subscription.status === 'expired' || subscription.status === 'suspended'
      ? 0
      : Math.max(4, Math.min(100, Math.round((subscription.daysRemaining / 30) * 100)))
    : 0;
  const hasPendingRequest = paymentRequests.some((r) => r.status === 'pending');

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-bold text-sq-gold-text">
            {user.role === 'merchant'
              ? `اشتراك صاحب المتجر${ownedStore ? ` · ${ownedStore.name}` : ''}`
              : 'اشتراك مندوب التوصيل'}
          </p>
          <h1 className="mt-0.5 font-display text-2xl sm:text-3xl font-extrabold text-sq-ink">
            الاشتراك وتجديد الباقة
          </h1>
        </div>
        <button
          type="button"
          onClick={() => void loadSubscription()}
          disabled={loading}
          className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-sq-border bg-sq-surface px-4 text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
        >
          <RefreshCw className={`h-4 w-4 text-sq-gold-text ${loading ? 'animate-spin' : ''}`} />
          <span>تحديث الحالة</span>
        </button>
      </div>

      {loading ? (
        <div className="flex min-h-[200px] items-center justify-center gap-2 rounded-3xl border border-sq-border bg-sq-surface text-sm text-sq-ink-muted">
          <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
          <span>جاري تحميل تفاصيل الاشتراك والباقات...</span>
        </div>
      ) : subscription ? (
        <>
          {/* Expired / Suspended Alert */}
          {(subscription.status === 'expired' || subscription.status === 'suspended') && (
            <div className="rounded-2xl border border-sq-danger-border bg-sq-danger-bg p-5 text-sq-danger-text space-y-2">
              <div className="flex items-start gap-3">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
                <div className="space-y-1">
                  <h2 className="font-display text-base font-extrabold">
                    {subscription.status === 'suspended'
                      ? 'تم إيقاف اشتراكك مؤقتاً من قِبل الإدارة'
                      : 'انتهت مدة اشتراكك — جدّد اشتراكك للاستمرار'}
                  </h2>
                  <p className="text-xs sm:text-sm leading-relaxed">
                    {user.role === 'merchant'
                      ? 'تم إيقاف الميزات التجارية فقط (إضافة منتجات، نشر عروض، وظهور المتجر للطلبات الجديدة). جميع بيانات متجرك ومنتجاتك وصورك وطلباتك محفوظة بالكامل ولن يُحذف أي شيء، وتعود للعمل فوراً بعد موافقة الإدارة على طلب التجديد.'
                      : 'تم إيقاف ميزات استقبال التوصيلات مؤقتاً. جميع بيانات حسابك وسجل توصيلاتك محفوظة بالكامل وتعود للعمل فوراً بعد موافقة الإدارة على طلب التجديد.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {subscription.isExpiringSoon && (
            <div className="rounded-2xl border border-sq-warning-border bg-sq-warning-bg p-4 text-sq-warning-text">
              <div className="flex items-start gap-2.5">
                <Clock className="mt-0.5 h-5 w-5 shrink-0" />
                <div className="text-xs sm:text-sm leading-relaxed">
                  <strong>تنبيه قرب انتهاء الاشتراك:</strong> متبقي{' '}
                  <strong className="font-mono">{subscription.daysRemaining}</strong> يوم على انتهاء
                  اشتراكك ({formatDateAr(subscription.expiresAt)}). اختر باقتك وأرسل إثبات التحويل
                  أدناه لضمان استمرار العمل دون انقطاع.
                </div>
              </div>
            </div>
          )}

          {/* Luxury Subscription Status Card */}
          <section className="relative overflow-hidden rounded-3xl border border-sq-gold-hairline bg-[#0C0E0D] p-6 sm:p-8 text-white shadow-xl">
            <div className="pointer-events-none absolute -top-24 -left-16 h-60 w-60 rounded-full bg-[#D4AF37]/15 blur-3xl" />
            <div className="relative space-y-6">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-[#D4AF37]/50 bg-[#151817] text-[#E8CB73]">
                    <Crown className="h-7 w-7" />
                  </div>
                  <div>
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-0.5 text-xs font-bold ${
                        subscription.status === 'active'
                          ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300'
                          : subscription.status === 'trial'
                          ? 'border-[#D4AF37]/50 bg-[#D4AF37]/15 text-[#E8CB73]'
                          : 'border-red-500/45 bg-red-500/15 text-red-300'
                      }`}
                    >
                      <span>حالة الاشتراك: {SUBSCRIPTION_STATUS_LABELS[subscription.status]}</span>
                    </span>
                    <h2 className="mt-1.5 font-display text-xl sm:text-2xl font-extrabold text-white">
                      {SUBSCRIPTION_PLAN_LABELS[subscription.planName] || subscription.planName}
                    </h2>
                  </div>
                </div>

                <div className="rounded-2xl border border-[#D4AF37]/35 bg-[#151817] px-5 py-3 text-center">
                  <p className="text-[11px] text-[#CFC8B8]">المدة المتبقية</p>
                  <p className="mt-0.5 font-mono text-3xl font-extrabold text-[#E8CB73] tabular-nums">
                    {subscription.daysRemaining}
                  </p>
                  <p className="text-[11px] font-semibold text-[#CFC8B8]">يوم</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/10">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      subscription.status === 'expired' || subscription.status === 'suspended'
                        ? 'bg-red-500'
                        : subscription.isExpiringSoon
                        ? 'bg-amber-400'
                        : 'bg-gradient-to-l from-[#E8CB73] to-[#C89B2B]'
                    }`}
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
                <div className="grid grid-cols-1 gap-3 pt-2 sm:grid-cols-3 text-xs">
                  <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                    <p className="text-[#B8B09E]">تاريخ بداية الاشتراك</p>
                    <p className="mt-1 font-bold text-white">{formatDateAr(subscription.startsAt)}</p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                    <p className="text-[#B8B09E]">تاريخ انتهاء الاشتراك</p>
                    <p className="mt-1 font-bold text-[#E8CB73]">
                      {formatDateAr(subscription.expiresAt)}
                    </p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                    <p className="text-[#B8B09E]">إجمالي المدفوعات المؤكدة</p>
                    <p className="mt-1 font-mono font-bold text-white tabular-nums">
                      {formatPrice(subscription.totalPaid, currency)}
                    </p>
                  </div>
                </div>
              </div>

              {subscription.notes && (
                <div className="rounded-xl border border-[#D4AF37]/30 bg-[#161918] p-3.5 text-xs text-[#E8E2D4]">
                  <strong className="text-[#E8CB73]">ملاحظة الإدارة: </strong>
                  {subscription.notes}
                </div>
              )}
            </div>
          </section>

          {/* Subscription Plans & Payment Proof Submission */}
          <section className="rounded-3xl border border-sq-gold-hairline bg-sq-surface p-5 sm:p-6 space-y-6">
            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-sq-border pb-4">
              <div>
                <h2 className="font-display text-lg sm:text-xl font-extrabold text-sq-ink">
                  اختر باقة الاشتراك وأرسل إثبات التحويل
                </h2>
                <p className="mt-1 text-xs leading-relaxed text-sq-ink-muted">
                  اختر المدة المناسبة، حوّل المبلغ عبر زين كاش أو ماستر كارد، ثم ارفع صورة واضحة
                  لإثبات التحويل. سيتم تفعيل اشتراكك فور مراجعة وموافقة المدير الرئيسي.
                </p>
              </div>
              {hasPendingRequest && (
                <span className="inline-flex items-center gap-1.5 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3 py-1.5 text-xs font-bold text-sq-warning-text">
                  <Clock className="h-4 w-4" />
                  <span>لديك طلب اشتراك قيد المراجعة</span>
                </span>
              )}
            </div>

            <form onSubmit={handleSubmitPaymentRequest} className="space-y-6">
              {/* Step 1: Choose Subscription Plan */}
              <div className="space-y-2.5">
                <label className="block text-xs font-extrabold text-sq-gold-text">
                  1. اختر مدة الاشتراك
                </label>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  {plans.map((plan) => {
                    const active = selectedPlan?.id === plan.id;
                    return (
                      <button
                        key={plan.id}
                        type="button"
                        onClick={() => setSelectedPlanId(plan.id)}
                        className={`relative flex flex-col items-start justify-between rounded-2xl border p-4 text-right transition-all ${
                          active
                            ? 'border-sq-gold bg-sq-gold-soft shadow-md'
                            : 'border-sq-border bg-sq-elevated hover:border-sq-gold/50'
                        }`}
                      >
                        <div className="flex w-full items-center justify-between">
                          <span className="font-display text-sm font-extrabold text-sq-ink">
                            {plan.name}
                          </span>
                          {active && <CheckCircle2 className="h-4 w-4 text-sq-gold-text shrink-0" />}
                        </div>
                        <div className="mt-3">
                          <p className="font-mono text-xl font-extrabold text-sq-gold-text tabular-nums">
                            {formatPrice(plan.priceIqd, currency)}
                          </p>
                          <p className="mt-0.5 text-[11px] text-sq-ink-muted">
                            المدة: {plan.durationDays} يوماً
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Payment Methods */}
              <div className="space-y-2.5">
                <label className="block text-xs font-extrabold text-sq-gold-text">
                  2. وسائل الدفع الرسمية (حوّل المبلغ ثم اختر الوسيلة المستخدمة)
                </label>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {/* ZainCash Card */}
                  <div
                    onClick={() => setPaymentMethod('zaincash')}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') setPaymentMethod('zaincash');
                    }}
                    className={`cursor-pointer rounded-2xl border p-4 transition-all ${
                      paymentMethod === 'zaincash'
                        ? 'border-sq-gold bg-sq-gold-soft'
                        : 'border-sq-border bg-sq-elevated hover:border-sq-gold/50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sq-gold text-[#0B0C0C]">
                          <Wallet className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="font-display text-sm font-extrabold text-sq-ink">
                            زين كاش (ZainCash)
                          </div>
                          <div className="text-[11px] text-sq-ink-muted">تحويل فوري عبر المحفظة</div>
                        </div>
                      </div>
                      {paymentMethod === 'zaincash' && (
                        <CheckCircle2 className="h-5 w-5 text-sq-gold-text shrink-0" />
                      )}
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-2 rounded-xl border border-sq-border bg-sq-surface px-3 py-2">
                      <span dir="ltr" className="font-mono text-base font-extrabold text-sq-ink">
                        {paymentMethods.zaincashNumber}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          void copyToClipboard(paymentMethods.zaincashNumber, 'زين كاش');
                        }}
                        className="inline-flex items-center gap-1 rounded-lg bg-sq-gold-soft px-2.5 py-1 text-[11px] font-bold text-sq-gold-text hover:bg-sq-gold hover:text-black"
                      >
                        <Copy className="h-3.5 w-3.5" />
                        <span>نسخ</span>
                      </button>
                    </div>
                  </div>

                  {/* MasterCard Card */}
                  <div
                    onClick={() => setPaymentMethod('mastercard')}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') setPaymentMethod('mastercard');
                    }}
                    className={`cursor-pointer rounded-2xl border p-4 transition-all ${
                      paymentMethod === 'mastercard'
                        ? 'border-sq-gold bg-sq-gold-soft'
                        : 'border-sq-border bg-sq-elevated hover:border-sq-gold/50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sq-gold text-[#0B0C0C]">
                          <CreditCard className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="font-display text-sm font-extrabold text-sq-ink">
                            ماستر كارد (MasterCard)
                          </div>
                          <div className="text-[11px] text-sq-ink-muted">تحويل إلى رقم البطاقة</div>
                        </div>
                      </div>
                      {paymentMethod === 'mastercard' && (
                        <CheckCircle2 className="h-5 w-5 text-sq-gold-text shrink-0" />
                      )}
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-2 rounded-xl border border-sq-border bg-sq-surface px-3 py-2">
                      <span dir="ltr" className="font-mono text-base font-extrabold text-sq-ink">
                        {paymentMethods.mastercardNumber}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          void copyToClipboard(paymentMethods.mastercardNumber, 'ماستر كارد');
                        }}
                        className="inline-flex items-center gap-1 rounded-lg bg-sq-gold-soft px-2.5 py-1 text-[11px] font-bold text-sq-gold-text hover:bg-sq-gold hover:text-black"
                      >
                        <Copy className="h-3.5 w-3.5" />
                        <span>نسخ</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Selected Summary Strip */}
              {selectedPlan && (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-sq-gold/35 bg-sq-gold-soft/45 px-4 py-3 text-xs">
                  <span className="font-semibold text-sq-ink">
                    الباقة المختارة: <strong>{selectedPlan.name}</strong> ({selectedPlan.durationDays}{' '}
                    يوم) · عبر <strong>{PAYMENT_METHOD_LABELS[paymentMethod]}</strong>
                  </span>
                  <span className="font-mono text-base font-extrabold text-sq-gold-text">
                    المبلغ المطلوب: {formatPrice(selectedPlan.priceIqd, currency)}
                  </span>
                </div>
              )}

              {/* Step 3: Upload Payment Proof & Transfer Details */}
              <div className="space-y-4">
                <label className="block text-xs font-extrabold text-sq-gold-text">
                  3. رفع صورة إثبات التحويل وتفاصيل العملية
                </label>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleSelectProofFile}
                  className="hidden"
                />

                {proofPreview ? (
                  <div className="rounded-2xl border border-sq-gold/45 bg-sq-elevated p-3 space-y-3">
                    <img
                      src={proofPreview}
                      alt="معاينة إثبات التحويل"
                      className="mx-auto max-h-64 rounded-xl object-contain"
                    />
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-4 text-xs font-bold text-sq-ink"
                      >
                        <Camera className="h-4 w-4 text-sq-gold-text" />
                        <span>تغيير الصورة</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setProofPreview('')}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 text-xs font-bold text-sq-danger-text"
                      >
                        <XCircle className="h-4 w-4" />
                        <span>إزالة</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={compressing}
                    onClick={() => fileInputRef.current?.click()}
                    className="flex w-full flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-sq-gold/45 bg-sq-elevated px-4 py-8 text-center transition-colors hover:border-sq-gold hover:bg-sq-gold-soft/30"
                  >
                    {compressing ? (
                      <Loader2 className="h-8 w-8 animate-spin text-sq-gold-text" />
                    ) : (
                      <Upload className="h-8 w-8 text-sq-gold-text" />
                    )}
                    <span className="font-display text-sm font-extrabold text-sq-ink">
                      {compressing
                        ? 'جاري تجهيز صورة الإثبات...'
                        : 'اضغط هنا لرفع صورة واضحة لإثبات التحويل (إلزامي)'}
                    </span>
                    <span className="text-[11px] text-sq-ink-muted">
                      تُحفظ الصورة في مخزن خاص ومشفّر لا يراه إلا أنت والمدير الرئيسي فقط
                    </span>
                  </button>
                )}

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                      رقم العملية / الحوالة (يُفضّل إدخاله لتسريع المراجعة)
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      value={transferReference}
                      onChange={(e) => setTransferReference(e.target.value)}
                      placeholder="مثال: ZC-84920194"
                      className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                      تفاصيل إضافية عن التحويل (اختياري)
                    </label>
                    <input
                      type="text"
                      value={transferDetails}
                      onChange={(e) => setTransferDetails(e.target.value)}
                      placeholder="مثال: رقم المحفظة المحوّل منها أو وقت التحويل"
                      className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 pt-1">
                <button
                  type="submit"
                  disabled={submitting || !proofPreview || !selectedPlan}
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl btn-gold px-6 text-sm font-bold disabled:opacity-55"
                >
                  {submitting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Crown className="h-4 w-4" />
                  )}
                  <span>إرسال طلب الاشتراك للمراجعة</span>
                </button>

                <a
                  href={SUPPORT_CONTACTS.telegramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-sq-gold/40 bg-sq-gold-soft px-4 text-xs font-bold text-sq-gold-text hover:border-sq-gold"
                >
                  <Send className="h-4 w-4" />
                  <span>تيليجرام (@{SUPPORT_CONTACTS.telegramHandle})</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>

                <a
                  href={SUPPORT_CONTACTS.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-sq-gold/40 bg-sq-gold-soft px-4 text-xs font-bold text-sq-gold-text hover:border-sq-gold"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>واتساب ({SUPPORT_CONTACTS.whatsappDisplay})</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </div>
            </form>
          </section>

          {/* My Submitted Subscription Payment Requests */}
          <section className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Receipt className="h-5 w-5 text-sq-gold-text" />
              <h2 className="font-display text-base font-extrabold text-sq-ink">
                طلبات الاشتراك المرسلة ({paymentRequests.length})
              </h2>
            </div>

            {paymentRequests.length === 0 ? (
              <p className="text-xs text-sq-ink-muted">
                لم ترسل أي طلب اشتراك مع إثبات تحويل بعد. عند إرسال طلب سيظهر هنا مع حالته (قيد
                المراجعة، مقبول، أو مرفوض).
              </p>
            ) : (
              <div className="space-y-3">
                {paymentRequests.map((reqItem) => (
                  <div
                    key={reqItem.id}
                    className="flex flex-wrap items-start justify-between gap-4 rounded-2xl border border-sq-border bg-sq-elevated p-4"
                  >
                    <div className="flex items-start gap-3.5 min-w-0 flex-1">
                      <PrivatePaymentProofImage
                        filename={reqItem.paymentProofDoc}
                        compact
                        alt={`إثبات تحويل ${reqItem.planName}`}
                      />
                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`rounded-lg border px-2.5 py-0.5 text-[11px] font-bold ${
                              reqItem.status === 'approved'
                                ? 'border-sq-success-border bg-sq-success-bg text-sq-success-text'
                                : reqItem.status === 'rejected'
                                ? 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
                                : 'border-sq-warning-border bg-sq-warning-bg text-sq-warning-text'
                            }`}
                          >
                            {PAYMENT_REQUEST_STATUS_LABELS[reqItem.status]}
                          </span>
                          <span className="font-display text-sm font-extrabold text-sq-ink">
                            {reqItem.planName}
                          </span>
                          <span className="font-mono text-xs font-bold text-sq-gold-text">
                            {formatPrice(reqItem.amountIqd, currency)}
                          </span>
                        </div>
                        <p className="text-xs text-sq-ink-muted">
                          وسيلة الدفع: {PAYMENT_METHOD_LABELS[reqItem.paymentMethod]}
                          {reqItem.transferReference
                            ? ` · رقم العملية: ${reqItem.transferReference}`
                            : ''}
                        </p>
                        {reqItem.transferDetails && (
                          <p className="text-xs text-sq-ink-muted">{reqItem.transferDetails}</p>
                        )}
                        {reqItem.status === 'rejected' && reqItem.rejectionReason && (
                          <div className="mt-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3 py-2 text-xs font-semibold text-sq-danger-text">
                            سبب الرفض: {reqItem.rejectionReason}
                          </div>
                        )}
                        {reqItem.status === 'approved' && reqItem.reviewedAt && (
                          <p className="text-[11px] font-semibold text-sq-success-text">
                            تمت الموافقة والتفعيل بتاريخ {formatDateAr(reqItem.reviewedAt)}
                          </p>
                        )}
                      </div>
                    </div>
                    <span className="text-[11px] text-sq-ink-muted shrink-0">
                      {formatDateAr(reqItem.createdAt)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Subscription History Ledger */}
          <section className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2">
              <History className="h-5 w-5 text-sq-gold-text" />
              <h2 className="font-display text-base font-extrabold text-sq-ink">
                سجل عمليات وتجديدات الاشتراك ({logs.length})
              </h2>
            </div>

            {logs.length === 0 ? (
              <p className="text-xs text-sq-ink-muted">لا توجد عمليات مسجلة بعد.</p>
            ) : (
              <div className="divide-y divide-sq-border">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="flex flex-wrap items-start justify-between gap-2 py-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-bold text-sq-gold-text">
                          {SUBSCRIPTION_ACTION_LABELS[log.actionType] || log.actionType}
                        </span>
                        {log.durationDays > 0 && (
                          <span className="rounded-md border border-sq-gold/30 bg-sq-gold-soft px-2 py-0.5 font-mono text-[11px] font-bold text-sq-gold-text">
                            +{log.durationDays} يوم
                          </span>
                        )}
                        {log.amountPaid > 0 && (
                          <span className="font-mono font-bold text-sq-ink tabular-nums">
                            {formatPrice(log.amountPaid, currency)}
                          </span>
                        )}
                      </div>
                      {log.notes && <p className="text-sq-ink-muted">{log.notes}</p>}
                      {log.newExpiresAt && (
                        <p className="text-[11px] text-sq-ink-muted">
                          تاريخ الانتهاء: {formatDateAr(log.newExpiresAt)}
                        </p>
                      )}
                    </div>
                    <span className="text-[11px] text-sq-ink-muted shrink-0">
                      {formatDateAr(log.createdAt)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>
        </>
      ) : null}
    </div>
  );
};
