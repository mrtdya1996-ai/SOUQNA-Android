import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Banknote,
  ChevronLeft,
  ChevronRight,
  Loader2,
  MapPin,
  Search,
  ShieldCheck,
  Store as StoreIcon,
  Truck,
} from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { SouqnaLogo } from '../components/SouqnaLogo';
import { StoreCard } from '../components/StoreCard';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import {
  FEATURED_NEW_CATEGORIES,
  LUXURY_BANNER_IMAGES,
  STORE_CATEGORY_META,
} from '../lib/storeCategories';
import {
  ALL_STORE_TYPES,
  STORE_TYPE_LABELS,
  type Product,
  type Store,
  type StoreType,
} from '../types';

interface HeroSlide {
  id: string;
  kicker: string;
  headline: string;
  subtitle: string;
  image: string;
  ctaLabel: string;
  ctaAction: 'stores' | 'products' | 'merchant';
}

const HERO_SLIDES: HeroSlide[] = [
  {
    id: 'luxury-mall',
    kicker: 'منصة التجارة العصرية · الأسواق والمولات والمحلات',
    headline: 'كل أسواق ومولات ومحلات مدينتك في واجهة فاخرة واحدة',
    subtitle:
      'تصفّح دليل المتاجر والأسواق الحقيقية، تابع عروضها ومنشوراتها اليومية، واطلب مباشرة بالدفع نقداً عند الاستلام.',
    image: LUXURY_BANNER_IMAGES.mall,
    ctaLabel: 'دخول دليل المتاجر والأسواق',
    ctaAction: 'stores',
  },
  {
    id: 'fresh-markets',
    kicker: 'الأسواق الغذائية · السوبر ماركت · الخضروات والفواكه',
    headline: 'تسوق بالمفرد والكارتون من أقرب سوق وسوبر ماركت في منطقتك',
    subtitle:
      'أسعار واضحة بالمفرد والكارتون، صور حقيقية للمنتجات، وتوصيل سريع أو استلام مباشر من المحل.',
    image: LUXURY_BANNER_IMAGES.market,
    ctaLabel: 'تصفح المنتجات وأسعار الكارتون',
    ctaAction: 'products',
  },
  {
    id: 'express-delivery',
    kicker: 'توصيل موثوق برمز أمان OTP · انضم كتاجر أو مندوب',
    headline: 'افتح متجرك الرقمي وشارك عروضك ومنشوراتك مع آلاف الزبائن',
    subtitle:
      'لوحة تحكم مستقلة لكل صاحب محل، نظام منشورات متعددة الصور، وشبكة مندوبين موثقين بإشراف كامل.',
    image: LUXURY_BANNER_IMAGES.delivery,
    ctaLabel: 'سجّل متجرك على سوقنا',
    ctaAction: 'merchant',
  },
];

const STORE_FILTERS: Array<{ id: 'all' | StoreType; label: string }> = [
  { id: 'all', label: 'جميع المتاجر' },
  ...ALL_STORE_TYPES.map((t) => ({ id: t, label: STORE_TYPE_LABELS[t] })),
];

export const HomeView: React.FC = () => {
  const {
    user,
    ownedStore,
    bootstrapStatus,
    navigate,
    openStore,
    openCategoryStores,
    addToCart,
  } = useApp();
  const [stores, setStores] = useState<Store[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');
  const [storeType, setStoreType] = useState<'all' | StoreType>('all');
  const [selectedCity, setSelectedCity] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSlide, setActiveSlide] = useState(0);
  const [pauseCarousel, setPauseCarousel] = useState(false);
  const loadSeqRef = useRef(0);

  const loadMarketplace = useCallback(async () => {
    const seq = ++loadSeqRef.current;
    setLoading(true);
    setError(null);
    try {
      const [storesResult, productsResult] = await Promise.allSettled([
        api.getStores({ search: search.trim(), type: storeType, city: selectedCity }),
        api.getProducts({
          search: search.trim(),
          storeType,
          city: selectedCity,
        }),
      ]);

      if (seq !== loadSeqRef.current) return;

      if (storesResult.status === 'fulfilled') {
        setStores(Array.isArray(storesResult.value?.stores) ? storesResult.value.stores : []);
        setCities(Array.isArray(storesResult.value?.cities) ? storesResult.value.cities : []);
      }
      if (productsResult.status === 'fulfilled') {
        setProducts(Array.isArray(productsResult.value?.products) ? productsResult.value.products : []);
      }

      if (storesResult.status === 'rejected' && productsResult.status === 'rejected') {
        const err = storesResult.reason;
        setError(err instanceof Error ? err.message : 'تعذر تحميل المتاجر حالياً.');
      }
    } catch (err) {
      if (seq !== loadSeqRef.current) return;
      setError(err instanceof Error ? err.message : 'تعذر تحميل المتاجر حالياً.');
    } finally {
      if (seq === loadSeqRef.current) {
        setLoading(false);
      }
    }
  }, [search, storeType, selectedCity]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadMarketplace();
    }, 280);
    return () => window.clearTimeout(timer);
  }, [loadMarketplace, user?.id]);

  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        void loadMarketplace();
      }
    };
    const onOnline = () => {
      void loadMarketplace();
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', onOnline);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', onOnline);
    };
  }, [loadMarketplace]);

  // Smooth auto-rotating luxury promotional banner carousel
  useEffect(() => {
    if (pauseCarousel) return;
    const interval = window.setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 6200);
    return () => window.clearInterval(interval);
  }, [pauseCarousel]);

  const currentSlide = HERO_SLIDES[activeSlide];

  const handleSlideCta = (action: HeroSlide['ctaAction']) => {
    if (action === 'stores') openCategoryStores('all');
    else if (action === 'products') navigate('products');
    else if (!user) navigate('auth');
    else if (user.role === 'merchant' || user.role === 'customer') navigate('merchant');
    else if (user.role === 'super_admin') navigate('admin');
    else navigate('courier');
  };

  return (
    <div className="space-y-10 md:space-y-14">
      {/* Section 1: Luxury Switchable Hero Banner Showcase */}
      <section
        onMouseEnter={() => setPauseCarousel(true)}
        onMouseLeave={() => setPauseCarousel(false)}
        className="relative overflow-hidden rounded-3xl border border-[#D4AF37]/30 bg-[#0B0C0C] text-white shadow-2xl"
      >
        {/* Background Slide Photography with Measured Obsidian Scrim */}
        <div className="relative min-h-[430px] sm:min-h-[470px] lg:min-h-[500px] flex flex-col justify-between p-5 sm:p-8 lg:p-10">
          {HERO_SLIDES.map((slide, idx) => (
            <img
              key={slide.id}
              src={slide.image}
              alt={slide.headline}
              referrerPolicy="no-referrer"
              className={`pointer-events-none absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${
                idx === activeSlide ? 'opacity-100' : 'opacity-0'
              }`}
            />
          ))}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 bg-gradient-to-l from-[#090A0A]/94 via-[#090A0A]/75 to-[#090A0A]/40"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#090A0A]/92 via-transparent to-[#090A0A]/35"
          />

          {/* Top Bar inside Hero: Emblem + Slide Arrows */}
          <div className="relative z-10 flex items-center justify-between gap-4">
            <div className="inline-flex items-center gap-3">
              <SouqnaLogo size="md" />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                aria-label="الإعلان السابق"
                onClick={() =>
                  setActiveSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length)
                }
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#D4AF37]/35 bg-black/50 text-[#E8CB73] backdrop-blur-sm transition hover:bg-black/75 active:scale-95"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
              <button
                type="button"
                aria-label="الإعلان التالي"
                onClick={() => setActiveSlide((prev) => (prev + 1) % HERO_SLIDES.length)}
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#D4AF37]/35 bg-black/50 text-[#E8CB73] backdrop-blur-sm transition hover:bg-black/75 active:scale-95"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Center Campaign Copy + Live Search + Primary Gold CTA */}
          <div className="relative z-10 my-auto max-w-2xl space-y-5 py-6">
            <p className="text-xs sm:text-sm font-semibold text-[#E8CB73]">
              {currentSlide.kicker}
            </p>

            <h1 className="font-display text-2xl sm:text-4xl lg:text-[42px] font-black leading-[1.18] text-white">
              {currentSlide.headline}
            </h1>

            <p className="max-w-xl text-sm sm:text-base leading-relaxed text-[#D8D2C5]">
              {currentSlide.subtitle}
            </p>

            {/* Quick Integrated Search Bar */}
            <div className="relative max-w-xl">
              <Search className="pointer-events-none absolute right-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#D4AF37]" />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="ابحث باسم متجر، مول، سوق، منطقة أو منتج..."
                className="min-h-[50px] w-full rounded-2xl border border-[#D4AF37]/35 bg-[#111312]/85 pr-11 pl-4 text-sm text-white placeholder:text-[#A8A194] backdrop-blur-md focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            {/* Single Primary Gold CTA + Quiet Secondary Links */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => handleSlideCta(currentSlide.ctaAction)}
                className="btn-gold inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl px-6 py-2.5 text-sm whitespace-nowrap"
              >
                <StoreIcon className="h-4 w-4" />
                <span>{currentSlide.ctaLabel}</span>
                <ArrowLeft className="h-4 w-4" />
              </button>

              {!user ? (
                <button
                  type="button"
                  onClick={() => navigate('auth')}
                  className="inline-flex min-h-[48px] items-center justify-center rounded-2xl border border-white/25 bg-white/10 px-5 py-2.5 text-sm font-bold text-white backdrop-blur-sm transition hover:bg-white/15 active:scale-[0.98] whitespace-nowrap"
                >
                  تسجيل الدخول / حساب جديد
                </button>
              ) : user.role === 'merchant' ? (
                <button
                  type="button"
                  onClick={() => navigate('merchant')}
                  className="inline-flex min-h-[48px] items-center justify-center rounded-2xl border border-[#D4AF37]/50 bg-[#D4AF37]/15 px-5 py-2.5 text-sm font-bold text-[#E8CB73] backdrop-blur-sm transition hover:bg-[#D4AF37]/25 active:scale-[0.98] whitespace-nowrap"
                >
                  {ownedStore ? 'إدارة متجري ومنشوراتي' : 'إنشاء متجري الآن'}
                </button>
              ) : user.role === 'super_admin' ? (
                <button
                  type="button"
                  onClick={() => navigate('admin')}
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl border border-[#D4AF37]/50 bg-[#D4AF37]/15 px-5 py-2.5 text-sm font-bold text-[#E8CB73] backdrop-blur-sm transition hover:bg-[#D4AF37]/25 active:scale-[0.98] whitespace-nowrap"
                >
                  <ShieldCheck className="h-4 w-4" />
                  <span>لوحة المدير العام</span>
                </button>
              ) : user.role === 'courier' ? (
                <button
                  type="button"
                  onClick={() => navigate('courier')}
                  className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl border border-[#D4AF37]/50 bg-[#D4AF37]/15 px-5 py-2.5 text-sm font-bold text-[#E8CB73] backdrop-blur-sm transition hover:bg-[#D4AF37]/25 active:scale-[0.98] whitespace-nowrap"
                >
                  <Truck className="h-4 w-4" />
                  <span>لوحة المندوب</span>
                </button>
              ) : null}
            </div>
          </div>

          {/* Bottom Strip: Payment Trust Note + Slide Indicator Bars */}
          <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-4">
            <div className="flex flex-wrap items-center gap-4 text-xs text-[#CFC9BC]">
              <span className="inline-flex items-center gap-1.5">
                <Banknote className="h-4 w-4 text-[#D4AF37]" />
                <span>الدفع نقداً عند الاستلام</span>
              </span>
              <span aria-hidden="true">·</span>
              <span>توصيل سريع أو استلام مباشر</span>
              <span aria-hidden="true">·</span>
              <span>11 قطاعاً تجارياً معتمداً</span>
            </div>

            <div className="flex items-center gap-2" role="tablist" aria-label="اختيار الشريحة الإعلانية">
              {HERO_SLIDES.map((s, idx) => (
                <button
                  key={s.id}
                  type="button"
                  role="tab"
                  aria-selected={idx === activeSlide}
                  aria-label={`شريحة ${idx + 1}`}
                  onClick={() => setActiveSlide(idx)}
                  className={`h-2 rounded-full transition-all ${
                    idx === activeSlide
                      ? 'w-9 bg-[#D4AF37]'
                      : 'w-2.5 bg-white/30 hover:bg-white/55'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Luxury Visual Categories Showcase */}
      <section className="space-y-5">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold text-sq-gold-text">تصفّح حسب القطاع</p>
            <h2 className="mt-1 font-display text-xl sm:text-2xl font-extrabold text-sq-ink">
              الأقسام والأنشطة التجارية في سوقنا
            </h2>
          </div>
          <button
            type="button"
            onClick={() => openCategoryStores('all')}
            className="inline-flex min-h-[40px] items-center gap-1.5 text-xs sm:text-sm font-bold text-sq-gold-text hover:underline whitespace-nowrap shrink-0"
          >
            <span>جميع التصنيفات (11)</span>
            <ArrowLeft className="h-4 w-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-4">
          {FEATURED_NEW_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.type}
                type="button"
                onClick={() => openCategoryStores(cat.type)}
                className="group relative flex flex-col overflow-hidden rounded-2xl border border-sq-border bg-sq-surface text-right transition-all duration-200 hover:-translate-y-0.5 hover:border-sq-gold/60 hover:shadow-lg active:scale-[0.985]"
              >
                <div className="relative aspect-4/3 w-full overflow-hidden bg-[#121413]">
                  <img
                    src={cat.imageUrl}
                    alt={cat.title}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.05]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#090A0A]/80 via-[#090A0A]/15 to-transparent" />
                  <div className="absolute top-2.5 right-2.5 flex h-9 w-9 items-center justify-center rounded-xl border border-[#D4AF37]/45 bg-[#0D0F0E]/85 text-[#E8CB73] backdrop-blur-sm">
                    <Icon className="h-4 w-4" />
                  </div>
                  <h3 className="absolute bottom-2.5 right-3 left-3 font-display text-sm sm:text-base font-extrabold text-white line-clamp-1">
                    {cat.title}
                  </h3>
                </div>
                <div className="p-3">
                  <p className="text-xs leading-relaxed text-sq-ink-muted line-clamp-2">
                    {cat.subtitle}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Section 3: Registered Stores & Markets Directory Preview */}
      <section className="space-y-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-bold text-sq-gold-text">دليل المتاجر المعتمد</p>
            <h2 className="mt-1 font-display text-xl sm:text-2xl font-extrabold text-sq-ink">
              المتاجر والأسواق والمولات المسجلة
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-sq-ink-muted">
              {stores.length > 0
                ? `يُعرض حالياً ${stores.length} متجر وسوق معتمد في سوقنا`
                : 'اختر التصنيف أو ابحث باسم السوق أو المول أو المنطقة'}
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {cities.length > 0 && (
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-sq-gold-text" />
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  aria-label="تصفية حسب المدينة"
                  className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
                >
                  <option value="all">جميع المحافظات</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <button
              type="button"
              onClick={() => openCategoryStores(storeType)}
              className="btn-surface inline-flex min-h-[44px] items-center gap-1.5 rounded-xl px-4 text-xs font-bold whitespace-nowrap"
            >
              <span>الدليل الكامل</span>
              <ArrowLeft className="h-3.5 w-3.5 text-sq-gold-text" />
            </button>
          </div>
        </div>

        {/* Interactive Store Type Segmented Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {STORE_FILTERS.map((filter) => {
            const active = storeType === filter.id;
            const Icon = filter.id !== 'all' ? STORE_CATEGORY_META[filter.id].icon : StoreIcon;
            return (
              <button
                key={filter.id}
                type="button"
                onClick={() => setStoreType(filter.id)}
                className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs sm:text-sm font-bold transition-all active:scale-95 whitespace-nowrap shrink-0 ${
                  active
                    ? 'btn-gold'
                    : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:border-sq-gold/50 hover:text-sq-ink'
                }`}
              >
                <Icon className="h-3.5 w-3.5 shrink-0" />
                <span>{filter.label}</span>
              </button>
            );
          })}
        </div>

        {loading ? (
          <div className="flex min-h-[220px] items-center justify-center gap-2 rounded-2xl border border-sq-border bg-sq-surface text-sm text-sq-ink-muted">
            <Loader2 className="h-5 w-5 animate-spin text-sq-gold" />
            <span>جاري تحميل المتاجر والأسواق...</span>
          </div>
        ) : error ? (
          <div className="rounded-2xl border border-sq-danger-border bg-sq-danger-bg p-6 text-center">
            <p className="text-sm font-semibold text-sq-danger-text">{error}</p>
            <button
              type="button"
              onClick={loadMarketplace}
              className="mt-3 min-h-[44px] rounded-xl bg-[#B42318] px-4 py-2 text-xs font-semibold text-white"
            >
              إعادة المحاولة
            </button>
          </div>
        ) : stores.length === 0 ? (
          <div className="rounded-3xl border border-sq-border bg-sq-surface p-8 sm:p-10 text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl border border-[#D4AF37]/40 bg-[#121413] text-[#E8CB73]">
              <StoreIcon className="h-7 w-7" />
            </div>
            <h3 className="font-display text-lg font-extrabold text-sq-ink">
              {search || storeType !== 'all' || selectedCity !== 'all'
                ? 'لا توجد متاجر مطابقة لخيارات البحث'
                : 'لم يتم تسجيل متاجر معتمدة بعد'}
            </h3>
            <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-sq-ink-muted">
              {search || storeType !== 'all' || selectedCity !== 'all'
                ? 'جرّب تعديل كلمة البحث أو اختيار جميع التصنيفات لعرض المتاجر المتاحة.'
                : 'تعمل منصة سوقنا ببيانات حقيقية فقط. سجّل حساب صاحب متجر وأطلق أول سوق أو مول أو محل تجاري في منطقتك.'}
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              {(search || storeType !== 'all' || selectedCity !== 'all') && (
                <button
                  type="button"
                  onClick={() => {
                    setSearch('');
                    setStoreType('all');
                    setSelectedCity('all');
                  }}
                  className="btn-surface min-h-[44px] rounded-xl px-4 py-2 text-sm font-bold"
                >
                  عرض جميع المتاجر
                </button>
              )}
              <button
                type="button"
                onClick={() =>
                  navigate(
                    !user
                      ? 'auth'
                      : user.role === 'merchant' || user.role === 'customer'
                      ? 'merchant'
                      : user.role === 'super_admin'
                      ? 'admin'
                      : 'courier'
                  )
                }
                className="btn-gold min-h-[44px] rounded-xl px-5 py-2 text-sm"
              >
                {user?.role === 'merchant'
                  ? 'افتح متجرك الآن'
                  : user?.role === 'customer'
                  ? 'افتح متجرك على نفس حسابك'
                  : 'سجّل كصاحب متجر وابدأ'}
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {stores.map((store) => (
              <StoreCard
                key={store.id}
                store={store}
                currency={bootstrapStatus.currency}
                isOwnStore={ownedStore?.id === store.id}
                onOpen={openStore}
              />
            ))}
          </div>
        )}
      </section>

      {/* Section 4: Latest Products Feed (only when real products exist) */}
      {products.length > 0 && (
        <section className="space-y-5">
          <div className="flex items-end justify-between gap-4">
            <div>
              <p className="text-xs font-bold text-sq-gold-text">تسوق مباشر</p>
              <h2 className="mt-1 font-display text-xl sm:text-2xl font-extrabold text-sq-ink">
                أحدث المنتجات وأسعار الكارتون
              </h2>
            </div>
            <button
              type="button"
              onClick={() => navigate('products')}
              className="inline-flex min-h-[40px] items-center gap-1.5 text-xs sm:text-sm font-bold text-sq-gold-text hover:underline whitespace-nowrap shrink-0"
            >
              <span>عرض كل المنتجات</span>
              <ArrowLeft className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {products.slice(0, 8).map((product) => {
              const isOwn = ownedStore?.id === product.storeId;
              return (
                <ProductCard
                  key={product.id}
                  product={product}
                  currency={bootstrapStatus.currency}
                  disableAdd={isOwn}
                  disableReason={isOwn ? 'منتج من متجرك الخاص' : undefined}
                  onOpenStore={() => openStore(product.storeId)}
                  onAdd={(pricingType, selectedOptions) =>
                    addToCart(
                      product,
                      {
                        id: product.storeId,
                        name: product.storeName || 'متجر',
                        deliveryFee: product.storeDeliveryFee || 0,
                        address: product.storeAddress,
                      },
                      pricingType,
                      selectedOptions
                    )
                  }
                />
              );
            })}
          </div>
        </section>
      )}

      {/* Section 5: Luxury Merchant & Courier Partner Callout */}
      <section className="overflow-hidden rounded-3xl border border-[#D4AF37]/30 bg-[#101211] text-white shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 lg:items-stretch">
          <div className="p-6 sm:p-9 lg:col-span-7 flex flex-col justify-center">
            <p className="text-xs font-bold text-[#E8CB73]">
              لأصحاب المحلات والأسواق والمولات ومندوبي التوصيل
            </p>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-black text-white leading-tight">
              واجهة فاخرة لمتجرك، منشورات وعروض يومية، ولوحة تحكم مستقلة بالكامل.
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-[#CFC9BC]">
              انضم إلى منصة سوقنا بأي نشاط تجاري، انشر صور عروضك ومنتجاتك بالمفرد والكارتون، استقبل الطلبات نقداً بإشعارات فورية، واطلب مندوب توصيل بضغطة زر.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() =>
                  navigate(
                    !user
                      ? 'auth'
                      : user.role === 'merchant' || user.role === 'customer'
                      ? 'merchant'
                      : user.role === 'super_admin'
                      ? 'admin'
                      : 'courier'
                  )
                }
                className="btn-gold inline-flex min-h-[46px] items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm"
              >
                <span>
                  {user?.role === 'merchant'
                    ? 'الانتقال إلى لوحة متجري'
                    : user?.role === 'customer'
                    ? 'افتح متجرك على حسابك الحالي'
                    : 'سجّل متجرك الآن'}
                </span>
                <ArrowLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => navigate('courier_register')}
                className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-[#D4AF37]/40 bg-white/5 px-5 py-2.5 text-sm font-bold text-[#E8CB73] hover:bg-white/10 active:scale-[0.98] transition"
              >
                <Truck className="h-4 w-4" />
                <span>انضم كمندوب توصيل</span>
              </button>
            </div>
          </div>

          <div className="relative min-h-[220px] bg-[#181B19] lg:col-span-5">
            <img
              src={LUXURY_BANNER_IMAGES.delivery}
              alt="شراكة أصحاب المحلات والمندوبين في سوقنا"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#101211]/70 via-transparent to-transparent lg:bg-gradient-to-l lg:from-[#101211]/55 lg:via-transparent" />
          </div>
        </div>
      </section>
    </div>
  );
};
