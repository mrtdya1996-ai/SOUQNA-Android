import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  BadgeCheck,
  Banknote,
  Clock,
  Flag,
  Loader2,
  MapPin,
  Megaphone,
  Package,
  Phone,
  PlusCircle,
  Search,
  Settings,
} from 'lucide-react';
import { ComplaintModal } from '../components/ComplaintModal';
import { GameTopupPanel } from '../components/GameTopupPanel';
import { PrintOrderPanel } from '../components/PrintOrderPanel';
import { ProductCard } from '../components/ProductCard';
import { StorePostCard } from '../components/StorePostCard';
import { useApp } from '../context/AppContext';
import { api, formatPrice, resolveMediaUrl } from '../lib/api';
import { STORE_CATEGORY_META } from '../lib/storeCategories';
import { STORE_TYPE_LABELS, type Product, type Store, type StorePost } from '../types';

type StoreSectionTab = 'all' | 'posts' | 'products';

export const StoreDetailView: React.FC = () => {
  const { user, selectedStoreId, ownedStore, bootstrapStatus, navigate, addToCart } = useApp();
  const [store, setStore] = useState<Store | null>(null);
  const [posts, setPosts] = useState<StorePost[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sectionTab, setSectionTab] = useState<StoreSectionTab>('all');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [search, setSearch] = useState('');
  const [coverErr, setCoverErr] = useState(false);
  const [showComplaint, setShowComplaint] = useState(false);
  const visitedStoreRef = useRef<string | null>(null);

  useEffect(() => {
    if (!selectedStoreId) {
      navigate('stores');
      return;
    }
    let active = true;
    setLoading(true);
    setError(null);
    setCoverErr(false);
    setSectionTab('all');
    api
      .getStoreDetail(selectedStoreId)
      .then((res) => {
        if (!active) return;
        setStore(res.store);
        setPosts(res.posts || []);
        setProducts(res.products || []);
        const isOwnerOrAdmin =
          (ownedStore && ownedStore.id === res.store.id) || user?.role === 'super_admin';
        if (
          res.store.status === 'active' &&
          !isOwnerOrAdmin &&
          visitedStoreRef.current !== res.store.id
        ) {
          visitedStoreRef.current = res.store.id;
          void api.recordStoreVisit(res.store.id).catch(() => {});
        }
      })
      .catch((err) => {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'تعذر تحميل بيانات المتجر.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedStoreId, navigate, ownedStore, user?.id, user?.role]);

  const categories = useMemo(() => {
    const unique = Array.from(new Set(products.map((p) => p.category)));
    return ['الكل', ...unique];
  }, [products]);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      const catMatch = selectedCategory === 'الكل' || p.category === selectedCategory;
      const textMatch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.gameName.toLowerCase().includes(q) ||
        p.compatibleModels.some((m) => m.toLowerCase().includes(q));
      return catMatch && textMatch;
    });
  }, [products, selectedCategory, search]);

  if (loading) {
    return (
      <div className="flex min-h-[320px] items-center justify-center gap-2 text-sm text-sq-ink-muted">
        <Loader2 className="h-5 w-5 animate-spin text-sq-gold" />
        <span>جاري فتح صفحة المتجر...</span>
      </div>
    );
  }

  if (error || !store) {
    return (
      <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center">
        <p className="text-sm font-semibold text-sq-danger-text">{error || 'المتجر غير متوفر.'}</p>
        <button
          type="button"
          onClick={() => navigate('stores')}
          className="btn-gold mt-4 min-h-[44px] rounded-xl px-5 py-2 text-sm"
        >
          العودة إلى دليل المتاجر والأسواق
        </button>
      </div>
    );
  }

  const isOwnStore = ownedStore?.id === store.id;
  const categoryMeta = STORE_CATEGORY_META[store.storeType] || STORE_CATEGORY_META.shop;
  const CategoryIcon = categoryMeta.icon;
  const coverSrc =
    store.coverUrl && !coverErr ? resolveMediaUrl(store.coverUrl) : categoryMeta.imageUrl;

  const showPostsSection = sectionTab === 'all' || sectionTab === 'posts';
  const showProductsSection = sectionTab === 'all' || sectionTab === 'products';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => navigate('stores')}
          className="inline-flex min-h-[44px] items-center gap-2 text-sm font-bold text-sq-secondary hover:text-sq-gold-text transition-colors"
        >
          <ArrowRight className="h-4 w-4 text-sq-gold-text" />
          <span>العودة إلى دليل المتاجر والأسواق</span>
        </button>

        {user && !isOwnStore && user.role !== 'super_admin' && (
          <button
            type="button"
            onClick={() => setShowComplaint(true)}
            className="btn-surface inline-flex min-h-[40px] items-center gap-1.5 rounded-xl px-3.5 py-1.5 text-xs font-bold text-sq-ink-muted hover:text-sq-danger-text"
          >
            <Flag className="h-3.5 w-3.5" />
            <span>الإبلاغ عن مشكلة</span>
          </button>
        )}
      </div>

      {/* Luxurious Black & Gold Store Header Card */}
      <section className="overflow-hidden rounded-3xl border border-[#D4AF37]/35 bg-[#0C0E0D] text-white shadow-xl">
        <div className="relative h-48 sm:h-60 w-full bg-[#181B19]">
          <img
            src={coverSrc}
            alt={store.name}
            referrerPolicy="no-referrer"
            onError={() => {
              if (!coverErr) setCoverErr(true);
            }}
            className="h-full w-full object-cover"
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0C0E0D] via-[#0C0E0D]/35 to-transparent" />
        </div>

        <div className="relative -mt-10 px-5 pb-6 sm:px-7 sm:pb-7">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="flex items-end gap-4">
              <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-2xl border-2 border-[#D4AF37] bg-[#161918] shadow-xl">
                {store.logoUrl ? (
                  <img
                    src={resolveMediaUrl(store.logoUrl)}
                    alt={`شعار ${store.name}`}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <CategoryIcon className="h-8 w-8 text-[#D4AF37]" />
                )}
              </div>

              <div className="pb-1">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="font-bold text-[#E8CB73]">
                    {STORE_TYPE_LABELS[store.storeType]}
                  </span>
                  <span aria-hidden="true" className="text-white/40">·</span>
                  <span className="text-[#CFC9BC]">
                    {store.city}
                    {store.district ? ` — ${store.district}` : ''}
                  </span>
                  {store.isVerified && (
                    <>
                      <span aria-hidden="true" className="text-white/40">·</span>
                      <span className="inline-flex items-center gap-1 font-bold text-[#E8CB73]">
                        <BadgeCheck className="h-4 w-4 text-[#D4AF37]" />
                        <span>متجر موثق</span>
                      </span>
                    </>
                  )}
                </div>

                <h1 className="mt-1.5 font-display text-2xl sm:text-3xl font-black text-white">
                  {store.name}
                </h1>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {store.phone && (
                <a
                  href={`tel:${store.phone}`}
                  className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-[#D4AF37]/50 bg-[#D4AF37]/15 px-4 py-2 text-sm font-bold text-[#E8CB73] hover:bg-[#D4AF37]/25 active:scale-95 transition whitespace-nowrap"
                >
                  <Phone className="h-4 w-4" />
                  <span dir="ltr" className="font-mono text-xs sm:text-sm">
                    {store.phone}
                  </span>
                </a>
              )}
              {isOwnStore && (
                <button
                  type="button"
                  onClick={() => navigate('merchant')}
                  className="btn-gold inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm whitespace-nowrap shrink-0"
                >
                  <Settings className="h-4 w-4" />
                  <span>إدارة المتجر والمنشورات</span>
                </button>
              )}
            </div>
          </div>

          {store.description && (
            <p className="mt-4 max-w-3xl text-sm leading-relaxed text-[#D8D2C5]">
              {store.description}
            </p>
          )}

          <div className="mt-5 grid grid-cols-1 gap-3 border-t border-white/10 pt-5 sm:grid-cols-2 lg:grid-cols-4 text-xs sm:text-sm text-[#CFC9BC]">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 shrink-0 text-[#D4AF37]" />
              <span className="truncate">
                {[store.city, store.district, store.address].filter(Boolean).join(' — ')}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 shrink-0 text-[#D4AF37]" />
              <span className="truncate">{store.openingHours || 'مفتوح يومياً'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Banknote className="h-4 w-4 shrink-0 text-[#D4AF37]" />
              <span className="tabular-nums text-white font-semibold">
                {store.deliveryFee > 0
                  ? `التوصيل ${formatPrice(store.deliveryFee, bootstrapStatus.currency)}`
                  : 'توصيل مجاني'}{' '}
                · توصيل أو استلام
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Megaphone className="h-4 w-4 shrink-0 text-[#D4AF37]" />
              <span className="tabular-nums text-white font-semibold">
                {posts.length} منشور · {products.length} منتج
              </span>
            </div>
          </div>

          {store.minOrderAmount > 0 && (
            <p className="mt-3 text-xs text-[#CFC9BC] tabular-nums">
              الحد الأدنى للطلب: {formatPrice(store.minOrderAmount, bootstrapStatus.currency)}
            </p>
          )}
        </div>
      </section>

      {/* Store Section Switcher: Posts & Offers vs. Products */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-sq-border bg-sq-surface p-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSectionTab('all')}
            className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-xl px-4 py-2 text-xs sm:text-sm font-bold transition-all active:scale-95 ${
              sectionTab === 'all'
                ? 'btn-gold'
                : 'text-sq-ink-muted hover:bg-sq-muted hover:text-sq-ink'
            }`}
          >
            <span>عرض الكل</span>
          </button>
          <button
            type="button"
            onClick={() => setSectionTab('posts')}
            className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-xl px-4 py-2 text-xs sm:text-sm font-bold transition-all active:scale-95 ${
              sectionTab === 'posts'
                ? 'btn-gold'
                : 'text-sq-ink-muted hover:bg-sq-muted hover:text-sq-ink'
            }`}
          >
            <Megaphone className="h-4 w-4" />
            <span>منشورات وعروض المتجر ({posts.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setSectionTab('products')}
            className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-xl px-4 py-2 text-xs sm:text-sm font-bold transition-all active:scale-95 ${
              sectionTab === 'products'
                ? 'btn-gold'
                : 'text-sq-ink-muted hover:bg-sq-muted hover:text-sq-ink'
            }`}
          >
            <Package className="h-4 w-4" />
            <span>
              {store.storeType === 'printing'
                ? 'خدمات الطباعة والمنتجات'
                : store.storeType === 'gaming_topup'
                ? `باقات الشحن (${products.length})`
                : `منتجات المتجر (${products.length})`}
            </span>
          </button>
        </div>

        {isOwnStore && (
          <button
            type="button"
            onClick={() => navigate('merchant')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-gold/45 bg-sq-gold-soft px-3.5 py-1.5 text-xs font-extrabold text-sq-gold-text active:scale-95 transition"
          >
            <PlusCircle className="h-4 w-4" />
            <span>إضافة منشور أو عرض جديد</span>
          </button>
        )}
      </div>

      {/* Store Posts & Offers Section */}
      {showPostsSection && (
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#D4AF37]/40 bg-[#121413] text-[#E8CB73]">
              <Megaphone className="h-4 w-4" />
            </div>
            <div>
              <h2 className="font-display text-lg sm:text-xl font-extrabold text-sq-ink">
                منشورات وعروض {store.name}
              </h2>
              <p className="text-xs text-sq-ink-muted">
                أحدث الإعلانات والعروض والصور التعريفية المنشورة مباشرة من صاحب المتجر
              </p>
            </div>
          </div>

          {posts.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-sq-border bg-sq-surface p-8 text-center">
              <Megaphone className="mx-auto h-9 w-9 text-sq-gold-text/60" />
              <p className="mt-2 font-display text-sm font-bold text-sq-ink">
                لا توجد منشورات أو عروض منشورة لهذا المتجر حالياً
              </p>
              <p className="mt-1 text-xs text-sq-ink-muted">
                {isOwnStore
                  ? 'يمكنك نشر عروضك وصور متجرك الجديدة الآن من لوحة تحكم متجرك لجذب الزبائن.'
                  : 'سيتم عرض إعلانات وعروض هذا المتجر هنا فور نشرها من قبل صاحب المتجر.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {posts.map((post) => (
                <StorePostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </section>
      )}

      {/* Specialized Workbenches & Store Products Catalog */}
      {showProductsSection && (
        <div className="space-y-6">
          {store.storeType === 'printing' && (
            <PrintOrderPanel store={store} isOwnStore={isOwnStore} />
          )}

          {store.storeType === 'gaming_topup' && (
            <GameTopupPanel store={store} products={products} isOwnStore={isOwnStore} />
          )}

          {store.storeType !== 'gaming_topup' &&
            (store.storeType !== 'printing' || products.length > 0) && (
              <section className="space-y-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <h2 className="font-display text-xl font-extrabold text-sq-ink">
                    {store.storeType === 'printing'
                      ? `منتجات وقرطاسية إضافية (${filteredProducts.length})`
                      : `منتجات المتجر (${filteredProducts.length})`}
                  </h2>

                  {products.length > 0 && (
                    <div className="relative sm:w-72">
                      <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
                      <input
                        type="search"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder={
                          store.storeType === 'phone_accessories'
                            ? 'ابحث بالمنتج أو موديل الهاتف...'
                            : 'ابحث داخل منتجات المتجر...'
                        }
                        className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-surface pr-10 pl-3 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                      />
                    </div>
                  )}
                </div>

                {categories.length > 1 && (
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`min-h-[40px] rounded-xl px-3.5 py-2 text-xs font-bold whitespace-nowrap shrink-0 transition-all active:scale-95 ${
                          selectedCategory === cat
                            ? 'btn-gold'
                            : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                )}

                {filteredProducts.length === 0 ? (
                  <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
                    لا توجد منتجات مضافة في هذا المتجر حالياً. يمكنك متابعة منشورات المتجر أو التواصل المباشر عبر رقم الهاتف.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                    {filteredProducts.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        currency={bootstrapStatus.currency}
                        disableAdd={isOwnStore}
                        disableReason={isOwnStore ? 'لا يمكنك الشراء من متجرك الخاص' : undefined}
                        onAdd={(pricingType, selectedOptions) =>
                          addToCart(
                            product,
                            {
                              id: store.id,
                              name: store.name,
                              deliveryFee: store.deliveryFee,
                              address: `${store.city}، ${store.address}`,
                            },
                            pricingType,
                            selectedOptions
                          )
                        }
                      />
                    ))}
                  </div>
                )}
              </section>
            )}
        </div>
      )}

      {showComplaint && (
        <ComplaintModal
          targetType="store"
          targetId={store.id}
          targetName={store.name}
          onClose={() => setShowComplaint(false)}
        />
      )}
    </div>
  );
};
