import React, { useState } from 'react';
import {
  ArrowRight,
  Bike,
  Camera,
  Car,
  CheckCircle2,
  FileUp,
  Lock,
  ShieldCheck,
  Truck,
} from 'lucide-react';
import { api, compressImageFile, readDocumentAsDataUrl } from '../lib/api';
import { useApp } from '../context/AppContext';
import {
  COURIER_ID_TYPES,
  COURIER_VEHICLE_LABELS,
  type CourierVehicleType,
} from '../types';

export const CourierRegisterView: React.FC = () => {
  const { setSession, navigate, notify } = useApp();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [district, setDistrict] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [address, setAddress] = useState('');
  const [vehicleType, setVehicleType] = useState<CourierVehicleType>('motorcycle');
  const [plateNumber, setPlateNumber] = useState('');
  const [idType, setIdType] = useState(COURIER_ID_TYPES[0]);
  const [idNumber, setIdNumber] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);

  const [avatarDataUrl, setAvatarDataUrl] = useState('');
  const [idFrontDataUrl, setIdFrontDataUrl] = useState('');
  const [idFrontName, setIdFrontName] = useState('');
  const [idBackDataUrl, setIdBackDataUrl] = useState('');
  const [idBackName, setIdBackName] = useState('');
  const [licenseDataUrl, setLicenseDataUrl] = useState('');
  const [licenseName, setLicenseName] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageFile(file, 720);
      setAvatarDataUrl(dataUrl);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر قراءة الصورة الشخصية.', 'error');
    } finally {
      e.target.value = '';
    }
  };

  const handlePrivateDocUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    target: 'front' | 'back' | 'license'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = file.type.startsWith('image/')
        ? await compressImageFile(file, 1400)
        : await readDocumentAsDataUrl(file);
      if (target === 'front') {
        setIdFrontDataUrl(dataUrl);
        setIdFrontName(file.name);
      } else if (target === 'back') {
        setIdBackDataUrl(dataUrl);
        setIdBackName(file.name);
      } else {
        setLicenseDataUrl(dataUrl);
        setLicenseName(file.name);
      }
      notify('تم تجهيز المستمسك للرفع الآمن.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر قراءة ملف المستمسك.', 'error');
    } finally {
      e.target.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!idFrontDataUrl) {
      setError('يرجى رفع صورة الوجه الأمامي للهوية الرسمية لإتمام توثيق حساب المندوب.');
      return;
    }
    if (!termsAccepted) {
      setError('يرجى الموافقة على شروط العمل وسياسة الخصوصية قبل الإرسال.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.registerCourier({
        fullName,
        email,
        phone,
        password,
        governorate,
        city: governorate,
        district,
        neighborhood,
        address,
        vehicleType,
        plateNumber,
        idType,
        idNumber,
        avatarDataUrl: avatarDataUrl || undefined,
        idFrontDataUrl,
        idBackDataUrl: idBackDataUrl || undefined,
        licenseDataUrl: licenseDataUrl || undefined,
        termsAccepted,
      });
      setSession(res.token, res.user, null, res.courier, res.subscription ?? null);
      notify(
        'تم استلام طلب تسجيلك كمندوب بنجاح وتفعيل فترة تجريبية مجانية 30 يوماً — حسابك الآن بانتظار توثيق المدير العام.',
        'success'
      );
      navigate('courier');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إتمام التسجيل كمندوب.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => navigate('auth')}
          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
        >
          <ArrowRight className="h-4 w-4" />
          <span>العودة لتسجيل الدخول</span>
        </button>
      </div>

      <div className="rounded-2xl border border-sq-border bg-sq-surface p-5 sm:p-7 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-sq-gold-soft text-sq-gold-text">
            <Truck className="h-5 w-5" />
          </div>
          <div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-sq-ink">
              التسجيل كمندوب توصيل في SOUQNA | سوقنا
            </h1>
            <p className="mt-1 text-sm text-sq-ink-muted leading-relaxed">
              انضم إلى شبكة المندوبين الموثقين لتوصيل طلبات المتاجر والأسواق. يتم مراجعة مستمسكاتك
              بسرية تامة من قِبل المدير العام قبل تفعيل استقبال الطلبات.
            </p>
          </div>
        </div>

        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-sq-gold/35 bg-sq-gold-soft/60 p-3.5 text-xs text-sq-gold-text">
          <Lock className="mt-0.5 h-4 w-4 shrink-0" />
          <p className="leading-relaxed">
            <strong>حماية المستمسكات:</strong> جميع صور الهوية ورخصة القيادة تُحفظ في مخزن خاص
            محمي خارج الملفات العامة ولا يمكن لأي زبون أو صاحب متجر الاطلاع عليها أبداً.
          </p>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 py-3 text-sm font-medium text-sq-danger-text">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          {/* 1. البيانات الشخصية والحساب */}
          <section className="space-y-4">
            <h2 className="border-b border-sq-border pb-2 font-display text-sm font-bold text-sq-ink">
              1. البيانات الشخصية وبيانات الدخول
            </h2>

            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-sq-border bg-sq-elevated">
                {avatarDataUrl ? (
                  <img src={avatarDataUrl} alt="الصورة الشخصية" className="h-full w-full object-cover" />
                ) : (
                  <Camera className="h-6 w-6 text-sq-ink-muted" />
                )}
              </div>
              <div className="flex-1">
                <label className="inline-flex min-h-[40px] cursor-pointer items-center gap-2 rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2 text-xs font-semibold text-sq-ink hover:bg-sq-muted">
                  <Camera className="h-4 w-4 text-sq-gold-text" />
                  <span>{avatarDataUrl ? 'تغيير الصورة الشخصية' : 'رفع صورة شخصية (اختياري)'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarUpload}
                    className="hidden"
                  />
                </label>
                <p className="mt-1 text-[11px] text-sq-ink-muted">
                  تساعد الزبون وصاحب المتجر على التعرف عليك عند الاستلام والتسليم.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  الاسم الكامل (الثلاثي) *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="الاسم الثلاثي المطابق للهوية"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  رقم الهاتف الفعّال *
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="07XXXXXXXXX"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink text-right outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  البريد الإلكتروني *
                </label>
                <input
                  type="email"
                  required
                  dir="ltr"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="courier@example.com"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink text-right outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  كلمة المرور *
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="6 أحرف على الأقل"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
            </div>
          </section>

          {/* 2. العنوان ونطاق العمل */}
          <section className="space-y-3.5">
            <h2 className="border-b border-sq-border pb-2 font-display text-sm font-bold text-sq-ink">
              2. السكن ونطاق التغطية الجغرافي
            </h2>
            <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">المحافظة *</label>
                <input
                  type="text"
                  required
                  value={governorate}
                  onChange={(e) => setGovernorate(e.target.value)}
                  placeholder="مثال: بغداد، البصرة..."
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">المنطقة *</label>
                <input
                  type="text"
                  required
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  placeholder="المنطقة أو القضاء"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">الحي</label>
                <input
                  type="text"
                  value={neighborhood}
                  onChange={(e) => setNeighborhood(e.target.value)}
                  placeholder="اسم الحي"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-sq-ink">
                عنوان السكن التفصيلي *
              </label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="الشارع، أقرب نقطة دالة..."
                className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
              />
            </div>
          </section>

          {/* 3. بيانات المركبة */}
          <section className="space-y-3.5">
            <h2 className="border-b border-sq-border pb-2 font-display text-sm font-bold text-sq-ink">
              3. بيانات المركبة المستخدمة في التوصيل
            </h2>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {(['motorcycle', 'car', 'bicycle', 'light_truck'] as CourierVehicleType[]).map((v) => {
                const active = vehicleType === v;
                return (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setVehicleType(v)}
                    className={`flex min-h-[56px] flex-col items-center justify-center gap-1 rounded-xl border p-2.5 text-xs font-bold transition-colors ${
                      active
                        ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                        : 'border-sq-border bg-sq-elevated text-sq-ink-muted hover:bg-sq-muted'
                    }`}
                  >
                    {v === 'car' ? (
                      <Car className="h-4 w-4" />
                    ) : v === 'light_truck' ? (
                      <Truck className="h-4 w-4" />
                    ) : (
                      <Bike className="h-4 w-4" />
                    )}
                    <span>{COURIER_VEHICLE_LABELS[v]}</span>
                  </button>
                );
              })}
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-sq-ink">
                رقم لوحة المركبة (إن وجدت)
              </label>
              <input
                type="text"
                value={plateNumber}
                onChange={(e) => setPlateNumber(e.target.value)}
                placeholder="مثال: 12345 ب بغداد (اتركه فارغاً للدراجة الهوائية)"
                className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
              />
            </div>
          </section>

          {/* 4. الهوية والمستمسكات الرسمية */}
          <section className="space-y-3.5">
            <h2 className="border-b border-sq-border pb-2 font-display text-sm font-bold text-sq-ink">
              4. التوثيق والمستمسكات الرسمية
            </h2>
            <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  نوع الهوية الرسمية *
                </label>
                <select
                  value={idType}
                  onChange={(e) => setIdType(e.target.value)}
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
                >
                  {COURIER_ID_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  رقم الهوية / المستند *
                </label>
                <input
                  type="text"
                  required
                  dir="ltr"
                  value={idNumber}
                  onChange={(e) => setIdNumber(e.target.value)}
                  placeholder="أدخل الرقم الوطني أو رقم الهوية"
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink text-right outline-none focus:border-sq-gold focus:bg-sq-surface"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <label className="flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-sq-border bg-sq-elevated p-4 text-center hover:border-sq-gold hover:bg-sq-gold-soft/40">
                {idFrontDataUrl ? (
                  <CheckCircle2 className="h-6 w-6 text-sq-gold-text" />
                ) : (
                  <FileUp className="h-6 w-6 text-sq-ink-muted" />
                )}
                <span className="text-xs font-bold text-sq-ink">وجه الهوية الأمامي *</span>
                <span className="text-[11px] text-sq-ink-muted truncate max-w-full">
                  {idFrontName || 'صورة أو PDF (مطلوب)'}
                </span>
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(e) => void handlePrivateDocUpload(e, 'front')}
                  className="hidden"
                />
              </label>

              <label className="flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-sq-border bg-sq-elevated p-4 text-center hover:border-sq-gold hover:bg-sq-gold-soft/40">
                {idBackDataUrl ? (
                  <CheckCircle2 className="h-6 w-6 text-sq-gold-text" />
                ) : (
                  <FileUp className="h-6 w-6 text-sq-ink-muted" />
                )}
                <span className="text-xs font-bold text-sq-ink">ظهر الهوية</span>
                <span className="text-[11px] text-sq-ink-muted truncate max-w-full">
                  {idBackName || 'صورة أو PDF (مستحسن)'}
                </span>
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(e) => void handlePrivateDocUpload(e, 'back')}
                  className="hidden"
                />
              </label>

              <label className="flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-sq-border bg-sq-elevated p-4 text-center hover:border-sq-gold hover:bg-sq-gold-soft/40">
                {licenseDataUrl ? (
                  <CheckCircle2 className="h-6 w-6 text-sq-gold-text" />
                ) : (
                  <FileUp className="h-6 w-6 text-sq-ink-muted" />
                )}
                <span className="text-xs font-bold text-sq-ink">رخصة القيادة</span>
                <span className="text-[11px] text-sq-ink-muted truncate max-w-full">
                  {licenseName || 'عند قيادة سيارة / دراجة'}
                </span>
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(e) => void handlePrivateDocUpload(e, 'license')}
                  className="hidden"
                />
              </label>
            </div>
          </section>

          {/* 5. الموافقة على الشروط */}
          <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-sq-border bg-sq-elevated p-4">
            <input
              type="checkbox"
              checked={termsAccepted}
              onChange={(e) => setTermsAccepted(e.target.checked)}
              className="mt-1 h-4 w-4 rounded accent-[#D4AF37]"
            />
            <span className="text-xs leading-relaxed text-sq-ink">
              أقرّ بصحة جميع البيانات والمستمسكات المرفقة، وأوافق على{' '}
              <strong>شروط عمل المندوبين وسياسة الخصوصية</strong> في منصة SOUQNA | سوقنا، بما في
              ذلك الالتزام بتسليم الطلبات بأمانة وتحصيل المبلغ النقدي المطابق للفاتورة وتأكيد
              التسليم برمز التحقق (OTP) من الزبون، وتحديث موقعي الجغرافي فقط أثناء تفعيل حالة (متاح
              للعمل).
            </span>
          </label>

          <button
            type="submit"
            disabled={submitting}
            className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold px-5 py-3 text-sm font-bold transition-colors disabled:opacity-60"
          >
            <ShieldCheck className="h-5 w-5" />
            <span>{submitting ? 'جاري إرسال طلب التوثيق...' : 'إرسال طلب التسجيل كمندوب'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
