import React, { useEffect, useState } from 'react';
import {
  ArrowRight,
  Bike,
  CheckCircle2,
  KeyRound,
  Loader2,
  LogOut,
  Mail,
  ShieldCheck,
  Store as StoreIcon,
  User as UserIcon,
} from 'lucide-react';
import { SouqnaLogo } from '../components/SouqnaLogo';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import { ROLE_LABELS } from '../types';

type AuthMode = 'login' | 'register' | 'recovery' | 'bootstrap_admin';
type RecoveryTab = 'email' | 'request' | 'reset';

export const AuthView: React.FC = () => {
  const {
    user,
    bootstrapStatus,
    pendingResetToken,
    clearPendingResetToken,
    forgotPasswordRequested,
    clearForgotPasswordRequested,
    setSession,
    logout,
    refreshBootstrap,
    navigate,
    notify,
  } = useApp();

  const [mode, setMode] = useState<AuthMode>(
    pendingResetToken || forgotPasswordRequested ? 'recovery' : 'login'
  );
  const [recoveryTab, setRecoveryTab] = useState<RecoveryTab>(
    pendingResetToken ? 'reset' : 'email'
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [warningMsg, setWarningMsg] = useState<string | null>(null);
  const [emailNotConfiguredHint, setEmailNotConfiguredHint] = useState(false);

  // Login state
  const [identifier, setIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register / Bootstrap state
  const [role, setRole] = useState<'customer' | 'merchant'>('customer');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [address, setAddress] = useState('');
  const [password, setPassword] = useState('');
  const [setupCode, setSetupCode] = useState('');

  // Self-service Email Reset state
  const [emailResetAddress, setEmailResetAddress] = useState('');

  // Account Recovery Request state (Admin-assisted)
  const [recName, setRecName] = useState('');
  const [recPhone, setRecPhone] = useState('');
  const [recEmail, setRecEmail] = useState('');
  const [recAccountType, setRecAccountType] = useState('merchant');
  const [recProofDetails, setRecProofDetails] = useState('');
  const [recSubmittedId, setRecSubmittedId] = useState<string | null>(null);

  // One-time Reset Password state
  const [resetTokenInput, setResetTokenInput] = useState(pendingResetToken || '');
  const [resetCodeInput, setResetCodeInput] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  useEffect(() => {
    if (pendingResetToken) {
      setMode('recovery');
      setRecoveryTab('reset');
      setResetTokenInput(pendingResetToken);
      setError(null);
      setSuccessMsg(null);
    }
  }, [pendingResetToken]);

  useEffect(() => {
    if (forgotPasswordRequested && !pendingResetToken) {
      setMode('recovery');
      setRecoveryTab('email');
      setError(null);
      setSuccessMsg(null);
      clearForgotPasswordRequested();
    }
  }, [forgotPasswordRequested, pendingResetToken, clearForgotPasswordRequested]);

  // Automatically redirect already-authenticated users to their role view so they never see a login screen
  useEffect(() => {
    if (!user || pendingResetToken || mode === 'recovery') return;
    const dashboardView =
      user.role === 'super_admin'
        ? 'admin'
        : user.role === 'merchant'
        ? 'merchant'
        : user.role === 'courier'
        ? 'courier'
        : 'home';
    navigate(dashboardView);
  }, [user, pendingResetToken, mode, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      const res = await api.login({ identifier: identifier.trim(), password: loginPassword });
      setSession(res.token, res.user, res.store, res.courier ?? null, res.subscription ?? null);
      notify(`مرحباً بعودتك، ${res.user.fullName}`, 'success');
      if (res.user.role === 'super_admin') {
        navigate('admin');
      } else if (res.user.role === 'merchant') {
        navigate('merchant');
      } else if (res.user.role === 'courier') {
        navigate('courier');
      } else {
        navigate('home');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تسجيل الدخول.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      const res = await api.register({
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        governorate: governorate.trim(),
        city: city.trim(),
        district: district.trim(),
        neighborhood: neighborhood.trim(),
        address: address.trim(),
        password,
        role,
      });
      setSession(res.token, res.user, res.store, null, res.subscription ?? null);
      const trialDays = bootstrapStatus.trialDays ?? 30;
      notify(
        role === 'merchant'
          ? trialDays > 0
            ? `تم إنشاء حساب التاجر بنجاح وتفعيل اشتراك تجريبي مجاني لمدة ${trialDays} يوماً!`
            : 'تم إنشاء حساب التاجر بنجاح!'
          : 'تم إنشاء حسابك بنجاح!',
        'success'
      );
      navigate(role === 'merchant' ? 'merchant' : 'home');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إنشاء الحساب.');
    } finally {
      setLoading(false);
    }
  };

  const handleBootstrapAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      const res = await api.bootstrapAdmin({
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        city: governorate.trim(),
        password,
        setupCode: setupCode.trim() || undefined,
      });
      setSession(res.token, res.user, null);
      await refreshBootstrap();
      notify('تم تفعيل حساب المدير العام (Super Admin) بنجاح.', 'success');
      navigate('admin');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إعداد حساب المدير العام.');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailResetRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setWarningMsg(null);
    setEmailNotConfiguredHint(false);
    if (bootstrapStatus.emailResetConfigured === false) {
      setEmailNotConfiguredHint(true);
      setWarningMsg(
        'خدمة إرسال البريد الإلكتروني غير مهيأة حالياً على الخادم، ولم يتم إرسال أي رسالة بريدية. يمكنك استعادة حسابك فوراً عبر تبويب «طلب عبر المدير».'
      );
      return;
    }
    setLoading(true);
    try {
      const res = await api.requestEmailPasswordReset(emailResetAddress.trim());
      if (res.deliveryMode === 'not_configured') {
        setEmailNotConfiguredHint(true);
        setWarningMsg(res.message);
      } else {
        setSuccessMsg(res.message);
        setEmailResetAddress('');
        notify('تمت معالجة طلب الاستعادة عبر البريد الإلكتروني.', 'success');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إرسال رابط الاستعادة عبر البريد.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitRecovery = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setWarningMsg(null);
    setEmailNotConfiguredHint(false);
    setLoading(true);
    try {
      const res = await api.submitAccountRecovery({
        requesterName: recName.trim(),
        requesterPhone: recPhone.trim(),
        requesterEmail: recEmail.trim() || undefined,
        accountType: recAccountType,
        proofDetails: recProofDetails.trim(),
      });
      setRecSubmittedId(res.requestId);
      setSuccessMsg(res.message);
      setRecName('');
      setRecPhone('');
      setRecEmail('');
      setRecProofDetails('');
      notify('تم إرسال طلب استعادة الحساب إلى المدير الرئيسي بنجاح.', 'success');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إرسال طلب استعادة الحساب.');
    } finally {
      setLoading(false);
    }
  };

  const handleCompleteReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    if (newPassword !== confirmNewPassword) {
      setError('كلمتا المرور غير متطابقتين.');
      return;
    }
    if (!resetTokenInput.trim() && !resetCodeInput.trim()) {
      setError('يرجى إدخال رمز الاستعادة المؤقت المرسل من المدير الرئيسي.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.completePasswordReset({
        token: resetTokenInput.trim() || undefined,
        code: resetCodeInput.trim() || undefined,
        newPassword,
      });
      clearPendingResetToken();
      setResetTokenInput('');
      setResetCodeInput('');
      setNewPassword('');
      setConfirmNewPassword('');
      setMode('login');
      setSuccessMsg(res.message);
      notify('تمت إعادة تعيين كلمة المرور بنجاح! سجّل دخولك الآن.', 'success');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر إعادة تعيين كلمة المرور.');
    } finally {
      setLoading(false);
    }
  };

  // If user is already logged in (persistent session) and not opening a reset token
  if (user && !pendingResetToken && mode !== 'recovery') {
    const dashboardView =
      user.role === 'super_admin'
        ? 'admin'
        : user.role === 'merchant'
        ? 'merchant'
        : user.role === 'courier'
        ? 'courier'
        : 'home';

    return (
      <div className="mx-auto max-w-lg py-6">
        <div className="rounded-3xl border border-sq-gold-hairline bg-sq-surface p-7 text-center shadow-xl space-y-5">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-sq-gold/45 bg-sq-gold-soft text-sq-gold-text">
            <CheckCircle2 className="h-7 w-7" />
          </div>
          <div>
            <p className="text-xs font-bold text-sq-gold-text">جلستك محفوظة ونشطة</p>
            <h1 className="mt-1 font-display text-2xl font-extrabold text-sq-ink">
              مرحباً {user.fullName}
            </h1>
            <p className="mt-1.5 text-sm text-sq-ink-muted">
              أنت مسجل الدخول حالياً بصلاحية{' '}
              <strong className="text-sq-ink">{ROLE_LABELS[user.role]}</strong> ولا تحتاج لتسجيل
              الدخول مرة أخرى حتى تقوم بتسجيل الخروج.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => navigate(dashboardView)}
              className="min-h-[46px] rounded-xl btn-gold px-6 text-sm font-bold"
            >
              الانتقال إلى لوحتي
            </button>
            <button
              type="button"
              onClick={() => void logout()}
              className="inline-flex min-h-[46px] items-center gap-2 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-5 text-sm font-bold text-sq-danger-text"
            >
              <LogOut className="h-4 w-4" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-lg py-2 sm:py-6">
      <div className="rounded-3xl border border-sq-gold-hairline bg-sq-surface p-6 sm:p-8 shadow-xl shadow-black/10">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-4">
            <SouqnaLogo size="lg" />
          </div>
          <h1 className="font-display text-2xl font-extrabold text-sq-ink">
            {mode === 'login'
              ? 'تسجيل الدخول الموحّد إلى سوقنا'
              : mode === 'register'
              ? 'إنشاء حساب جديد'
              : mode === 'recovery'
              ? 'استعادة الحساب وكلمة المرور'
              : 'إعداد حساب المدير العام لأول مرة'}
          </h1>
          <p className="mt-1.5 text-sm text-sq-ink-muted">
            {mode === 'login'
              ? 'حساب واحد للزبائن وأصحاب المتاجر والمندوبين والمدير العام — تُحفظ جلستك تلقائياً حتى تسجيل الخروج'
              : mode === 'register'
              ? 'حساب واحد يتيح لك التسوق كزبون ويمكنك فتح متجرك عليه في أي وقت'
              : mode === 'recovery'
              ? 'آلية آمنة لاستعادة حسابك عبر مراجعة المدير الرئيسي أو رمز التعيين المؤقت'
              : 'إعداد أول حساب مدير عام للمنصة — يُغلق هذا الخيار تلقائياً بعد التفعيل'}
          </p>
        </div>

        {/* Mode Switcher */}
        {mode !== 'recovery' ? (
          <div className="mb-6 flex gap-1.5 rounded-xl bg-sq-muted p-1">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
                setSuccessMsg(null);
                setWarningMsg(null);
              }}
              className={`min-h-[42px] flex-1 rounded-lg px-3 py-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
                mode === 'login'
                  ? 'bg-sq-surface text-sq-ink shadow-xs'
                  : 'text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
                setSuccessMsg(null);
                setWarningMsg(null);
              }}
              className={`min-h-[42px] flex-1 rounded-lg px-3 py-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
                mode === 'register'
                  ? 'bg-sq-surface text-sq-ink shadow-xs'
                  : 'text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              حساب جديد
            </button>
            {!bootstrapStatus.hasSuperAdmin && (
              <button
                type="button"
                onClick={() => {
                  setMode('bootstrap_admin');
                  setError(null);
                  setSuccessMsg(null);
                  setWarningMsg(null);
                }}
                className={`min-h-[42px] flex-1 rounded-lg px-3 py-2 text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
                  mode === 'bootstrap_admin'
                    ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                    : 'text-sq-ink-muted hover:text-sq-ink'
                }`}
              >
                المدير العام
              </button>
            )}
          </div>
        ) : (
          <div className="mb-5 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => {
                clearPendingResetToken();
                setMode('login');
                setError(null);
                setSuccessMsg(null);
                setWarningMsg(null);
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-sq-gold-text hover:underline"
            >
              <ArrowRight className="h-4 w-4" />
              <span>العودة لتسجيل الدخول</span>
            </button>
          </div>
        )}

        {error && (
          <div
            role="alert"
            className="mb-4 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 py-3 text-xs font-semibold text-sq-danger-text"
          >
            {error}
          </div>
        )}

        {warningMsg && (
          <div
            role="status"
            className="mb-4 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-4 py-3 text-xs font-semibold leading-relaxed text-sq-warning-text"
          >
            {warningMsg}
          </div>
        )}

        {successMsg && (
          <div
            role="status"
            className="mb-4 rounded-xl border border-sq-success-border bg-sq-success-bg px-4 py-3 text-xs font-semibold text-sq-success-text space-y-1"
          >
            <div>{successMsg}</div>
            {recSubmittedId && (
              <div className="font-mono text-[11px]">رقم الطلب المرجعي: {recSubmittedId}</div>
            )}
          </div>
        )}

        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            {!bootstrapStatus.hasSuperAdmin && (
              <div className="rounded-2xl border border-sq-gold/45 bg-sq-gold-soft p-3.5 text-right space-y-2">
                <div className="flex items-center gap-2 text-xs font-extrabold text-sq-gold-text">
                  <ShieldCheck className="h-4 w-4 shrink-0" />
                  <span>تهيئة حساب المدير العام (Super Admin) لأول مرة</span>
                </div>
                <p className="text-[11px] leading-relaxed text-sq-ink">
                  لا يوجد حساب مدير عام مسجل في قاعدة البيانات بعد. يمكنك إنشاؤه الآن مباشرة دون
                  أي مفاتيح خارجية، وسيُغلق خيار التسجيل الإداري تلقائياً بعد الإنشاء.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setMode('bootstrap_admin');
                    setError(null);
                    setSuccessMsg(null);
                    setWarningMsg(null);
                  }}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold"
                >
                  <ShieldCheck className="h-3.5 w-3.5" />
                  <span>إنشاء حساب المدير العام الآن</span>
                </button>
              </div>
            )}

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                البريد الإلكتروني أو رقم الهاتف
              </label>
              <input
                type="text"
                required
                dir="ltr"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="name@example.com"
                className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label className="block text-xs font-semibold text-sq-ink">كلمة المرور</label>
                <button
                  type="button"
                  onClick={() => {
                    setMode('recovery');
                    setRecoveryTab('email');
                    setError(null);
                    setSuccessMsg(null);
                    setEmailNotConfiguredHint(false);
                  }}
                  className="text-xs font-bold text-sq-gold-text hover:underline"
                >
                  هل نسيت كلمة المرور؟
                </button>
              </div>
              <input
                type="password"
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="••••••••"
                className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold py-3 text-sm font-semibold transition-colors disabled:opacity-60"
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              <span>دخول وحفظ الجلسة</span>
            </button>

            <div className="pt-1 text-center">
              <button
                type="button"
                onClick={() => {
                  setMode('recovery');
                  setRecoveryTab('reset');
                  setError(null);
                  setSuccessMsg(null);
                }}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-sq-ink-muted hover:text-sq-gold-text"
              >
                <KeyRound className="h-3.5 w-3.5" />
                <span>لديك رمز استعادة مؤقت من الإدارة؟ أعد تعيين كلمة المرور الآن</span>
              </button>
            </div>
          </form>
        )}

        {mode === 'recovery' && (
          <div className="space-y-5">
            <div className="grid grid-cols-3 gap-1 rounded-xl bg-sq-muted p-1">
              <button
                type="button"
                onClick={() => {
                  setRecoveryTab('email');
                  setError(null);
                  setSuccessMsg(null);
                  setWarningMsg(null);
                }}
                className={`min-h-[40px] rounded-lg px-2 text-[11px] sm:text-xs font-bold transition-colors ${
                  recoveryTab === 'email'
                    ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                    : 'text-sq-ink-muted hover:text-sq-ink'
                }`}
              >
                عبر البريد الإلكتروني
              </button>
              <button
                type="button"
                onClick={() => {
                  setRecoveryTab('request');
                  setError(null);
                  setSuccessMsg(null);
                  setWarningMsg(null);
                  setEmailNotConfiguredHint(false);
                }}
                className={`min-h-[40px] rounded-lg px-2 text-[11px] sm:text-xs font-bold transition-colors ${
                  recoveryTab === 'request'
                    ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                    : 'text-sq-ink-muted hover:text-sq-ink'
                }`}
              >
                طلب عبر المدير
              </button>
              <button
                type="button"
                onClick={() => {
                  setRecoveryTab('reset');
                  setError(null);
                  setSuccessMsg(null);
                  setWarningMsg(null);
                  setEmailNotConfiguredHint(false);
                }}
                className={`min-h-[40px] rounded-lg px-2 text-[11px] sm:text-xs font-bold transition-colors ${
                  recoveryTab === 'reset'
                    ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                    : 'text-sq-ink-muted hover:text-sq-ink'
                }`}
              >
                رمز التعيين
              </button>
            </div>

            {recoveryTab === 'email' ? (
              <form onSubmit={handleEmailResetRequest} className="space-y-4">
                <div className="rounded-xl border border-sq-gold/30 bg-sq-gold-soft/50 p-3.5 text-xs leading-relaxed text-sq-ink">
                  <div className="mb-1 flex items-center gap-1.5 font-bold text-sq-gold-text">
                    <Mail className="h-4 w-4" />
                    <span>استعادة الحساب عبر البريد الإلكتروني</span>
                  </div>
                  إذا كان لديك وصول لبريدك الإلكتروني المسجّل، أدخله أدناه لإرسال{' '}
                  <strong className="text-sq-gold-text">رابط ورمز إعادة تعيين مؤقت لمرة واحدة</strong>
                  . لا يتم إرسال كلمة المرور القديمة مطلقاً.
                </div>

                {bootstrapStatus.emailResetConfigured === false ? (
                  <div className="rounded-2xl border border-sq-warning-border bg-sq-warning-bg p-4 text-xs leading-relaxed text-sq-warning-text space-y-3">
                    <p className="font-bold">
                      خدمة إرسال البريد الإلكتروني غير مهيأة حالياً على الخادم.
                    </p>
                    <p>
                      لن يتم إرسال أي رسالة بريدية تلقائياً حتى يتم ربط مزوّد بريد (Resend أو SMTP)
                      في إعدادات الخادم. يمكنك استعادة حسابك فوراً وبأمان عبر إرسال طلب إلى المدير
                      الرئيسي ليُصدر لك رمزاً مؤقتاً لإعادة تعيين كلمة المرور.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setRecoveryTab('request');
                        setRecEmail(emailResetAddress.trim());
                        setError(null);
                        setSuccessMsg(null);
                        setWarningMsg(null);
                      }}
                      className="flex min-h-[46px] w-full items-center justify-center rounded-xl btn-gold px-4 text-xs font-bold"
                    >
                      الانتقال إلى طلب الاستعادة عبر المدير الرئيسي
                    </button>
                  </div>
                ) : (
                  <>
                    <div>
                      <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                        البريد الإلكتروني المسجّل في الحساب
                      </label>
                      <input
                        type="email"
                        required
                        dir="ltr"
                        value={emailResetAddress}
                        onChange={(e) => setEmailResetAddress(e.target.value)}
                        placeholder="name@example.com"
                        className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold py-3 text-sm font-bold disabled:opacity-60"
                    >
                      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                      <span>إرسال رابط إعادة تعيين كلمة المرور</span>
                    </button>
                  </>
                )}

                <div className="rounded-xl border border-sq-border bg-sq-elevated p-3.5 text-xs text-sq-ink-muted flex flex-wrap items-center justify-between gap-2">
                  <span>فقدت الوصول إلى بريدك الإلكتروني أو لا تتذكره؟</span>
                  <button
                    type="button"
                    onClick={() => {
                      setRecoveryTab('request');
                      setRecEmail(emailResetAddress.trim());
                      setError(null);
                      setSuccessMsg(null);
                      setWarningMsg(null);
                      setEmailNotConfiguredHint(false);
                    }}
                    className="font-bold text-sq-gold-text hover:underline"
                  >
                    قدّم طلب استعادة عبر المدير الرئيسي
                  </button>
                </div>

                {emailNotConfiguredHint && (
                  <button
                    type="button"
                    onClick={() => {
                      setRecoveryTab('request');
                      setRecEmail(emailResetAddress.trim());
                      setError(null);
                      setSuccessMsg(null);
                      setWarningMsg(null);
                      setEmailNotConfiguredHint(false);
                    }}
                    className="w-full min-h-[44px] rounded-xl border border-sq-gold/45 bg-sq-gold-soft px-4 text-xs font-bold text-sq-gold-text"
                  >
                    المتابعة عبر طلب استعادة للمدير الرئيسي الآن
                  </button>
                )}
              </form>
            ) : recoveryTab === 'request' ? (
              <form onSubmit={handleSubmitRecovery} className="space-y-4">
                <div className="rounded-xl border border-sq-gold/30 bg-sq-gold-soft/50 p-3.5 text-xs leading-relaxed text-sq-ink">
                  إذا فقدت الوصول إلى بريدك الإلكتروني أو لا تتذكر البريد المسجّل، أرسل طلب استعادة
                  حساب إلى المدير الرئيسي. بعد التحقق من ملكيتك للحساب سيُصدر لك المدير{' '}
                  <strong className="text-sq-gold-text">رابط أو رمز مؤقت آمن</strong> لتعيين كلمة
                  مرور جديدة (لا يتم كشف أو إرسال كلمات المرور القديمة مطلقاً).
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                    الاسم الكامل لصاحب الحساب
                  </label>
                  <input
                    type="text"
                    required
                    value={recName}
                    onChange={(e) => setRecName(e.target.value)}
                    placeholder="الاسم المسجل في الحساب"
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                      رقم الهاتف للتواصل والتحقق
                    </label>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={recPhone}
                      onChange={(e) => setRecPhone(e.target.value)}
                      placeholder="07XXXXXXXXX"
                      className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                      البريد الإلكتروني (اختياري)
                    </label>
                    <input
                      type="email"
                      dir="ltr"
                      value={recEmail}
                      onChange={(e) => setRecEmail(e.target.value)}
                      placeholder="إن كنت تتذكره"
                      className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">نوع الحساب</label>
                  <select
                    value={recAccountType}
                    onChange={(e) => setRecAccountType(e.target.value)}
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  >
                    <option value="merchant">صاحب محل / متجر / سوق / مول</option>
                    <option value="courier">مندوب توصيل</option>
                    <option value="customer">زبون</option>
                    <option value="super_admin">مدير</option>
                  </select>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                    معلومات تثبت ملكيتك للحساب
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={recProofDetails}
                    onChange={(e) => setRecProofDetails(e.target.value)}
                    placeholder="اذكر اسم المتجر أو المحافظة والمنطقة أو آخر طلب أو أي تفاصيل تساعد المدير على التحقق من هويتك..."
                    className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold py-3 text-sm font-bold disabled:opacity-60"
                >
                  {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                  <span>إرسال طلب استعادة الحساب إلى المدير</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleCompleteReset} className="space-y-4">
                {resetTokenInput ? (
                  <div className="rounded-xl border border-sq-success-border bg-sq-success-bg p-3 text-xs font-semibold text-sq-success-text">
                    تم التعرف على رابط إعادة التعيين الآمن تلقائياً. أدخل كلمة المرور الجديدة أدناه.
                  </div>
                ) : (
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                      رمز الاستعادة المؤقت (المرسل عبر البريد أو من المدير الرئيسي)
                    </label>
                    <input
                      type="text"
                      required
                      dir="ltr"
                      value={resetCodeInput}
                      onChange={(e) => setResetCodeInput(e.target.value)}
                      placeholder="مثال: SQ-A7K9-M2P4"
                      className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-center font-mono text-base font-bold tracking-wider uppercase focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                    />
                  </div>
                )}

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                    كلمة المرور الجديدة (6 أحرف على الأقل)
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                    تأكيد كلمة المرور الجديدة
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold py-3 text-sm font-bold disabled:opacity-60"
                >
                  {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                  <span>تعيين كلمة المرور الجديدة</span>
                </button>
              </form>
            )}
          </div>
        )}

        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-sq-ink">نوع الحساب</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('customer')}
                  className={`flex flex-col items-start gap-1.5 rounded-2xl border p-3.5 text-right transition-colors ${
                    role === 'customer'
                      ? 'border-sq-gold bg-sq-gold-soft'
                      : 'border-sq-border bg-sq-surface hover:bg-sq-elevated'
                  }`}
                >
                  <UserIcon
                    className={`h-5 w-5 ${role === 'customer' ? 'text-sq-gold-text' : 'text-sq-ink-muted'}`}
                  />
                  <span className="font-display text-sm font-bold text-sq-ink">زبون (مجاني)</span>
                  <span className="text-[11px] leading-snug text-sq-ink-muted">
                    تصفّح المتاجر واطلب منتجاتك مجاناً بالكامل
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setRole('merchant')}
                  className={`flex flex-col items-start gap-1.5 rounded-2xl border p-3.5 text-right transition-colors ${
                    role === 'merchant'
                      ? 'border-sq-gold bg-sq-gold-soft'
                      : 'border-sq-border bg-sq-surface hover:bg-sq-elevated'
                  }`}
                >
                  <StoreIcon
                    className={`h-5 w-5 ${role === 'merchant' ? 'text-sq-gold-text' : 'text-sq-ink-muted'}`}
                  />
                  <span className="font-display text-sm font-bold text-sq-ink">
                    صاحب محل أو سوق
                  </span>
                  <span className="text-[11px] leading-snug text-sq-ink-muted">
                    لوحة تحكم لمتجرك + فترة تجريبية مجانية 30 يوماً
                  </span>
                </button>
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                الاسم الثلاثي
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="مثال: أحمد محمد العلي"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  required
                  dir="ltr"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="07XXXXXXXXX"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المحافظة</label>
                <input
                  type="text"
                  value={governorate}
                  onChange={(e) => setGovernorate(e.target.value)}
                  placeholder="المحافظة"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المدينة</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="المدينة"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المنطقة</label>
                <input
                  type="text"
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  placeholder="المنطقة"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">الحي</label>
                <input
                  type="text"
                  value={neighborhood}
                  onChange={(e) => setNeighborhood(e.target.value)}
                  placeholder="الحي"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                العنوان التفصيلي (اختياري)
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="الشارع، رقم الدار، أقرب نقطة دالة"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                كلمة المرور (6 أحرف على الأقل)
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold py-3 text-sm font-semibold transition-colors disabled:opacity-60"
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              <span>{role === 'merchant' ? 'إنشاء حساب صاحب متجر' : 'إنشاء حساب زبون'}</span>
            </button>
          </form>
        )}

        {mode === 'bootstrap_admin' && !bootstrapStatus.hasSuperAdmin && (
          <form onSubmit={handleBootstrapAdmin} className="space-y-4">
            <div className="flex items-start gap-2.5 rounded-xl bg-sq-gold-soft p-3.5 text-xs leading-relaxed text-sq-gold-text">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                لا يوجد مدير عام مسجل بعد في قاعدة البيانات. أنشئ حساب المدير العام الآن لإدارة
                المتاجر والمستخدمين وإعدادات المنصة.
              </span>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                اسم المدير العام
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="الاسم الكامل"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  required
                  dir="ltr"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@souqna.app"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="07XXXXXXXXX"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                كلمة مرور قوية (8 أحرف على الأقل)
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            {bootstrapStatus.requireSetupCode && (
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                  رمز تفعيل المدير العام
                </label>
                <input
                  type="password"
                  required
                  value={setupCode}
                  onChange={(e) => setSetupCode(e.target.value)}
                  placeholder="أدخل رمز التفعيل المضبوط في متغيرات البيئة"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold py-3 text-sm font-semibold transition-colors disabled:opacity-60"
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              <span>تفعيل حساب المدير العام</span>
            </button>
          </form>
        )}
      </div>

      {/* Courier Registration & Super Admin Portal Guidance */}
      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => navigate('courier_register')}
          className="flex items-start gap-3 rounded-2xl border border-sq-gold/35 bg-sq-gold-soft p-4 text-right transition-colors hover:bg-sq-gold-soft"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sq-gold text-[#0B0C0C]">
            <Bike className="h-5 w-5" />
          </div>
          <div>
            <div className="font-display text-sm font-bold text-sq-gold-text">
              التسجيل كمندوب توصيل
            </div>
            <p className="mt-0.5 text-[11px] leading-relaxed text-sq-ink">
              قدّم طلب انضمام رسمي مع رفع الهوية والمركبة لاستلام طلبات التوصيل القريبة منك بعد
              توثيق الإدارة.
            </p>
          </div>
        </button>

        {!bootstrapStatus.hasSuperAdmin ? (
          <button
            type="button"
            onClick={() => {
              setMode('bootstrap_admin');
              setError(null);
              setSuccessMsg(null);
              setWarningMsg(null);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-start gap-3 rounded-2xl border border-sq-gold/40 bg-sq-surface p-4 text-right transition-colors hover:border-sq-gold hover:bg-sq-elevated"
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sq-gold-soft text-sq-gold-text">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-sm font-bold text-sq-gold-text">
                إعداد المدير العام (Super Admin)
              </div>
              <p className="mt-0.5 text-[11px] leading-relaxed text-sq-ink-muted">
                اضغط هنا لإنشاء حساب مالك المنصة لأول مرة وفتح لوحة الإدارة الشاملة مباشرة.
              </p>
            </div>
          </button>
        ) : (
          <div className="flex items-start gap-3 rounded-2xl border border-sq-border bg-sq-surface p-4 text-right">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sq-muted text-sq-gold-text">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-sm font-bold text-sq-ink">
                بوابة المدير العام (Super Admin)
              </div>
              <p className="mt-0.5 text-[11px] leading-relaxed text-sq-ink-muted">
                سجّل الدخول أعلاه ببريد وكلمة مرور حساب المدير العام ليتم توجيهك تلقائياً إلى لوحة
                الإدارة الكاملة.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
