import React, { useEffect, useState } from 'react';
import {
  Bell,
  Bike,
  ClipboardList,
  Crosshair,
  Crown,
  Headphones,
  KeyRound,
  Loader2,
  LogOut,
  MapPin,
  Moon,
  ShieldCheck,
  Smartphone,
  Store as StoreIcon,
  Sun,
  User as UserIcon,
} from 'lucide-react';
import { PWAInstallButton } from '../components/PWAWidgets';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import { COURIER_STATUS_LABELS, ROLE_LABELS, SUBSCRIPTION_STATUS_LABELS } from '../types';

export const AccountView: React.FC = () => {
  const {
    theme,
    setTheme,
    user,
    ownedStore,
    courierProfile,
    mySubscription,
    bootstrapStatus,
    unreadNotificationCount,
    updateUser,
    setSession,
    refreshBootstrap,
    logout,
    navigate,
    notify,
  } = useApp();

  const [claimCode, setClaimCode] = useState('');
  const [claimingAdmin, setClaimingAdmin] = useState(false);

  const [fullName, setFullName] = useState(user?.fullName || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [governorate, setGovernorate] = useState(user?.governorate || '');
  const [city, setCity] = useState(user?.city || '');
  const [district, setDistrict] = useState(user?.district || '');
  const [neighborhood, setNeighborhood] = useState(user?.neighborhood || '');
  const [address, setAddress] = useState(user?.address || '');
  const [latInput, setLatInput] = useState(user?.latitude !== null && user?.latitude !== undefined ? String(user.latitude) : '');
  const [lngInput, setLngInput] = useState(user?.longitude !== null && user?.longitude !== undefined ? String(user.longitude) : '');
  const [locating, setLocating] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    setFullName(user.fullName);
    setPhone(user.phone);
    setGovernorate(user.governorate || '');
    setCity(user.city || '');
    setDistrict(user.district || '');
    setNeighborhood(user.neighborhood || '');
    setAddress(user.address || '');
    setLatInput(user.latitude !== null ? String(user.latitude) : '');
    setLngInput(user.longitude !== null ? String(user.longitude) : '');
  }, [user]);

  const renderThemeSwitcherCard = () => (
    <section className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="font-display text-base sm:text-lg font-extrabold text-sq-ink">
            مظهر التطبيق (الوضع الداكن والفاتح)
          </h2>
          <p className="mt-0.5 text-xs text-sq-ink-muted">
            اختر المظهر المفضل لديك — يتم حفظ اختيارك تلقائياً على هذا الجهاز
          </p>
        </div>
        <span className="rounded-lg border border-sq-gold/35 bg-sq-gold-soft px-2.5 py-1 text-[11px] font-bold text-sq-gold-text">
          {theme === 'dark' ? 'الوضع الداكن مفعّل' : 'الوضع الفاتح مفعّل'}
        </span>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => setTheme('dark')}
          className={`group flex items-center gap-3.5 rounded-2xl border p-4 text-right transition-all active:scale-[0.985] ${
            theme === 'dark'
              ? 'border-sq-gold bg-sq-gold-soft shadow-sm'
              : 'border-sq-border bg-sq-elevated hover:border-sq-gold/45'
          }`}
        >
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#D4AF37]/50 bg-[#0B0C0C] text-[#E8CB73] shadow-sm">
            <Moon className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <span className="font-display text-sm font-extrabold text-sq-ink">
                الوضع الداكن الفاخر
              </span>
              {theme === 'dark' && (
                <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-sq-gold" />
              )}
            </div>
            <p className="mt-0.5 text-[11px] text-sq-ink-muted">
              أسود فحمي مع تفاصيل ذهبية متناسقة ومريحة للعين
            </p>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setTheme('light')}
          className={`group flex items-center gap-3.5 rounded-2xl border p-4 text-right transition-all active:scale-[0.985] ${
            theme === 'light'
              ? 'border-sq-gold bg-sq-gold-soft shadow-sm'
              : 'border-sq-border bg-sq-elevated hover:border-sq-gold/45'
          }`}
        >
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#E5DEC9] bg-[#F9F7F2] text-[#B68B22] shadow-sm">
            <Sun className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <span className="font-display text-sm font-extrabold text-sq-ink">
                الوضع الفاتح الأنيق
              </span>
              {theme === 'light' && (
                <span className="h-2.5 w-2.5 shrink-0 rounded-full bg-sq-gold" />
              )}
            </div>
            <p className="mt-0.5 text-[11px] text-sq-ink-muted">
              خلفيات عاجية مشرقة مع لمسات ذهبية راقية للنهار
            </p>
          </div>
        </button>
      </div>
    </section>
  );

  if (!user) {
    return (
      <div className="mx-auto max-w-2xl space-y-5">
        <div className="rounded-3xl border border-sq-gold-hairline bg-sq-surface p-8 text-center">
          <UserIcon className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/80" />
          <h1 className="font-display text-xl font-bold text-sq-ink">بيانات الزبون وحسابي</h1>
          <p className="mt-2 text-sm text-sq-ink-muted">
            سجّل دخولك أو أنشئ حساباً جديداً لحفظ بياناتك (الاسم الثلاثي، الهاتف، المحافظة، المنطقة،
            الحي، العنوان، والموقع الجغرافي).
          </p>
          <button
            type="button"
            onClick={() => navigate('auth')}
            className="mt-5 min-h-[46px] w-full max-w-sm rounded-xl btn-gold py-2.5 text-sm font-semibold"
          >
            تسجيل الدخول / إنشاء حساب
          </button>
        </div>

        <button
          type="button"
          onClick={() => navigate('support')}
          className="flex w-full min-h-[64px] items-center justify-between rounded-2xl border border-sq-gold/35 bg-sq-surface px-5 py-4 text-right hover:bg-sq-elevated"
        >
          <div className="flex items-center gap-3">
            <Headphones className="h-5 w-5 text-sq-gold-text" />
            <div>
              <div className="font-display text-sm font-bold text-sq-ink">الدعم الفني والتواصل المباشر</div>
              <div className="text-xs text-sq-ink-muted">تيليجرام @murtadaa199 · واتساب 07764327688</div>
            </div>
          </div>
        </button>

        {renderThemeSwitcherCard()}
      </div>
    );
  }

  const handleCaptureLocation = () => {
    if (!('geolocation' in navigator)) {
      notify('جهازك أو المتصفح لا يدعم تحديد الموقع الجغرافي تلقائياً.', 'error');
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatInput((Math.round(pos.coords.latitude * 1000000) / 1000000).toString());
        setLngInput((Math.round(pos.coords.longitude * 1000000) / 1000000).toString());
        setLocating(false);
        notify('تم التقاط موقعك الجغرافي بنجاح. اضغط «حفظ بيانات الزبون» لتثبيته.', 'success');
      },
      () => {
        setLocating(false);
        notify('تعذر التقاط الموقع. تأكد من تفعيل GPS ومنح الإذن للمتصفح.', 'error');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const parsedLat = latInput.trim() !== '' ? Number(latInput) : null;
      const parsedLng = lngInput.trim() !== '' ? Number(lngInput) : null;
      const { user: updated } = await api.updateProfile({
        fullName: fullName.trim(),
        phone: phone.trim(),
        governorate: governorate.trim(),
        city: city.trim(),
        district: district.trim(),
        neighborhood: neighborhood.trim(),
        address: address.trim(),
        latitude: parsedLat !== null && Number.isFinite(parsedLat) ? parsedLat : null,
        longitude: parsedLng !== null && Number.isFinite(parsedLng) ? parsedLng : null,
      });
      updateUser(updated);
      notify('تم حفظ بيانات الزبون والموقع الجغرافي بنجاح.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث البيانات.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleClaimSuperAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!claimCode.trim()) return;
    setClaimingAdmin(true);
    try {
      const res = await api.claimSuperAdmin(claimCode.trim());
      updateUser(res.user);
      await refreshBootstrap();
      setClaimCode('');
      notify('تم تفعيل صلاحية المدير العام (Super Admin) لحسابك بنجاح.', 'success');
      navigate('admin');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'رمز التفعيل غير صحيح.', 'error');
    } finally {
      setClaimingAdmin(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-sq-gold-hairline bg-sq-surface p-6">
        <div>
          <p className="text-xs font-semibold text-sq-gold-text">{ROLE_LABELS[user.role]}</p>
          <h1 className="mt-1 font-display text-2xl font-extrabold text-sq-ink">
            {user.fullName}
          </h1>
          <p className="mt-0.5 text-xs text-sq-ink-muted">{user.email}</p>
        </div>

        <button
          type="button"
          onClick={logout}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 py-2 text-xs font-semibold text-sq-danger-text transition-transform active:scale-[0.98]"
        >
          <LogOut className="h-4 w-4" />
          <span>تسجيل الخروج</span>
        </button>
      </div>

      {/* Appearance & Dark/Light Mode Switcher */}
      {renderThemeSwitcherCard()}

      {/* Role Shortcuts */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => navigate('orders')}
          className="flex min-h-[64px] items-center justify-between rounded-2xl border border-sq-border bg-sq-surface px-5 py-4 text-right hover:bg-sq-elevated"
        >
          <div className="flex items-center gap-3">
            <ClipboardList className="h-5 w-5 text-sq-gold-text" />
            <div>
              <div className="font-display text-sm font-bold text-sq-ink">طلباتي النقدية</div>
              <div className="text-xs text-sq-ink-muted">متابعة مشترياتك من جميع المتاجر</div>
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => navigate('notifications')}
          className="flex min-h-[64px] items-center justify-between rounded-2xl border border-sq-border bg-sq-surface px-5 py-4 text-right hover:bg-sq-elevated"
        >
          <div className="flex items-center gap-3">
            <Bell className="h-5 w-5 text-sq-gold-text" />
            <div>
              <div className="font-display text-sm font-bold text-sq-ink">
                مركز الإشعارات وتنبيهات الهاتف
              </div>
              <div className="text-xs text-sq-ink-muted">
                تفعيل الإشعارات الفورية ومراجعة التنبيهات
              </div>
            </div>
          </div>
          {unreadNotificationCount > 0 && (
            <span className="flex h-6 min-w-[24px] items-center justify-center rounded-full bg-[#B42318] px-1.5 font-mono text-xs font-bold text-white tabular-nums">
              {unreadNotificationCount}
            </span>
          )}
        </button>

        {(user.role === 'merchant' || user.role === 'customer') && (
          <button
            type="button"
            onClick={() => navigate('merchant')}
            className="flex min-h-[64px] items-center justify-between rounded-2xl border border-sq-gold/30 bg-sq-gold-soft px-5 py-4 text-right hover:bg-sq-gold-soft"
          >
            <div className="flex items-center gap-3">
              <StoreIcon className="h-5 w-5 text-sq-gold-text" />
              <div>
                <div className="font-display text-sm font-bold text-sq-gold-text">
                  {user.role === 'merchant'
                    ? ownedStore
                      ? ownedStore.name
                      : 'إنشاء متجري'
                    : 'افتح متجرك على سوقنا'}
                </div>
                <div className="text-xs text-sq-ink">
                  {user.role === 'merchant'
                    ? 'الدخول إلى لوحة تحكم المتجر المستقلة'
                    : 'فعّل متجرك على نفس حسابك الحالي دون إنشاء حساب ثانٍ'}
                </div>
              </div>
            </div>
          </button>
        )}

        {user.role === 'courier' && (
          <button
            type="button"
            onClick={() => navigate('courier')}
            className="flex min-h-[64px] items-center justify-between rounded-2xl border border-sq-gold/30 bg-sq-gold-soft px-5 py-4 text-right hover:bg-sq-gold-soft"
          >
            <div className="flex items-center gap-3">
              <Bike className="h-5 w-5 text-sq-gold-text" />
              <div>
                <div className="font-display text-sm font-bold text-sq-gold-text">
                  لوحة مندوب التوصيل
                </div>
                <div className="text-xs text-sq-ink">
                  {courierProfile
                    ? `حالة التوثيق: ${COURIER_STATUS_LABELS[courierProfile.verificationStatus]}`
                    : 'متابعة طلبات التوصيل المتاحة والنشطة'}
                </div>
              </div>
            </div>
          </button>
        )}

        {(user.role === 'customer' || user.role === 'merchant') && (
          <button
            type="button"
            onClick={() => navigate('courier_register')}
            className="flex min-h-[64px] items-center justify-between rounded-2xl border border-sq-border bg-sq-surface px-5 py-4 text-right hover:bg-sq-elevated"
          >
            <div className="flex items-center gap-3">
              <Bike className="h-5 w-5 text-sq-gold-text" />
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">
                  التسجيل كمندوب توصيل
                </div>
                <div className="text-xs text-sq-ink-muted">
                  قدّم طلب الانضمام لشبكة مندوبي سوقنا الموثقين
                </div>
              </div>
            </div>
          </button>
        )}

        {user.role === 'super_admin' && (
          <button
            type="button"
            onClick={() => navigate('admin')}
            className="flex min-h-[64px] items-center justify-between rounded-2xl border border-sq-gold/30 bg-sq-gold-soft px-5 py-4 text-right hover:bg-sq-gold-soft"
          >
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-sq-gold-text" />
              <div>
                <div className="font-display text-sm font-bold text-sq-gold-text">لوحة المدير العام</div>
                <div className="text-xs text-sq-ink">
                  إدارة المتاجر والمندوبين والاشتراكات والدعم والإعدادات
                </div>
              </div>
            </div>
          </button>
        )}

        {(user.role === 'merchant' || user.role === 'courier') && (
          <button
            type="button"
            onClick={() => navigate('subscription')}
            className={`flex min-h-[64px] items-center justify-between rounded-2xl border px-5 py-4 text-right transition-colors ${
              mySubscription &&
              (mySubscription.status === 'expired' || mySubscription.status === 'suspended')
                ? 'border-sq-danger-border bg-sq-danger-bg'
                : 'border-sq-gold/35 bg-sq-gold-soft/50 hover:border-sq-gold'
            }`}
          >
            <div className="flex items-center gap-3">
              <Crown className="h-5 w-5 text-sq-gold-text" />
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">
                  اشتراكي الشهري والتجديد
                </div>
                <div className="text-xs text-sq-ink-muted">
                  {mySubscription
                    ? `الحالة: ${SUBSCRIPTION_STATUS_LABELS[mySubscription.status]} · متبقي ${mySubscription.daysRemaining} يوم`
                    : 'عرض حالة الاشتراك وطلب التجديد عبر الإدارة'}
                </div>
              </div>
            </div>
          </button>
        )}

        <button
          type="button"
          onClick={() => navigate('support')}
          className="flex min-h-[64px] items-center justify-between rounded-2xl border border-sq-border bg-sq-surface px-5 py-4 text-right hover:border-sq-gold/50 hover:bg-sq-elevated"
        >
          <div className="flex items-center gap-3">
            <Headphones className="h-5 w-5 text-sq-gold-text" />
            <div>
              <div className="font-display text-sm font-bold text-sq-ink">الدعم الفني والشكاوى</div>
              <div className="text-xs text-sq-ink-muted">
                تواصل عبر تيليجرام وواتساب أو افتح تذكرة دعم داخل التطبيق
              </div>
            </div>
          </div>
        </button>
      </div>

      {/* Secure Super Admin Role Activation via Environment Secret (only shown when SUPER_ADMIN_SETUP_CODE is configured and no Super Admin exists) */}
      {bootstrapStatus.requireSetupCode && !bootstrapStatus.hasSuperAdmin && user.role !== 'super_admin' && (
        <form
          onSubmit={handleClaimSuperAdmin}
          className="rounded-3xl border border-sq-gold/35 bg-sq-gold-soft/55 p-5 space-y-3"
        >
          <div className="flex items-start gap-2.5">
            <KeyRound className="mt-0.5 h-5 w-5 shrink-0 text-sq-gold-text" />
            <div>
              <h2 className="font-display text-sm font-bold text-sq-ink">
                تفعيل صلاحية المدير العام (Super Admin) لمالك المنصة
              </h2>
              <p className="mt-0.5 text-xs text-sq-ink-muted">
                إذا كنت مالك المنصة، أدخل رمز التفعيل المضبوط في متغيرات البيئة لفتح لوحة الإدارة
                العامة مباشرة لهذا الحساب.
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              type="password"
              required
              value={claimCode}
              onChange={(e) => setClaimCode(e.target.value)}
              placeholder="أدخل رمز تفعيل المدير العام"
              className="min-h-[44px] flex-1 rounded-xl border border-sq-border bg-sq-surface px-3.5 text-sm focus:border-sq-gold focus:outline-none"
            />
            <button
              type="submit"
              disabled={claimingAdmin}
              className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl btn-gold px-5 text-xs font-bold disabled:opacity-60"
            >
              {claimingAdmin && <Loader2 className="h-4 w-4 animate-spin" />}
              <span>تفعيل صلاحية المدير</span>
            </button>
          </div>
        </form>
      )}

      {/* Complete Customer Data & Geolocation Form */}
      <form
        onSubmit={handleSaveProfile}
        className="rounded-3xl border border-sq-border bg-sq-surface p-6 space-y-5"
      >
        <div>
          <h2 className="font-display text-lg font-bold text-sq-ink">
            صفحة بيانات الزبون والعنوان الجغرافي
          </h2>
          <p className="mt-1 text-xs text-sq-ink-muted">
            تُستخدم هذه البيانات تلقائياً عند إتمام أي طلب توصيل أو استلام من المحل
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
              الاسم الثلاثي
            </label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="الاسم الأول، الأب، الجد"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">رقم الهاتف</label>
            <input
              type="tel"
              required
              dir="ltr"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="07XXXXXXXXX"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المحافظة</label>
            <input
              type="text"
              value={governorate}
              onChange={(e) => setGovernorate(e.target.value)}
              placeholder="مثال: بغداد / البصرة / الرياض"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المدينة</label>
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="اسم المدينة"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">المنطقة</label>
            <input
              type="text"
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              placeholder="مثال: الكرادة / المنصور"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">الحي</label>
            <input
              type="text"
              value={neighborhood}
              onChange={(e) => setNeighborhood(e.target.value)}
              placeholder="اسم الحي أو المحلة"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
            العنوان التفصيلي
          </label>
          <textarea
            rows={2}
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="الشارع، رقم الزقاق، رقم الدار، وأقرب نقطة دالة"
            className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-sm focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
          />
        </div>

        {/* Geolocation Capture Box */}
        <div className="rounded-2xl border border-sq-border bg-sq-elevated p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-sq-gold-text" />
              <div>
                <div className="text-sm font-bold text-sq-ink">الموقع الجغرافي (GPS)</div>
                <div className="text-xs text-sq-ink-muted">
                  التقط إحداثيات موقعك لتسريع وصول التوصيل بدقة
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={locating}
                onClick={handleCaptureLocation}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl btn-gold px-4 py-2 text-xs font-semibold disabled:opacity-60"
              >
                {locating ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Crosshair className="h-4 w-4" />
                )}
                <span>تحديد موقعي الآن</span>
              </button>
              {(latInput || lngInput) && (
                <button
                  type="button"
                  onClick={() => {
                    setLatInput('');
                    setLngInput('');
                  }}
                  className="min-h-[42px] rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink-muted hover:text-sq-ink"
                >
                  مسح
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-[11px] font-medium text-sq-ink-muted">
                خط العرض (Latitude)
              </label>
              <input
                type="text"
                dir="ltr"
                value={latInput}
                onChange={(e) => setLatInput(e.target.value)}
                placeholder="33.315200"
                className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-left font-mono text-xs tabular-nums focus:border-sq-gold focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-medium text-sq-ink-muted">
                خط الطول (Longitude)
              </label>
              <input
                type="text"
                dir="ltr"
                value={lngInput}
                onChange={(e) => setLngInput(e.target.value)}
                placeholder="44.366100"
                className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-left font-mono text-xs tabular-nums focus:border-sq-gold focus:outline-none"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl btn-gold px-6 py-2.5 text-sm font-semibold disabled:opacity-60"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          <span>حفظ بيانات الزبون</span>
        </button>
      </form>

      {/* Mobile App & Android APK Readiness */}
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-6 space-y-4">
        <div className="flex items-start gap-3">
          <Smartphone className="mt-0.5 h-5 w-5 text-sq-gold-text" />
          <div>
            <h2 className="font-display text-base font-bold text-sq-ink">
              تطبيق الهاتف وتجهيز Android APK
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-sq-ink-muted">
              التطبيق مبني كـ PWA قابل للتثبيت الفوري على الهواتف، ومجهّز بإعدادات{' '}
              <span className="font-mono text-sq-ink">capacitor.config.json</span> وملفات
              الأيقونات القياسية للتحويل المباشر إلى تطبيق Android APK مستقبلاً.
            </p>
          </div>
        </div>
        <PWAInstallButton variant="full" />
      </div>
    </div>
  );
};
