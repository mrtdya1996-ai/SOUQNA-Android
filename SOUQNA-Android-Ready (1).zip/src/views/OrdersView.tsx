import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  Banknote,
  Bike,
  ClipboardList,
  Download,
  FileText,
  Flag,
  History,
  KeyRound,
  Loader2,
  MapPin,
  Phone,
  ReceiptText,
  RefreshCw,
  X,
  XCircle,
} from 'lucide-react';
import { ComplaintModal } from '../components/ComplaintModal';
import { OrderInvoiceModal } from '../components/OrderInvoiceModal';
import { useApp } from '../context/AppContext';
import { api, formatDateAr, formatPrice, resolveMediaUrl } from '../lib/api';
import {
  CANCEL_REASON_PRESETS,
  COURIER_VEHICLE_LABELS,
  DELIVERY_STATUS_LABELS,
  FULFILLMENT_LABELS,
  ORDER_STATUS_LABELS,
  ROLE_LABELS,
  formatOrderItemOptionsSummary,
  type ComplaintTargetType,
  type Order,
  type OrderStatus,
} from '../types';

const STATUS_STEPS: OrderStatus[] = [
  'pending',
  'confirmed',
  'preparing',
  'ready',
  'out_for_delivery',
  'delivered',
];

const EVENT_TYPE_LABELS: Record<string, string> = {
  created: 'إنشاء الطلب',
  status_changed: 'تحديث الحالة',
  cancelled: 'إلغاء الطلب',
  cancel_requested: 'طلب إلغاء بعد بدء التجهيز',
  rejected: 'رفض الطلب',
  stock_restored: 'إعادة الكمية إلى المخزون',
};

export const OrdersView: React.FC = () => {
  const {
    user,
    bootstrapStatus,
    focusedOrderId,
    clearFocusedOrder,
    navigate,
    openStore,
    notify,
  } = useApp();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelTarget, setCancelTarget] = useState<Order | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<string>(CANCEL_REASON_PRESETS[0]);
  const [customReason, setCustomReason] = useState('');
  const [submittingCancel, setSubmittingCancel] = useState(false);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);
  const [complaintTarget, setComplaintTarget] = useState<{
    targetType: ComplaintTargetType;
    targetId: string;
    targetName: string;
    orderId: string;
    deliveryId?: string | null;
  } | null>(null);

  const loadOrders = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const res = await api.getMyOrders();
      setOrders(Array.isArray(res?.orders) ? res.orders : []);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحميل الطلبات.', 'error');
    } finally {
      setLoading(false);
    }
  }, [user, notify]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  // Auto-scroll to focused order when arriving from a Push/SSE Notification
  useEffect(() => {
    if (!focusedOrderId || loading || orders.length === 0) return;
    const el = document.getElementById(`order-card-${focusedOrderId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    const timer = window.setTimeout(() => {
      clearFocusedOrder();
    }, 6000);
    return () => window.clearTimeout(timer);
  }, [focusedOrderId, loading, orders.length, clearFocusedOrder]);

  const openCancelModal = (order: Order) => {
    setCancelTarget(order);
    setSelectedPreset(CANCEL_REASON_PRESETS[0]);
    setCustomReason('');
  };

  const handleConfirmCancel = async () => {
    if (!cancelTarget) return;
    const finalReason =
      selectedPreset === 'سبب آخر' ? customReason.trim() : `${selectedPreset}${customReason.trim() ? ` — ${customReason.trim()}` : ''}`;

    if (finalReason.length < 2) {
      notify('يرجى كتابة سبب الإلغاء قبل التأكيد.', 'error');
      return;
    }

    setSubmittingCancel(true);
    try {
      const res = await api.cancelMyOrder(cancelTarget.id, finalReason);
      setOrders((prev) => prev.map((o) => (o.id === res.order.id ? res.order : o)));
      setCancelTarget(null);
      notify(res.message, res.mode === 'cancelled' ? 'info' : 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إلغاء الطلب.', 'error');
    } finally {
      setSubmittingCancel(false);
    }
  };

  if (!user) {
    return (
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
        <ClipboardList className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/70" />
        <h1 className="font-display text-xl font-bold text-sq-ink">سجل الطلبات</h1>
        <p className="mt-2 text-sm text-sq-ink-muted">
          سجّل دخولك لمتابعة طلبات الشراء النقدية وحالة توصيلها من المتاجر.
        </p>
        <button
          type="button"
          onClick={() => navigate('auth')}
          className="mt-5 min-h-[46px] rounded-xl btn-gold px-6 py-2.5 text-sm font-semibold"
        >
          تسجيل الدخول
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-sq-ink">
            طلباتي ومشترياتي
          </h1>
          <p className="mt-1 text-sm text-sq-ink-muted">
            {user.role === 'merchant'
              ? 'طلباتك الشخصية من المتاجر الأخرى (لإدارة طلبات متجرك افتح لوحة متجري)'
              : 'تابع جميع طلباتك النقدية ومراحل تجهيزها أو إلغائها مع سجل التوثيق الكامل'}
          </p>
        </div>

        <button
          type="button"
          onClick={loadOrders}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-sq-border bg-sq-surface px-4 py-2 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
        >
          <RefreshCw className="h-4 w-4" />
          <span>تحديث</span>
        </button>
      </div>

      {loading ? (
        <div className="flex min-h-[220px] items-center justify-center gap-2 text-sm text-sq-ink-muted">
          <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
          <span>جاري تحميل طلباتك...</span>
        </div>
      ) : orders.length === 0 ? (
        <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
          <ClipboardList className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/60" />
          <h2 className="font-display text-lg font-bold text-sq-ink">لا توجد طلبات حتى الآن</h2>
          <p className="mt-2 text-sm text-sq-ink-muted">
            عند إتمام أي طلب شراء من أحد متاجر سوقنا سيظهر هنا مع تفاصيله الكاملة.
          </p>
          <button
            type="button"
            onClick={() => navigate('home')}
            className="mt-5 min-h-[46px] rounded-xl btn-gold px-6 py-2.5 text-sm font-semibold"
          >
            استكشف المتاجر
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => {
            const currentStep = STATUS_STEPS.indexOf(order.status);
            const isFocused = focusedOrderId === order.id;
            const canCancel =
              order.status === 'pending' ||
              order.status === 'confirmed' ||
              order.status === 'preparing' ||
              order.status === 'ready' ||
              order.status === 'out_for_delivery';
            const isInPreparation =
              order.status === 'preparing' ||
              order.status === 'ready' ||
              order.status === 'out_for_delivery';
            const hasPendingCancelRequest = (order.events || []).some(
              (ev) => ev.eventType === 'cancel_requested'
            );

            return (
              <div
                key={order.id}
                id={`order-card-${order.id}`}
                className={`overflow-hidden rounded-2xl border bg-sq-surface transition-all ${
                  isFocused
                    ? 'border-sq-gold ring-2 ring-sq-gold/30 shadow-md'
                    : 'border-sq-border'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-sq-border bg-sq-elevated px-5 py-3.5">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-sq-ink-muted">
                    <span className="font-mono text-sm font-semibold text-sq-ink">
                      {order.orderNumber}
                    </span>
                    <span aria-hidden="true">·</span>
                    <button
                      type="button"
                      onClick={() => openStore(order.storeId)}
                      className="font-semibold text-sq-gold-text hover:underline"
                    >
                      {order.storeName}
                    </button>
                    <span aria-hidden="true">·</span>
                    <span className="font-semibold text-sq-ink">
                      {FULFILLMENT_LABELS[order.fulfillmentMethod]}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{formatDateAr(order.createdAt)}</span>
                  </div>

                  <span
                    className={`text-xs font-bold ${
                      order.status === 'cancelled' || order.status === 'rejected'
                        ? 'text-sq-danger-text'
                        : order.status === 'delivered'
                        ? 'text-sq-gold-text'
                        : 'text-sq-warning-text'
                    }`}
                  >
                    {ORDER_STATUS_LABELS[order.status]}
                  </span>
                </div>

                {/* Progress Bar (active orders) or Rejected/Cancelled detailed audit notice */}
                {order.status !== 'cancelled' && order.status !== 'rejected' ? (
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 px-5 pt-4">
                    {STATUS_STEPS.map((step, idx) => (
                      <div key={step} className="space-y-1">
                        <div
                          className={`h-1.5 rounded-full ${
                            idx <= currentStep ? 'bg-sq-gold' : 'bg-sq-muted'
                          }`}
                        />
                        <div className="text-[10px] text-sq-ink-muted truncate">
                          {ORDER_STATUS_LABELS[step]}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="mx-5 mt-4 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 py-3 text-xs text-sq-danger-text space-y-1">
                    <div className="font-bold">
                      {order.status === 'rejected'
                        ? 'تم رفض هذا الطلب من قِبل المتجر'
                        : 'تم إلغاء هذا الطلب'}
                    </div>
                    {order.cancelReason && (
                      <div>
                        <strong>السبب:</strong> {order.cancelReason}
                      </div>
                    )}
                    {order.cancelledByName && (
                      <div className="text-[11px] opacity-90">
                        بواسطة: {order.cancelledByName}
                        {order.cancelledByRole &&
                        ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]
                          ? ` (${ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]})`
                          : ''}
                        {order.cancelledAt ? ` · ${formatDateAr(order.cancelledAt)}` : ''}
                        {order.stockRestored ? ' · تمت إعادة الكمية إلى المخزون' : ''}
                      </div>
                    )}
                  </div>
                )}

                {hasPendingCancelRequest &&
                  order.status !== 'cancelled' &&
                  order.status !== 'rejected' &&
                  order.status !== 'delivered' && (
                    <div className="mx-5 mt-3 flex items-start gap-2 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3.5 py-2.5 text-xs text-sq-warning-text">
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                      <span>
                        تم إرسال طلب إلغاء عاجل لصاحب المتجر والمدير العام لكون الطلب قيد التجهيز
                        حالياً.
                      </span>
                    </div>
                  )}

                <div className="p-5 space-y-4">
                  <div className="divide-y divide-sq-border">
                    {order.items.map((item) => {
                      const optTags = formatOrderItemOptionsSummary(item.selectedOptions);
                      const printJob = item.selectedOptions?.printJob;
                      return (
                        <div key={item.id} className="py-2.5 space-y-1.5 text-sm">
                          <div className="flex items-center justify-between gap-2">
                            <div className="text-sq-ink">
                              <span className="font-semibold">{item.productName}</span>
                              <span className="mr-2 text-xs text-sq-ink-muted tabular-nums">
                                ({item.quantity} × {item.unit} ·{' '}
                                {formatPrice(item.unitPrice, bootstrapStatus.currency)})
                              </span>
                            </div>
                            <span className="font-mono text-xs font-semibold tabular-nums text-sq-ink shrink-0">
                              {formatPrice(item.lineTotal, bootstrapStatus.currency)}
                            </span>
                          </div>
                          {optTags.length > 0 && (
                            <div className="flex flex-wrap gap-1.5 text-[11px] font-medium text-sq-gold-text">
                              {optTags.map((tag, idx) => (
                                <span
                                  key={idx}
                                  className="rounded-md border border-sq-gold/35 bg-sq-gold-soft px-2 py-0.5"
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          )}
                          {printJob?.fileUrl && (
                            <div className="flex flex-wrap items-center gap-2 pt-0.5 text-xs">
                              <a
                                href={resolveMediaUrl(printJob.fileUrl)}
                                target="_blank"
                                rel="noopener noreferrer"
                                download={printJob.fileName}
                                className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-sq-gold/30 bg-sq-elevated px-3 py-1 text-xs font-semibold text-sq-gold-text hover:bg-sq-gold-soft"
                              >
                                <FileText className="h-3.5 w-3.5" />
                                <span className="truncate max-w-[200px]">{printJob.fileName}</span>
                                <Download className="h-3.5 w-3.5" />
                              </a>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex flex-wrap items-start justify-between gap-3 border-t border-sq-border pt-3 text-xs text-sq-ink-muted">
                    <div className="space-y-1">
                      <div className="font-semibold text-sq-ink">
                        المستلم: {order.customerName} ·{' '}
                        <span dir="ltr" className="font-mono">
                          {order.customerPhone}
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sq-gold-text" />
                        <span>
                          {[
                            order.governorate,
                            order.city,
                            order.district,
                            order.neighborhood,
                            order.deliveryAddress,
                          ]
                            .filter(Boolean)
                            .join(' — ')}
                        </span>
                      </div>
                      {order.latitude !== null && order.longitude !== null && (
                        <div dir="ltr" className="font-mono text-[11px] text-sq-gold-text">
                          GPS: {order.latitude.toFixed(5)}, {order.longitude.toFixed(5)}
                        </div>
                      )}
                      {order.notes && (
                        <div>
                          <strong>ملاحظاتك:</strong> {order.notes}
                        </div>
                      )}
                      {order.storePhone && (
                        <div className="flex items-center gap-1.5">
                          <Phone className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>هاتف المتجر:</span>
                          <span dir="ltr" className="font-mono">
                            {order.storePhone}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="text-left space-y-0.5">
                      <div className="flex items-center justify-end gap-1.5 text-xs text-sq-ink-muted">
                        <Banknote className="h-3.5 w-3.5 text-sq-gold-text" />
                        <span>الدفع نقداً عند الاستلام</span>
                      </div>
                      <div className="text-[11px] text-sq-ink-muted tabular-nums">
                        المنتجات: {formatPrice(order.subtotal, bootstrapStatus.currency)} · التوصيل:{' '}
                        {order.deliveryFee > 0
                          ? formatPrice(order.deliveryFee, bootstrapStatus.currency)
                          : 'مجاني'}
                      </div>
                      <div className="font-mono text-base font-bold text-sq-gold-text tabular-nums">
                        {formatPrice(order.totalAmount, bootstrapStatus.currency)}
                      </div>
                    </div>
                  </div>

                  {/* Live Delivery & Customer OTP Handover Box */}
                  {order.delivery && (
                    <div className="rounded-2xl border border-sq-gold/35 bg-sq-gold-soft/55 p-4 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Bike className="h-4 w-4 text-sq-gold-text" />
                          <span className="font-display text-sm font-bold text-sq-ink">
                            متابعة التوصيل عبر المندوب
                          </span>
                          <span className="font-mono text-xs text-sq-ink-muted">
                            {order.delivery.deliveryNumber}
                          </span>
                        </div>
                        <span
                          className={`text-xs font-bold ${
                            order.delivery.status === 'delivered'
                              ? 'text-sq-gold-text'
                              : order.delivery.status === 'cancelled'
                              ? 'text-sq-danger-text'
                              : 'text-sq-warning-text'
                          }`}
                        >
                          {DELIVERY_STATUS_LABELS[order.delivery.status]}
                        </span>
                      </div>

                      {order.delivery.courierName ? (
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-sq-ink">
                          <span>
                            <strong>المندوب:</strong> {order.delivery.courierName}
                          </span>
                          {order.delivery.courierPhone && (
                            <span className="inline-flex items-center gap-1">
                              <Phone className="h-3.5 w-3.5 text-sq-gold-text" />
                              <span dir="ltr" className="font-mono font-semibold">
                                {order.delivery.courierPhone}
                              </span>
                            </span>
                          )}
                          {order.delivery.courierVehicleType && (
                            <span className="text-sq-ink-muted">
                              المركبة: {COURIER_VEHICLE_LABELS[order.delivery.courierVehicleType]}
                              {order.delivery.courierPlateNumber
                                ? ` (${order.delivery.courierPlateNumber})`
                                : ''}
                            </span>
                          )}
                        </div>
                      ) : (
                        <p className="text-xs text-sq-ink-muted">
                          قام المتجر بطلب مندوب توصيل — بانتظار قبول أقرب مندوب متاح.
                        </p>
                      )}

                      {order.delivery.deliveryOtp &&
                        order.delivery.status !== 'delivered' &&
                        order.delivery.status !== 'cancelled' && (
                          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-sq-gold/30 bg-sq-surface px-4 py-3">
                            <div className="flex items-start gap-2 text-xs">
                              <KeyRound className="mt-0.5 h-4 w-4 shrink-0 text-sq-gold-text" />
                              <div>
                                <div className="font-bold text-sq-ink">
                                  رمز تأكيد استلام الطلب (OTP)
                                </div>
                                <div className="text-[11px] text-sq-ink-muted">
                                  أعطِ هذا الرمز للمندوب فقط عند استلامك الطلب فعلياً لإغلاق
                                  التوصيل.
                                </div>
                              </div>
                            </div>
                            <span
                              dir="ltr"
                              className="rounded-xl bg-sq-gold px-4 py-2 font-mono text-lg font-extrabold tracking-[0.2em] text-[#0B0C0C] tabular-nums"
                            >
                              {order.delivery.deliveryOtp}
                            </span>
                          </div>
                        )}

                      {order.delivery.otpVerified && (
                        <div className="text-xs font-semibold text-sq-gold-text">
                          تم التحقق من رمز الاستلام وتأكيد التسليم
                          {order.delivery.deliveredAt
                            ? ` في ${formatDateAr(order.delivery.deliveredAt)}`
                            : ''}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Audit Trail Log */}
                  {order.events && order.events.length > 0 && (
                    <details className="rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-xs">
                      <summary className="cursor-pointer list-none flex items-center gap-1.5 font-semibold text-sq-ink-muted hover:text-sq-ink">
                        <History className="h-3.5 w-3.5 text-sq-gold-text" />
                        <span>سجل حركات الطلب وتوثيق الإلغاء ({order.events.length})</span>
                      </summary>
                      <div className="mt-2.5 space-y-2 border-t border-sq-border pt-2.5">
                        {order.events.map((ev) => (
                          <div
                            key={ev.id}
                            className="flex flex-wrap items-baseline justify-between gap-2 text-[11px]"
                          >
                            <div className="text-sq-ink">
                              <strong>{EVENT_TYPE_LABELS[ev.eventType] || ev.eventType}</strong>
                              {ev.actorName ? ` · ${ev.actorName}` : ''}
                              {ev.reason ? ` — ${ev.reason}` : ''}
                            </div>
                            <span className="text-sq-ink-muted">{formatDateAr(ev.createdAt)}</span>
                          </div>
                        ))}
                      </div>
                    </details>
                  )}

                  <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setInvoiceOrder(order)}
                      className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-4 py-2 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                    >
                      <ReceiptText className="h-4 w-4 text-sq-gold-text" />
                      <span>عرض الفاتورة المفصلة</span>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setComplaintTarget({
                          targetType: 'store',
                          targetId: order.storeId,
                          targetName: `متجر ${order.storeName} (طلب ${order.orderNumber})`,
                          orderId: order.id,
                          deliveryId: order.delivery?.id ?? null,
                        })
                      }
                      className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink-muted hover:border-sq-danger-border hover:text-sq-danger-text"
                    >
                      <Flag className="h-3.5 w-3.5" />
                      <span>شكوى على المتجر</span>
                    </button>

                    {order.delivery?.courierId && (
                      <button
                        type="button"
                        onClick={() =>
                          setComplaintTarget({
                            targetType: 'courier',
                            targetId: order.delivery!.courierId!,
                            targetName: `المندوب ${order.delivery!.courierName || ''} (${order.delivery!.deliveryNumber})`,
                            orderId: order.id,
                            deliveryId: order.delivery!.id,
                          })
                        }
                        className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink-muted hover:border-sq-danger-border hover:text-sq-danger-text"
                      >
                        <Flag className="h-3.5 w-3.5" />
                        <span>شكوى على المندوب</span>
                      </button>
                    )}

                    {canCancel && (
                      <button
                        type="button"
                        onClick={() => openCancelModal(order)}
                        className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 py-2 text-xs font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
                      >
                        <XCircle className="h-4 w-4" />
                        <span>
                          {isInPreparation ? 'طلب إلغاء عاجل (بعد بدء التجهيز)' : 'إلغاء الطلب'}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Order Cancellation Modal with Mandatory Reason & Confirmation */}
      {cancelTarget && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="cancel-order-title"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-sq-border pb-3">
              <div>
                <h2
                  id="cancel-order-title"
                  className="font-display text-lg font-extrabold text-sq-ink"
                >
                  إلغاء الطلب {cancelTarget.orderNumber}
                </h2>
                <p className="text-xs text-sq-ink-muted">متجر {cancelTarget.storeName}</p>
              </div>
              <button
                type="button"
                onClick={() => setCancelTarget(null)}
                aria-label="إغلاق"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {cancelTarget.status === 'preparing' ||
            cancelTarget.status === 'ready' ||
            cancelTarget.status === 'out_for_delivery' ? (
              <div className="rounded-xl border border-sq-warning-border bg-sq-warning-bg p-3.5 text-xs leading-relaxed text-sq-warning-text">
                <strong>تنبيه مهم:</strong> بدأ المتجر بتجهيز طلبك حالياً (
                {ORDER_STATUS_LABELS[cancelTarget.status]}). عند تأكيد الإرسال، سيتم تسجيل سببك
                وإرسال إشعار عاجل لصاحب المتجر والمدير العام للبت في الإلغاء وفق صلاحيات الإدارة.
              </div>
            ) : (
              <div className="rounded-xl border border-sq-gold/35 bg-sq-gold-soft p-3.5 text-xs leading-relaxed text-sq-gold-text">
                سيتم إلغاء الطلب فوراً، وإعادة الكميات المحجوزة تلقائياً إلى مخزون المتجر، وإرسال
                إشعار فوري لصاحب المتجر مع تسجيل سبب الإلغاء في السجل.
              </div>
            )}

            <div className="space-y-2">
              <label className="block text-xs font-bold text-sq-ink">
                اختر سبب الإلغاء (مطلوب)
              </label>
              <div className="space-y-1.5">
                {CANCEL_REASON_PRESETS.map((preset) => (
                  <label
                    key={preset}
                    className={`flex cursor-pointer items-center gap-2.5 rounded-xl border px-3.5 py-2.5 text-xs font-medium transition-colors ${
                      selectedPreset === preset
                        ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                        : 'border-sq-border bg-sq-elevated text-sq-ink'
                    }`}
                  >
                    <input
                      type="radio"
                      name="cancelReason"
                      checked={selectedPreset === preset}
                      onChange={() => setSelectedPreset(preset)}
                      className="h-4 w-4 accent-[#D4AF37]"
                    />
                    <span>{preset}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-sq-ink">
                {selectedPreset === 'سبب آخر'
                  ? 'اكتب سبب الإلغاء بالتفصيل (مطلوب)'
                  : 'تفاصيل إضافية (اختياري)'}
              </label>
              <textarea
                rows={2}
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                placeholder="مثال: اخترت منتجاً خاطئاً بالخطأ أو أرغب بتعديل الكمية..."
                className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-xs focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setCancelTarget(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
              >
                تراجع والاحتفاظ بالطلب
              </button>
              <button
                type="button"
                disabled={submittingCancel}
                onClick={handleConfirmCancel}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#B42318] text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
              >
                {submittingCancel && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>
                  {cancelTarget.status === 'preparing' ||
                  cancelTarget.status === 'ready' ||
                  cancelTarget.status === 'out_for_delivery'
                    ? 'إرسال طلب الإلغاء'
                    : 'تأكيد إلغاء الطلب'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {invoiceOrder && (
        <OrderInvoiceModal
          order={invoiceOrder}
          currency={bootstrapStatus.currency}
          onClose={() => setInvoiceOrder(null)}
        />
      )}

      {complaintTarget && (
        <ComplaintModal
          targetType={complaintTarget.targetType}
          targetId={complaintTarget.targetId}
          targetName={complaintTarget.targetName}
          orderId={complaintTarget.orderId}
          deliveryId={complaintTarget.deliveryId}
          onClose={() => setComplaintTarget(null)}
        />
      )}
    </div>
  );
};
