import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  BadgeCheck,
  Bell,
  Bike,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Crown,
  Download,
  FileText,
  Flag,
  FolderKanban,
  History,
  KeyRound,
  LayoutDashboard,
  Loader2,
  LogOut,
  Megaphone,
  Package,
  Phone,
  ReceiptText,
  RefreshCw,
  ScrollText,
  Search,
  Send,
  ShieldCheck,
  Trash2,
  UserCog,
  X,
  XCircle,
} from 'lucide-react';
import { AdminAccountSection } from '../components/AdminAccountSection';
import { AdminCategoriesSection } from '../components/AdminCategoriesSection';
import { AdminComplaintsSection } from '../components/AdminComplaintsSection';
import { AdminCouriersSection } from '../components/AdminCouriersSection';
import { AdminPostsSection } from '../components/AdminPostsSection';
import { AdminRecoverySection } from '../components/AdminRecoverySection';
import { AdminSettingsSection } from '../components/AdminSettingsSection';
import { AdminSubscriptionsSection } from '../components/AdminSubscriptionsSection';
import { OrderInvoiceModal } from '../components/OrderInvoiceModal';
import { useApp } from '../context/AppContext';
import { api, formatDateAr, formatPrice, resolveMediaUrl } from '../lib/api';
import {
  ALL_STORE_TYPES,
  COURIER_VEHICLE_LABELS,
  DEFAULT_PAYMENT_METHODS,
  DELIVERY_STATUS_LABELS,
  FULFILLMENT_LABELS,
  ORDER_STATUS_LABELS,
  ROLE_LABELS,
  STORE_PLAN_LABELS,
  STORE_STATUS_LABELS,
  STORE_TYPE_LABELS,
  SUBSCRIPTION_STATUS_LABELS,
  formatOrderItemOptionsSummary,
  type AccountRecoveryRequest,
  type AdminAuditLog,
  type Complaint,
  type ComplaintStatus,
  type CourierProfile,
  type CourierVerificationStatus,
  type Delivery,
  type IssuedPasswordReset,
  type MarketplaceCategory,
  type NotificationItem,
  type Order,
  type OrderStatus,
  type PlatformOverview,
  type Product,
  type Store,
  type StorePlanName,
  type StorePost,
  type StorePostStatus,
  type StoreStatus,
  type StoreSubscription,
  type StoreSubscriptionStatus,
  type StoreType,
  type SubscriptionLog,
  type SubscriptionPaymentMethodsConfig,
  type SubscriptionPaymentRequest,
  type SubscriptionPlan,
  type SubscriptionSummaryStats,
  type User,
  type UserRole,
  type UserSubscription,
} from '../types';

type AdminTab =
  | 'overview'
  | 'subscriptions'
  | 'recovery'
  | 'stores'
  | 'categories'
  | 'posts'
  | 'couriers'
  | 'orders'
  | 'complaints'
  | 'products'
  | 'users'
  | 'notifications'
  | 'audit'
  | 'settings'
  | 'admin_account';
type AdminOrderFilter = 'all' | 'pending' | 'active_delivery' | 'cancelled' | 'delivered';
type AdminOrdersSubMode = 'orders' | 'deliveries';
type AdminNotifFilter = 'all' | 'orders' | 'cancellations' | 'visits' | 'system';

const ORDER_STATUS_LIST: OrderStatus[] = [
  'pending',
  'confirmed',
  'preparing',
  'ready',
  'out_for_delivery',
  'delivered',
  'rejected',
  'cancelled',
];

const NOTIF_TYPE_LABELS: Record<string, string> = {
  order_new: 'طلب جديد',
  order_updated: 'تحديث حالة طلب',
  order_cancelled: 'إلغاء طلب',
  order_rejected: 'رفض طلب',
  order_cancel_requested: 'طلب إلغاء عاجل',
  store_status: 'حالة متجر',
  store_visit: 'زيارة متجر',
  courier_status: 'حالة مندوب توصيل',
  delivery_new: 'طلب توصيل متاح',
  delivery_accepted: 'قبول مندوب لتوصيل',
  delivery_updated: 'تحديث حالة توصيل',
  delivery_completed: 'إتمام التوصيل',
  delivery_cancelled: 'إلغاء توصيل',
  complaint_new: 'تذكرة دعم / شكوى جديدة',
  complaint_reply: 'رد الدعم الفني',
  subscription_alert: 'تنبيه اشتراك',
  account_recovery: 'طلب استعادة حساب',
  system: 'تنبيه إداري / نظام',
};

const EVENT_TYPE_LABELS: Record<string, string> = {
  created: 'إنشاء الطلب',
  status_changed: 'تحديث الحالة',
  cancelled: 'إلغاء الطلب',
  cancel_requested: 'طلب إلغاء عاجل بعد التجهيز',
  rejected: 'رفض الطلب',
  stock_restored: 'إعادة الكمية للمخزون',
};

export const AdminDashboardView: React.FC = () => {
  const {
    user,
    authReady,
    focusedOrderId,
    clearFocusedOrder,
    refreshBootstrap,
    navigate,
    openStore,
    notify,
    logout,
  } = useApp();
  const [tab, setTab] = useState<AdminTab>('overview');
  const [loading, setLoading] = useState(true);
  const [overview, setOverview] = useState<PlatformOverview | null>(null);
  const [stores, setStores] = useState<Store[]>([]);
  const [categories, setCategories] = useState<MarketplaceCategory[]>([]);
  const [posts, setPosts] = useState<StorePost[]>([]);
  const [couriers, setCouriers] = useState<CourierProfile[]>([]);
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [subscriptions, setSubscriptions] = useState<StoreSubscription[]>([]);
  const [userSubscriptions, setUserSubscriptions] = useState<UserSubscription[]>([]);
  const [subStats, setSubStats] = useState<SubscriptionSummaryStats | null>(null);
  const [subLogs, setSubLogs] = useState<SubscriptionLog[]>([]);
  const [subPlans, setSubPlans] = useState<SubscriptionPlan[]>([]);
  const [paymentMethods, setPaymentMethods] =
    useState<SubscriptionPaymentMethodsConfig>(DEFAULT_PAYMENT_METHODS);
  const [paymentRequests, setPaymentRequests] = useState<SubscriptionPaymentRequest[]>([]);
  const [recoveryRequests, setRecoveryRequests] = useState<AccountRecoveryRequest[]>([]);
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [adminNotifications, setAdminNotifications] = useState<NotificationItem[]>([]);
  const [savingSettings, setSavingSettings] = useState(false);

  // Filters & inline states
  const [storeSearch, setStoreSearch] = useState('');
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<UserRole | 'all'>('all');
  const [storeStatusFilter, setStoreStatusFilter] = useState<StoreStatus | 'all'>('all');
  const [storeTypeFilter, setStoreTypeFilter] = useState<StoreType | 'all'>('all');
  const [ordersSubMode, setOrdersSubMode] = useState<AdminOrdersSubMode>('orders');
  const [orderFilter, setOrderFilter] = useState<AdminOrderFilter>('all');
  const [notifFilter, setNotifFilter] = useState<AdminNotifFilter>('all');
  const [rejectingStoreId, setRejectingStoreId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);

  // Admin intervention alert modal
  const [alertModal, setAlertModal] = useState<{
    userId: string;
    recipientLabel: string;
    orderId?: string;
    storeId?: string;
  } | null>(null);
  const [alertTitle, setAlertTitle] = useState('');
  const [alertBody, setAlertBody] = useState('');

  // Sensitive Confirmation Modals
  const [confirmDeleteStore, setConfirmDeleteStore] = useState<Store | null>(null);
  const [confirmDeleteProduct, setConfirmDeleteProduct] = useState<Product | null>(null);
  const [adminOrderCloseModal, setAdminOrderCloseModal] = useState<{
    order: Order;
    status: 'cancelled' | 'rejected';
  } | null>(null);
  const [adminCloseReason, setAdminCloseReason] = useState('');
  const [adminRestoreStock, setAdminRestoreStock] = useState(true);
  const [busyAction, setBusyAction] = useState(false);

  const loadAll = useCallback(async () => {
    if (!user || user.role !== 'super_admin') return;
    setLoading(true);
    try {
      const results = await Promise.allSettled([
        api.getAdminOverview(),
        api.getAdminStores(),
        api.getAdminCategories(),
        api.getAdminPosts(),
        api.getAdminCouriers(),
        api.getAdminDeliveries(),
        api.getAdminComplaints(),
        api.getAdminSubscriptions(),
        api.getAdminAllSubscriptions(),
        api.getAdminRecoveryRequests(),
        api.getAdminAuditLogs(),
        api.getAdminProducts(),
        api.getAdminUsers(),
        api.getAdminOrders(),
        api.getAdminNotifications(),
      ]);

      const [
        ovRes,
        stRes,
        catRes,
        poRes,
        coRes,
        deRes,
        cmRes,
        suRes,
        allSubRes,
        recRes,
        auditRes,
        prRes,
        usRes,
        orRes,
        noRes,
      ] = results;

      if (ovRes.status === 'fulfilled' && ovRes.value?.overview) setOverview(ovRes.value.overview);
      if (stRes.status === 'fulfilled') setStores(Array.isArray(stRes.value?.stores) ? stRes.value.stores : []);
      if (catRes.status === 'fulfilled') setCategories(Array.isArray(catRes.value?.categories) ? catRes.value.categories : []);
      if (poRes.status === 'fulfilled') setPosts(Array.isArray(poRes.value?.posts) ? poRes.value.posts : []);
      if (coRes.status === 'fulfilled') setCouriers(Array.isArray(coRes.value?.couriers) ? coRes.value.couriers : []);
      if (deRes.status === 'fulfilled') setDeliveries(Array.isArray(deRes.value?.deliveries) ? deRes.value.deliveries : []);
      if (cmRes.status === 'fulfilled') setComplaints(Array.isArray(cmRes.value?.complaints) ? cmRes.value.complaints : []);
      if (suRes.status === 'fulfilled') setSubscriptions(Array.isArray(suRes.value?.subscriptions) ? suRes.value.subscriptions : []);
      if (allSubRes.status === 'fulfilled' && allSubRes.value) {
        setUserSubscriptions(Array.isArray(allSubRes.value.subscriptions) ? allSubRes.value.subscriptions : []);
        setSubStats(allSubRes.value.stats ?? null);
        setSubLogs(Array.isArray(allSubRes.value.logs) ? allSubRes.value.logs : []);
        setSubPlans(Array.isArray(allSubRes.value.plans) ? allSubRes.value.plans : []);
        setPaymentMethods(allSubRes.value.paymentMethods || DEFAULT_PAYMENT_METHODS);
        setPaymentRequests(Array.isArray(allSubRes.value.paymentRequests) ? allSubRes.value.paymentRequests : []);
      }
      if (recRes.status === 'fulfilled') setRecoveryRequests(Array.isArray(recRes.value?.requests) ? recRes.value.requests : []);
      if (auditRes.status === 'fulfilled') setAuditLogs(Array.isArray(auditRes.value?.logs) ? auditRes.value.logs : []);
      if (prRes.status === 'fulfilled') setProducts(Array.isArray(prRes.value?.products) ? prRes.value.products : []);
      if (usRes.status === 'fulfilled') setUsers(Array.isArray(usRes.value?.users) ? usRes.value.users : []);
      if (orRes.status === 'fulfilled') setOrders(Array.isArray(orRes.value?.orders) ? orRes.value.orders : []);
      if (noRes.status === 'fulfilled') setAdminNotifications(Array.isArray(noRes.value?.notifications) ? noRes.value.notifications : []);

      const failedCount = results.filter((r) => r.status === 'rejected').length;
      if (failedCount === results.length) {
        const firstErr = results[0].status === 'rejected' ? results[0].reason : null;
        notify(
          firstErr instanceof Error
            ? firstErr.message
            : 'تعذر الاتصال بالخادم لتحميل بيانات الإدارة. يرجى التحقق من الإنترنت والمحاولة مرة أخرى.',
          'error'
        );
      } else if (
        stRes.status === 'rejected' ||
        usRes.status === 'rejected' ||
        prRes.status === 'rejected'
      ) {
        notify('تعذر تحديث جزء من بيانات الإدارة، اضغط على زر التحديث لإعادة المحاولة.', 'error');
      }
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحميل بيانات الإدارة.', 'error');
    } finally {
      setLoading(false);
    }
  }, [user, notify]);

  const handleCreateCategory = async (payload: {
    name: string;
    description: string;
    storeType: StoreType | 'all';
    sortOrder: number;
    isActive: boolean;
  }): Promise<boolean> => {
    try {
      const { category } = await api.createAdminCategory(payload);
      setCategories((prev) =>
        [...prev, category].sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name))
      );
      notify(`تمت إضافة القسم «${category.name}» بنجاح.`, 'success');
      return true;
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إضافة القسم.', 'error');
      return false;
    }
  };

  const handleUpdateCategory = async (
    categoryId: string,
    payload: Partial<{
      name: string;
      description: string;
      storeType: StoreType | 'all';
      sortOrder: number;
      isActive: boolean;
    }>
  ): Promise<boolean> => {
    try {
      const { category } = await api.updateAdminCategory(categoryId, payload);
      setCategories((prev) =>
        prev
          .map((c) => (c.id === categoryId ? category : c))
          .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name))
      );
      notify('تم تحديث بيانات القسم بنجاح.', 'success');
      return true;
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث القسم.', 'error');
      return false;
    }
  };

  const handleDeleteCategory = async (categoryId: string) => {
    try {
      await api.deleteAdminCategory(categoryId);
      setCategories((prev) => prev.filter((c) => c.id !== categoryId));
      notify('تم حذف القسم بنجاح.', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حذف القسم.', 'error');
    }
  };

  const handleModeratePost = async (
    postId: string,
    status: StorePostStatus,
    reason?: string
  ) => {
    try {
      const res = await api.moderateAdminPost(postId, { status, moderationReason: reason });
      setPosts((prev) => prev.map((p) => (p.id === postId ? res.post : p)));
      notify(
        status === 'hidden' ? 'تم إخفاء المنشور وإشعار صاحب المتجر.' : 'تم إعادة إظهار المنشور.',
        'success'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث حالة المنشور.', 'error');
    }
  };

  const handleDeletePost = async (postId: string, reason?: string) => {
    try {
      await api.deleteAdminPost(postId, reason);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      notify('تم حذف المنشور المخالف وإشعار صاحب المتجر.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حذف المنشور.', 'error');
    }
  };

  useEffect(() => {
    void loadAll();
  }, [loadAll, tab]);

  // Keep Admin dashboard synchronized with live central DB when app resumes or reconnects
  useEffect(() => {
    if (!user || user.role !== 'super_admin') return;
    const handleSync = () => {
      if (document.visibilityState === 'visible') {
        void loadAll();
      }
    };
    const handleOnline = () => {
      void loadAll();
    };
    document.addEventListener('visibilitychange', handleSync);
    window.addEventListener('online', handleOnline);
    return () => {
      document.removeEventListener('visibilitychange', handleSync);
      window.removeEventListener('online', handleOnline);
    };
  }, [user, loadAll]);

  // Switch to Orders tab and expand focused order when coming from an Admin Push/SSE alert
  useEffect(() => {
    if (!focusedOrderId) return;
    setTab('orders');
    setOrdersSubMode('orders');
    setExpandedOrderId(focusedOrderId);
    if (loading || orders.length === 0) return;
    const el = document.getElementById(`admin-order-${focusedOrderId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    const timer = window.setTimeout(() => clearFocusedOrder(), 7000);
    return () => window.clearTimeout(timer);
  }, [focusedOrderId, loading, orders.length, clearFocusedOrder]);

  const filteredStores = useMemo(() => {
    const q = storeSearch.trim().toLowerCase();
    return stores.filter((s) => {
      if (storeStatusFilter !== 'all' && s.status !== storeStatusFilter) return false;
      if (storeTypeFilter !== 'all' && s.storeType !== storeTypeFilter) return false;
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        (s.ownerName || '').toLowerCase().includes(q) ||
        (s.ownerPhone || '').toLowerCase().includes(q) ||
        s.phone.toLowerCase().includes(q) ||
        s.city.toLowerCase().includes(q) ||
        (s.district || '').toLowerCase().includes(q)
      );
    });
  }, [stores, storeSearch, storeStatusFilter, storeTypeFilter]);

  const filteredProducts = useMemo(() => {
    const q = productSearch.trim().toLowerCase();
    if (!q) return products;
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.storeName || '').toLowerCase().includes(q)
    );
  }, [products, productSearch]);

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    return users.filter((u) => {
      if (userRoleFilter !== 'all' && u.role !== userRoleFilter) return false;
      if (!q) return true;
      return (
        u.fullName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.phone.toLowerCase().includes(q) ||
        (u.city || '').toLowerCase().includes(q)
      );
    });
  }, [users, userSearch, userRoleFilter]);

  const filteredOrders = useMemo(() => {
    if (orderFilter === 'all') return orders;
    if (orderFilter === 'pending') return orders.filter((o) => o.status === 'pending');
    if (orderFilter === 'active_delivery') {
      return orders.filter(
        (o) =>
          o.delivery &&
          o.delivery.status !== 'delivered' &&
          o.delivery.status !== 'cancelled'
      );
    }
    if (orderFilter === 'delivered') return orders.filter((o) => o.status === 'delivered');
    return orders.filter(
      (o) =>
        o.status === 'cancelled' ||
        o.status === 'rejected' ||
        (o.events || []).some((ev) => ev.eventType === 'cancel_requested')
    );
  }, [orders, orderFilter]);

  const filteredAdminNotifications = useMemo(() => {
    if (notifFilter === 'all') return adminNotifications;
    if (notifFilter === 'orders') {
      return adminNotifications.filter(
        (n) =>
          n.type === 'order_new' ||
          n.type === 'order_updated' ||
          n.type === 'delivery_new' ||
          n.type === 'delivery_accepted' ||
          n.type === 'delivery_updated' ||
          n.type === 'delivery_completed'
      );
    }
    if (notifFilter === 'cancellations') {
      return adminNotifications.filter(
        (n) =>
          n.type === 'order_cancelled' ||
          n.type === 'order_rejected' ||
          n.type === 'order_cancel_requested' ||
          n.type === 'delivery_cancelled'
      );
    }
    if (notifFilter === 'visits') {
      return adminNotifications.filter((n) => n.type === 'store_visit');
    }
    return adminNotifications.filter(
      (n) =>
        n.type === 'system' ||
        n.type === 'store_status' ||
        n.type === 'courier_status' ||
        n.type === 'complaint_new'
    );
  }, [adminNotifications, notifFilter]);

  useEffect(() => {
    if (authReady && !user) {
      navigate('auth');
    }
  }, [authReady, user, navigate]);

  if (!user) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center gap-2 text-sm text-sq-ink-muted">
        <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
        <span>جاري الانتقال إلى صفحة تسجيل الدخول الموحّد...</span>
      </div>
    );
  }

  if (user.role !== 'super_admin') {
    const userHomeView =
      user.role === 'merchant' ? 'merchant' : user.role === 'courier' ? 'courier' : 'home';

    return (
      <div className="mx-auto max-w-md py-6">
        <div className="rounded-3xl border border-sq-gold-hairline bg-sq-surface p-6 sm:p-8 shadow-2xl space-y-5 text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-[#D4AF37]/50 bg-[#0C0E0D] text-[#E8CB73] shadow-lg">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <div className="space-y-2">
            <p className="text-[11px] font-bold tracking-wide text-sq-gold-text">
              SOUQNA | صلاحيات المدير العام
            </p>
            <h1 className="font-display text-xl sm:text-2xl font-extrabold text-sq-ink">
              الوصول محصور بحساب المدير العام
            </h1>
            <p className="text-xs leading-relaxed text-sq-ink-muted">
              حسابك الحالي ({ROLE_LABELS[user.role]}) لا يملك صلاحية المدير العام (Super Admin). يتم
              تحديد الصلاحيات تلقائياً من قاعدة البيانات عبر تسجيل الدخول الموحّد.
            </p>
          </div>
          <div className="flex flex-col gap-2.5 pt-1">
            <button
              type="button"
              onClick={() => navigate(userHomeView)}
              className="min-h-[46px] w-full rounded-xl btn-gold px-5 text-sm font-bold"
            >
              الانتقال إلى واجهتي
            </button>
            <button
              type="button"
              onClick={() => navigate('home')}
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-5 text-xs font-semibold text-sq-ink"
            >
              العودة إلى الصفحة الرئيسية
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleStoreUpdate = async (
    storeId: string,
    payload: { status?: StoreStatus; isVerified?: boolean; rejectionReason?: string }
  ) => {
    try {
      const { store } = await api.updateAdminStore(storeId, payload);
      setStores((prev) => prev.map((s) => (s.id === store.id ? store : s)));
      if (rejectingStoreId === storeId) {
        setRejectingStoreId(null);
        setRejectionReason('');
      }
      notify('تم تحديث حالة المتجر بنجاح.', 'success');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث المتجر.', 'error');
    }
  };

  const handleDeleteStore = async (storeId: string) => {
    setBusyAction(true);
    try {
      await api.deleteAdminStore(storeId);
      setStores((prev) => prev.filter((s) => s.id !== storeId));
      setConfirmDeleteStore(null);
      notify('تم حذف المتجر نهائياً.', 'info');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حذف المتجر.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const handleToggleProduct = async (product: Product) => {
    try {
      const { product: updated } = await api.updateAdminProduct(product.id, {
        isAvailable: !product.isAvailable,
      });
      setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
      notify(
        updated.isAvailable ? 'تم إظهار المنتج للزبائن.' : 'تم إخفاء المنتج عن الزبائن.',
        'success'
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث المنتج.', 'error');
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    setBusyAction(true);
    try {
      await api.deleteAdminProduct(productId);
      setProducts((prev) => prev.filter((p) => p.id !== productId));
      setConfirmDeleteProduct(null);
      notify('تم حذف المنتج بنجاح.', 'info');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حذف المنتج.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const handleUserUpdate = async (
    userId: string,
    payload: { isActive?: boolean; role?: UserRole }
  ) => {
    try {
      const { user: updated } = await api.updateAdminUser(userId, payload);
      setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
      notify('تم تحديث بيانات الحساب بنجاح.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث الحساب.', 'error');
    }
  };

  const handleOrderStatusSelect = (order: Order, nextStatus: OrderStatus) => {
    if (nextStatus === 'cancelled' || nextStatus === 'rejected') {
      setAdminOrderCloseModal({ order, status: nextStatus });
      setAdminCloseReason('');
      setAdminRestoreStock(true);
      return;
    }
    void handleOrderStatusUpdate(order.id, nextStatus);
  };

  const handleOrderStatusUpdate = async (
    orderId: string,
    status: OrderStatus,
    options?: { reason?: string; restoreStock?: boolean }
  ) => {
    setBusyAction(true);
    try {
      const { order } = await api.updateAdminOrderStatus(orderId, status, options);
      setOrders((prev) => prev.map((o) => (o.id === order.id ? order : o)));
      setAdminOrderCloseModal(null);
      notify(`تم تحديث حالة الطلب إلى «${ORDER_STATUS_LABELS[status]}».`, 'success');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث حالة الطلب.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const handleSettingsUpdate = async (payload: {
    requireStoreApproval?: boolean;
    requireCourierApproval?: boolean;
    currency?: string;
    enabledStoreTypes?: StoreType[];
    trialDays?: number;
    appName?: string;
    supportPhone?: string;
    supportTelegram?: string;
    announcementText?: string;
  }) => {
    setSavingSettings(true);
    try {
      const updated = await api.updateAdminSettings(payload);
      setOverview((prev) =>
        prev
          ? {
              ...prev,
              currency: updated.currency,
              requireStoreApproval: updated.requireStoreApproval,
              requireCourierApproval: updated.requireCourierApproval,
              enabledStoreTypes: updated.enabledStoreTypes,
              trialDays: updated.trialDays,
              appName: updated.appName,
              supportPhone: updated.supportPhone,
              supportTelegram: updated.supportTelegram,
              announcementText: updated.announcementText,
            }
          : prev
      );
      await refreshBootstrap();
      notify('تم حفظ إعدادات المنصة بنجاح.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حفظ الإعدادات.', 'error');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleCourierUpdate = async (
    courierId: string,
    payload: { verificationStatus: CourierVerificationStatus; rejectionReason?: string }
  ) => {
    try {
      const { courier } = await api.updateAdminCourier(courierId, payload);
      setCouriers((prev) => prev.map((c) => (c.id === courier.id ? courier : c)));
      notify('تم تحديث حالة المندوب بنجاح.', 'success');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث بيانات المندوب.', 'error');
    }
  };

  const handleCancelAdminDelivery = async (deliveryId: string) => {
    try {
      await api.cancelAdminDelivery(deliveryId, 'إلغاء إداري لطلب التوصيل من قِبل المدير العام');
      notify('تم إلغاء طلب التوصيل وإشعار الأطراف المعنية.', 'info');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إلغاء طلب التوصيل.', 'error');
    }
  };

  const handleComplaintUpdate = async (
    complaintId: string,
    payload: {
      status: ComplaintStatus;
      adminNotes?: string;
      violationRecorded?: boolean;
      suspendTarget?: boolean;
      replyMessage?: string;
    }
  ) => {
    try {
      const { complaint } = await api.updateAdminComplaint(complaintId, payload);
      setComplaints((prev) => prev.map((c) => (c.id === complaint.id ? complaint : c)));
      notify(
        payload.suspendTarget
          ? 'تم تسجيل المخالفة وإيقاف الحساب المعني بنجاح.'
          : 'تم تحديث حالة التذكرة بنجاح.',
        'success'
      );
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث التذكرة.', 'error');
    }
  };

  const handleReplyComplaint = async (complaintId: string, message: string) => {
    try {
      const res = await api.replyComplaintMessage(complaintId, { message });
      setComplaints((prev) => prev.map((c) => (c.id === complaintId ? res.complaint : c)));
      notify('تم إرسال رد الدعم الفني وإشعار المستخدم فوراً.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال الرد.', 'error');
    }
  };

  const handleRunSubscriptionAction = async (
    userId: string,
    payload: {
      action: 'activate' | 'extend' | 'suspend' | 'reactivate' | 'record_payment' | 'set_dates';
      durationDays?: number;
      amountPaid?: number;
      monthlyFee?: number;
      planName?: string;
      startsAt?: string;
      expiresAt?: string;
      notes?: string;
    }
  ) => {
    try {
      await api.runAdminSubscriptionAction(userId, payload);
      notify('تم تنفيذ إجراء الاشتراك وتحديث سجل المدفوعات بنجاح.', 'success');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث الاشتراك.', 'error');
    }
  };

  const handleReviewPaymentRequest = async (
    requestId: string,
    payload: {
      decision: 'approve' | 'reject';
      rejectionReason?: string;
      adminNotes?: string;
      startsAt?: string;
      expiresAt?: string;
    }
  ) => {
    try {
      const res = await api.reviewAdminPaymentRequest(requestId, payload);
      setPaymentRequests(res.paymentRequests);
      setSubStats(res.stats);
      setSubLogs(res.logs);
      notify(
        payload.decision === 'approve'
          ? 'تم قبول إثبات الدفع وتفعيل الاشتراك تلقائياً بنجاح.'
          : 'تم رفض طلب الاشتراك وإشعار المستخدم بسبب الرفض.',
        payload.decision === 'approve' ? 'success' : 'info'
      );
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر مراجعة طلب الاشتراك.', 'error');
    }
  };

  const handleUpdateSubscriptionPlans = async (payload: {
    plans: Array<{
      id: string;
      name: string;
      priceIqd: number;
      durationDays: number;
      isActive: boolean;
    }>;
    paymentMethods: SubscriptionPaymentMethodsConfig;
  }) => {
    try {
      const res = await api.updateAdminSubscriptionPlans(payload);
      setSubPlans(res.plans);
      setPaymentMethods(res.paymentMethods);
      notify('تم حفظ أسعار باقات الاشتراك وأرقام الدفع الرسمية بنجاح.', 'success');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حفظ باقات الاشتراك.', 'error');
    }
  };

  const handleNotifyExpiring = async (userId?: string) => {
    try {
      const res = await api.notifyAdminExpiringSubscriptions(userId);
      notify(res.message, res.notifiedCount > 0 ? 'success' : 'info');
      await loadAll();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال تنبيهات الاشتراك.', 'error');
    }
  };

  const handleReviewRecovery = async (
    requestId: string,
    payload: {
      decision: 'approve' | 'reject';
      targetUserId?: string;
      rejectionReason?: string;
      adminNotes?: string;
    }
  ): Promise<IssuedPasswordReset | undefined> => {
    try {
      const res = await api.reviewAdminRecoveryRequest(requestId, payload);
      notify(
        payload.decision === 'approve'
          ? 'تمت الموافقة وإصدار رابط ورمز إعادة تعيين لمرة واحدة بنجاح.'
          : 'تم رفض طلب استعادة الحساب.',
        payload.decision === 'approve' ? 'success' : 'info'
      );
      await loadAll();
      return res.issuedReset;
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر معالجة طلب استعادة الحساب.', 'error');
      return undefined;
    }
  };

  const handleIssueDirectReset = async (
    userId: string,
    notes?: string
  ): Promise<IssuedPasswordReset | undefined> => {
    try {
      const res = await api.issueAdminPasswordReset(userId, notes);
      notify('تم إصدار رابط ورمز إعادة تعيين كلمة مرور لمرة واحدة بنجاح.', 'success');
      await loadAll();
      return res.issuedReset;
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إصدار رمز إعادة التعيين.', 'error');
      return undefined;
    }
  };

  const handleSubscriptionUpdate = async (
    storeId: string,
    payload: {
      planName: StorePlanName;
      status: StoreSubscriptionStatus;
      monthlyFee: number;
      expiresAt?: string;
      notes?: string;
    }
  ) => {
    try {
      const { subscription } = await api.updateAdminSubscription(storeId, payload);
      setSubscriptions((prev) => {
        const exists = prev.some((s) => s.storeId === storeId);
        return exists
          ? prev.map((s) => (s.storeId === storeId ? subscription : s))
          : [subscription, ...prev];
      });
      setStores((prev) =>
        prev.map((st) => (st.id === storeId ? { ...st, subscription } : st))
      );
      notify('تم حفظ إعدادات اشتراك المتجر بنجاح.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث الاشتراك.', 'error');
    }
  };

  const openInterventionModal = (params: {
    userId: string;
    recipientLabel: string;
    orderId?: string;
    storeId?: string;
    defaultTitle?: string;
  }) => {
    setAlertModal({
      userId: params.userId,
      recipientLabel: params.recipientLabel,
      orderId: params.orderId,
      storeId: params.storeId,
    });
    setAlertTitle(params.defaultTitle || 'تنبيه إداري من إدارة سوقنا');
    setAlertBody('');
  };

  const handleSendAdminIntervention = async () => {
    if (!alertModal) return;
    if (alertTitle.trim().length < 2 || alertBody.trim().length < 3) {
      notify('يرجى إدخال عنوان ونص التنبيه الإداري.', 'error');
      return;
    }
    setBusyAction(true);
    try {
      const { notification } = await api.sendAdminNotification({
        userId: alertModal.userId,
        title: alertTitle.trim(),
        body: alertBody.trim(),
        orderId: alertModal.orderId,
        storeId: alertModal.storeId,
      });
      setAdminNotifications((prev) => [notification, ...prev]);
      setAlertModal(null);
      notify('تم إرسال التنبيه الإداري الفوري بنجاح.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال التنبيه الإداري.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const currency = overview?.currency || 'د.ع';

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-3xl border border-[#D4AF37]/35 bg-[#0C0E0D] p-5 sm:p-6 text-white shadow-xl">
        <div className="pointer-events-none absolute -top-20 -left-16 h-56 w-56 rounded-full bg-[#D4AF37]/12 blur-3xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#D4AF37]/50 bg-[#151817] text-[#E8CB73]">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-bold tracking-wide text-[#E8CB73]">
                صلاحية المدير العام · Super Admin
              </p>
              <h1 className="mt-0.5 font-display text-2xl sm:text-3xl font-extrabold text-white">
                لوحة إدارة منصة SOUQNA | سوقنا
              </h1>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={loadAll}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[#D4AF37]/40 bg-[#171A18] px-4 py-2 text-xs font-bold text-[#F5F2EB] transition-all hover:border-[#D4AF37] hover:bg-[#1E2220] active:scale-[0.98]"
            >
              <RefreshCw className="h-4 w-4 text-[#E8CB73]" />
              <span>تحديث الإحصائيات</span>
            </button>
            <button
              type="button"
              onClick={() => void logout()}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-red-500/40 bg-red-950/40 px-4 py-2 text-xs font-bold text-red-200 transition-all hover:border-red-400 hover:bg-red-900/50 active:scale-[0.98]"
            >
              <LogOut className="h-4 w-4" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </div>
      </div>

      {/* Compact KPI Grid on inner tabs */}
      {overview && tab !== 'overview' && (
        <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-5">
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-xs text-sq-ink-muted">إجمالي المستخدمين</p>
            <p className="mt-1.5 font-mono text-2xl font-bold text-sq-ink tabular-nums">
              {overview.totalUsers}
            </p>
            <p className="mt-1 text-[11px] text-sq-ink-muted tabular-nums">
              {overview.totalCustomers} زبون · {overview.totalMerchants} تاجر ·{' '}
              {overview.totalCouriers} مندوب
            </p>
          </div>
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-xs text-sq-ink-muted">المتاجر المسجلة</p>
            <p className="mt-1.5 font-mono text-2xl font-bold text-sq-gold-text tabular-nums">
              {overview.totalStores}
            </p>
            <p className="mt-1 text-[11px] text-sq-ink-muted tabular-nums">
              {overview.activeStores} مقبول · {overview.pendingStores} قيد المراجعة
              {overview.rejectedStores > 0 ? ` · ${overview.rejectedStores} مرفوض` : ''}
            </p>
          </div>
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-xs text-sq-ink-muted">إجمالي المنتجات</p>
            <p className="mt-1.5 font-mono text-2xl font-bold text-sq-ink tabular-nums">
              {overview.totalProducts}
            </p>
          </div>
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-xs text-sq-ink-muted">الطلبات النقدية</p>
            <p className="mt-1.5 font-mono text-2xl font-bold text-sq-ink tabular-nums">
              {overview.totalOrders}
            </p>
            <p className="mt-1 text-[11px] text-sq-ink-muted tabular-nums">
              {overview.pendingOrders} جديد · {overview.deliveredOrders} مكتمل
              {overview.cancelledOrders > 0 ? ` · ${overview.cancelledOrders} ملغي` : ''}
            </p>
          </div>
          <div className="col-span-2 lg:col-span-1 rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-xs text-sq-ink-muted">حجم المبيعات النقدية (باستثناء الملغية)</p>
            <p className="mt-1.5 font-mono text-xl font-bold text-sq-gold-text tabular-nums">
              {formatPrice(overview.totalCashVolume, currency)}
            </p>
          </div>
        </div>
      )}

      {/* Admin Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto rounded-xl bg-sq-muted p-1 no-scrollbar">
        <button
          type="button"
          onClick={() => setTab('overview')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'overview' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          <LayoutDashboard className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>الرئيسية</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('subscriptions')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'subscriptions'
              ? 'bg-sq-surface text-sq-gold-text shadow-xs'
              : 'text-sq-ink-muted'
          }`}
        >
          <Crown className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>الاشتراكات ({userSubscriptions.length})</span>
          {paymentRequests.filter((r) => r.status === 'pending').length > 0 && (
            <span className="rounded-md bg-sq-gold px-1.5 py-0.5 font-mono text-[10px] font-extrabold text-[#0B0C0C]">
              {paymentRequests.filter((r) => r.status === 'pending').length}
            </span>
          )}
        </button>
        <button
          type="button"
          onClick={() => setTab('recovery')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'recovery'
              ? 'bg-sq-surface text-sq-gold-text shadow-xs'
              : 'text-sq-ink-muted'
          }`}
        >
          <KeyRound className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>استعادة الحسابات ({recoveryRequests.length})</span>
          {recoveryRequests.filter((r) => r.status === 'pending').length > 0 && (
            <span className="rounded-md bg-sq-warning-bg border border-sq-warning-border px-1.5 py-0.5 font-mono text-[10px] font-extrabold text-sq-warning-text">
              {recoveryRequests.filter((r) => r.status === 'pending').length}
            </span>
          )}
        </button>
        <button
          type="button"
          onClick={() => setTab('stores')}
          className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'stores' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          المتاجر ({stores.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('categories')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'categories'
              ? 'bg-sq-surface text-sq-gold-text shadow-xs'
              : 'text-sq-ink-muted'
          }`}
        >
          <FolderKanban className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>الأقسام ({categories.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('posts')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'posts' ? 'bg-sq-surface text-sq-gold-text shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          <Megaphone className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>المنشورات ({posts.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('couriers')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'couriers' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          <Bike className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>المندوبون ({couriers.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('orders')}
          className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'orders' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          الطلبات والتوصيل ({orders.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('complaints')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'complaints' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          <Flag className="h-3.5 w-3.5 text-sq-danger-text" />
          <span>الدعم والشكاوى ({complaints.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('products')}
          className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'products' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          المنتجات ({products.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('users')}
          className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'users' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          المستخدمون ({users.length})
        </button>
        <button
          type="button"
          onClick={() => setTab('notifications')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'notifications' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          <Bell className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>الإشعارات ({adminNotifications.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('audit')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'audit' ? 'bg-sq-surface text-sq-gold-text shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          <ScrollText className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>سجل التغييرات ({auditLogs.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setTab('settings')}
          className={`min-h-[42px] rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'settings' ? 'bg-sq-surface text-sq-ink shadow-xs' : 'text-sq-ink-muted'
          }`}
        >
          إعدادات المنصة
        </button>
        <button
          type="button"
          onClick={() => setTab('admin_account')}
          className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold whitespace-nowrap ${
            tab === 'admin_account'
              ? 'bg-sq-surface text-sq-gold-text shadow-xs'
              : 'text-sq-ink-muted'
          }`}
        >
          <UserCog className="h-3.5 w-3.5 text-sq-gold-text" />
          <span>حساب المدير</span>
        </button>
      </div>

      {loading ? (
        <div className="flex min-h-[200px] items-center justify-center gap-2 text-sm text-sq-ink-muted">
          <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
          <span>جاري تحميل بيانات المنصة...</span>
        </div>
      ) : tab === 'overview' && overview ? (
        <div className="space-y-5">
          {/* Complete Executive KPI Grid */}
          <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 lg:grid-cols-4">
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">إجمالي المستخدمين</p>
              <p className="mt-1.5 font-mono text-2xl font-bold text-sq-ink tabular-nums">
                {overview.totalUsers}
              </p>
              <p className="mt-1 text-[11px] text-sq-ink-muted tabular-nums">
                {overview.totalCustomers} زبون · {overview.totalMerchants} تاجر ·{' '}
                {overview.totalCouriers} مندوب
              </p>
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">إجمالي المتاجر</p>
              <p className="mt-1.5 font-mono text-2xl font-bold text-sq-gold-text tabular-nums">
                {overview.totalStores}
              </p>
              <p className="mt-1 text-[11px] text-sq-ink-muted tabular-nums">
                {overview.activeStores} مقبول · {overview.pendingStores} قيد المراجعة
              </p>
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">المتاجر قيد المراجعة</p>
              <p
                className={`mt-1.5 font-mono text-2xl font-bold tabular-nums ${
                  overview.pendingStores > 0 ? 'text-sq-warning-text' : 'text-sq-ink'
                }`}
              >
                {overview.pendingStores}
              </p>
              <button
                type="button"
                onClick={() => {
                  setStoreStatusFilter('pending');
                  setTab('stores');
                }}
                className="mt-1 text-[11px] font-semibold text-sq-gold-text hover:underline"
              >
                مراجعة طلبات المتاجر ←
              </button>
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">المندوبون بانتظار الموافقة</p>
              <p
                className={`mt-1.5 font-mono text-2xl font-bold tabular-nums ${
                  overview.pendingCouriers > 0 ? 'text-sq-warning-text' : 'text-sq-ink'
                }`}
              >
                {overview.pendingCouriers}
              </p>
              <button
                type="button"
                onClick={() => setTab('couriers')}
                className="mt-1 text-[11px] font-semibold text-sq-gold-text hover:underline"
              >
                توثيق المندوبين ({overview.verifiedCouriers} موثق) ←
              </button>
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">المندوبون الموثقون والمتاحون</p>
              <p className="mt-1.5 font-mono text-2xl font-bold text-sq-gold-text tabular-nums">
                {overview.verifiedCouriers}
              </p>
              <p className="mt-1 text-[11px] text-sq-ink-muted tabular-nums">
                متاح للعمل الآن: {overview.availableCouriers}
              </p>
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">طلبات التوصيل النشطة</p>
              <p className="mt-1.5 font-mono text-2xl font-bold text-sq-warning-text tabular-nums">
                {overview.activeDeliveries}
              </p>
              <button
                type="button"
                onClick={() => {
                  setOrdersSubMode('deliveries');
                  setTab('orders');
                }}
                className="mt-1 text-[11px] font-semibold text-sq-gold-text hover:underline"
              >
                مكتمل عبر المندوبين: {overview.deliveredDeliveries} ←
              </button>
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">الشكاوى المفتوحة</p>
              <p
                className={`mt-1.5 font-mono text-2xl font-bold tabular-nums ${
                  overview.openComplaints > 0 ? 'text-sq-danger-text' : 'text-sq-ink'
                }`}
              >
                {overview.openComplaints}
              </p>
              <button
                type="button"
                onClick={() => setTab('complaints')}
                className="mt-1 text-[11px] font-semibold text-sq-gold-text hover:underline"
              >
                فتح سجل الشكاوى والمخالفات ←
              </button>
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
              <p className="text-xs text-sq-ink-muted">حجم الطلبات النقدية</p>
              <p className="mt-1.5 font-mono text-xl font-bold text-sq-gold-text tabular-nums">
                {formatPrice(overview.totalCashVolume, currency)}
              </p>
              <p className="mt-1 text-[11px] text-sq-ink-muted tabular-nums">
                {overview.totalOrders} طلب ({overview.deliveredOrders} مكتمل ·{' '}
                {overview.cancelledOrders} ملغي)
              </p>
            </div>
          </div>

          {/* Quick Jump Strip: Categories & Super Admin Account */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <button
              type="button"
              onClick={() => setTab('categories')}
              className="flex items-center justify-between rounded-2xl border border-sq-border bg-sq-surface p-4 text-right hover:border-sq-gold"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">إدارة الأقسام</div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  إضافة وتعديل وتعطيل وحذف أقسام المنتجات
                </div>
              </div>
              <span className="font-mono text-lg font-extrabold text-sq-gold-text tabular-nums">
                {overview.activeCategories ?? categories.filter((c) => c.isActive).length}/
                {overview.totalCategories ?? categories.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTab('settings')}
              className="flex items-center justify-between rounded-2xl border border-sq-border bg-sq-surface p-4 text-right hover:border-sq-gold"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">
                  التجربة المجانية وإعدادات التطبيق
                </div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  المدة الحالية للتجار والمندوبين: {overview.trialDays ?? 30} يوماً · الزبون مجاني
                </div>
              </div>
              <span className="font-mono text-base font-extrabold text-sq-gold-text tabular-nums">
                {overview.trialDays ?? 30} يوم
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTab('admin_account')}
              className="flex items-center justify-between rounded-2xl border border-sq-gold/35 bg-sq-gold-soft/45 p-4 text-right hover:border-sq-gold"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-gold-text">
                  صفحة حساب المدير العام
                </div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  تعديل بياناتك، تغيير كلمة المرور، وإدارة جلسات الأجهزة
                </div>
              </div>
              <UserCog className="h-5 w-5 text-sq-gold-text shrink-0" />
            </button>
          </div>

          {/* Pending Administrative Actions Strip + Subscriptions & Recovery Summary */}
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-5">
            <button
              type="button"
              onClick={() => setTab('subscriptions')}
              className="flex items-center justify-between rounded-2xl border border-sq-gold/40 bg-sq-gold-soft/45 p-4 text-right hover:border-sq-gold"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-gold-text">
                  الاشتراكات وإثباتات الدفع
                </div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  {subStats
                    ? `${subStats.pendingPaymentRequestsCount} إثبات بانتظار المراجعة · ${subStats.expiredCount} منتهي`
                    : 'إدارة الباقات والأسعار ومراجعة الحوالات'}
                </div>
              </div>
              <span className="font-mono text-lg font-extrabold text-sq-gold-text tabular-nums">
                {subStats?.pendingPaymentRequestsCount ??
                  paymentRequests.filter((r) => r.status === 'pending').length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTab('recovery')}
              className="flex items-center justify-between rounded-2xl border border-sq-border bg-sq-surface p-4 text-right hover:border-sq-gold"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">
                  طلبات استعادة الحسابات
                </div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  التحقق وإصدار روابط ورموز إعادة تعيين لمرة واحدة
                </div>
              </div>
              <span className="font-mono text-lg font-extrabold text-sq-warning-text tabular-nums">
                {overview.pendingRecoveryRequests ??
                  recoveryRequests.filter((r) => r.status === 'pending').length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setStoreStatusFilter('pending');
                setTab('stores');
              }}
              className="flex items-center justify-between rounded-2xl border border-sq-border bg-sq-surface p-4 text-right hover:border-sq-gold"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">
                  طلبات المتاجر بانتظار المراجعة
                </div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  قبول أو رفض أو إيقاف المحلات والأسواق والمولات
                </div>
              </div>
              <span className="font-mono text-lg font-extrabold text-sq-gold-text tabular-nums">
                {overview.pendingStores}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTab('couriers')}
              className="flex items-center justify-between rounded-2xl border border-sq-border bg-sq-surface p-4 text-right hover:border-sq-gold"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">
                  طلبات توثيق المندوبين والوثائق
                </div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  مراجعة الهويات الرسمية وتفعيل المندوبين الموثقين
                </div>
              </div>
              <span className="font-mono text-lg font-extrabold text-sq-warning-text tabular-nums">
                {overview.pendingCouriers}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTab('complaints')}
              className="flex items-center justify-between rounded-2xl border border-sq-border bg-sq-surface p-4 text-right hover:border-sq-danger-border"
            >
              <div>
                <div className="font-display text-sm font-bold text-sq-ink">
                  تذاكر الدعم والشكاوى المفتوحة
                </div>
                <div className="mt-0.5 text-xs text-sq-ink-muted">
                  الرد على المستخدمين ومعالجة البلاغات
                </div>
              </div>
              <span className="font-mono text-lg font-extrabold text-sq-danger-text tabular-nums">
                {overview.openComplaints}
              </span>
            </button>
          </div>
        </div>
      ) : tab === 'subscriptions' ? (
        <AdminSubscriptionsSection
          subscriptions={userSubscriptions}
          stats={subStats}
          logs={subLogs}
          plans={subPlans}
          paymentMethods={paymentMethods}
          paymentRequests={paymentRequests}
          currency={currency}
          onRunAction={handleRunSubscriptionAction}
          onReviewPaymentRequest={handleReviewPaymentRequest}
          onUpdatePlans={handleUpdateSubscriptionPlans}
          onNotifyExpiring={handleNotifyExpiring}
        />
      ) : tab === 'recovery' ? (
        <AdminRecoverySection
          requests={recoveryRequests}
          users={users}
          onReview={handleReviewRecovery}
          onIssueDirectReset={handleIssueDirectReset}
        />
      ) : tab === 'couriers' ? (
        <AdminCouriersSection
          couriers={couriers}
          currency={currency}
          onUpdateCourier={handleCourierUpdate}
          onSendAlert={(params) => openInterventionModal(params)}
        />
      ) : tab === 'complaints' ? (
        <AdminComplaintsSection
          complaints={complaints}
          onUpdateComplaint={handleComplaintUpdate}
          onReplyComplaint={handleReplyComplaint}
        />
      ) : tab === 'stores' ? (
        <div className="space-y-4">
          {/* Status, Store Type & Search filter bar */}
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {(['all', 'pending', 'active', 'rejected', 'suspended'] as const).map((statusKey) => (
                <button
                  key={statusKey}
                  type="button"
                  onClick={() => setStoreStatusFilter(statusKey)}
                  className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    storeStatusFilter === statusKey
                      ? 'bg-sq-gold text-[#0B0C0C]'
                      : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                  }`}
                >
                  {statusKey === 'all' ? 'الكل' : STORE_STATUS_LABELS[statusKey]}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative w-56">
                <Search className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-sq-ink-muted" />
                <input
                  type="search"
                  value={storeSearch}
                  onChange={(e) => setStoreSearch(e.target.value)}
                  placeholder="بحث باسم المتجر أو المالك..."
                  className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface pr-9 pl-3 text-xs focus:border-sq-gold focus:outline-none"
                />
              </div>

              <select
                value={storeTypeFilter}
                onChange={(e) => setStoreTypeFilter(e.target.value as StoreType | 'all')}
                aria-label="تصفية حسب نوع النشاط"
                className="min-h-[38px] rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
              >
                <option value="all">جميع الأنشطة ({stores.length})</option>
                {ALL_STORE_TYPES.map((typeKey) => (
                  <option key={typeKey} value={typeKey}>
                    {STORE_TYPE_LABELS[typeKey]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {filteredStores.length === 0 ? (
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
              لا توجد متاجر مطابقة لهذا التصنيف.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredStores.map((store) => (
                <div
                  key={store.id}
                  className="rounded-2xl border border-sq-border bg-sq-surface p-5 space-y-3"
                >
                  <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs text-sq-ink-muted">
                        <span>{STORE_TYPE_LABELS[store.storeType]}</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {store.city}
                          {store.district ? ` — ${store.district}` : ''}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span
                          className={
                            store.status === 'active'
                              ? 'font-semibold text-sq-gold-text'
                              : store.status === 'pending'
                              ? 'font-semibold text-sq-warning-text'
                              : 'font-semibold text-sq-danger-text'
                          }
                        >
                          {STORE_STATUS_LABELS[store.status]}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => openStore(store.id)}
                          className="font-display text-base font-bold text-sq-ink hover:text-sq-gold-text"
                        >
                          {store.name}
                        </button>
                        {store.isVerified && <BadgeCheck className="h-4 w-4 text-sq-gold-text" />}
                      </div>

                      <p className="text-xs text-sq-ink-muted tabular-nums">
                        المالك: {store.ownerName} ({store.ownerPhone}) · الهاتف: {store.phone} ·{' '}
                        {store.productCount ?? 0} منتج · {store.orderCount ?? 0} طلب
                        {store.subscription
                          ? ` · الاشتراك: ${STORE_PLAN_LABELS[store.subscription.planName]} (${SUBSCRIPTION_STATUS_LABELS[store.subscription.status]})`
                          : ''}
                      </p>
                      {store.address && (
                        <p className="text-xs text-sq-ink-muted">العنوان: {store.address}</p>
                      )}
                      {store.status === 'rejected' && store.rejectionReason && (
                        <p className="text-xs font-semibold text-sq-danger-text">
                          سبب الرفض: {store.rejectionReason}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      {store.status !== 'active' && (
                        <button
                          type="button"
                          onClick={() => handleStoreUpdate(store.id, { status: 'active' })}
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>{store.status === 'pending' ? 'قبول المتجر' : 'تفعيل'}</span>
                        </button>
                      )}

                      {store.status === 'pending' && (
                        <button
                          type="button"
                          onClick={() => {
                            setRejectingStoreId(
                              rejectingStoreId === store.id ? null : store.id
                            );
                            setRejectionReason('');
                          }}
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 text-xs font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          <span>رفض المتجر</span>
                        </button>
                      )}

                      {store.status === 'active' && (
                        <button
                          type="button"
                          onClick={() => handleStoreUpdate(store.id, { status: 'suspended' })}
                          className="min-h-[40px] rounded-xl border border-sq-border px-3.5 text-xs font-semibold text-sq-warning-text hover:bg-sq-elevated"
                        >
                          إيقاف المتجر
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() =>
                          handleStoreUpdate(store.id, { isVerified: !store.isVerified })
                        }
                        className="min-h-[40px] rounded-xl border border-sq-border px-3.5 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                      >
                        {store.isVerified ? 'إلغاء التوثيق' : 'توثيق'}
                      </button>

                      <button
                        type="button"
                        onClick={() => setConfirmDeleteStore(store)}
                        aria-label="حذف المتجر"
                        className="flex h-10 w-10 items-center justify-center rounded-xl border border-sq-danger-border text-sq-danger-text hover:bg-sq-danger-bg"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Inline Rejection Reason Input */}
                  {rejectingStoreId === store.id && (
                    <div className="flex flex-col gap-2 rounded-xl border border-sq-danger-border bg-sq-danger-bg p-3.5 sm:flex-row sm:items-center">
                      <input
                        type="text"
                        value={rejectionReason}
                        onChange={(e) => setRejectionReason(e.target.value)}
                        placeholder="اكتب سبب الرفض ليظهر لصاحب المتجر (اختياري)..."
                        className="min-h-[40px] flex-1 rounded-lg border border-sq-danger-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-danger-border focus:outline-none"
                      />
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            handleStoreUpdate(store.id, {
                              status: 'rejected',
                              rejectionReason: rejectionReason.trim(),
                            })
                          }
                          className="min-h-[40px] rounded-lg bg-[#B42318] px-4 text-xs font-semibold text-white hover:bg-[#912018]"
                        >
                          تأكيد الرفض
                        </button>
                        <button
                          type="button"
                          onClick={() => setRejectingStoreId(null)}
                          className="min-h-[40px] rounded-lg border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink-muted"
                        >
                          إلغاء
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ) : tab === 'categories' ? (
        <AdminCategoriesSection
          categories={categories}
          onCreateCategory={handleCreateCategory}
          onUpdateCategory={handleUpdateCategory}
          onDeleteCategory={handleDeleteCategory}
        />
      ) : tab === 'posts' ? (
        <AdminPostsSection
          posts={posts}
          onModeratePost={handleModeratePost}
          onDeletePost={handleDeletePost}
          onOpenStore={openStore}
        />
      ) : tab === 'products' ? (
        <div className="space-y-4">
          <div className="relative max-w-md">
            <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
            <input
              type="search"
              value={productSearch}
              onChange={(e) => setProductSearch(e.target.value)}
              placeholder="ابحث باسم المنتج أو التصنيف أو المتجر..."
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-surface pr-10 pl-3 text-sm focus:border-sq-gold focus:outline-none"
            />
          </div>

          {filteredProducts.length === 0 ? (
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
              لا توجد منتجات مسجلة في المنصة بعد.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-sq-border bg-sq-surface">
              <table className="w-full text-right text-sm">
                <thead className="border-b border-sq-border bg-sq-elevated text-xs text-sq-ink-muted">
                  <tr>
                    <th className="px-4 py-3 font-semibold">المنتج</th>
                    <th className="px-4 py-3 font-semibold">المتجر</th>
                    <th className="px-4 py-3 font-semibold">السعر / الكارتون</th>
                    <th className="px-4 py-3 font-semibold">المخزون</th>
                    <th className="px-4 py-3 font-semibold">الحالة</th>
                    <th className="px-4 py-3 font-semibold">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-sq-border">
                  {filteredProducts.map((product) => (
                    <tr key={product.id}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-sq-muted">
                            {product.imageUrl ? (
                              <img
                                src={resolveMediaUrl(product.imageUrl)}
                                alt={product.name}
                                referrerPolicy="no-referrer"
                                className="h-full w-full object-cover"
                              />
                            ) : (
                              <div className="flex h-full w-full items-center justify-center text-sq-ink-muted/50">
                                <Package className="h-4 w-4" />
                              </div>
                            )}
                          </div>
                          <div>
                            <div className="font-semibold text-sq-ink">{product.name}</div>
                            <div className="text-xs text-sq-ink-muted">
                              {product.category} · {product.unit}
                              {product.gameName ? ` · ${product.gameName}` : ''}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs">
                        <button
                          type="button"
                          onClick={() => openStore(product.storeId)}
                          className="font-semibold text-sq-gold-text hover:underline"
                        >
                          {product.storeName}
                        </button>
                        {product.storeCity && (
                          <div className="text-sq-ink-muted">{product.storeCity}</div>
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs tabular-nums">
                        <div className="font-bold text-sq-ink">
                          {formatPrice(product.price, currency)}
                        </div>
                        {product.cartonPrice > 0 && (
                          <div className="text-sq-gold-text">
                            كارتون: {formatPrice(product.cartonPrice, currency)}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs font-semibold tabular-nums">
                        {product.stockQty}
                      </td>
                      <td className="px-4 py-3 text-xs font-semibold">
                        <span className={product.isAvailable ? 'text-sq-gold-text' : 'text-sq-danger-text'}>
                          {product.isAvailable ? 'ظاهر' : 'مخفي'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleToggleProduct(product)}
                            className="min-h-[36px] rounded-lg border border-sq-border px-3 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                          >
                            {product.isAvailable ? 'إخفاء' : 'إظهار'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteProduct(product)}
                            aria-label="حذف المنتج"
                            className="flex h-9 w-9 items-center justify-center rounded-lg border border-sq-danger-border text-sq-danger-text hover:bg-sq-danger-bg"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : tab === 'users' ? (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {(['all', 'customer', 'merchant', 'courier', 'super_admin'] as const).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setUserRoleFilter(r)}
                  className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    userRoleFilter === r
                      ? 'bg-sq-gold text-[#0B0C0C]'
                      : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                  }`}
                >
                  {r === 'all'
                    ? `الكل (${users.length})`
                    : `${ROLE_LABELS[r]} (${users.filter((u) => u.role === r).length})`}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
              <input
                type="search"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="بحث بالاسم، الهاتف، أو البريد..."
                className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface pr-10 pl-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-sq-border bg-sq-surface">
            <table className="w-full text-right text-sm">
              <thead className="border-b border-sq-border bg-sq-elevated text-xs text-sq-ink-muted">
                <tr>
                  <th className="px-4 py-3 font-semibold">المستخدم</th>
                  <th className="px-4 py-3 font-semibold">الهاتف</th>
                  <th className="px-4 py-3 font-semibold">الدور</th>
                  <th className="px-4 py-3 font-semibold">الحالة</th>
                  <th className="px-4 py-3 font-semibold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sq-border">
                {filteredUsers.map((u) => {
                  const isSelf = u.id === user.id;
                  return (
                    <tr key={u.id}>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-sq-ink">{u.fullName}</div>
                        <div className="text-xs text-sq-ink-muted">{u.email}</div>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs tabular-nums" dir="ltr">
                        {u.phone}
                      </td>
                      <td className="px-4 py-3 text-xs font-semibold text-sq-ink">
                        {isSelf ? (
                          ROLE_LABELS[u.role]
                        ) : (
                          <select
                            value={u.role}
                            onChange={(e) =>
                              handleUserUpdate(u.id, { role: e.target.value as UserRole })
                            }
                            className="min-h-[36px] rounded-lg border border-sq-border bg-sq-elevated px-2 text-xs"
                          >
                            <option value="customer">{ROLE_LABELS.customer}</option>
                            <option value="merchant">{ROLE_LABELS.merchant}</option>
                            <option value="courier">{ROLE_LABELS.courier}</option>
                            <option value="super_admin">{ROLE_LABELS.super_admin}</option>
                          </select>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs font-semibold">
                        <span className={u.isActive ? 'text-sq-gold-text' : 'text-sq-danger-text'}>
                          {u.isActive ? 'نشط' : 'معلّق'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {!isSelf && (
                          <button
                            type="button"
                            onClick={() => handleUserUpdate(u.id, { isActive: !u.isActive })}
                            className="min-h-[36px] rounded-lg border border-sq-border px-3 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                          >
                            {u.isActive ? 'تعليق الحساب' : 'تفعيل الحساب'}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : tab === 'orders' ? (
        <div className="space-y-4">
          {/* Sub-switcher: All Orders vs Dedicated Deliveries Tracker */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 rounded-xl bg-sq-muted p-1">
              <button
                type="button"
                onClick={() => setOrdersSubMode('orders')}
                className={`min-h-[38px] rounded-lg px-3.5 text-xs font-semibold ${
                  ordersSubMode === 'orders'
                    ? 'bg-sq-surface text-sq-ink shadow-xs'
                    : 'text-sq-ink-muted'
                }`}
              >
                سجل الطلبات ({orders.length})
              </button>
              <button
                type="button"
                onClick={() => setOrdersSubMode('deliveries')}
                className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg px-3.5 text-xs font-semibold ${
                  ordersSubMode === 'deliveries'
                    ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                    : 'text-sq-ink-muted'
                }`}
              >
                <Bike className="h-3.5 w-3.5" />
                <span>طلبات التوصيل عبر المندوبين ({deliveries.length})</span>
              </button>
            </div>
          </div>

          {ordersSubMode === 'deliveries' ? (
            deliveries.length === 0 ? (
              <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
                لا توجد طلبات توصيل عبر المندوبين مسجلة حتى الآن.
              </div>
            ) : (
              <div className="space-y-3">
                {deliveries.map((del) => (
                  <div
                    key={del.id}
                    className="rounded-2xl border border-sq-border bg-sq-surface p-5 space-y-2.5 text-xs"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-sm font-bold text-sq-ink">
                          {del.deliveryNumber}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-sq-gold-text">{del.storeName}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-sq-ink-muted">الطلب: {del.orderNumber}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-sq-ink-muted">{formatDateAr(del.requestedAt)}</span>
                      </div>
                      <span
                        className={`font-bold ${
                          del.status === 'delivered'
                            ? 'text-sq-gold-text'
                            : del.status === 'cancelled'
                            ? 'text-sq-danger-text'
                            : 'text-sq-warning-text'
                        }`}
                      >
                        {DELIVERY_STATUS_LABELS[del.status]}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-3 text-sq-ink-muted">
                      <div>
                        <strong className="text-sq-ink">الزبون:</strong> {del.customerName} (
                        <span dir="ltr" className="font-mono">
                          {del.customerPhone}
                        </span>
                        )
                      </div>
                      <div>
                        <strong className="text-sq-ink">المندوب:</strong>{' '}
                        {del.courierName ? (
                          <>
                            {del.courierName} (
                            <span dir="ltr" className="font-mono">
                              {del.courierPhone}
                            </span>
                            {del.courierVehicleType
                              ? ` · ${COURIER_VEHICLE_LABELS[del.courierVehicleType]}`
                              : ''}
                            )
                          </>
                        ) : (
                          'بانتظار قبول مندوب'
                        )}
                      </div>
                      <div className="font-mono font-bold text-sq-gold-text tabular-nums">
                        قيمة الطلب: {formatPrice(del.cashToCollect, currency)}
                        {del.deliveryOtp ? ` · OTP: ${del.deliveryOtp}` : ''}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 border-t border-sq-border pt-2.5 text-[11px] text-sq-ink-muted">
                      <div className="flex flex-wrap items-center gap-3">
                        {del.acceptedAt && <span>قُبل: {formatDateAr(del.acceptedAt)}</span>}
                        {del.pickedUpAt && <span>استُلم: {formatDateAr(del.pickedUpAt)}</span>}
                        {del.deliveredAt && (
                          <span className="font-semibold text-sq-gold-text">
                            سُلّم: {formatDateAr(del.deliveredAt)}
                          </span>
                        )}
                        <span
                          className={
                            del.otpVerified ? 'font-bold text-sq-gold-text' : 'text-sq-ink-muted'
                          }
                        >
                          {del.otpVerified ? '✓ تم التحقق من OTP' : 'بانتظار OTP عند التسليم'}
                        </span>
                      </div>

                      {del.status !== 'delivered' && del.status !== 'cancelled' && (
                        <button
                          type="button"
                          onClick={() => void handleCancelAdminDelivery(del.id)}
                          className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-sq-danger-border bg-sq-danger-bg px-3 text-xs font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          <span>إلغاء التوصيل إدارياً</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : orders.length === 0 ? (
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
              لا توجد طلبات مسجلة في المنصة بعد.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {(
                  [
                    { key: 'all', label: `الكل (${orders.length})` },
                    {
                      key: 'pending',
                      label: `طلبات جديدة (${orders.filter((o) => o.status === 'pending').length})`,
                    },
                    {
                      key: 'active_delivery',
                      label: `توصيل نشط بمندوب (${
                        orders.filter(
                          (o) =>
                            o.delivery &&
                            o.delivery.status !== 'delivered' &&
                            o.delivery.status !== 'cancelled'
                        ).length
                      })`,
                    },
                    {
                      key: 'cancelled',
                      label: `الإلغاءات وطلبات الإلغاء (${
                        orders.filter(
                          (o) =>
                            o.status === 'cancelled' ||
                            o.status === 'rejected' ||
                            (o.events || []).some((ev) => ev.eventType === 'cancel_requested')
                        ).length
                      })`,
                    },
                    {
                      key: 'delivered',
                      label: `مكتمل (${orders.filter((o) => o.status === 'delivered').length})`,
                    },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.key}
                    type="button"
                    onClick={() => setOrderFilter(f.key)}
                    className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                      orderFilter === f.key
                        ? 'bg-sq-gold text-[#0B0C0C]'
                        : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              {filteredOrders.length === 0 ? (
                <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
                  لا توجد طلبات مطابقة لهذا التصنيف.
                </div>
              ) : (
              <div className="space-y-3">
                {filteredOrders.map((order) => {
                  const isExpanded = expandedOrderId === order.id;
                  const isFocused = focusedOrderId === order.id;
                  const storeObj = stores.find((s) => s.id === order.storeId);
                  const cancelRequestEvent = (order.events || [])
                    .slice()
                    .reverse()
                    .find((ev) => ev.eventType === 'cancel_requested');

              return (
                <div
                  key={order.id}
                  id={`admin-order-${order.id}`}
                  className={`overflow-hidden rounded-2xl border bg-sq-surface transition-all ${
                    isFocused
                      ? 'border-sq-gold ring-2 ring-sq-gold/30 shadow-md'
                      : 'border-sq-border'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-3 p-4">
                    <div className="space-y-1 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-sm font-bold text-sq-ink">
                          {order.orderNumber}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-sq-gold-text">{order.storeName}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-sq-ink-muted">{formatDateAr(order.createdAt)}</span>
                        {cancelRequestEvent &&
                          order.status !== 'cancelled' &&
                          order.status !== 'rejected' && (
                            <span className="inline-flex items-center gap-1 font-bold text-sq-warning-text">
                              <AlertTriangle className="h-3.5 w-3.5" />
                              <span>طلب إلغاء عاجل</span>
                            </span>
                          )}
                      </div>
                      <div className="text-sq-ink-muted">
                        الزبون: <strong className="text-sq-ink">{order.customerName}</strong> (
                        <span dir="ltr" className="font-mono">
                          {order.customerPhone}
                        </span>
                        ) · {FULFILLMENT_LABELS[order.fulfillmentMethod]}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="font-mono text-sm font-bold text-sq-gold-text tabular-nums">
                        {formatPrice(order.totalAmount, currency)}
                      </span>

                      <select
                        value={order.status}
                        onChange={(e) =>
                          handleOrderStatusSelect(order, e.target.value as OrderStatus)
                        }
                        aria-label={`تحديث حالة الطلب ${order.orderNumber}`}
                        className="min-h-[38px] rounded-xl border border-sq-border bg-sq-elevated px-2.5 text-xs font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
                      >
                        {ORDER_STATUS_LIST.map((st) => (
                          <option key={st} value={st}>
                            {ORDER_STATUS_LABELS[st]}
                          </option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                        className="inline-flex min-h-[38px] items-center gap-1 rounded-xl border border-sq-border px-3 text-xs font-semibold text-sq-ink-muted hover:bg-sq-muted"
                      >
                        <span>التفاصيل</span>
                        {isExpanded ? (
                          <ChevronUp className="h-3.5 w-3.5" />
                        ) : (
                          <ChevronDown className="h-3.5 w-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="border-t border-sq-border bg-sq-elevated p-4 space-y-3 text-xs">
                      {cancelRequestEvent &&
                        order.status !== 'cancelled' &&
                        order.status !== 'rejected' && (
                          <div className="rounded-xl border border-sq-warning-border bg-sq-warning-bg p-3 text-sq-warning-text">
                            <strong>طلب إلغاء بعد بدء التجهيز:</strong> {cancelRequestEvent.reason}
                          </div>
                        )}

                      {(order.status === 'cancelled' || order.status === 'rejected') && (
                        <div className="rounded-xl border border-sq-danger-border bg-sq-danger-bg p-3 text-sq-danger-text space-y-0.5">
                          <div>
                            <strong>السبب:</strong> {order.cancelReason || 'غير محدد'}
                          </div>
                          {order.cancelledByName && (
                            <div className="text-[11px]">
                              بواسطة: {order.cancelledByName}
                              {order.cancelledByRole &&
                              ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]
                                ? ` (${ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]})`
                                : ''}
                              {order.cancelledAt ? ` · ${formatDateAr(order.cancelledAt)}` : ''}
                              {order.stockRestored ? ' · تمت إعادة الكمية للمخزون' : ''}
                            </div>
                          )}
                        </div>
                      )}

                      {order.delivery && (
                        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-sq-gold/35 bg-sq-gold-soft/60 px-3.5 py-2.5 text-sq-ink">
                          <div className="flex flex-wrap items-center gap-2">
                            <Bike className="h-4 w-4 text-sq-gold-text" />
                            <strong>التوصيل ({order.delivery.deliveryNumber}):</strong>
                            <span className="font-bold text-sq-gold-text">
                              {DELIVERY_STATUS_LABELS[order.delivery.status]}
                            </span>
                            {order.delivery.courierName && (
                              <>
                                <span>· المندوب: {order.delivery.courierName}</span>
                                {order.delivery.courierPhone && (
                                  <span className="inline-flex items-center gap-1 font-mono" dir="ltr">
                                    <Phone className="h-3 w-3 text-sq-gold-text" />
                                    {order.delivery.courierPhone}
                                  </span>
                                )}
                              </>
                            )}
                            {order.delivery.deliveryOtp && (
                              <span dir="ltr" className="font-mono font-bold text-sq-gold-text">
                                OTP: {order.delivery.deliveryOtp}
                              </span>
                            )}
                            {order.delivery.otpVerified && (
                              <span className="font-bold text-sq-gold-text">✓ OTP موثق</span>
                            )}
                          </div>
                          {order.delivery.status !== 'delivered' &&
                            order.delivery.status !== 'cancelled' && (
                              <button
                                type="button"
                                onClick={() => void handleCancelAdminDelivery(order.delivery!.id)}
                                className="rounded-lg border border-sq-danger-border bg-sq-surface px-2.5 py-1 text-[11px] font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
                              >
                                إلغاء التوصيل
                              </button>
                            )}
                        </div>
                      )}

                      <div className="text-sq-ink-muted">
                        <strong>العنوان:</strong>{' '}
                        {[
                          order.governorate,
                          order.city,
                          order.district,
                          order.neighborhood,
                          order.deliveryAddress,
                        ]
                          .filter(Boolean)
                          .join(' — ')}
                        {order.latitude !== null && order.longitude !== null
                          ? ` (GPS: ${order.latitude.toFixed(5)}, ${order.longitude.toFixed(5)})`
                          : ''}
                        {order.notes ? ` · ملاحظات: ${order.notes}` : ''}
                      </div>

                      <div className="divide-y divide-sq-border rounded-xl border border-sq-border bg-sq-surface px-3.5">
                        {order.items.map((item) => {
                          const optTags = formatOrderItemOptionsSummary(item.selectedOptions);
                          const printJob = item.selectedOptions?.printJob;
                          return (
                            <div key={item.id} className="py-2.5 space-y-1.5">
                              <div className="flex justify-between gap-2">
                                <span>
                                  <strong>{item.productName}</strong> ({item.quantity} × {item.unit}{' '}
                                  · {formatPrice(item.unitPrice, currency)})
                                </span>
                                <span className="font-mono font-semibold tabular-nums shrink-0">
                                  {formatPrice(item.lineTotal, currency)}
                                </span>
                              </div>
                              {optTags.length > 0 && (
                                <div className="flex flex-wrap gap-1.5 text-[11px] font-medium text-sq-gold-text">
                                  {optTags.map((tag, idx) => (
                                    <span
                                      key={idx}
                                      className="rounded-md border border-sq-gold/35 bg-sq-gold-soft px-2 py-0.5"
                                    >
                                      {tag}
                                    </span>
                                  ))}
                                </div>
                              )}
                              {printJob?.fileUrl && (
                                <a
                                  href={resolveMediaUrl(printJob.fileUrl)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  download={printJob.fileName}
                                  className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-sq-gold/30 bg-sq-elevated px-3 py-1 text-[11px] font-semibold text-sq-gold-text hover:bg-sq-gold-soft"
                                >
                                  <FileText className="h-3.5 w-3.5" />
                                  <span className="truncate max-w-[200px]">
                                    ملف الطباعة: {printJob.fileName}
                                  </span>
                                  <Download className="h-3.5 w-3.5" />
                                </a>
                              )}
                            </div>
                          );
                        })}
                      </div>

                      {order.events && order.events.length > 0 && (
                        <div className="rounded-xl border border-sq-border bg-sq-surface p-3 space-y-1.5">
                          <div className="flex items-center gap-1.5 font-bold text-sq-ink">
                            <History className="h-3.5 w-3.5 text-sq-gold-text" />
                            <span>سجل الحركات والتدقيق</span>
                          </div>
                          {order.events.map((ev) => (
                            <div
                              key={ev.id}
                              className="flex flex-wrap justify-between gap-2 text-[11px] text-sq-ink-muted"
                            >
                              <span className="text-sq-ink">
                                <strong>{EVENT_TYPE_LABELS[ev.eventType] || ev.eventType}</strong>
                                {ev.actorName ? ` · ${ev.actorName}` : ''}
                                {ev.reason ? ` — ${ev.reason}` : ''}
                              </span>
                              <span>{formatDateAr(ev.createdAt)}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setInvoiceOrder(order)}
                          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                        >
                          <ReceiptText className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>عرض الفاتورة المفصلة</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            openInterventionModal({
                              userId: order.customerId,
                              recipientLabel: `الزبون: ${order.customerName}`,
                              orderId: order.id,
                              storeId: order.storeId,
                              defaultTitle: `تنبيه إداري بخصوص الطلب ${order.orderNumber}`,
                            })
                          }
                          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-gold/30 bg-sq-gold-soft px-3 text-xs font-semibold text-sq-gold-text hover:bg-sq-gold-soft"
                        >
                          <Send className="h-3.5 w-3.5" />
                          <span>إرسال تنبيه للزبون</span>
                        </button>
                        {storeObj && (
                          <button
                            type="button"
                            onClick={() =>
                              openInterventionModal({
                                userId: storeObj.ownerId,
                                recipientLabel: `صاحب متجر ${order.storeName} (${storeObj.ownerName || ''})`,
                                orderId: order.id,
                                storeId: order.storeId,
                                defaultTitle: `تدخل إداري بخصوص الطلب ${order.orderNumber}`,
                              })
                            }
                            className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3 text-xs font-semibold text-sq-warning-text hover:bg-sq-warning-bg"
                          >
                            <Send className="h-3.5 w-3.5" />
                            <span>تنبيه صاحب المتجر</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
              </div>
            )}
          </div>
          )}
        </div>
      ) : tab === 'notifications' ? (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {(
                [
                  { key: 'all', label: `الكل (${adminNotifications.length})` },
                  {
                    key: 'orders',
                    label: `الطلبات (${
                      adminNotifications.filter(
                        (n) => n.type === 'order_new' || n.type === 'order_updated'
                      ).length
                    })`,
                  },
                  {
                    key: 'cancellations',
                    label: `الإلغاءات (${
                      adminNotifications.filter(
                        (n) =>
                          n.type === 'order_cancelled' ||
                          n.type === 'order_rejected' ||
                          n.type === 'order_cancel_requested'
                      ).length
                    })`,
                  },
                  {
                    key: 'visits',
                    label: `زيارات المتاجر (${
                      adminNotifications.filter((n) => n.type === 'store_visit').length
                    })`,
                  },
                  {
                    key: 'system',
                    label: `تنبيهات إدارية (${
                      adminNotifications.filter(
                        (n) => n.type === 'system' || n.type === 'store_status'
                      ).length
                    })`,
                  },
                ] as const
              ).map((f) => (
                <button
                  key={f.key}
                  type="button"
                  onClick={() => setNotifFilter(f.key)}
                  className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    notifFilter === f.key
                      ? 'bg-sq-gold text-[#0B0C0C]'
                      : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {filteredAdminNotifications.length === 0 ? (
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
              لا توجد إشعارات مسجلة في هذا التصنيف حالياً.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredAdminNotifications.map((item) => (
                <div
                  key={item.id}
                  className="rounded-2xl border border-sq-border bg-sq-surface p-4 sm:p-5 space-y-2"
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-[11px] text-sq-ink-muted">
                        <span className="font-bold text-sq-gold-text">
                          {NOTIF_TYPE_LABELS[item.type] || item.type}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>
                          المستلم:{' '}
                          <strong className="text-sq-ink">
                            {item.recipientName || item.userId}
                          </strong>
                          {item.recipientRole &&
                          ROLE_LABELS[item.recipientRole as keyof typeof ROLE_LABELS]
                            ? ` (${ROLE_LABELS[item.recipientRole as keyof typeof ROLE_LABELS]})`
                            : ''}
                        </span>
                        {item.storeName && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{item.storeName}</span>
                          </>
                        )}
                        {item.orderNumber && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono font-semibold text-sq-ink">
                              {item.orderNumber}
                            </span>
                          </>
                        )}
                      </div>
                      <h3 className="font-display text-sm font-bold text-sq-ink">
                        {item.title}
                      </h3>
                      <p className="text-xs leading-relaxed text-sq-ink-muted">{item.body}</p>
                    </div>

                    <div className="flex flex-col items-end gap-2 shrink-0 text-[11px] text-sq-ink-muted">
                      <span>{formatDateAr(item.createdAt)}</span>
                      <div className="flex items-center gap-1.5">
                        {item.orderId && (
                          <button
                            type="button"
                            onClick={() => {
                              setTab('orders');
                              setOrderFilter('all');
                              setExpandedOrderId(item.orderId);
                            }}
                            className="min-h-[34px] rounded-lg btn-gold px-3 text-xs font-semibold"
                          >
                            مراجعة الطلب
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            openInterventionModal({
                              userId: item.userId,
                              recipientLabel: item.recipientName || item.userId,
                              orderId: item.orderId || undefined,
                              storeId: item.storeId || undefined,
                            })
                          }
                          className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-sq-border bg-sq-elevated px-2.5 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                        >
                          <Send className="h-3 w-3 text-sq-gold-text" />
                          <span>تنبيه</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : tab === 'audit' ? (
        <div className="space-y-4">
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-extrabold text-sq-ink">
                سجل تدقيق وتغييرات المدير العام (Audit Log)
              </h2>
              <p className="text-xs text-sq-ink-muted">
                يُحفظ هنا كل تعديل إداري على الحسابات والمتاجر والمندوبين والاشتراكات وتذاكر الدعم
              </p>
            </div>
            <span className="font-mono text-xs font-bold text-sq-gold-text">
              {auditLogs.length} سجل
            </span>
          </div>

          {auditLogs.length === 0 ? (
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
              لا توجد عمليات مسجلة في سجل التغييرات بعد.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-sq-border bg-sq-surface">
              <table className="w-full text-right text-xs">
                <thead className="border-b border-sq-border bg-sq-elevated text-sq-ink-muted">
                  <tr>
                    <th className="px-4 py-3 font-semibold">الإجراء</th>
                    <th className="px-4 py-3 font-semibold">الهدف</th>
                    <th className="px-4 py-3 font-semibold">التفاصيل</th>
                    <th className="px-4 py-3 font-semibold">المدير المنفّذ</th>
                    <th className="px-4 py-3 font-semibold">الوقت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-sq-border">
                  {auditLogs.map((log) => (
                    <tr key={log.id}>
                      <td className="px-4 py-3 font-mono font-bold text-sq-gold-text whitespace-nowrap">
                        {log.actionType}
                      </td>
                      <td className="px-4 py-3 text-sq-ink whitespace-nowrap">
                        {log.targetType}
                        {log.targetLabel ? ` · ${log.targetLabel}` : ''}
                      </td>
                      <td className="px-4 py-3 text-sq-ink-muted">{log.details || '—'}</td>
                      <td className="px-4 py-3 font-semibold text-sq-ink whitespace-nowrap">
                        {log.adminName}
                      </td>
                      <td className="px-4 py-3 text-[11px] text-sq-ink-muted whitespace-nowrap">
                        {formatDateAr(log.createdAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : tab === 'admin_account' ? (
        <AdminAccountSection />
      ) : (
        <AdminSettingsSection
          overview={overview}
          stores={stores}
          subscriptions={subscriptions}
          currency={currency}
          savingSettings={savingSettings}
          onUpdateSettings={handleSettingsUpdate}
          onUpdateSubscription={handleSubscriptionUpdate}
        />
      )}

      {/* Confirmation Modal: Delete Store */}
      {confirmDeleteStore && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-sm rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <h2 className="font-display text-base font-extrabold text-sq-danger-text">
              تأكيد حذف المتجر نهائياً
            </h2>
            <p className="text-xs leading-relaxed text-sq-ink-muted">
              هل أنت متأكد من حذف متجر «<strong>{confirmDeleteStore.name}</strong>»؟ سيؤدي هذا
              الإجراء الحساس إلى حذف المتجر ومنتجاته نهائياً ولا يمكن التراجع عنه.
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteStore(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={busyAction}
                onClick={() => handleDeleteStore(confirmDeleteStore.id)}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#B42318] text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
              >
                {busyAction && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>تأكيد الحذف</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal: Delete Product */}
      {confirmDeleteProduct && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-sm rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <h2 className="font-display text-base font-extrabold text-sq-danger-text">
              تأكيد حذف المنتج نهائياً
            </h2>
            <p className="text-xs leading-relaxed text-sq-ink-muted">
              هل أنت متأكد من حذف المنتج «<strong>{confirmDeleteProduct.name}</strong>» من متجر{' '}
              {confirmDeleteProduct.storeName}؟
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteProduct(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={busyAction}
                onClick={() => handleDeleteProduct(confirmDeleteProduct.id)}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#B42318] text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
              >
                {busyAction && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>تأكيد الحذف</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal: Admin Order Cancel / Reject with Reason & Stock Policy */}
      {adminOrderCloseModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-sq-border pb-3">
              <div>
                <h2 className="font-display text-base font-extrabold text-sq-ink">
                  قرار المدير العام —{' '}
                  {adminOrderCloseModal.status === 'cancelled' ? 'إلغاء الطلب' : 'رفض الطلب'}{' '}
                  {adminOrderCloseModal.order.orderNumber}
                </h2>
                <p className="text-xs text-sq-ink-muted">
                  المتجر: {adminOrderCloseModal.order.storeName} · الزبون:{' '}
                  {adminOrderCloseModal.order.customerName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setAdminOrderCloseModal(null)}
                aria-label="إغلاق"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
                سبب القرار الإداري (يُسجل في سجل التدقيق ويُرسل للزبون والمتجر)
              </label>
              <textarea
                rows={2}
                value={adminCloseReason}
                onChange={(e) => setAdminCloseReason(e.target.value)}
                placeholder="مثال: الموافقة على طلب الإلغاء بعد التواصل مع المتجر..."
                className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-xs focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <label className="flex items-center gap-2.5 text-xs font-semibold text-sq-ink">
              <input
                type="checkbox"
                checked={adminRestoreStock}
                onChange={(e) => setAdminRestoreStock(e.target.checked)}
                className="h-4 w-4 accent-[#D4AF37]"
              />
              <span>إعادة الكميات المحجوزة إلى مخزون المتجر</span>
            </label>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setAdminOrderCloseModal(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink"
              >
                تراجع
              </button>
              <button
                type="button"
                disabled={busyAction}
                onClick={() =>
                  handleOrderStatusUpdate(
                    adminOrderCloseModal.order.id,
                    adminOrderCloseModal.status,
                    {
                      reason: adminCloseReason.trim(),
                      restoreStock: adminRestoreStock,
                    }
                  )
                }
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#B42318] text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
              >
                {busyAction && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>تأكيد الإجراء الإداري</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Intervention Notification Modal */}
      {alertModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-sq-border pb-3">
              <div>
                <h2 className="font-display text-base font-extrabold text-sq-ink">
                  تدخل إداري — إرسال تنبيه فوري
                </h2>
                <p className="text-xs text-sq-ink-muted">إلى: {alertModal.recipientLabel}</p>
              </div>
              <button
                type="button"
                onClick={() => setAlertModal(null)}
                aria-label="إغلاق"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-sq-ink">عنوان التنبيه</label>
              <input
                type="text"
                value={alertTitle}
                onChange={(e) => setAlertTitle(e.target.value)}
                className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-sq-ink">
                نص التنبيه الإداري (يصل فوراً كإشعار داخل التطبيق وإشعار هاتف)
              </label>
              <textarea
                rows={3}
                value={alertBody}
                onChange={(e) => setAlertBody(e.target.value)}
                placeholder="اكتب توجيه الإدارة أو تفاصيل حل المشكلة..."
                className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-xs focus:border-sq-gold focus:bg-sq-surface focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setAlertModal(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={busyAction}
                onClick={handleSendAdminIntervention}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl btn-gold text-xs font-bold disabled:opacity-60"
              >
                {busyAction ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-3.5 w-3.5" />
                )}
                <span>إرسال التنبيه الآن</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {invoiceOrder && (
        <OrderInvoiceModal
          order={invoiceOrder}
          currency={currency}
          onClose={() => setInvoiceOrder(null)}
        />
      )}
    </div>
  );
};
