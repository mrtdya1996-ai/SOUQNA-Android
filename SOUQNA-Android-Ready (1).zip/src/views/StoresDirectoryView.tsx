import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Compass,
  Loader2,
  MapPin,
  Package,
  Search,
  SlidersHorizontal,
  Store as StoreIcon,
  X,
} from 'lucide-react';
import { StoreCard } from '../components/StoreCard';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import {
  ALL_CATEGORY_CARDS,
  LUXURY_BANNER_IMAGES,
  STORE_CATEGORY_META,
} from '../lib/storeCategories';
import { ALL_STORE_TYPES, STORE_TYPE_LABELS, type Store, type StoreType } from '../types';

const STORE_FILTERS: Array<{ id: 'all' | StoreType; label: string }> = [
  { id: 'all', label: 'جميع التصنيفات' },
  ...ALL_STORE_TYPES.map((t) => ({ id: t, label: STORE_TYPE_LABELS[t] })),
];

type SortOption = 'verified' | 'active_posts' | 'newest' | 'lowest_delivery';

export const StoresDirectoryView: React.FC = () => {
  const {
    user,
    ownedStore,
    bootstrapStatus,
    selectedStoreTypeFilter,
    setSelectedStoreTypeFilter,
    openStore,
    navigate,
  } = useApp();
  const [stores, setStores] = useState<Store[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [districts, setDistricts] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [storeType, setStoreType] = useState<'all' | StoreType>(selectedStoreTypeFilter);
  const [selectedCity, setSelectedCity] = useState('all');
  const [selectedDistrict, setSelectedDistrict] = useState('all');
  const [sortBy, setSortBy] = useState<SortOption>('verified');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setStoreType(selectedStoreTypeFilter);
  }, [selectedStoreTypeFilter]);

  const handleSelectStoreType = (nextType: 'all' | StoreType) => {
    setStoreType(nextType);
    setSelectedStoreTypeFilter(nextType);
  };

  const handleCityChange = (nextCity: string) => {
    setSelectedCity(nextCity);
    setSelectedDistrict('all');
  };

  const loadSeqRef = useRef(0);

  const loadStores = useCallback(async () => {
    const seq = ++loadSeqRef.current;
    setLoading(true);
    setError(null);
    try {
      const res = await api.getStores({
        search: search.trim(),
        type: storeType,
        city: selectedCity,
        district: selectedDistrict,
      });
      if (seq !== loadSeqRef.current) return;
      setStores(Array.isArray(res?.stores) ? res.stores : []);
      setCities(Array.isArray(res?.cities) ? res.cities : []);
      setDistricts(Array.isArray(res?.districts) ? res.districts : []);
    } catch (err) {
      if (seq !== loadSeqRef.current) return;
      setError(err instanceof Error ? err.message : 'تعذر تحميل دليل المتاجر والأسواق.');
    } finally {
      if (seq === loadSeqRef.current) {
        setLoading(false);
      }
    }
  }, [search, storeType, selectedCity, selectedDistrict]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadStores();
    }, 280);
    return () => window.clearTimeout(timer);
  }, [loadStores, user?.id]);

  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        void loadStores();
      }
    };
    const onOnline = () => {
      void loadStores();
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', onOnline);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', onOnline);
    };
  }, [loadStores]);

  const sortedStores = useMemo(() => {
    const copy = [...stores];
    if (sortBy === 'lowest_delivery') {
      copy.sort((a, b) => a.deliveryFee - b.deliveryFee);
    } else if (sortBy === 'newest') {
      copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    } else if (sortBy === 'active_posts') {
      copy.sort((a, b) => (b.postCount ?? 0) - (a.postCount ?? 0));
    } else {
      copy.sort(
        (a, b) =>
          Number(b.isVerified) - Number(a.isVerified) ||
          (b.postCount ?? 0) - (a.postCount ?? 0)
      );
    }
    return copy;
  }, [stores, sortBy]);

  const activeCategoryMeta = storeType !== 'all' ? STORE_CATEGORY_META[storeType] : null;
  const hasFilters =
    Boolean(search.trim()) ||
    storeType !== 'all' ||
    selectedCity !== 'all' ||
    selectedDistrict !== 'all';

  const resetFilters = () => {
    setSearch('');
    handleSelectStoreType('all');
    setSelectedCity('all');
    setSelectedDistrict('all');
  };

  return (
    <div className="space-y-6">
      {/* Luxury Obsidian & Gold Directory Hero */}
      <section className="relative overflow-hidden rounded-3xl border border-[#D4AF37]/35 bg-[#0C0E0D] p-6 sm:p-8 text-white shadow-xl">
        <img
          src={activeCategoryMeta ? activeCategoryMeta.imageUrl : LUXURY_BANNER_IMAGES.mall}
          alt="دليل المتاجر والأسواق"
          referrerPolicy="no-referrer"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-gradient-to-l from-[#090A0A]/95 via-[#090A0A]/80 to-[#090A0A]/60"
        />

        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="space-y-2 max-w-2xl">
            <p className="text-xs font-bold text-[#E8CB73]">
              SOUQNA | دليل المتاجر والأسواق والمولات المعتمد
            </p>
            <h1 className="font-display text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white">
              {activeCategoryMeta ? activeCategoryMeta.title : 'المتاجر والأسواق والمولات'}
            </h1>
            <p className="text-sm leading-relaxed text-[#D8D2C5]">
              {activeCategoryMeta
                ? activeCategoryMeta.subtitle
                : 'تصفّح الأسواق الغذائية، السوبر ماركت، البقالات، الخضروات، المولات، الإنشائية، الملابس والمحلات المسجلة في منطقتك وتابع منشوراتها وعروضها.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <div className="rounded-2xl border border-[#D4AF37]/35 bg-black/55 px-4 py-2.5 text-center backdrop-blur-sm">
              <p className="font-mono text-xl font-extrabold text-[#E8CB73] tabular-nums">
                {loading ? '—' : sortedStores.length}
              </p>
              <p className="text-[11px] text-[#CFC9BC]">متجر وسوق معتمد</p>
            </div>

            <button
              type="button"
              onClick={() => navigate(user?.role === 'merchant' ? 'merchant' : 'auth')}
              className="btn-gold inline-flex min-h-[46px] items-center gap-2 rounded-2xl px-5 py-2.5 text-sm"
            >
              <StoreIcon className="h-4 w-4" />
              <span>{user?.role === 'merchant' ? 'إدارة متجري ومنشوراتي' : 'سجّل متجرك في الدليل'}</span>
            </button>

            <button
              type="button"
              onClick={() => navigate('products')}
              className="inline-flex min-h-[46px] items-center gap-2 rounded-2xl border border-white/25 bg-black/45 px-4 py-2.5 text-xs sm:text-sm font-bold text-white backdrop-blur-sm hover:bg-black/65 active:scale-95 transition"
            >
              <Package className="h-4 w-4 text-[#E8CB73]" />
              <span>قسم المنتجات</span>
            </button>
          </div>
        </div>
      </section>

      {/* Search & Multi-Criteria Filter Bar */}
      <section className="rounded-2xl border border-sq-border bg-sq-surface p-4 sm:p-5 space-y-4">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
          <div className="relative md:col-span-5">
            <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-gold-text" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث باسم المتجر، السوق، المول، النشاط أو المنطقة..."
              className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated pr-10 pl-4 text-sm text-sq-ink placeholder:text-sq-ink-muted focus:border-sq-gold focus:outline-none"
            />
          </div>

          <div className="relative md:col-span-2">
            <MapPin className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-gold-text" />
            <select
              value={selectedCity}
              onChange={(e) => handleCityChange(e.target.value)}
              aria-label="تصفية حسب المحافظة أو المدينة"
              className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated pr-9 pl-3 text-xs sm:text-sm font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
            >
              <option value="all">كل المحافظات</option>
              {cities.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </div>

          <div className="relative md:col-span-2">
            <Compass className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-gold-text" />
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              aria-label="تصفية حسب المنطقة أو الحي"
              className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated pr-9 pl-3 text-xs sm:text-sm font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
            >
              <option value="all">كل المناطق</option>
              {districts.map((dist) => (
                <option key={dist} value={dist}>
                  {dist}
                </option>
              ))}
            </select>
          </div>

          <div className="relative md:col-span-3">
            <SlidersHorizontal className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              aria-label="ترتيب المتاجر"
              className="min-h-[46px] w-full rounded-xl border border-sq-border bg-sq-elevated pr-9 pl-3 text-xs sm:text-sm font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
            >
              <option value="verified">الموثقة والأكثر تفاعلاً</option>
              <option value="active_posts">الأكثر منشورات وعروض</option>
              <option value="newest">الأحدث تسجيلاً</option>
              <option value="lowest_delivery">الأقل رسوم توصيل</option>
            </select>
          </div>
        </div>

        {/* All 11 Category Segmented Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {STORE_FILTERS.map((filter) => {
            const active = storeType === filter.id;
            const Icon = filter.id !== 'all' ? STORE_CATEGORY_META[filter.id].icon : StoreIcon;
            return (
              <button
                key={filter.id}
                type="button"
                onClick={() => handleSelectStoreType(filter.id)}
                className={`inline-flex min-h-[42px] items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs sm:text-sm font-bold transition-all active:scale-95 whitespace-nowrap shrink-0 ${
                  active
                    ? 'btn-gold'
                    : 'border border-sq-border bg-sq-elevated text-sq-ink-muted hover:border-sq-gold/50 hover:text-sq-ink'
                }`}
              >
                <Icon className="h-3.5 w-3.5 shrink-0" />
                <span>{filter.label}</span>
              </button>
            );
          })}
        </div>

        {hasFilters && (
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-sq-border pt-3 text-xs">
            <span className="text-sq-ink-muted">
              يتم عرض المتاجر المطابقة للفلاتر المحددة ({sortedStores.length} نتيجة)
            </span>
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-1 font-bold text-sq-gold-text hover:underline"
            >
              <X className="h-3.5 w-3.5" />
              <span>مسح جميع الفلاتر</span>
            </button>
          </div>
        )}
      </section>

      {/* Quick Category Showcase when directory has 0 stores yet */}
      {!hasFilters && stores.length === 0 && !loading && (
        <section className="space-y-3">
          <h2 className="font-display text-base font-extrabold text-sq-ink">
            الأقسام المتاحة للتسجيل والتصفح في دليل سوقنا
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {ALL_CATEGORY_CARDS.map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.type}
                  type="button"
                  onClick={() => handleSelectStoreType(cat.type)}
                  className="flex items-center gap-3 rounded-2xl border border-sq-border bg-sq-surface p-3 text-right transition hover:border-sq-gold/60 active:scale-[0.98]"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#D4AF37]/40 bg-[#121413] text-[#E8CB73]">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-extrabold text-sq-ink truncate">{cat.title}</p>
                    <p className="text-[11px] text-sq-ink-muted truncate">{cat.subtitle}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* Real Stores Feed */}
      {loading ? (
        <div className="flex min-h-[240px] items-center justify-center gap-2 rounded-2xl border border-sq-border bg-sq-surface text-sm text-sq-ink-muted">
          <Loader2 className="h-5 w-5 animate-spin text-sq-gold" />
          <span>جاري تحميل دليل المتاجر والأسواق...</span>
        </div>
      ) : error ? (
        <div className="rounded-2xl border border-sq-danger-border bg-sq-danger-bg p-6 text-center">
          <p className="text-sm font-semibold text-sq-danger-text">{error}</p>
          <button
            type="button"
            onClick={loadStores}
            className="mt-3 min-h-[44px] rounded-xl bg-[#B42318] px-4 py-2 text-xs font-semibold text-white"
          >
            إعادة المحاولة
          </button>
        </div>
      ) : sortedStores.length === 0 ? (
        <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl border border-[#D4AF37]/40 bg-[#121413] text-[#E8CB73]">
            <StoreIcon className="h-7 w-7" />
          </div>
          <h2 className="font-display text-lg font-extrabold text-sq-ink">
            {hasFilters
              ? 'لا توجد متاجر أو أسواق مطابقة لهذا البحث'
              : 'لا توجد متاجر معتمدة في الدليل حتى الآن'}
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-sq-ink-muted">
            {hasFilters
              ? 'جرّب تغيير التصنيف أو المنطقة أو مسح نص البحث لعرض جميع المتاجر المسجلة.'
              : 'تظهر هنا المتاجر والأسواق والمولات الحقيقية فور تسجيلها من قبل أصحابها وموافقة الإدارة العامة عليها.'}
          </p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
            {hasFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="btn-surface min-h-[44px] rounded-xl px-4 py-2 text-sm font-bold"
              >
                عرض جميع المتاجر
              </button>
            )}
            <button
              type="button"
              onClick={() => navigate(user?.role === 'merchant' ? 'merchant' : 'auth')}
              className="btn-gold min-h-[44px] rounded-xl px-5 py-2 text-sm"
            >
              {user?.role === 'merchant' ? 'إدارة متجري' : 'سجّل متجرك على سوقنا'}
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {sortedStores.map((store) => (
            <StoreCard
              key={store.id}
              store={store}
              currency={bootstrapStatus.currency}
              isOwnStore={ownedStore?.id === store.id}
              onOpen={openStore}
            />
          ))}
        </div>
      )}
    </div>
  );
};
