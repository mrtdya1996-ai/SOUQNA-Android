import React, { useCallback, useEffect, useState } from 'react';
import {
  Bell,
  BellOff,
  BellRing,
  CheckCheck,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Loader2,
  RefreshCw,
  Send,
  Smartphone,
  Trash2,
} from 'lucide-react';
import { useApp, type AppView } from '../context/AppContext';
import { api, formatDateAr } from '../lib/api';
import {
  getExistingPushSubscription,
  getNotificationPermission,
  isWebPushSupported,
  subscribeDeviceToWebPush,
  unsubscribeDeviceFromWebPush,
  type PushPermissionState,
} from '../lib/push';
import type { NotificationItem, PushConfig } from '../types';

export const NotificationsView: React.FC = () => {
  const {
    user,
    ownedStore,
    notifications,
    unreadNotificationCount,
    navigate,
    openOrderFromNotification,
    refreshNotifications,
    markNotificationRead,
    markAllNotificationsRead,
    deleteNotification,
    clearReadNotifications,
    notify,
  } = useApp();

  const [pushConfig, setPushConfig] = useState<PushConfig | null>(null);
  const [permission, setPermission] = useState<PushPermissionState>(() =>
    getNotificationPermission()
  );
  const [deviceSubscribed, setDeviceSubscribed] = useState(false);
  const [busyPush, setBusyPush] = useState(false);
  const [sendingTest, setSendingTest] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [showTechDetails, setShowTechDetails] = useState(false);

  const loadPushState = useCallback(async () => {
    if (!user) return;
    setPermission(getNotificationPermission());
    try {
      const [cfg, existingSub] = await Promise.all([
        api.getPushConfig(),
        getExistingPushSubscription(),
      ]);
      setPushConfig(cfg);
      setDeviceSubscribed(Boolean(existingSub));
    } catch {
      // keep fallback state
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      void refreshNotifications();
      void loadPushState();
    }
  }, [user, refreshNotifications, loadPushState]);

  if (!user) {
    return (
      <div className="mx-auto max-w-md rounded-3xl border border-sq-border bg-sq-surface p-8 text-center">
        <Bell className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/70" />
        <h1 className="font-display text-xl font-bold text-sq-ink">مركز الإشعارات</h1>
        <p className="mt-2 text-sm text-sq-ink-muted">
          سجّل دخولك لاستلام إشعارات الطلبات الفورية على هاتفك ومتابعة سجل التنبيهات.
        </p>
        <button
          type="button"
          onClick={() => navigate('auth')}
          className="mt-5 min-h-[46px] w-full rounded-xl btn-gold py-2.5 text-sm font-semibold"
        >
          تسجيل الدخول
        </button>
      </div>
    );
  }

  const handleEnablePush = async () => {
    if (!pushConfig?.vapidPublicKey) {
      notify('مفتاح إشعارات الخادم غير جاهز حالياً. أعد تحميل الصفحة ثم حاول مجدداً.', 'error');
      return;
    }
    setBusyPush(true);
    try {
      const res = await subscribeDeviceToWebPush(pushConfig.vapidPublicKey);
      setPermission(getNotificationPermission());
      setDeviceSubscribed(true);
      setPushConfig((prev) => (prev ? { ...prev, activeDeviceCount: res.deviceCount } : prev));
      notify(
        'تم تفعيل إشعارات الهاتف الفورية بنجاح! ستصلك التنبيهات حتى لو كان التطبيق مغلقاً.',
        'success'
      );
    } catch (err) {
      setPermission(getNotificationPermission());
      notify(err instanceof Error ? err.message : 'تعذر تفعيل الإشعارات على هذا الجهاز.', 'error');
    } finally {
      setBusyPush(false);
    }
  };

  const handleDisablePush = async () => {
    setBusyPush(true);
    try {
      await unsubscribeDeviceFromWebPush();
      setDeviceSubscribed(false);
      await loadPushState();
      notify('تم إيقاف إشعارات الهاتف على هذا الجهاز.', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إيقاف الإشعارات.', 'error');
    } finally {
      setBusyPush(false);
    }
  };

  const handleSendTestPush = async () => {
    setSendingTest(true);
    try {
      const res = await api.sendTestPush();
      if (res.totalDevices === 0) {
        notify('اضغط «تفعيل إشعارات الهاتف الفورية» أولاً لتسجيل جهازك ثم أعد الاختبار.', 'info');
      } else if (res.sent > 0) {
        notify(`تم إرسال إشعار تجريبي حقيقي إلى ${res.sent} جهاز بنجاح.`, 'success');
      } else {
        notify('تعذر توصيل الإشعار التجريبي للجهاز؛ أعد تفعيل الإشعارات على هذا الجهاز.', 'error');
      }
      await refreshNotifications();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال الإشعار التجريبي.', 'error');
    } finally {
      setSendingTest(false);
    }
  };

  const handleRefreshAll = async () => {
    setRefreshing(true);
    await Promise.all([refreshNotifications(), loadPushState()]);
    setRefreshing(false);
  };

  const handleOpenNotification = async (item: NotificationItem) => {
    if (!item.isRead) {
      await markNotificationRead(item.id);
    }
    const targetView = (item.targetView || (user.role === 'merchant' ? 'merchant' : 'orders')) as AppView;
    openOrderFromNotification(item.orderId, targetView);
  };

  const readCount = notifications.filter((n) => n.isRead).length;
  const webPushSupported = isWebPushSupported();

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-sq-ink">
            مركز الإشعارات والتنبيهات الفورية
          </h1>
          <p className="mt-1 text-sm text-sq-ink-muted">
            {user.role === 'merchant' && ownedStore
              ? `إشعارات متجر «${ownedStore.name}» الحصرية — تصلك طلبات متجرك وتحديثاتها فور إرسالها`
              : 'إشعارات طلباتك وتحديثات حالتها مباشرة على هاتفك'}
          </p>
        </div>

        <button
          type="button"
          onClick={handleRefreshAll}
          disabled={refreshing}
          className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-sq-border bg-sq-surface px-4 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          <span>تحديث</span>
        </button>
      </div>

      {/* Real Device Push Notifications Activation Card */}
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <div
              className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${
                deviceSubscribed
                  ? 'bg-sq-gold-soft text-sq-gold-text'
                  : 'bg-sq-elevated border border-sq-border text-sq-ink-muted'
              }`}
            >
              {deviceSubscribed ? (
                <BellRing className="h-5 w-5" />
              ) : (
                <BellOff className="h-5 w-5" />
              )}
            </div>
            <div>
              <h2 className="font-display text-base font-bold text-sq-ink">
                إشعارات الهاتف الفورية (Push Notifications)
              </h2>
              <p className="mt-1 text-xs leading-relaxed text-sq-ink-muted">
                عند التفعيل، تصلك تنبيهات الطلبات الجديدة أو الإلغاءات مباشرة إلى شاشة الهاتف
                كإشعار نظام حقيقي حتى لو كان التطبيق مغلقاً أو في الخلفية، ويفتح النقر عليها تفاصيل
                الطلب فوراً.
              </p>
              <div className="mt-2 flex flex-wrap items-center gap-3 text-xs">
                <span className="text-sq-ink-muted">
                  حالة الصلاحية:{' '}
                  <strong
                    className={
                      permission === 'granted'
                        ? 'text-sq-gold-text'
                        : permission === 'denied'
                        ? 'text-sq-danger-text'
                        : 'text-sq-warning-text'
                    }
                  >
                    {permission === 'granted'
                      ? 'مسموح بها'
                      : permission === 'denied'
                      ? 'محظورة من المتصفح'
                      : permission === 'unsupported'
                      ? 'غير مدعومة على هذا المتصفح'
                      : 'بانتظار التفعيل'}
                  </strong>
                </span>
                <span aria-hidden="true" className="text-sq-border">·</span>
                <span className="text-sq-ink-muted tabular-nums">
                  الأجهزة المفعّلة على حسابك:{' '}
                  <strong className="font-mono text-sq-ink">
                    {pushConfig?.activeDeviceCount ?? 0}
                  </strong>
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {webPushSupported && !deviceSubscribed && (
              <button
                type="button"
                disabled={busyPush || permission === 'denied'}
                onClick={handleEnablePush}
                className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl btn-gold px-4 py-2 text-xs font-semibold disabled:opacity-50"
              >
                {busyPush ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <BellRing className="h-4 w-4" />
                )}
                <span>تفعيل إشعارات الهاتف الفورية</span>
              </button>
            )}

            {deviceSubscribed && (
              <>
                <button
                  type="button"
                  disabled={sendingTest}
                  onClick={handleSendTestPush}
                  className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl btn-gold px-4 py-2 text-xs font-semibold disabled:opacity-60"
                >
                  {sendingTest ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  <span>إرسال إشعار تجريبي حقيقي</span>
                </button>
                <button
                  type="button"
                  disabled={busyPush}
                  onClick={handleDisablePush}
                  className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2 text-xs font-semibold text-sq-ink-muted hover:bg-sq-muted"
                >
                  <BellOff className="h-4 w-4" />
                  <span>إيقاف على هذا الجهاز</span>
                </button>
              </>
            )}
          </div>
        </div>

        {permission === 'denied' && (
          <div className="rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 py-3 text-xs text-sq-danger-text">
            تم حظر الإشعارات سابقاً في إعدادات المتصفح. لتفعيلها، افتح إعدادات الموقع (أيقونة القفل
            بجوار الرابط) واختر «السماح بالإشعارات» ثم أعد تحميل الصفحة.
          </div>
        )}

        {/* Collapsible Mobile / Expo / APK Readiness Info */}
        <div className="border-t border-sq-border pt-3">
          <button
            type="button"
            onClick={() => setShowTechDetails((prev) => !prev)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-sq-gold-text hover:underline"
          >
            <Smartphone className="h-4 w-4" />
            <span>دليل تشغيل إشعارات الخلفية على الهاتف وتطبيق Android APK</span>
            {showTechDetails ? (
              <ChevronUp className="h-3.5 w-3.5" />
            ) : (
              <ChevronDown className="h-3.5 w-3.5" />
            )}
          </button>

          {showTechDetails && (
            <div className="mt-3 rounded-2xl border border-sq-border bg-sq-elevated p-4 text-xs leading-relaxed text-sq-ink-muted space-y-2">
              <p>
                <strong>1. على هواتف أندرويد وآيفون (PWA):</strong> ثبّت تطبيق سوقنا على الشاشة
                الرئيسية من المتصفح ثم اضغط «تفعيل إشعارات الهاتف الفورية» أعلاه. يعمل الإرسال عبر
                بروتوكول <span className="font-mono text-sq-ink">Web Push (VAPID)</span> مع
                Service Worker في الخلفية.
              </p>
              <p>
                <strong>2. عند التحويل إلى Android APK / Expo:</strong> الخادم جاهز مسبقاً لاستقبال
                رموز الأجهزة عبر المسار{' '}
                <span className="font-mono text-sq-ink" dir="ltr">
                  POST /api/push/register-token
                </span>{' '}
                (بصيغة Expo Push Token أو FCM) ويربط كل جهاز تلقائياً بحساب المستخدم ومتجره الخاص
                فقط.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Notifications List Header & Bulk Actions */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-sm font-bold text-sq-ink">
          سجل الإشعارات ({notifications.length})
          {unreadNotificationCount > 0 && (
            <span className="mr-2 font-mono text-xs font-semibold text-sq-danger-text tabular-nums">
              {unreadNotificationCount} غير مقروء
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {unreadNotificationCount > 0 && (
            <button
              type="button"
              onClick={markAllNotificationsRead}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-3.5 text-xs font-semibold text-sq-gold-text hover:bg-sq-gold-soft"
            >
              <CheckCheck className="h-4 w-4" />
              <span>تحديد الكل كمقروء</span>
            </button>
          )}
          {readCount > 0 && (
            <button
              type="button"
              onClick={clearReadNotifications}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 text-xs font-semibold text-sq-danger-text hover:bg-sq-danger-bg"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>حذف الإشعارات المقروءة</span>
            </button>
          )}
        </div>
      </div>

      {/* Notifications Feed */}
      {notifications.length === 0 ? (
        <div className="rounded-3xl border border-sq-border bg-sq-surface p-10 text-center">
          <Bell className="mx-auto mb-3 h-10 w-10 text-sq-gold-text/50" />
          <h2 className="font-display text-lg font-bold text-sq-ink">لا توجد إشعارات بعد</h2>
          <p className="mt-2 text-sm text-sq-ink-muted">
            ستظهر هنا جميع تنبيهات الطلبات الجديدة وتحديثات الحالة وإشعارات الإلغاء فور حدوثها.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((item) => {
            const typeLabel =
              item.type === 'store_visit'
                ? 'زيارة متجر الآن'
                : item.type === 'order_new'
                ? 'طلب جديد'
                : item.type === 'order_cancelled'
                ? 'إلغاء طلب'
                : item.type === 'order_rejected'
                ? 'رفض طلب'
                : item.type === 'order_cancel_requested'
                ? 'طلب إلغاء عاجل'
                : item.type === 'order_updated'
                ? 'تحديث حالة'
                : item.type === 'store_status'
                ? 'حالة المتجر'
                : item.type === 'complaint_new'
                ? 'تذكرة دعم جديدة'
                : item.type === 'complaint_reply'
                ? 'رد الدعم الفني'
                : item.type === 'subscription_alert'
                ? 'تنبيه الاشتراك'
                : item.type === 'account_recovery'
                ? 'طلب استعادة حساب'
                : item.type === 'courier_status'
                ? 'حالة مندوب التوصيل'
                : item.type.startsWith('delivery_')
                ? 'تحديث التوصيل'
                : 'تنبيه إداري';
            return (
              <div
                key={item.id}
                className={`rounded-2xl border p-4 sm:p-5 transition-colors ${
                  item.isRead
                    ? 'border-sq-border bg-sq-surface'
                    : 'border-sq-gold/40 bg-sq-gold-soft/55'
                }`}
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      {!item.isRead && (
                        <span
                          aria-label="غير مقروء"
                          className="h-2.5 w-2.5 rounded-full bg-sq-gold shrink-0"
                        />
                      )}
                      <span
                        className={`text-[11px] font-bold ${
                          item.type === 'order_cancelled' ||
                          item.type === 'order_rejected' ||
                          item.type === 'order_cancel_requested'
                            ? 'text-sq-danger-text'
                            : item.type === 'store_visit'
                            ? 'text-sq-warning-text'
                            : 'text-sq-gold-text'
                        }`}
                      >
                        {typeLabel}
                      </span>
                      <span aria-hidden="true" className="text-sq-border">·</span>
                      <h3 className="font-display text-sm sm:text-base font-bold text-sq-ink">
                        {item.title}
                      </h3>
                    </div>

                    <p className="text-xs sm:text-sm leading-relaxed text-sq-ink-muted">{item.body}</p>

                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-sq-ink-muted">
                      <span>{formatDateAr(item.createdAt)}</span>
                      {item.storeName && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-sq-gold-text">{item.storeName}</span>
                        </>
                      )}
                      {item.orderNumber && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono font-semibold text-sq-ink">
                            {item.orderNumber}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {item.orderId && (
                      <button
                        type="button"
                        onClick={() => handleOpenNotification(item)}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        <span>فتح تفاصيل الطلب</span>
                      </button>
                    )}

                    {!item.orderId && item.type === 'store_visit' && user.role === 'merchant' && (
                      <button
                        type="button"
                        onClick={() => handleOpenNotification(item)}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-gold/30 bg-sq-surface px-3.5 text-xs font-semibold text-sq-gold-text hover:bg-sq-gold-soft"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                        <span>فتح لوحة المتجر</span>
                      </button>
                    )}

                    {!item.orderId &&
                      (item.targetView === 'support' ||
                        item.targetView === 'subscription' ||
                        (item.targetView === 'admin' && user.role === 'super_admin') ||
                        (item.targetView === 'courier' && user.role === 'courier')) && (
                        <button
                          type="button"
                          onClick={() => handleOpenNotification(item)}
                          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                          <span>
                            {item.targetView === 'support'
                              ? 'فتح الدعم الفني'
                              : item.targetView === 'subscription'
                              ? 'فتح صفحة الاشتراك'
                              : item.targetView === 'admin'
                              ? 'فتح لوحة المدير'
                              : 'فتح لوحة المندوب'}
                          </span>
                        </button>
                      )}

                  {!item.isRead && (
                    <button
                      type="button"
                      onClick={() => markNotificationRead(item.id)}
                      className="inline-flex min-h-[38px] items-center rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
                    >
                      تحديد كمقروء
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => deleteNotification(item.id)}
                    aria-label="حذف الإشعار"
                    className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-danger-border text-sq-danger-text hover:bg-sq-danger-bg"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
