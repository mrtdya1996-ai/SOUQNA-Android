import React from 'react';
import { Loader2 } from 'lucide-react';
import { AppShell } from './components/AppShell';
import { SouqnaLogo } from './components/SouqnaLogo';
import { AppProvider, useApp } from './context/AppContext';
import { AccountView } from './views/AccountView';
import { AdminDashboardView } from './views/AdminDashboardView';
import { AuthView } from './views/AuthView';
import { CartCheckoutView } from './views/CartCheckoutView';
import { CourierDashboardView } from './views/CourierDashboardView';
import { CourierRegisterView } from './views/CourierRegisterView';
import { HomeView } from './views/HomeView';
import { MerchantDashboardView } from './views/MerchantDashboardView';
import { NotificationsView } from './views/NotificationsView';
import { OrdersView } from './views/OrdersView';
import { ProductsCatalogView } from './views/ProductsCatalogView';
import { StoreDetailView } from './views/StoreDetailView';
import { StoresDirectoryView } from './views/StoresDirectoryView';
import { SubscriptionView } from './views/SubscriptionView';
import { SupportView } from './views/SupportView';

import { getConfiguredApiBaseUrl, isNativeCapacitorApp } from './lib/api';
import {
  getLastConnectionDiagnostic,
  runLiveConnectivityProbe,
  sanitizeDiagnosticText,
  type LiveProbeReport,
} from './lib/diagnostics';

interface ErrorBoundaryState {
  hasError: boolean;
  errorName: string;
  errorMessage: string;
  errorStack: string;
  componentStack: string;
  copied: boolean;
  probing: boolean;
  probeReport: LiveProbeReport | null;
}

const INITIAL_ERROR_STATE: ErrorBoundaryState = {
  hasError: false,
  errorName: '',
  errorMessage: '',
  errorStack: '',
  componentStack: '',
  copied: false,
  probing: false,
  probeReport: null,
};

function summarizeBoundaryCause(state: ErrorBoundaryState): {
  titleAr: string;
  summaryAr: string;
} {
  const connDiag = getLastConnectionDiagnostic();
  if (connDiag) {
    return {
      titleAr: connDiag.titleAr,
      summaryAr: `${connDiag.messageAr} (${connDiag.code})`,
    };
  }
  const safeName = sanitizeDiagnosticText(state.errorName || 'RuntimeError', 60);
  const safeMsg = sanitizeDiagnosticText(state.errorMessage || 'خطأ غير محدد أثناء العرض', 220);
  return {
    titleAr: `توقف عرض الصفحة بسبب خطأ (${safeName})`,
    summaryAr: safeMsg,
  };
}

function buildDiagnosticReport(boundary: string, state: ErrorBoundaryState): string {
  const origin = typeof window !== 'undefined' ? window.location?.origin || '' : '';
  const pathname = typeof window !== 'undefined' ? window.location?.pathname || '/' : '/';
  const apiBase = getConfiguredApiBaseUrl() || '(same-origin)';
  const runtime = isNativeCapacitorApp() ? 'android-capacitor' : 'web';
  const connDiag = getLastConnectionDiagnostic();
  const lines = [
    `Boundary: ${boundary}`,
    `Runtime: ${runtime}`,
    `Error: ${state.errorName || 'Error'}: ${state.errorMessage || 'Unknown error'}`,
    `App Origin: ${origin}`,
    `Path: ${pathname}`,
    `API Base: ${apiBase}`,
  ];
  if (connDiag) {
    lines.push(
      `Last API Failure: ${connDiag.code} | HTTP ${connDiag.status} | ${connDiag.endpoint} -> ${connDiag.targetOrigin}`
    );
  }
  if (state.probeReport) {
    lines.push('Live Probe:');
    for (const step of state.probeReport.steps) {
      lines.push(`  [${step.ok ? 'OK' : 'FAIL'}] ${step.name} (${step.status}, ${step.latencyMs}ms): ${step.summary}`);
    }
  }
  if (state.componentStack) {
    lines.push(`ComponentStack:${state.componentStack.slice(0, 600)}`);
  }
  if (state.errorStack) {
    lines.push(`Stack:\n${state.errorStack.slice(0, 900)}`);
  }
  return sanitizeDiagnosticText(lines.join('\n'), 2600);
}

function copyDiagnosticText(text: string, onDone: () => void): void {
  try {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      void navigator.clipboard.writeText(text).then(onDone).catch(() => {});
      return;
    }
  } catch {
    // ignore
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    onDone();
  } catch {
    // ignore
  }
}

class ViewErrorBoundary extends React.Component<
  { resetKey: string; onGoHome: () => void; children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { resetKey: string; onGoHome: () => void; children: React.ReactNode }) {
    super(props);
    this.state = { ...INITIAL_ERROR_STATE };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return {
      hasError: true,
      errorName: error instanceof Error ? error.name : 'Error',
      errorMessage: error instanceof Error ? error.message : String(error || 'Unexpected render error'),
      errorStack: error instanceof Error ? error.stack || '' : '',
      copied: false,
      probing: false,
      probeReport: null,
    };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    const componentStack = info?.componentStack || '';
    console.error('[SOUQNA ViewErrorBoundary]', error, componentStack);
    this.setState({ componentStack });
  }

  componentDidUpdate(prevProps: { resetKey: string }): void {
    if (this.state.hasError && prevProps.resetKey !== this.props.resetKey) {
      this.setState({ ...INITIAL_ERROR_STATE });
    }
  }

  handleProbe = async (): Promise<void> => {
    this.setState({ probing: true });
    try {
      const probeReport = await runLiveConnectivityProbe(
        getConfiguredApiBaseUrl(),
        isNativeCapacitorApp()
      );
      this.setState({ probeReport, probing: false });
    } catch {
      this.setState({ probing: false });
    }
  };

  render() {
    if (this.state.hasError) {
      const report = buildDiagnosticReport(`ViewErrorBoundary(${this.props.resetKey})`, this.state);
      const cause = summarizeBoundaryCause(this.state);
      return (
        <div className="mx-auto max-w-lg py-10 text-center">
          <div className="rounded-3xl border border-sq-gold-hairline bg-sq-surface p-6 sm:p-7 space-y-4 shadow-xl">
            <h2 className="font-display text-lg font-extrabold text-sq-ink">
              {cause.titleAr}
            </h2>
            <p className="text-sm text-sq-ink-muted leading-relaxed">
              {cause.summaryAr}
            </p>
            <div className="rounded-xl border border-sq-border bg-sq-muted p-3 text-left space-y-2" dir="ltr">
              <pre className="max-h-40 overflow-auto whitespace-pre-wrap break-words font-mono text-[11px] text-sq-ink">
                {report}
              </pre>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={this.state.probing}
                  onClick={() => void this.handleProbe()}
                  className="rounded-lg border border-sq-gold/40 bg-sq-gold-soft px-2.5 py-1 text-[11px] font-bold text-sq-gold-text disabled:opacity-60"
                >
                  {this.state.probing ? 'جاري فحص الخادم...' : 'فحص الاتصال بالخادم'}
                </button>
                <button
                  type="button"
                  onClick={() => copyDiagnosticText(report, () => this.setState({ copied: true }))}
                  className="rounded-lg border border-sq-border bg-sq-surface px-2.5 py-1 text-[11px] font-semibold text-sq-ink"
                >
                  {this.state.copied ? 'تم النسخ' : 'نسخ تقرير التشخيص'}
                </button>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => this.setState({ ...INITIAL_ERROR_STATE })}
                className="min-h-[44px] flex-1 rounded-xl btn-gold px-4 text-sm font-bold"
              >
                إعادة المحاولة
              </button>
              <button
                type="button"
                onClick={() => {
                  this.setState({ ...INITIAL_ERROR_STATE });
                  this.props.onGoHome();
                }}
                className="min-h-[44px] flex-1 rounded-xl border border-sq-border bg-sq-elevated px-4 text-sm font-semibold text-sq-ink"
              >
                الصفحة الرئيسية
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const ActiveViewRouter: React.FC = () => {
  const { activeView, authReady, navigate } = useApp();

  if (!authReady) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
        <SouqnaLogo size="lg" />
        <div className="inline-flex items-center gap-2 rounded-xl border border-sq-gold-hairline bg-sq-surface px-4 py-2.5 text-xs font-semibold text-sq-ink-muted">
          <Loader2 className="h-4 w-4 animate-spin text-sq-gold-text" />
          <span>جاري استعادة جلستك المحفوظة...</span>
        </div>
      </div>
    );
  }

  let content: React.ReactNode;
  switch (activeView) {
    case 'stores':
      content = <StoresDirectoryView />;
      break;
    case 'products':
      content = <ProductsCatalogView />;
      break;
    case 'store':
      content = <StoreDetailView />;
      break;
    case 'cart':
      content = <CartCheckoutView />;
      break;
    case 'orders':
      content = <OrdersView />;
      break;
    case 'merchant':
      content = <MerchantDashboardView />;
      break;
    case 'courier':
      content = <CourierDashboardView />;
      break;
    case 'courier_register':
      content = <CourierRegisterView />;
      break;
    case 'admin':
      content = <AdminDashboardView />;
      break;
    case 'account':
      content = <AccountView />;
      break;
    case 'notifications':
      content = <NotificationsView />;
      break;
    case 'support':
      content = <SupportView />;
      break;
    case 'subscription':
      content = <SubscriptionView />;
      break;
    case 'auth':
      content = <AuthView />;
      break;
    case 'home':
    default:
      content = <HomeView />;
      break;
  }

  return (
    <ViewErrorBoundary resetKey={activeView} onGoHome={() => navigate('home')}>
      {content}
    </ViewErrorBoundary>
  );
};

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { ...INITIAL_ERROR_STATE };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return {
      hasError: true,
      errorName: error instanceof Error ? error.name : 'Error',
      errorMessage: error instanceof Error ? error.message : String(error || 'Unexpected runtime error'),
      errorStack: error instanceof Error ? error.stack || '' : '',
      copied: false,
      probing: false,
      probeReport: null,
    };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    const componentStack = info?.componentStack || '';
    console.error('[SOUQNA AppErrorBoundary]', error, componentStack);
    this.setState({ componentStack });
  }

  handleProbe = async (): Promise<void> => {
    this.setState({ probing: true });
    try {
      const probeReport = await runLiveConnectivityProbe(
        getConfiguredApiBaseUrl(),
        isNativeCapacitorApp()
      );
      this.setState({ probeReport, probing: false });
    } catch {
      this.setState({ probing: false });
    }
  };

  render() {
    if (this.state.hasError) {
      const report = buildDiagnosticReport('AppErrorBoundary', this.state);
      const cause = summarizeBoundaryCause(this.state);
      return (
        <div
          dir="rtl"
          className="min-h-screen flex items-center justify-center bg-sq-canvas px-4 py-8 text-sq-ink"
        >
          <div className="max-w-lg w-full rounded-3xl border border-sq-gold-hairline bg-sq-surface p-6 sm:p-7 text-center space-y-4 shadow-xl">
            <h1 className="font-display text-lg sm:text-xl font-extrabold text-sq-ink">
              {cause.titleAr}
            </h1>
            <p className="text-sm text-sq-ink-muted leading-relaxed">
              {cause.summaryAr}
            </p>
            <div className="rounded-xl border border-sq-border bg-sq-muted p-3 text-left space-y-2" dir="ltr">
              <pre className="max-h-48 overflow-auto whitespace-pre-wrap break-words font-mono text-[11px] text-sq-ink">
                {report}
              </pre>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={this.state.probing}
                  onClick={() => void this.handleProbe()}
                  className="rounded-lg border border-sq-gold/40 bg-sq-gold-soft px-2.5 py-1 text-[11px] font-bold text-sq-gold-text disabled:opacity-60"
                >
                  {this.state.probing ? 'جاري فحص الخادم...' : 'فحص الاتصال بالخادم'}
                </button>
                <button
                  type="button"
                  onClick={() => copyDiagnosticText(report, () => this.setState({ copied: true }))}
                  className="rounded-lg border border-sq-border bg-sq-surface px-2.5 py-1 text-[11px] font-semibold text-sq-ink"
                >
                  {this.state.copied ? 'تم النسخ' : 'نسخ تقرير التشخيص'}
                </button>
              </div>
            </div>
            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => this.setState({ ...INITIAL_ERROR_STATE })}
                className="min-h-[46px] w-full rounded-xl btn-gold px-5 text-sm font-bold"
              >
                المحاولة مجدداً
              </button>
              <button
                type="button"
                onClick={() => {
                  if (isNativeCapacitorApp() && window.location?.pathname && window.location.pathname !== '/') {
                    window.location.replace('/');
                  } else {
                    window.location.reload();
                  }
                }}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-5 text-sm font-semibold text-sq-ink"
              >
                إعادة تحميل سوقنا
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <AppErrorBoundary>
      <AppProvider>
        <AppShell>
          <ActiveViewRouter />
        </AppShell>
      </AppProvider>
    </AppErrorBoundary>
  );
}
