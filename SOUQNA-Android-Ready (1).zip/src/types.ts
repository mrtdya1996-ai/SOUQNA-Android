export type UserRole = 'customer' | 'merchant' | 'courier' | 'super_admin';

export type CourierVehicleType = 'motorcycle' | 'car' | 'bicycle' | 'light_truck';

export type CourierVerificationStatus = 'pending' | 'verified' | 'rejected' | 'suspended';

export type DeliveryStatus =
  | 'waiting_courier'
  | 'dispatched'
  | 'accepted'
  | 'heading_to_store'
  | 'picked_up'
  | 'on_the_way'
  | 'delivered'
  | 'cancelled';

export type ComplaintTargetType =
  | 'store'
  | 'courier'
  | 'order'
  | 'user'
  | 'technical_support'
  | 'subscription'
  | 'general';
export type ComplaintStatus =
  | 'open'
  | 'under_review'
  | 'replied'
  | 'resolved'
  | 'dismissed'
  | 'closed';

export type StorePlanName = 'free' | 'basic' | 'pro' | 'enterprise';
export type StoreSubscriptionStatus = 'active' | 'trial' | 'expired' | 'suspended';
export type SubscriberType = 'merchant' | 'courier';
export type SubscriptionActionType =
  | 'trial_started'
  | 'activated'
  | 'extended'
  | 'suspended'
  | 'reactivated'
  | 'payment_recorded'
  | 'payment_approved'
  | 'payment_rejected'
  | 'dates_updated'
  | 'reminder_sent'
  | 'expired'
  | 'renewal_requested'
  | 'updated';

export type PaymentMethodCode = 'zaincash' | 'mastercard';
export type SubscriptionPaymentRequestStatus = 'pending' | 'approved' | 'rejected';
export type AccountRecoveryStatus = 'pending' | 'approved' | 'rejected' | 'completed';

export type StoreType =
  | 'grocery'
  | 'supermarket'
  | 'food_market'
  | 'produce'
  | 'mall'
  | 'shop'
  | 'construction'
  | 'clothing'
  | 'phone_accessories'
  | 'printing'
  | 'gaming_topup';

export type StorePostType = 'announcement' | 'offer' | 'new_arrival' | 'update';
export type StorePostStatus = 'active' | 'hidden';

export interface StorePost {
  id: string;
  storeId: string;
  storeName?: string;
  storeType?: StoreType;
  storeCity?: string;
  storeDistrict?: string;
  storeLogoUrl?: string;
  storeStatus?: StoreStatus;
  authorId: string;
  authorName?: string;
  title: string;
  content: string;
  postType: StorePostType;
  offerBadge: string;
  images: string[];
  status: StorePostStatus;
  moderationReason: string;
  createdAt: string;
  updatedAt: string;
}

export type StoreStatus = 'pending' | 'active' | 'rejected' | 'suspended';

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'preparing'
  | 'ready'
  | 'out_for_delivery'
  | 'delivered'
  | 'rejected'
  | 'cancelled';

export type FulfillmentMethod = 'delivery' | 'pickup';

export type PricingType = 'unit' | 'carton';

export type PrintPaperSize = 'A4' | 'A3' | 'A5' | 'photo';
export type PrintColorMode = 'bw' | 'color';
export type PrintSides = 'single' | 'double';
export type PrintBindingType = 'none' | 'spiral' | 'thermal' | 'lamination';

export interface PrintPricingConfig {
  bwA4Price: number;
  colorA4Price: number;
  bwA3Price: number;
  colorA3Price: number;
  bwA5Price: number;
  colorA5Price: number;
  photoPrice: number;
  doubleSidedDiscountPercent: number;
  bindingSpiralPrice: number;
  bindingThermalPrice: number;
  laminationPrice: number;
}

export interface StoreServiceConfig {
  printPricing?: PrintPricingConfig;
}

export interface PrintJobDetails {
  serviceType: string;
  fileUrl: string;
  fileName: string;
  fileMime: string;
  copies: number;
  pages: number;
  colorMode: PrintColorMode;
  paperSize: PrintPaperSize;
  sides: PrintSides;
  binding: PrintBindingType;
  unitPagePrice: number;
  bindingPricePerCopy: number;
  notes?: string;
}

export interface OrderItemOptions {
  selectedSize?: string;
  selectedColor?: string;
  selectedPhoneModel?: string;
  selectedOption?: string;
  gameName?: string;
  playerId?: string;
  printJob?: PrintJobDetails;
}

export interface User {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  city: string;
  governorate: string;
  district: string;
  neighborhood: string;
  address: string;
  latitude: number | null;
  longitude: number | null;
  role: UserRole;
  isActive: boolean;
  createdAt: string;
}

export interface Store {
  id: string;
  ownerId: string;
  ownerName?: string;
  ownerPhone?: string;
  name: string;
  storeType: StoreType;
  description: string;
  city: string;
  district: string;
  address: string;
  latitude?: number | null;
  longitude?: number | null;
  phone: string;
  openingHours: string;
  deliveryFee: number;
  minOrderAmount: number;
  logoUrl: string;
  coverUrl: string;
  status: StoreStatus;
  rejectionReason: string;
  isVerified: boolean;
  notifyOnStoreVisit: boolean;
  serviceConfig?: StoreServiceConfig;
  subscription?: StoreSubscription | null;
  productCount?: number;
  orderCount?: number;
  postCount?: number;
  latestPost?: StorePost | null;
  createdAt: string;
}

export interface StoreSubscription {
  storeId: string;
  storeName?: string;
  storeStatus?: StoreStatus;
  ownerName?: string;
  planName: StorePlanName;
  status: StoreSubscriptionStatus;
  monthlyFee: number;
  expiresAt: string;
  notes: string;
  updatedAt: string;
}

export interface UserSubscription {
  id: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
  userActive?: boolean;
  subscriberType: SubscriberType;
  storeId: string | null;
  storeName?: string;
  storeType?: StoreType;
  storeStatus?: StoreStatus;
  courierId?: string | null;
  courierStatus?: CourierVerificationStatus;
  planName: string;
  status: StoreSubscriptionStatus;
  startsAt: string;
  expiresAt: string;
  daysRemaining: number;
  isExpiringSoon: boolean;
  isCommercialActive: boolean;
  monthlyFee: number;
  totalPaid: number;
  renewalRequested: boolean;
  renewalNote: string;
  renewalRequestedAt: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
  logs?: SubscriptionLog[];
}

export interface SubscriptionLog {
  id: string;
  subscriptionId: string;
  userId: string;
  userName?: string;
  subscriberType?: SubscriberType;
  storeName?: string;
  actionType: SubscriptionActionType;
  amountPaid: number;
  durationDays: number;
  previousStatus: string;
  newStatus: string;
  previousExpiresAt: string;
  newExpiresAt: string;
  actorId: string | null;
  actorName: string;
  actorRole: string;
  notes: string;
  createdAt: string;
}

export interface SubscriptionPlan {
  id: string;
  code: string;
  name: string;
  durationMonths: number;
  durationDays: number;
  priceIqd: number;
  isActive: boolean;
  sortOrder: number;
  updatedAt: string;
}

export interface SubscriptionPaymentMethodsConfig {
  zaincashNumber: string;
  mastercardNumber: string;
}

export interface SubscriptionPaymentRequest {
  id: string;
  subscriptionId: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
  subscriberType: SubscriberType;
  storeId: string | null;
  storeName?: string;
  storeType?: StoreType;
  planId: string;
  planCode: string;
  planName: string;
  durationDays: number;
  amountIqd: number;
  paymentMethod: PaymentMethodCode;
  transferReference: string;
  transferDetails: string;
  paymentProofDoc: string;
  status: SubscriptionPaymentRequestStatus;
  rejectionReason: string;
  adminNotes: string;
  reviewedById: string | null;
  reviewedByName: string;
  reviewedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface AccountRecoveryRequest {
  id: string;
  matchedUserId: string | null;
  matchedUserName?: string;
  matchedUserEmail?: string;
  matchedUserPhone?: string;
  matchedUserRole?: UserRole;
  requesterName: string;
  requesterPhone: string;
  requesterEmail: string;
  accountType: string;
  proofDetails: string;
  status: AccountRecoveryStatus;
  adminNotes: string;
  rejectionReason: string;
  reviewedById: string | null;
  reviewedAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface IssuedPasswordReset {
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  resetToken: string;
  tempCode: string;
  resetPath: string;
  expiresAt: string;
}

export interface SubscriptionSummaryStats {
  totalSubscribers: number;
  merchantSubscribers: number;
  courierSubscribers: number;
  activeCount: number;
  trialCount: number;
  expiringSoonCount: number;
  expiredCount: number;
  suspendedCount: number;
  renewalRequestsCount: number;
  pendingPaymentRequestsCount: number;
  totalRecordedRevenue: number;
}

export interface AdminAuditLog {
  id: string;
  adminId: string;
  adminName: string;
  actionType: string;
  targetType: string;
  targetId: string;
  targetLabel: string;
  details: string;
  createdAt: string;
}

export interface CourierProfile {
  id: string;
  userId: string;
  fullName: string;
  email: string;
  phone: string;
  isUserActive: boolean;
  governorate: string;
  city: string;
  district: string;
  neighborhood: string;
  address: string;
  avatarUrl: string;
  vehicleType: CourierVehicleType;
  plateNumber: string;
  idType: string;
  idNumber: string;
  idFrontDoc: string;
  idBackDoc: string;
  licenseDoc: string;
  termsAccepted: boolean;
  verificationStatus: CourierVerificationStatus;
  rejectionReason: string;
  isAvailable: boolean;
  latitude: number | null;
  longitude: number | null;
  locationUpdatedAt: string;
  totalDeliveries: number;
  activeDeliveriesCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface DeliveryEvent {
  id: string;
  deliveryId: string;
  eventType: string;
  actorId: string | null;
  actorName: string;
  actorRole: string;
  notes: string;
  previousStatus: string;
  newStatus: string;
  createdAt: string;
}

export interface Delivery {
  id: string;
  deliveryNumber: string;
  orderId: string;
  orderNumber?: string;
  storeId: string;
  storeName?: string;
  storePhone?: string;
  storeAddress?: string;
  customerId: string;
  customerName?: string;
  customerPhone?: string;
  courierId: string | null;
  courierName?: string;
  courierPhone?: string;
  courierVehicleType?: CourierVehicleType;
  courierPlateNumber?: string;
  status: DeliveryStatus;
  pickupAddress: string;
  pickupLat: number | null;
  pickupLng: number | null;
  dropoffAddress: string;
  dropoffLat: number | null;
  dropoffLng: number | null;
  deliveryFee: number;
  cashToCollect: number;
  deliveryOtp?: string;
  otpVerified: boolean;
  distanceKm: number | null;
  cancelReason: string;
  requestedAt: string;
  dispatchedAt: string;
  acceptedAt: string;
  pickedUpAt: string;
  deliveredAt: string;
  cancelledAt: string;
  updatedAt: string;
  events?: DeliveryEvent[];
}

export interface ComplaintMessage {
  id: string;
  complaintId: string;
  senderId: string;
  senderName: string;
  senderRole: string;
  message: string;
  imageUrl: string;
  createdAt: string;
}

export interface Complaint {
  id: string;
  reporterId: string;
  reporterName?: string;
  reporterPhone?: string;
  reporterRole: string;
  targetType: ComplaintTargetType;
  targetId: string;
  targetName: string;
  orderId: string | null;
  orderNumber?: string;
  deliveryId: string | null;
  category: string;
  description: string;
  imageUrl: string;
  status: ComplaintStatus;
  violationRecorded: boolean;
  adminNotes: string;
  resolvedById: string | null;
  messages?: ComplaintMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  id: string;
  storeId: string;
  storeName?: string;
  storeCity?: string;
  storeDistrict?: string;
  storeType?: StoreType;
  storeDeliveryFee?: number;
  storeAddress?: string;
  storePhone?: string;
  name: string;
  category: string;
  description: string;
  price: number;
  unit: string;
  cartonPrice: number;
  cartonUnits: number;
  stockQty: number;
  imageUrl: string;
  isAvailable: boolean;
  availableSizes: string[];
  availableColors: string[];
  compatibleModels: string[];
  gameName: string;
  customOptions: string[];
  createdAt: string;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string | null;
  productName: string;
  unit: string;
  pricingType: PricingType;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
  imageUrl: string;
  selectedOptions?: OrderItemOptions;
}

export interface OrderEvent {
  id: string;
  orderId: string;
  eventType:
    | 'created'
    | 'status_changed'
    | 'cancelled'
    | 'cancel_requested'
    | 'rejected'
    | 'stock_restored';
  actorId: string | null;
  actorName: string;
  actorRole: string;
  reason: string;
  previousStatus: string;
  newStatus: string;
  createdAt: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  storeId: string;
  storeName: string;
  storePhone?: string;
  storeAddress?: string;
  status: OrderStatus;
  paymentMethod: 'cash_on_delivery';
  fulfillmentMethod: FulfillmentMethod;
  subtotal: number;
  deliveryFee: number;
  totalAmount: number;
  governorate: string;
  city: string;
  district: string;
  neighborhood: string;
  deliveryAddress: string;
  latitude: number | null;
  longitude: number | null;
  customerName: string;
  customerPhone: string;
  notes: string;
  cancelReason: string;
  cancelledById: string | null;
  cancelledByName: string;
  cancelledByRole: string;
  cancelledAt: string;
  stockRestored: boolean;
  items: OrderItem[];
  events?: OrderEvent[];
  delivery?: Delivery | null;
  createdAt: string;
  updatedAt: string;
}

export type NotificationType =
  | 'order_new'
  | 'order_cancelled'
  | 'order_cancel_requested'
  | 'order_updated'
  | 'order_rejected'
  | 'store_visit'
  | 'store_status'
  | 'delivery_new'
  | 'delivery_accepted'
  | 'delivery_updated'
  | 'delivery_completed'
  | 'delivery_cancelled'
  | 'courier_status'
  | 'complaint_new'
  | 'complaint_reply'
  | 'subscription_alert'
  | 'account_recovery'
  | 'system';

export interface NotificationItem {
  id: string;
  userId: string;
  recipientName?: string;
  recipientRole?: string;
  storeId: string | null;
  storeName?: string;
  orderId: string | null;
  orderNumber?: string;
  type: NotificationType;
  title: string;
  body: string;
  targetView: 'merchant' | 'orders' | 'admin' | 'courier' | 'notifications' | 'support' | 'subscription';
  isRead: boolean;
  createdAt: string;
}

export interface PushConfig {
  vapidPublicKey: string;
  webPushEnabled: boolean;
  activeDeviceCount: number;
  expoConfigured: boolean;
}

export interface CartItem {
  id?: string;
  key: string; // `${product.id}:${pricingType}:${optionSignature}`
  product: Product;
  pricingType: PricingType;
  appliedUnitPrice: number;
  appliedUnitLabel: string;
  storeId: string;
  storeName: string;
  storeDeliveryFee: number;
  storeAddress: string;
  quantity: number;
  selectedOptions?: OrderItemOptions;
}

export interface MarketplaceCategory {
  id: string;
  name: string;
  description: string;
  storeType: StoreType | 'all';
  sortOrder: number;
  isActive: boolean;
  productCount?: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminAccountSummary {
  user: User;
  activeSessionsCount: number;
  totalAuditActions: number;
  lastAuditAt: string;
}

export interface BootstrapStatus {
  hasSuperAdmin: boolean;
  requireSetupCode: boolean;
  emailResetConfigured?: boolean;
  currency: string;
  trialDays?: number;
  appName?: string;
  supportPhone?: string;
  supportTelegram?: string;
  announcementText?: string;
  requireStoreApproval: boolean;
  requireCourierApproval: boolean;
  enabledStoreTypes: StoreType[];
}

export interface PlatformOverview {
  totalUsers: number;
  totalCustomers: number;
  totalMerchants: number;
  totalCouriers: number;
  pendingCouriers: number;
  verifiedCouriers: number;
  availableCouriers: number;
  totalStores: number;
  activeStores: number;
  pendingStores: number;
  rejectedStores: number;
  suspendedStores: number;
  totalProducts: number;
  totalCategories?: number;
  activeCategories?: number;
  totalStorePosts?: number;
  hiddenStorePosts?: number;
  totalOrders: number;
  pendingOrders: number;
  deliveredOrders: number;
  cancelledOrders: number;
  totalDeliveries: number;
  activeDeliveries: number;
  deliveredDeliveries: number;
  openComplaints: number;
  pendingRecoveryRequests?: number;
  pendingPaymentRequests?: number;
  totalCashVolume: number;
  subscriptionStats?: SubscriptionSummaryStats;
  currency: string;
  trialDays?: number;
  appName?: string;
  supportPhone?: string;
  supportTelegram?: string;
  announcementText?: string;
  requireStoreApproval: boolean;
  requireCourierApproval: boolean;
  enabledStoreTypes: StoreType[];
}

export const ALL_STORE_TYPES: StoreType[] = [
  'food_market',
  'supermarket',
  'grocery',
  'produce',
  'mall',
  'shop',
  'construction',
  'clothing',
  'phone_accessories',
  'printing',
  'gaming_topup',
];

export const STORE_TYPE_LABELS: Record<StoreType, string> = {
  grocery: 'بقالة',
  supermarket: 'سوبر ماركت',
  food_market: 'أسواق غذائية',
  produce: 'خضروات وفواكه',
  mall: 'مولات',
  shop: 'محلات تجارية',
  construction: 'محلات إنشائية',
  clothing: 'ملابس وأحذية',
  phone_accessories: 'إكسسوارات هواتف',
  printing: 'مطابع واستنساخ',
  gaming_topup: 'شحن ألعاب',
};

export const STORE_POST_TYPE_LABELS: Record<StorePostType, string> = {
  offer: 'عرض خاص',
  announcement: 'إعلان متجر',
  new_arrival: 'وصل حديثاً',
  update: 'تحديث المتجر',
};

export const STORE_SUBCATEGORIES: Record<StoreType, string[]> = {
  grocery: ['خضار وفواكه', 'مواد غذائية', 'ألبان ومخبوزات', 'مشروبات وعصائر', 'منظفات ومنزلية', 'أخرى'],
  supermarket: ['مواد غذائية', 'خضار وفواكه', 'ألبان ومخبوزات', 'لحوم ودواجن', 'مشروبات وعصائر', 'منظفات ومنزلية', 'أخرى'],
  food_market: ['مواد غذائية', 'خضار وفواكه', 'لحوم ودواجن', 'ألبان ومخبوزات', 'بهارات وحبوب', 'مشروبات وعصائر', 'أخرى'],
  produce: ['خضروات طازجة', 'فواكه موسمية', 'ورقيات وأعشاب', 'تمور وفواكه مجففة', 'سلال خضار وفواكه', 'أخرى'],
  mall: ['ملابس وموضة', 'مواد غذائية', 'إلكترونيات ومنوعات', 'مستلزمات منزلية', 'عطور وهدايا', 'أخرى'],
  shop: ['مواد غذائية', 'مستلزمات منزلية', 'إلكترونيات ومنوعات', 'هدايا وقرطاسية', 'أخرى'],
  construction: [
    'مواد البناء',
    'الإسمنت والطابوق',
    'الحديد والمواد الإنشائية',
    'الأدوات الصحية',
    'الكهرباء والمواد الكهربائية',
    'الدهانات ومستلزمات البناء',
    'أخرى',
  ],
  clothing: [
    'ملابس رجالية',
    'ملابس نسائية',
    'ملابس أطفال',
    'أحذية',
    'حقائب',
    'ملابس رياضية',
    'أخرى',
  ],
  phone_accessories: [
    'إكسسوارات الهواتف',
    'شواحن',
    'سماعات',
    'كفرات',
    'حماية الشاشة',
    'باور بانك',
    'قطع ومستلزمات الهواتف',
    'أخرى',
  ],
  printing: [
    'طباعة مستندات',
    'استنساخ وتصوير',
    'طباعة ملونة وأبيض وأسود',
    'طباعة الصور',
    'طباعة البحوث والملفات',
    'التغليف والتجليد',
    'قرطاسية ومستلزمات',
  ],
  gaming_topup: [
    'شحن PUBG Mobile',
    'شحن Free Fire',
    'شحن Call of Duty Mobile',
    'بطاقات ألعاب ومنصات',
    'ألعاب أخرى',
  ],
};

export const STORE_UNITS: Record<StoreType, string[]> = {
  grocery: ['قطعة', 'كيلو', 'نصف كيلو', 'علبة', 'عبوة', 'ربطة', 'لتر', 'كيس'],
  supermarket: ['قطعة', 'كيلو', 'علبة', 'عبوة', 'لتر', 'كيس', 'باكيت'],
  food_market: ['كيلو', 'نصف كيلو', 'قطعة', 'علبة', 'كيس', 'ربطة', 'لتر'],
  produce: ['كيلو', 'نصف كيلو', 'صندوق', 'سلة', 'ربطة', 'قطعة', 'كيس'],
  mall: ['قطعة', 'طقم', 'علبة', 'عبوة', 'زوج'],
  shop: ['قطعة', 'علبة', 'عبوة', 'طقم', 'كيس'],
  construction: ['كيس', 'طن', 'قطعة', 'متر', 'لفة', 'سطل', 'علبة', 'لوح', 'طقم', 'طابوقة'],
  clothing: ['قطعة', 'طقم', 'زوج', 'حقيبة'],
  phone_accessories: ['قطعة', 'طقم', 'علبة'],
  printing: ['نسخة', 'صفحة', 'صورة', 'ملف', 'دفتر', 'قطعة'],
  gaming_topup: ['باقة', 'شدة / جوهرة', 'بطاقة', 'اشتراك'],
};

export const POPULAR_GAMES: string[] = [
  'PUBG Mobile',
  'Free Fire',
  'Call of Duty Mobile',
  'Mobile Legends',
  'Roblox',
  'PlayStation / Xbox',
  'ألعاب أخرى',
];

export const CLOTHING_SIZE_PRESETS: string[] = [
  'XS',
  'S',
  'M',
  'L',
  'XL',
  'XXL',
  '3XL',
  '38',
  '39',
  '40',
  '41',
  '42',
  '43',
  '44',
  '45',
  'مقاس موحد',
];

export const CLOTHING_COLOR_PRESETS: string[] = [
  'أسود',
  'أبيض',
  'رمادي',
  'كحلي',
  'بيج',
  'أخضر',
  'أزرق',
  'أحمر',
  'بني',
  'وردي',
];

export const PHONE_MODEL_PRESETS: string[] = [
  'جميع الهواتف (عام)',
  'iPhone 16 Pro Max',
  'iPhone 16 / 16 Pro',
  'iPhone 15 Pro Max',
  'iPhone 15 / 15 Pro',
  'iPhone 14 / 14 Pro',
  'iPhone 13 / 13 Pro',
  'Samsung S24 Ultra',
  'Samsung S24 / S23',
  'Samsung A55 / A54',
  'Samsung A35 / A25',
  'Xiaomi Redmi Note 13',
  'Huawei / Honor',
  'Oppo / Realme',
];

export const PRINT_SERVICE_TYPES: string[] = [
  'طباعة مستندات',
  'استنساخ وتصوير',
  'طباعة ملونة وأبيض وأسود',
  'طباعة الصور',
  'طباعة البحوث والملفات',
  'خدمات التغليف والتجليد',
];

export const PRINT_PAPER_LABELS: Record<PrintPaperSize, string> = {
  A4: 'ورق A4 (قياسي)',
  A3: 'ورق A3 (كبير)',
  A5: 'ورق A5 (صغير)',
  photo: 'ورق صور لامع (Photo)',
};

export const PRINT_COLOR_LABELS: Record<PrintColorMode, string> = {
  bw: 'أبيض وأسود',
  color: 'ملون',
};

export const PRINT_SIDES_LABELS: Record<PrintSides, string> = {
  single: 'وجه واحد',
  double: 'وجهين (وش وظهر)',
};

export const PRINT_BINDING_LABELS: Record<PrintBindingType, string> = {
  none: 'بدون تغليف / تجليد',
  spiral: 'تجليد حلزوني (سلك / بلاستيك)',
  thermal: 'تجليد حراري (كتب وبحوث)',
  lamination: 'تغليف شفاف (حماية حرارية)',
};

export const DEFAULT_PRINT_PRICING: PrintPricingConfig = {
  bwA4Price: 100,
  colorA4Price: 250,
  bwA3Price: 250,
  colorA3Price: 500,
  bwA5Price: 75,
  colorA5Price: 200,
  photoPrice: 1000,
  doubleSidedDiscountPercent: 0,
  bindingSpiralPrice: 1500,
  bindingThermalPrice: 2500,
  laminationPrice: 1000,
};

export function calculatePrintJobPrice(
  pricingInput: Partial<PrintPricingConfig> | undefined,
  params: {
    pages: number;
    copies: number;
    colorMode: PrintColorMode;
    paperSize: PrintPaperSize;
    sides: PrintSides;
    binding: PrintBindingType;
  }
): {
  unitPagePrice: number;
  bindingPricePerCopy: number;
  perCopyTotal: number;
  grandTotal: number;
} {
  const pricing: PrintPricingConfig = {
    ...DEFAULT_PRINT_PRICING,
    ...(pricingInput || {}),
  };

  let unitPagePrice = pricing.bwA4Price;
  if (params.paperSize === 'photo') {
    unitPagePrice = pricing.photoPrice;
  } else if (params.paperSize === 'A3') {
    unitPagePrice = params.colorMode === 'color' ? pricing.colorA3Price : pricing.bwA3Price;
  } else if (params.paperSize === 'A5') {
    unitPagePrice = params.colorMode === 'color' ? pricing.colorA5Price : pricing.bwA5Price;
  } else {
    unitPagePrice = params.colorMode === 'color' ? pricing.colorA4Price : pricing.bwA4Price;
  }

  const safePages = Math.max(1, Math.min(2000, Math.floor(params.pages || 1)));
  const safeCopies = Math.max(1, Math.min(500, Math.floor(params.copies || 1)));

  const discountRatio =
    params.sides === 'double' && params.paperSize !== 'photo'
      ? Math.max(0, Math.min(50, Number(pricing.doubleSidedDiscountPercent) || 0)) / 100
      : 0;

  const effectivePagePrice = Math.round(unitPagePrice * (1 - discountRatio) * 100) / 100;

  let bindingPricePerCopy = 0;
  if (params.binding === 'spiral') bindingPricePerCopy = pricing.bindingSpiralPrice;
  else if (params.binding === 'thermal') bindingPricePerCopy = pricing.bindingThermalPrice;
  else if (params.binding === 'lamination') bindingPricePerCopy = pricing.laminationPrice;

  const perCopyTotal = Math.round((safePages * effectivePagePrice + bindingPricePerCopy) * 100) / 100;
  const grandTotal = Math.round(perCopyTotal * safeCopies * 100) / 100;

  return {
    unitPagePrice: effectivePagePrice,
    bindingPricePerCopy,
    perCopyTotal,
    grandTotal,
  };
}

export function buildOptionSignature(options?: OrderItemOptions): string {
  if (!options) return '';
  const parts = [
    options.selectedSize ? `sz=${options.selectedSize.trim()}` : '',
    options.selectedColor ? `cl=${options.selectedColor.trim()}` : '',
    options.selectedPhoneModel ? `pm=${options.selectedPhoneModel.trim()}` : '',
    options.selectedOption ? `op=${options.selectedOption.trim()}` : '',
    options.gameName ? `gm=${options.gameName.trim()}` : '',
    options.playerId ? `pid=${options.playerId.trim()}` : '',
    options.printJob ? `pr=${options.printJob.fileUrl}` : '',
  ].filter(Boolean);
  return parts.join('|');
}

export function formatOrderItemOptionsSummary(options?: OrderItemOptions): string[] {
  if (!options) return [];
  const badges: string[] = [];
  if (options.selectedSize) badges.push(`المقاس: ${options.selectedSize}`);
  if (options.selectedColor) badges.push(`اللون: ${options.selectedColor}`);
  if (options.selectedPhoneModel) badges.push(`موديل الهاتف: ${options.selectedPhoneModel}`);
  if (options.selectedOption) badges.push(`الخيار: ${options.selectedOption}`);
  if (options.gameName) badges.push(`اللعبة: ${options.gameName}`);
  if (options.playerId) badges.push(`ID اللاعب: ${options.playerId}`);
  if (options.printJob) {
    const pj = options.printJob;
    badges.push(`الخدمة: ${pj.serviceType}`);
    badges.push(`${PRINT_COLOR_LABELS[pj.colorMode]} · ${PRINT_PAPER_LABELS[pj.paperSize]}`);
    badges.push(`${pj.pages} صفحة × ${pj.copies} نسخة · ${PRINT_SIDES_LABELS[pj.sides]}`);
    if (pj.binding !== 'none') {
      badges.push(PRINT_BINDING_LABELS[pj.binding]);
    }
  }
  return badges;
}

export const STORE_STATUS_LABELS: Record<StoreStatus, string> = {
  pending: 'قيد المراجعة',
  active: 'مقبول ونشط',
  rejected: 'مرفوض',
  suspended: 'موقوف',
};

export const ROLE_LABELS: Record<UserRole, string> = {
  customer: 'زبون',
  merchant: 'صاحب متجر',
  courier: 'مندوب توصيل',
  super_admin: 'المدير العام',
};

export const COURIER_VEHICLE_LABELS: Record<CourierVehicleType, string> = {
  motorcycle: 'دراجة نارية',
  car: 'سيارة',
  bicycle: 'دراجة هوائية',
  light_truck: 'ستوتة / نقل خفيف',
};

export const COURIER_STATUS_LABELS: Record<CourierVerificationStatus, string> = {
  pending: 'بانتظار مراجعة المدير',
  verified: 'موثق ومعتمد',
  rejected: 'مرفوض',
  suspended: 'موقوف',
};

export const DELIVERY_STATUS_LABELS: Record<DeliveryStatus, string> = {
  waiting_courier: 'بانتظار مندوب',
  dispatched: 'تم إرسال طلب التوصيل',
  accepted: 'وافق المندوب',
  heading_to_store: 'المندوب متجه إلى المتجر',
  picked_up: 'استلم المندوب الطلب',
  on_the_way: 'المندوب في الطريق إلى الزبون',
  delivered: 'تم تسليم الطلب',
  cancelled: 'التوصيل ملغي',
};

export const DELIVERY_STAGE_ORDER: DeliveryStatus[] = [
  'waiting_courier',
  'dispatched',
  'accepted',
  'heading_to_store',
  'picked_up',
  'on_the_way',
  'delivered',
];

export const SUPPORT_CONTACTS = {
  telegramHandle: 'murtadaa199',
  telegramUrl: 'https://t.me/murtadaa199',
  whatsappDisplay: '07764327688',
  whatsappUrl: 'https://wa.me/9647764327688',
} as const;

export const COMPLAINT_STATUS_LABELS: Record<ComplaintStatus, string> = {
  open: 'جديدة',
  under_review: 'قيد المراجعة',
  replied: 'تم الرد',
  resolved: 'تمت المعالجة',
  closed: 'مغلقة',
  dismissed: 'مغلقة بدون مخالفة',
};

export const COMPLAINT_TARGET_LABELS: Record<ComplaintTargetType, string> = {
  store: 'متجر',
  courier: 'مندوب توصيل',
  order: 'طلب',
  user: 'حساب مستخدم',
  technical_support: 'الدعم الفني',
  subscription: 'الاشتراكات والتجديد',
  general: 'استفسار أو شكوى عامة',
};

export const COMPLAINT_CATEGORIES: string[] = [
  'تأخر كبير في التوصيل أو التجهيز',
  'منتج تالف أو مختلف عن الطلب',
  'سلوك غير لائق من المندوب أو المتجر',
  'مخالفة في السعر أو المبلغ المطلوب',
  'عدم استلام الطلب أو إلغاء غير مبرر',
  'اشتباه احتيال أو مخالفة شروط المنصة',
  'مشكلة تقنية في التطبيق',
  'طلب تفعيل أو تجديد اشتراك',
  'مشكلة في الحساب أو الدخول',
  'شكوى أخرى',
];

export const SUPPORT_ISSUE_CATEGORIES: string[] = [
  'مشكلة تقنية في التطبيق',
  'استفسار أو تجديد اشتراك',
  'شكوى على متجر أو طلب',
  'شكوى على مندوب توصيل',
  'مشكلة في تسجيل الدخول أو الحساب',
  'مشكلة في رفع الصور أو المنتجات',
  'اقتراح تطوير أو استفسار عام',
];

export const STORE_PLAN_LABELS: Record<StorePlanName, string> = {
  free: 'الباقة المجانية',
  basic: 'الباقة الأساسية',
  pro: 'الباقة الاحترافية',
  enterprise: 'باقة المولات والشركات',
};

export const SUBSCRIPTION_PLAN_LABELS: Record<string, string> = {
  trial_30: 'فترة تجريبية مجانية (30 يوماً)',
  '1_month': 'اشتراك شهر واحد (30 يوماً)',
  '2_months': 'اشتراك شهرين (60 يوماً)',
  '3_months': 'اشتراك 3 أشهر (90 يوماً)',
  '6_months': 'اشتراك 6 أشهر (180 يوماً)',
  monthly: 'اشتراك شهري (30 يوماً)',
  quarterly: 'اشتراك ربع سنوي (90 يوماً)',
  semi_annual: 'اشتراك نصف سنوي (180 يوماً)',
  annual: 'اشتراك سنوي (365 يوماً)',
  yearly: 'اشتراك سنوي (365 يوماً)',
  free: 'الباقة المجانية',
  basic: 'الباقة الأساسية',
  pro: 'الباقة الاحترافية',
  enterprise: 'باقة المولات والشركات',
};

export const SUBSCRIPTION_STATUS_LABELS: Record<StoreSubscriptionStatus, string> = {
  trial: 'تجريبي',
  active: 'فعال',
  expired: 'منتهي',
  suspended: 'متوقف',
};

export const SUBSCRIPTION_ACTION_LABELS: Record<SubscriptionActionType, string> = {
  trial_started: 'بدء الفترة التجريبية (30 يوم)',
  activated: 'تفعيل الاشتراك',
  extended: 'تمديد الاشتراك',
  suspended: 'إيقاف الاشتراك',
  reactivated: 'إعادة تفعيل الاشتراك',
  payment_recorded: 'تسجيل دفعة مالية يدوياً',
  payment_approved: 'قبول طلب اشتراك وتفعيله',
  payment_rejected: 'رفض طلب اشتراك',
  dates_updated: 'تعديل تاريخ بداية ونهاية الاشتراك',
  reminder_sent: 'إرسال تنبيه تجديد اشتراك',
  expired: 'انتهاء مدة الاشتراك',
  renewal_requested: 'طلب تجديد / اشتراك جديد',
  updated: 'تحديث بيانات الاشتراك',
};

export const PAYMENT_METHOD_LABELS: Record<PaymentMethodCode, string> = {
  zaincash: 'زين كاش (ZainCash)',
  mastercard: 'ماستر كارد (MasterCard)',
};

export const PAYMENT_REQUEST_STATUS_LABELS: Record<SubscriptionPaymentRequestStatus, string> = {
  pending: 'قيد المراجعة',
  approved: 'مقبول ومفعّل',
  rejected: 'مرفوض',
};

export const RECOVERY_STATUS_LABELS: Record<AccountRecoveryStatus, string> = {
  pending: 'بانتظار المراجعة',
  approved: 'تم إصدار رمز الاستعادة',
  completed: 'تمت إعادة التعيين بنجاح',
  rejected: 'مرفوض',
};

export const DEFAULT_PAYMENT_METHODS: SubscriptionPaymentMethodsConfig = {
  zaincashNumber: '07825625699',
  mastercardNumber: '7113775733',
};

export const COURIER_ID_TYPES: string[] = [
  'البطاقة الوطنية الموحدة',
  'هوية الأحوال المدنية',
  'جواز سفر ساري المفعول',
  'إقامة رسمية سارية',
];

export const FULFILLMENT_LABELS: Record<FulfillmentMethod, string> = {
  delivery: 'توصيل إلى العنوان',
  pickup: 'استلام من المحل',
};

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'جديد',
  confirmed: 'مقبول',
  preparing: 'قيد التجهيز',
  ready: 'جاهز',
  out_for_delivery: 'قيد التوصيل',
  delivered: 'مكتمل',
  rejected: 'مرفوض',
  cancelled: 'ملغي',
};

export const CANCEL_REASON_PRESETS: string[] = [
  'طلبت بالخطأ',
  'غيّرت رأيي',
  'اشتباه في المنتج أو الكمية',
  'أريد تعديل العنوان أو المنتجات',
  'تأخر وقت التجهيز أو التوصيل',
  'سبب آخر',
];

export const MERCHANT_CANCEL_REASON_PRESETS: string[] = [
  'اشتباه في الطلب أو بيانات غير مطابقة',
  'نفاد أحد المنتجات المطلوبة',
  'بناءً على طلب الزبون',
  'مشكلة في العنوان أو تعذر التواصل مع الزبون',
  'سبب آخر',
];

export const PRODUCT_CATEGORIES: string[] = [
  'خضار وفواكه',
  'مواد غذائية',
  'ألبان ومخبوزات',
  'لحوم ودواجن',
  'مشروبات وعصائر',
  'منظفات ومنزلية',
  'مواد البناء',
  'الإسمنت والطابوق',
  'الحديد والمواد الإنشائية',
  'الأدوات الصحية',
  'الكهرباء والمواد الكهربائية',
  'الدهانات ومستلزمات البناء',
  'ملابس رجالية',
  'ملابس نسائية',
  'ملابس أطفال',
  'أحذية',
  'حقائب',
  'ملابس رياضية',
  'إكسسوارات الهواتف',
  'شواحن',
  'سماعات',
  'كفرات',
  'حماية الشاشة',
  'باور بانك',
  'قطع ومستلزمات الهواتف',
  'طباعة مستندات',
  'طباعة البحوث والملفات',
  'التغليف والتجليد',
  'شحن PUBG Mobile',
  'شحن Free Fire',
  'بطاقات ألعاب ومنصات',
  'إلكترونيات ومنوعات',
  'أخرى',
];

export const PRODUCT_UNITS: string[] = [
  'قطعة',
  'كيلو',
  'نصف كيلو',
  'علبة',
  'عبوة',
  'ربطة',
  'لتر',
  'كيس',
  'طن',
  'متر',
  'لفة',
  'سطل',
  'طقم',
  'زوج',
  'نسخة',
  'باقة',
];

export const CURRENCY_OPTIONS: Array<{ code: string; label: string }> = [
  { code: 'د.ع', label: 'دينار عراقي (د.ع)' },
  { code: 'ر.س', label: 'ريال سعودي (ر.س)' },
  { code: 'د.إ', label: 'درهم إماراتي (د.إ)' },
  { code: 'د.أ', label: 'دينار أردني (د.أ)' },
  { code: 'ج.م', label: 'جنيه مصري (ج.م)' },
  { code: 'د.ك', label: 'دينار كويتي (د.ك)' },
  { code: 'ر.ق', label: 'ريال قطري (ر.ق)' },
  { code: 'ل.س', label: 'ليرة سورية (ل.س)' },
  { code: '$', label: 'دولار أمريكي ($)' },
];
