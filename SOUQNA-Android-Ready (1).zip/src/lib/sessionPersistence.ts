/**
 * Persistent device session vault backed by IndexedDB + WebCrypto (AES-GCM 256).
 *
 * - Never writes session tokens to localStorage or sessionStorage.
 * - Uses a non-extractable CryptoKey (extractable: false) stored natively inside IndexedDB
 *   so the encrypted session token persists across page refreshes, cross-origin iframes
 *   (where third-party cookies may be blocked by Safari/privacy browsers), PWA launches,
 *   and Android WebView restarts — until explicit logout or server-side revocation.
 */

const DB_NAME = 'souqna_auth_vault';
const DB_VERSION = 1;
const STORE_NAME = 'kv';
const CRYPTO_KEY_RECORD = 'device_aes_key_v1';
const SESSION_RECORD = 'active_session_v1';
const IDB_TIMEOUT_MS = 2500;

interface EncryptedSessionRecord {
  v: 2;
  iv: Uint8Array<ArrayBuffer>;
  ciphertext: ArrayBuffer;
  savedAt: string;
}

interface PlainIdbSessionRecord {
  v: 1;
  token: string;
  savedAt: string;
}

type StoredSessionRecord = EncryptedSessionRecord | PlainIdbSessionRecord;

function isIndexedDbAvailable(): boolean {
  return typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined';
}

function isWebCryptoAvailable(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof window.crypto !== 'undefined' &&
    typeof window.crypto.subtle !== 'undefined'
  );
}

function withTimeout<T>(promise: Promise<T>, fallback: T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  return Promise.race([
    promise.finally(() => {
      if (timer !== undefined) clearTimeout(timer);
    }),
    new Promise<T>((resolve) => {
      timer = setTimeout(() => resolve(fallback), IDB_TIMEOUT_MS);
    }),
  ]);
}

function openVaultDb(): Promise<IDBDatabase | null> {
  if (!isIndexedDbAvailable()) return Promise.resolve(null);
  return withTimeout(
    new Promise<IDBDatabase | null>((resolve) => {
      try {
        const req = window.indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME);
          }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
        req.onblocked = () => resolve(null);
      } catch {
        resolve(null);
      }
    }),
    null
  );
}

function idbGet<T>(db: IDBDatabase, key: string): Promise<T | undefined> {
  return withTimeout(
    new Promise<T | undefined>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result as T | undefined);
        req.onerror = () => resolve(undefined);
      } catch {
        resolve(undefined);
      }
    }),
    undefined
  );
}

function idbPut(db: IDBDatabase, key: string, value: unknown): Promise<boolean> {
  return withTimeout(
    new Promise<boolean>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        store.put(value, key);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
        tx.onabort = () => resolve(false);
      } catch {
        resolve(false);
      }
    }),
    false
  );
}

function idbDelete(db: IDBDatabase, key: string): Promise<boolean> {
  return withTimeout(
    new Promise<boolean>((resolve) => {
      try {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        store.delete(key);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
        tx.onabort = () => resolve(false);
      } catch {
        resolve(false);
      }
    }),
    false
  );
}

async function getOrCreateDeviceKey(db: IDBDatabase): Promise<CryptoKey | null> {
  if (!isWebCryptoAvailable()) return null;
  try {
    const existing = await idbGet<CryptoKey>(db, CRYPTO_KEY_RECORD);
    if (existing && typeof existing === 'object') {
      return existing;
    }
    const key = await window.crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      false, // non-extractable device key
      ['encrypt', 'decrypt']
    );
    const stored = await idbPut(db, CRYPTO_KEY_RECORD, key);
    return stored ? key : null;
  } catch {
    return null;
  }
}

export async function savePersistedSessionToken(token: string): Promise<void> {
  if (!token || token.length < 32) return;
  const db = await openVaultDb();
  if (!db) return;
  try {
    const now = new Date().toISOString();
    const key = await getOrCreateDeviceKey(db);
    if (key && isWebCryptoAvailable()) {
      const iv = window.crypto.getRandomValues(new Uint8Array(12));
      const encoded = new TextEncoder().encode(token);
      const ciphertext = await window.crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        key,
        encoded
      );
      const record: EncryptedSessionRecord = { v: 2, iv, ciphertext, savedAt: now };
      await idbPut(db, SESSION_RECORD, record);
      return;
    }

    // Fallback for non-HTTPS local dev hosts where crypto.subtle is unavailable
    const plainRecord: PlainIdbSessionRecord = { v: 1, token, savedAt: now };
    await idbPut(db, SESSION_RECORD, plainRecord);
  } catch {
    // Non-fatal: HttpOnly cookie remains primary
  } finally {
    try {
      db.close();
    } catch {
      // ignore
    }
  }
}

export async function loadPersistedSessionToken(): Promise<string | null> {
  const db = await openVaultDb();
  if (!db) return null;
  try {
    const record = await idbGet<StoredSessionRecord>(db, SESSION_RECORD);
    if (!record || typeof record !== 'object') return null;

    if (record.v === 2) {
      if (!isWebCryptoAvailable()) return null;
      const key = await idbGet<CryptoKey>(db, CRYPTO_KEY_RECORD);
      if (!key) return null;
      const iv = new Uint8Array(record.iv);
      const decrypted = await window.crypto.subtle.decrypt(
        { name: 'AES-GCM', iv },
        key,
        record.ciphertext
      );
      const token = new TextDecoder().decode(decrypted).trim();
      return token.length >= 32 ? token : null;
    }

    if (record.v === 1 && typeof record.token === 'string' && record.token.length >= 32) {
      return record.token;
    }

    return null;
  } catch {
    return null;
  } finally {
    try {
      db.close();
    } catch {
      // ignore
    }
  }
}

export async function clearPersistedSessionToken(): Promise<void> {
  const db = await openVaultDb();
  if (!db) return;
  try {
    await idbDelete(db, SESSION_RECORD);
  } catch {
    // ignore
  } finally {
    try {
      db.close();
    } catch {
      // ignore
    }
  }
}
