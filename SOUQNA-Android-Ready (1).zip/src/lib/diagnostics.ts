export type DiagnosticCode =
  | 'APK_MISSING_API_BASE_URL'
  | 'PREVIEW_PROXY_BLOCKED'
  | 'CORS_OR_NETWORK_UNREACHABLE'
  | 'REQUEST_TIMEOUT'
  | 'INVALID_SERVER_RESPONSE'
  | 'SERVER_ERROR'
  | 'AUTH_REQUIRED'
  | 'CLIENT_HTTP_ERROR';

export interface ConnectionDiagnostic {
  code: DiagnosticCode;
  titleAr: string;
  messageAr: string;
  hintAr: string;
  endpoint: string;
  targetOrigin: string;
  appOrigin: string;
  status: number;
  runtime: 'android-capacitor' | 'web';
  detail?: string;
  timestamp: string;
}

export interface LiveProbeStep {
  name: string;
  ok: boolean;
  status: number;
  latencyMs: number;
  summary: string;
}

export interface LiveProbeReport {
  checkedAt: string;
  targetOrigin: string;
  allPassed: boolean;
  steps: LiveProbeStep[];
}

const MAX_HISTORY = 10;
const TRANSIENT_THRESHOLD = 2;
let activeDiagnostic: ConnectionDiagnostic | null = null;
let consecutiveTransientFailures = 0;
const diagnosticHistory: ConnectionDiagnostic[] = [];
const listeners = new Set<(diag: ConnectionDiagnostic | null) => void>();

function isImmediateConfigError(code: DiagnosticCode): boolean {
  return code === 'APK_MISSING_API_BASE_URL' || code === 'PREVIEW_PROXY_BLOCKED';
}

/**
 * Strips any potential bearer tokens, cookies, passwords, or query secrets
 * so sensitive user/admin data can NEVER appear in UI diagnostics or copied logs.
 */
export function sanitizeDiagnosticText(input: string, maxLen = 600): string {
  if (!input) return '';
  return String(input)
    .replace(/Bearer\s+[A-Za-z0-9._~+/-]+=*/gi, 'Bearer [REDACTED]')
    .replace(/([?&](?:token|resetToken|code|password|pass|secret|key|auth)=)[^&\s]+/gi, '$1[REDACTED]')
    .replace(/("(?:password|token|secret|authorization|cookie|setupCode)"\s*:\s*")[^"]*(")/gi, '$1[REDACTED]$2')
    .slice(0, maxLen);
}

export function sanitizeEndpointPath(rawPath: string): string {
  if (!rawPath) return '/';
  try {
    const base = typeof window !== 'undefined' && window.location?.origin
      ? window.location.origin
      : 'https://souqna.invalid';
    const parsed = new URL(rawPath, base);
    return parsed.pathname || '/';
  } catch {
    return sanitizeDiagnosticText(rawPath.split('?')[0] || '/', 160);
  }
}

export function isAiStudioPreviewHost(hostname: string): boolean {
  const host = (hostname || '').trim().toLowerCase();
  return (
    /^ais-(dev|pre)-[a-z0-9-]+\..*run\.app$/i.test(host) ||
    host.endsWith('.aistudio.google.com')
  );
}

export function isLocalhostOrPrivateHost(hostname: string): boolean {
  const host = (hostname || '').trim().toLowerCase().replace(/^\[|\]$/g, '');
  return (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host === '10.0.2.2' ||
    host.endsWith('.local')
  );
}

function emit(): void {
  for (const listener of listeners) {
    try {
      listener(activeDiagnostic);
    } catch {
      // ignore subscriber errors
    }
  }
}

export function recordConnectionDiagnostic(diag: ConnectionDiagnostic): void {
  const sanitized: ConnectionDiagnostic = {
    ...diag,
    endpoint: sanitizeEndpointPath(diag.endpoint),
    targetOrigin: sanitizeDiagnosticText(diag.targetOrigin, 200),
    appOrigin: sanitizeDiagnosticText(diag.appOrigin, 200),
    messageAr: sanitizeDiagnosticText(diag.messageAr, 400),
    hintAr: sanitizeDiagnosticText(diag.hintAr, 400),
    detail: diag.detail ? sanitizeDiagnosticText(diag.detail, 260) : undefined,
  };
  diagnosticHistory.unshift(sanitized);
  if (diagnosticHistory.length > MAX_HISTORY) {
    diagnosticHistory.length = MAX_HISTORY;
  }
  try {
    window.sessionStorage?.setItem('souqna_last_connection_error', JSON.stringify(sanitized));
  } catch {
    // ignore storage errors in restricted WebView
  }

  // Deterministic APK/preview misconfigurations surface immediately;
  // transient network/timeout/5xx hiccups require consecutive failures so 1 flaky request never disrupts UI.
  if (isImmediateConfigError(sanitized.code)) {
    activeDiagnostic = sanitized;
    emit();
    return;
  }

  consecutiveTransientFailures += 1;
  if (consecutiveTransientFailures >= TRANSIENT_THRESHOLD) {
    activeDiagnostic = sanitized;
    emit();
  }
}

export function clearConnectionDiagnostic(): void {
  consecutiveTransientFailures = 0;
  if (!activeDiagnostic) return;
  activeDiagnostic = null;
  emit();
}

export function getLastConnectionDiagnostic(): ConnectionDiagnostic | null {
  return activeDiagnostic;
}

export function getDiagnosticHistory(): ConnectionDiagnostic[] {
  return [...diagnosticHistory];
}

export function subscribeConnectionDiagnostic(
  listener: (diag: ConnectionDiagnostic | null) => void
): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function formatConnectionDiagnosticReport(
  diag: ConnectionDiagnostic,
  probe?: LiveProbeReport | null
): string {
  const lines = [
    '=== SOUQNA Connection Diagnostics ===',
    `Code: ${diag.code}`,
    `Title: ${diag.titleAr}`,
    `Message: ${diag.messageAr}`,
    `Endpoint: ${diag.endpoint}`,
    `HTTP Status: ${diag.status}`,
    `Target API: ${diag.targetOrigin || '(same-origin)'}`,
    `App Origin: ${diag.appOrigin || '(unknown)'}`,
    `Runtime: ${diag.runtime}`,
    `Time: ${diag.timestamp}`,
  ];
  if (diag.detail) {
    lines.push(`Detail: ${diag.detail}`);
  }
  if (probe) {
    lines.push('--- Live Connectivity Probe ---');
    lines.push(`CheckedAt: ${probe.checkedAt}`);
    for (const step of probe.steps) {
      lines.push(
        `[${step.ok ? 'PASS' : 'FAIL'}] ${step.name} -> HTTP ${step.status} (${step.latencyMs}ms): ${step.summary}`
      );
    }
  }
  return sanitizeDiagnosticText(lines.join('\n'), 2500);
}

export async function runLiveConnectivityProbe(
  configuredApiBaseUrl: string,
  isNativeApk: boolean
): Promise<LiveProbeReport> {
  const targetOrigin = configuredApiBaseUrl || (typeof window !== 'undefined' ? window.location.origin : '');
  const checkedAt = new Date().toISOString();
  const steps: LiveProbeStep[] = [];

  if (
    isNativeApk &&
    !configuredApiBaseUrl &&
    typeof window !== 'undefined' &&
    (window.location.hostname === 'localhost' || window.location.protocol === 'capacitor:')
  ) {
    return {
      checkedAt,
      targetOrigin: '(غير مضبوط — VITE_API_BASE_URL فارغ)',
      allPassed: false,
      steps: [
        {
          name: 'API Base Config',
          ok: false,
          status: 503,
          latencyMs: 0,
          summary: 'النسخة مبنية بدون ربط رابط خادم إنتاجي عام (VITE_API_BASE_URL فارغ).',
        },
      ],
    };
  }

  try {
    const parsedTarget = new URL(targetOrigin);
    if (isNativeApk && isAiStudioPreviewHost(parsedTarget.hostname)) {
      return {
        checkedAt,
        targetOrigin,
        allPassed: false,
        steps: [
          {
            name: 'Server URL Validation',
            ok: false,
            status: 502,
            latencyMs: 0,
            summary: 'الرابط مضبوط على رابط معاينة مؤقت خاص بـ AI Studio ولا يعمل من الهاتف.',
          },
        ],
      };
    }
    if (
      isNativeApk &&
      configuredApiBaseUrl &&
      (isLocalhostOrPrivateHost(parsedTarget.hostname) || parsedTarget.protocol !== 'https:')
    ) {
      return {
        checkedAt,
        targetOrigin,
        allPassed: false,
        steps: [
          {
            name: 'Server URL Validation',
            ok: false,
            status: 503,
            latencyMs: 0,
            summary:
              'رابط السيرفر داخل APK محلي أو غير مشفر (HTTP/localhost). يجب استخدام رابط HTTPS عام منشور على الإنترنت.',
          },
        ],
      };
    }
  } catch {
    // ignore URL parse error; let fetch report below
  }

  const probeEndpoint = async (
    path: string,
    expectJsonKey: string,
    sendXhrHeader: boolean
  ): Promise<LiveProbeStep> => {
    const start = Date.now();
    const url = configuredApiBaseUrl ? `${configuredApiBaseUrl}${path}` : path;
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = controller ? window.setTimeout(() => controller.abort(), 12000) : null;
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (sendXhrHeader) {
      headers['X-Requested-With'] = 'XMLHttpRequest';
    }
    try {
      const resp = await fetch(url, {
        method: 'GET',
        cache: 'no-store',
        credentials: 'include',
        headers,
        signal: controller?.signal,
      });
      const latencyMs = Date.now() - start;
      const text = await resp.text().catch(() => '');
      if (/__cookie_check|_aistudio-iframe|accounts\.google/i.test(text)) {
        return {
          name: path,
          ok: false,
          status: resp.status || 302,
          latencyMs,
          summary: 'الخادم أعاد صفحة بوابة AI Studio/Google بدلاً من JSON.',
        };
      }
      if (!resp.ok) {
        return {
          name: path,
          ok: false,
          status: resp.status,
          latencyMs,
          summary: `الخادم استجاب برمز خطأ HTTP ${resp.status}.`,
        };
      }
      try {
        const parsed = JSON.parse(text) as Record<string, unknown>;
        if (parsed && expectJsonKey in parsed) {
          return {
            name: path,
            ok: true,
            status: resp.status,
            latencyMs,
            summary: 'الاتصال بالخادم ناجح واستجابة JSON سليمة.',
          };
        }
      } catch {
        // non-JSON
      }
      return {
        name: path,
        ok: false,
        status: resp.status,
        latencyMs,
        summary: 'الاستجابة ليست بصيغة JSON صالحة من خادم سوقنا.',
      };
    } catch (err) {
      const latencyMs = Date.now() - start;
      if (err instanceof DOMException && err.name === 'AbortError') {
        return {
          name: path,
          ok: false,
          status: 408,
          latencyMs,
          summary: 'انتهت مهلة الاتصال (12 ثانية) — الخادم بطيء أو غير متاح.',
        };
      }
      return {
        name: path,
        ok: false,
        status: 0,
        latencyMs,
        summary: 'فشل الشبكة أو حظر CORS أو خطأ شهادة HTTPS.',
      };
    } finally {
      if (timer !== null) window.clearTimeout(timer);
    }
  };

  const healthStep = await probeEndpoint('/healthz', 'ok', false);
  steps.push(healthStep);
  const bootStep = await probeEndpoint('/api/bootstrap-status', 'hasSuperAdmin', true);
  steps.push(bootStep);

  const allPassed = steps.every((s) => s.ok);
  if (allPassed) {
    clearConnectionDiagnostic();
  }

  return {
    checkedAt,
    targetOrigin,
    allPassed,
    steps,
  };
}
