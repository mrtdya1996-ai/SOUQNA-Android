import {
  Building2,
  Gamepad2,
  Hammer,
  Leaf,
  Printer,
  Shirt,
  ShoppingBag,
  ShoppingBasket,
  Smartphone,
  Store as StoreIcon,
  UtensilsCrossed,
  type LucideIcon,
} from 'lucide-react';
import type { StoreType } from '../types';

export interface StoreCategoryMeta {
  type: StoreType;
  title: string;
  shortTitle: string;
  subtitle: string;
  imageUrl: string;
  icon: LucideIcon;
  isNewVertical: boolean;
}

export const LUXURY_BANNER_IMAGES = {
  mall: '/src/assets/images/banner_luxury_mall_gold_1795249357158.jpg',
  market: '/src/assets/images/banner_fresh_market_luxury_1795249357585.jpg',
  delivery: '/src/assets/images/banner_delivery_vip_gold_1795249358620.jpg',
};

export const STORE_CATEGORY_META: Record<StoreType, StoreCategoryMeta> = {
  food_market: {
    type: 'food_market',
    title: 'الأسواق الغذائية',
    shortTitle: 'أسواق غذائية',
    subtitle: 'مواد غذائية، ألبان، لحوم ومبيعات الجملة والكارتون',
    imageUrl: '/src/assets/images/banner_fresh_market_luxury_1795249357585.jpg',
    icon: UtensilsCrossed,
    isNewVertical: false,
  },
  supermarket: {
    type: 'supermarket',
    title: 'السوبر ماركت',
    shortTitle: 'سوبر ماركت',
    subtitle: 'تسوق شامل بالمفرد والكارتون مع توصيل سريع للمنزل',
    imageUrl: '/src/assets/images/hero_souqna_market_1795207846740.jpg',
    icon: ShoppingBag,
    isNewVertical: false,
  },
  grocery: {
    type: 'grocery',
    title: 'البقالات',
    shortTitle: 'بقالات',
    subtitle: 'احتياجات يومية ومواد منزلية سريعة من منطقتك',
    imageUrl: '/src/assets/images/merchant_storefront_banner_1795207846679.jpg',
    icon: ShoppingBasket,
    isNewVertical: false,
  },
  produce: {
    type: 'produce',
    title: 'خضروات وفواكه',
    shortTitle: 'خضروات وفواكه',
    subtitle: 'خضروات طازجة، فواكه موسمية، ورقيات وسلال يومية مباشرة',
    imageUrl: '/src/assets/images/cat_produce_fresh_gold_1795249359308.jpg',
    icon: Leaf,
    isNewVertical: true,
  },
  mall: {
    type: 'mall',
    title: 'المولات التجارية',
    shortTitle: 'مولات',
    subtitle: 'أرقى المولات والمجمعات التجارية المتكاملة في مدينتك',
    imageUrl: '/src/assets/images/cat_mall_luxury_gold_1795249360040.jpg',
    icon: Building2,
    isNewVertical: false,
  },
  shop: {
    type: 'shop',
    title: 'المحلات التجارية',
    shortTitle: 'محلات تجارية',
    subtitle: 'محلات البيع المباشر والمستلزمات المتنوعة',
    imageUrl: '/src/assets/images/banner_luxury_mall_gold_1795249357158.jpg',
    icon: StoreIcon,
    isNewVertical: false,
  },
  construction: {
    type: 'construction',
    title: 'المحلات الإنشائية',
    shortTitle: 'إنشائية وبناء',
    subtitle: 'مواد البناء، الإسمنت والطابوق، الحديد، الصحية، الكهرباء والدهانات',
    imageUrl: '/src/assets/images/cat_construction_supplies_1795213255920.jpg',
    icon: Hammer,
    isNewVertical: true,
  },
  clothing: {
    type: 'clothing',
    title: 'ملابس وأحذية',
    shortTitle: 'ملابس وأحذية',
    subtitle: 'رجالي، نسائي، أطفال، أحذية، حقائب ورياضي بالمقاسات والألوان',
    imageUrl: '/src/assets/images/cat_clothing_fashion_1795213256287.jpg',
    icon: Shirt,
    isNewVertical: true,
  },
  phone_accessories: {
    type: 'phone_accessories',
    title: 'إكسسوارات الهواتف',
    shortTitle: 'إكسسوارات هواتف',
    subtitle: 'شواحن، سماعات، كفرات، حماية شاشة وباور بانك حسب موديل الهاتف',
    imageUrl: '/src/assets/images/cat_phone_accessories_1795213257019.jpg',
    icon: Smartphone,
    isNewVertical: true,
  },
  printing: {
    type: 'printing',
    title: 'المطابع والاستنساخ',
    shortTitle: 'مطابع واستنساخ',
    subtitle: 'طباعة مستندات PDF وصور، ملون وأبيض وأسود، بحوث وتجليد فوري',
    imageUrl: '/src/assets/images/cat_printing_copyshop_1795213256166.jpg',
    icon: Printer,
    isNewVertical: true,
  },
  gaming_topup: {
    type: 'gaming_topup',
    title: 'شحن الألعاب الإلكترونية',
    shortTitle: 'شحن ألعاب',
    subtitle: 'شحن PUBG Mobile و Free Fire وألعاب أخرى عبر معرّف اللاعب (ID)',
    imageUrl: '/src/assets/images/cat_gaming_topup_1795213256287.jpg',
    icon: Gamepad2,
    isNewVertical: true,
  },
};

export const FEATURED_NEW_CATEGORIES: StoreCategoryMeta[] = [
  STORE_CATEGORY_META.mall,
  STORE_CATEGORY_META.food_market,
  STORE_CATEGORY_META.produce,
  STORE_CATEGORY_META.construction,
  STORE_CATEGORY_META.clothing,
  STORE_CATEGORY_META.phone_accessories,
  STORE_CATEGORY_META.printing,
  STORE_CATEGORY_META.gaming_topup,
];

export const ALL_CATEGORY_CARDS: StoreCategoryMeta[] = [
  STORE_CATEGORY_META.food_market,
  STORE_CATEGORY_META.supermarket,
  STORE_CATEGORY_META.grocery,
  STORE_CATEGORY_META.produce,
  STORE_CATEGORY_META.mall,
  STORE_CATEGORY_META.shop,
  STORE_CATEGORY_META.construction,
  STORE_CATEGORY_META.clothing,
  STORE_CATEGORY_META.phone_accessories,
  STORE_CATEGORY_META.printing,
  STORE_CATEGORY_META.gaming_topup,
];
