import { api } from './api';

export type PushPermissionState = NotificationPermission | 'unsupported';

export function isWebPushSupported(): boolean {
  try {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
    const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform()) {
      return false;
    }
    const proto = window.location?.protocol || '';
    if (proto === 'capacitor:' || proto === 'file:') {
      return false;
    }
    const ua = navigator.userAgent || '';
    if (/Android/i.test(ua) && /;\s*wv\)/i.test(ua)) {
      return false;
    }
    return (
      'serviceWorker' in navigator &&
      Boolean(navigator.serviceWorker) &&
      'PushManager' in window &&
      'Notification' in window &&
      typeof Notification !== 'undefined'
    );
  } catch {
    return false;
  }
}

export function getNotificationPermission(): PushPermissionState {
  if (!isWebPushSupported()) return 'unsupported';
  try {
    return Notification.permission;
  } catch {
    return 'unsupported';
  }
}

export function urlBase64ToUint8Array(base64String: string): Uint8Array<ArrayBuffer> {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const buffer = new ArrayBuffer(rawData.length);
  const outputArray = new Uint8Array(buffer);
  for (let i = 0; i < rawData.length; i += 1) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

async function getServiceWorkerRegistration(): Promise<ServiceWorkerRegistration> {
  const existing = await navigator.serviceWorker.getRegistration();
  if (existing) {
    await navigator.serviceWorker.ready;
    return existing;
  }
  // Fallback registration for dev environments where VitePWA SW might not yet be active
  const registered = await navigator.serviceWorker.register('/push-sw.js', { scope: '/' });
  await navigator.serviceWorker.ready;
  return registered;
}

export async function getExistingPushSubscription(): Promise<PushSubscription | null> {
  if (!isWebPushSupported()) return null;
  try {
    const registration = await navigator.serviceWorker.getRegistration();
    if (!registration) return null;
    return await registration.pushManager.getSubscription();
  } catch {
    return null;
  }
}

export async function subscribeDeviceToWebPush(vapidPublicKey: string): Promise<{
  endpoint: string;
  deviceCount: number;
}> {
  if (!isWebPushSupported()) {
    throw new Error('المتصفح الحالي لا يدعم إشعارات الخلفية (Web Push).');
  }
  if (!vapidPublicKey) {
    throw new Error('مفتاح إشعارات الخادم (VAPID) غير متوفر حالياً.');
  }

  let permission = Notification.permission;
  if (permission === 'default') {
    permission = await Notification.requestPermission();
  }
  if (permission !== 'granted') {
    throw new Error('تم رفض صلاحية الإشعارات. يرجى تفعيل الإشعارات من إعدادات المتصفح ثم المحاولة مجدداً.');
  }

  const registration = await getServiceWorkerRegistration();
  let subscription = await registration.pushManager.getSubscription();

  if (!subscription) {
    subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
    });
  }

  const json = subscription.toJSON();
  const p256dh = json.keys?.p256dh || '';
  const auth = json.keys?.auth || '';
  if (!subscription.endpoint || !p256dh || !auth) {
    throw new Error('تعذر استخراج بيانات اشتراك الإشعارات من المتصفح.');
  }

  const res = await api.subscribeWebPush({
    endpoint: subscription.endpoint,
    keys: { p256dh, auth },
    deviceLabel: navigator.userAgent.slice(0, 120),
  });

  return { endpoint: subscription.endpoint, deviceCount: res.activeDeviceCount };
}

export async function unsubscribeDeviceFromWebPush(): Promise<void> {
  const existing = await getExistingPushSubscription();
  const endpoint = existing?.endpoint;
  if (existing) {
    try {
      await existing.unsubscribe();
    } catch {
      // ignore local unsubscribe failure and still inform backend
    }
  }
  await api.unsubscribeWebPush(endpoint);
}
