import {
  isAiStudioPreviewHost,
  isLocalhostOrPrivateHost,
  type DiagnosticCode,
} from './diagnostics';

/**
 * Centralized API & media base URL configuration for SOUQNA (Web + Android Capacitor APK).
 *
 * - On Web (same-origin): VITE_API_BASE_URL is empty string "" so relative `/api/...` and `/uploads/...`
 *   resolve directly against the deployed web host.
 * - On Android Capacitor APK: VITE_API_BASE_URL MUST be baked at build time with the real public
 *   HTTPS production server URL (e.g. https://souqna.up.railway.app). Localhost, HTTP, empty,
 *   and temporary AI Studio Preview URLs are strictly rejected.
 */
export const API_BASE_URL = String(import.meta.env?.VITE_API_BASE_URL || '')
  .trim()
  .replace(/\/+$/, '');

export function isNativeCapacitorApp(): boolean {
  try {
    if (typeof window === 'undefined') return false;
    const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform()) {
      return true;
    }
    const proto = window.location?.protocol || '';
    return proto === 'capacitor:' || proto === 'file:';
  } catch {
    return false;
  }
}

export function getConfiguredApiBaseUrl(): string {
  return API_BASE_URL;
}

export function isCrossOriginApi(): boolean {
  if (!API_BASE_URL || typeof window === 'undefined') return false;
  try {
    return new URL(API_BASE_URL).origin !== window.location.origin;
  } catch {
    return false;
  }
}

export function resolveApiUrl(path: string): string {
  if (!API_BASE_URL || /^https?:\/\//i.test(path)) return path;
  return `${API_BASE_URL}${path.startsWith('/') ? path : `/${path}`}`;
}

export function resolveMediaUrl(url: string | null | undefined): string {
  if (!url || typeof url !== 'string') return '';
  const trimmed = url.trim();
  if (!trimmed) return '';
  if (/^(https?:|data:|blob:)/i.test(trimmed)) return trimmed;
  if (API_BASE_URL && (trimmed.startsWith('/uploads/') || trimmed.startsWith('/api/'))) {
    return `${API_BASE_URL}${trimmed}`;
  }
  return trimmed;
}

export function getDiagnosticTargetOrigin(): string {
  if (API_BASE_URL) return API_BASE_URL;
  if (typeof window !== 'undefined' && window.location?.origin) return window.location.origin;
  return '';
}

export function getAppOriginSafe(): string {
  if (typeof window !== 'undefined' && window.location?.origin) return window.location.origin;
  return '';
}

export type NativeApiValidationResult =
  | { ok: true; baseUrl: string }
  | {
      ok: false;
      code: DiagnosticCode;
      titleAr: string;
      messageAr: string;
      hintAr: string;
      status: number;
      detail: string;
      targetOrigin: string;
    };

/**
 * Validates that an installed native Android Capacitor APK has a valid public HTTPS
 * production API server URL baked in and is never attempting to reach localhost or a preview host.
 */
export function validateNativeApiBaseUrl(): NativeApiValidationResult {
  if (!isNativeCapacitorApp()) {
    return { ok: true, baseUrl: API_BASE_URL };
  }

  // 1) Missing API base URL on local Capacitor asset origin (https://localhost / capacitor://localhost)
  if (
    !API_BASE_URL &&
    typeof window !== 'undefined' &&
    (window.location.hostname === 'localhost' ||
      window.location.protocol === 'capacitor:' ||
      window.location.protocol === 'file:')
  ) {
    return {
      ok: false,
      code: 'APK_MISSING_API_BASE_URL',
      titleAr: 'لم يتم ربط تطبيق Android بالسيرفر الإنتاجي',
      messageAr:
        'نسخة Android APK هذه مبنية بدون رابط سيرفر إنتاجي حقيقي (VITE_API_BASE_URL فارغ)، لذلك تحاول الاتصال بـ https://localhost داخل الهاتف.',
      hintAr:
        'انشر سيرفر SOUQNA على استضافة عامة (HTTPS مثل Railway أو Render)، ثم أعد بناء APK عبر GitHub Actions مع تمرير رابط السيرفر الحقيقي.',
      status: 503,
      detail: 'Missing VITE_API_BASE_URL inside bundled Capacitor APK',
      targetOrigin: '(غير مضبوط)',
    };
  }

  if (!API_BASE_URL) {
    return { ok: true, baseUrl: '' };
  }

  let parsedApi: URL;
  try {
    parsedApi = new URL(API_BASE_URL);
  } catch {
    return {
      ok: false,
      code: 'APK_MISSING_API_BASE_URL',
      titleAr: 'صيغة رابط السيرفر في APK غير صالحة',
      messageAr: 'رابط السيرفر المدمج في نسخة Android APK غير صالح ولا يمكن تحليله كعنوان HTTPS.',
      hintAr: 'تأكد من كتابة رابط السيرفر كاملاً بصيغة https://example.com عند بناء APK.',
      status: 503,
      detail: `Malformed VITE_API_BASE_URL: ${API_BASE_URL}`,
      targetOrigin: API_BASE_URL,
    };
  }

  if (isAiStudioPreviewHost(parsedApi.hostname)) {
    return {
      ok: false,
      code: 'PREVIEW_PROXY_BLOCKED',
      titleAr: 'رابط الخادم في APK هو رابط Preview مؤقت',
      messageAr:
        'رابط السيرفر المدمج في APK هو رابط معاينة مؤقت خاص بـ AI Studio (ais-dev / ais-pre) ولا يعمل خارج AI Studio.',
      hintAr:
        'روابط AI Studio تطلب جلسة Google وتعيد توجيه الطلبات. اربط APK برابط سيرفر إنتاجي عام HTTPS.',
      status: 502,
      detail: `Blocked preview host: ${parsedApi.hostname}`,
      targetOrigin: API_BASE_URL,
    };
  }

  if (isLocalhostOrPrivateHost(parsedApi.hostname) || parsedApi.protocol !== 'https:') {
    return {
      ok: false,
      code: 'APK_MISSING_API_BASE_URL',
      titleAr: 'رابط السيرفر في APK غير صالح للإنتاج',
      messageAr:
        'رابط السيرفر المدمج في نسخة Android APK محلي أو غير مشفّر (localhost/HTTP)، ولا يمكن للهاتف الاتصال به.',
      hintAr:
        'أعد بناء APK مع تمرير رابط السيرفر الإنتاجي الحقيقي بصيغة https://... في GitHub Actions.',
      status: 503,
      detail: `Blocked non-production API URL: ${parsedApi.origin}`,
      targetOrigin: API_BASE_URL,
    };
  }

  return { ok: true, baseUrl: API_BASE_URL };
}
