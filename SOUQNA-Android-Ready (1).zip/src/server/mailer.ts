import net from 'node:net';
import tls from 'node:tls';

export type EmailSendResult =
  | { ok: true; provider: 'resend' | 'smtp' }
  | { ok: false; reason: 'not_configured' | 'send_failed'; error?: string };

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function getFromAddress(): string {
  const configured = process.env.SMTP_FROM?.replace(/[\r\n]+/g, ' ').trim();
  if (configured) return configured;
  const smtpUser = process.env.SMTP_USER?.replace(/[\r\n]+/g, '').trim();
  if (smtpUser && smtpUser.includes('@')) return `SOUQNA | سوقنا <${smtpUser}>`;
  return 'SOUQNA | سوقنا <no-reply@souqna.app>';
}

function extractEnvelopeEmail(address: string): string {
  const match = address.match(/<([^>]+)>/);
  return (match ? match[1] : address).replace(/[\r\n<>]+/g, '').trim();
}

export function isEmailDeliveryConfigured(): boolean {
  const resendKey = process.env.RESEND_API_KEY?.trim() || '';
  if (resendKey) return true;
  const host = process.env.SMTP_HOST?.trim() || '';
  const user = process.env.SMTP_USER?.trim() || '';
  const pass = process.env.SMTP_PASS?.trim() || '';
  return Boolean(host && user && pass);
}

async function sendViaResend(params: {
  to: string;
  subject: string;
  html: string;
  text: string;
}): Promise<EmailSendResult> {
  const apiKey = process.env.RESEND_API_KEY?.trim() || '';
  if (!apiKey) return { ok: false, reason: 'not_configured' };

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: getFromAddress(),
        to: [params.to],
        subject: params.subject,
        html: params.html,
        text: params.text,
      }),
    });
    if (!response.ok) {
      return { ok: false, reason: 'send_failed', error: `Resend HTTP ${response.status}` };
    }
    return { ok: true, provider: 'resend' };
  } catch (err) {
    return {
      ok: false,
      reason: 'send_failed',
      error: err instanceof Error ? err.message : 'Resend request failed',
    };
  }
}

function createSmtpReader(socket: net.Socket | tls.TLSSocket) {
  let buffer = '';
  const waiters: Array<{ resolve: (line: string) => void; reject: (err: Error) => void }> = [];
  let closedError: Error | null = null;

  socket.setEncoding('utf8');
  socket.on('data', (chunk: string) => {
    buffer += chunk;
    while (waiters.length > 0) {
      const lines = buffer.split('\r\n');
      let completeIdx = -1;
      for (let i = 0; i < lines.length - 1; i++) {
        if (/^\d{3} /.test(lines[i])) {
          completeIdx = i;
          break;
        }
      }
      if (completeIdx === -1) break;
      const response = lines.slice(0, completeIdx + 1).join('\r\n');
      buffer = lines.slice(completeIdx + 1).join('\r\n');
      const waiter = waiters.shift()!;
      waiter.resolve(response);
    }
  });
  socket.on('error', (err) => {
    closedError = err;
    while (waiters.length > 0) waiters.shift()!.reject(err);
  });
  socket.on('close', () => {
    const err = closedError || new Error('SMTP connection closed unexpectedly');
    while (waiters.length > 0) waiters.shift()!.reject(err);
  });

  return {
    readResponse: (): Promise<string> => {
      if (closedError) return Promise.reject(closedError);
      return new Promise((resolve, reject) => {
        waiters.push({ resolve, reject });
      });
    },
  };
}

async function sendViaSmtp(params: {
  to: string;
  subject: string;
  html: string;
  text: string;
}): Promise<EmailSendResult> {
  const host = process.env.SMTP_HOST?.trim() || '';
  const port = Number(process.env.SMTP_PORT || 465);
  const secure = process.env.SMTP_SECURE
    ? process.env.SMTP_SECURE.trim().toLowerCase() === 'true'
    : port === 465;
  const user = process.env.SMTP_USER?.trim() || '';
  const pass = process.env.SMTP_PASS?.trim() || '';
  if (!host || !user || !pass) return { ok: false, reason: 'not_configured' };

  const fromHeader = getFromAddress();
  const fromEnvelope = extractEnvelopeEmail(fromHeader);
  const boundary = `souqna_alt_${Date.now().toString(36)}`;
  const encodedSubject = `=?UTF-8?B?${Buffer.from(params.subject, 'utf8').toString('base64')}?=`;

  const rawMessage = [
    `From: ${fromHeader}`,
    `To: <${params.to}>`,
    `Subject: ${encodedSubject}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    Buffer.from(params.text, 'utf8').toString('base64'),
    `--${boundary}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    Buffer.from(params.html, 'utf8').toString('base64'),
    `--${boundary}--`,
    '',
  ].join('\r\n');

  let socket: net.Socket | tls.TLSSocket | null = null;
  try {
    socket = secure
      ? tls.connect({ host, port, servername: host, timeout: 12000 })
      : net.connect({ host, port, timeout: 12000 });

    await new Promise<void>((resolve, reject) => {
      socket!.once(secure ? 'secureConnect' : 'connect', () => resolve());
      socket!.once('error', reject);
      socket!.once('timeout', () => reject(new Error('SMTP connection timed out')));
    });

    let reader = createSmtpReader(socket);
    const expect = async (expectedPrefixes: string[]) => {
      const resp = await reader.readResponse();
      if (!expectedPrefixes.some((p) => resp.startsWith(p))) {
        throw new Error(`SMTP error: ${resp.slice(0, 120)}`);
      }
      return resp;
    };
    const sendCmd = async (cmd: string, expectedPrefixes: string[]) => {
      socket!.write(`${cmd}\r\n`);
      return expect(expectedPrefixes);
    };

    await expect(['220']);
    const ehlo = await sendCmd('EHLO souqna.local', ['250']);

    if (!secure && /STARTTLS/i.test(ehlo)) {
      await sendCmd('STARTTLS', ['220']);
      const upgraded = tls.connect({ socket, servername: host, timeout: 12000 });
      await new Promise<void>((resolve, reject) => {
        upgraded.once('secureConnect', () => resolve());
        upgraded.once('error', reject);
      });
      socket = upgraded;
      reader = createSmtpReader(socket);
      await sendCmd('EHLO souqna.local', ['250']);
    }

    await sendCmd('AUTH LOGIN', ['334']);
    await sendCmd(Buffer.from(user, 'utf8').toString('base64'), ['334']);
    await sendCmd(Buffer.from(pass, 'utf8').toString('base64'), ['235']);
    await sendCmd(`MAIL FROM:<${fromEnvelope}>`, ['250']);
    await sendCmd(`RCPT TO:<${params.to}>`, ['250', '251']);
    await sendCmd('DATA', ['354']);
    socket.write(`${rawMessage.replace(/^\./gm, '..')}\r\n.\r\n`);
    await expect(['250']);
    await sendCmd('QUIT', ['221']).catch(() => {});
    socket.end();
    return { ok: true, provider: 'smtp' };
  } catch (err) {
    socket?.destroy();
    return {
      ok: false,
      reason: 'send_failed',
      error: err instanceof Error ? err.message : 'SMTP delivery failed',
    };
  }
}

export async function sendPasswordResetEmail(params: {
  to: string;
  fullName: string;
  resetUrl: string;
  tempCode: string;
  expiresMinutes: number;
}): Promise<EmailSendResult> {
  const safeName = escapeHtml(params.fullName || 'مستخدم سوقنا');
  const safeUrl = escapeHtml(params.resetUrl);
  const safeCode = escapeHtml(params.tempCode);
  const subject = 'إعادة تعيين كلمة المرور — SOUQNA | سوقنا';

  const text = [
    `مرحباً ${params.fullName || 'مستخدم سوقنا'}،`,
    '',
    'تم طلب إعادة تعيين كلمة المرور لحسابك في منصة SOUQNA | سوقنا.',
    `رمز الاستعادة المؤقت (صالح لمدة ${params.expiresMinutes} دقيقة لمرة واحدة): ${params.tempCode}`,
    `أو افتح رابط إعادة التعيين المباشر: ${params.resetUrl}`,
    '',
    'إذا لم تطلب ذلك، يمكنك تجاهل هذه الرسالة بأمان ولن يتم تغيير كلمة مرورك.',
  ].join('\n');

  const html = `<!doctype html>
<html lang="ar" dir="rtl">
  <body style="margin:0;padding:24px;background:#090A0A;color:#F5F2EA;font-family:Tahoma,Arial,sans-serif;">
    <div style="max-width:520px;margin:0 auto;background:#121414;border:1px solid #3A3220;border-radius:16px;padding:28px;">
      <div style="color:#E8CB73;font-size:18px;font-weight:bold;margin-bottom:8px;">SOUQNA | سوقنا</div>
      <h1 style="margin:0 0 12px;font-size:20px;color:#FFFFFF;">إعادة تعيين كلمة المرور</h1>
      <p style="font-size:14px;line-height:1.7;color:#D6D1C4;">
        مرحباً <strong>${safeName}</strong>،<br/>
        تلقينا طلباً لإعادة تعيين كلمة المرور الخاصة بحسابك. استخدم الزر أدناه أو الرمز المؤقت خلال <strong>${params.expiresMinutes} دقيقة</strong> (صالح لاستخدام واحد فقط):
      </p>
      <div style="margin:20px 0;padding:14px;background:#1A1D1D;border:1px solid #C89B2B;border-radius:12px;text-align:center;">
        <div style="font-size:12px;color:#B8B09E;margin-bottom:6px;">رمز الاستعادة المؤقت</div>
        <div style="font-family:monospace;font-size:22px;font-weight:bold;letter-spacing:2px;color:#E8CB73;direction:ltr;">${safeCode}</div>
      </div>
      <div style="text-align:center;margin:22px 0;">
        <a href="${safeUrl}" style="display:inline-block;padding:12px 26px;background:#D4AF37;color:#0B0C0C;text-decoration:none;font-weight:bold;border-radius:10px;font-size:14px;">
          إعادة تعيين كلمة المرور الآن
        </a>
      </div>
      <p style="font-size:12px;line-height:1.6;color:#9B9484;">
        إذا لم تطلب إعادة تعيين كلمة المرور، يرجى تجاهل هذه الرسالة. لا تشارك هذا الرابط أو الرمز مع أي شخص.
      </p>
    </div>
  </body>
</html>`;

  if (process.env.RESEND_API_KEY?.trim()) {
    return sendViaResend({ to: params.to, subject, html, text });
  }
  return sendViaSmtp({ to: params.to, subject, html, text });
}
