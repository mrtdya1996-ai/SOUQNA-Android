import { createRequire } from 'node:module';
import type { Response } from 'express';
import type * as WebPushTypes from 'web-push';
import type { NotificationItem, NotificationType } from '../types.ts';
import { generateId } from './security.ts';
import { db, getPlatformSetting, setPlatformSetting } from './db.ts';

const require = createRequire(import.meta.url);
const webpush = require('web-push') as typeof WebPushTypes;

// Ensure persistent real VAPID keys exist (from env or generated once & stored in SQLite)
function ensureVapidKeys(): { publicKey: string; privateKey: string; subject: string } {
  const subject =
    process.env.VAPID_SUBJECT?.trim() || 'mailto:notifications@souqna.app';
  const envPublic = process.env.VAPID_PUBLIC_KEY?.trim();
  const envPrivate = process.env.VAPID_PRIVATE_KEY?.trim();

  if (envPublic && envPrivate) {
    return { publicKey: envPublic, privateKey: envPrivate, subject };
  }

  let publicKey = getPlatformSetting('vapid_public_key', '');
  let privateKey = getPlatformSetting('vapid_private_key', '');

  if (!publicKey || !privateKey) {
    const generated = webpush.generateVAPIDKeys();
    publicKey = generated.publicKey;
    privateKey = generated.privateKey;
    setPlatformSetting('vapid_public_key', publicKey);
    setPlatformSetting('vapid_private_key', privateKey);
  }

  return { publicKey, privateKey, subject };
}

const vapid = ensureVapidKeys();
try {
  webpush.setVapidDetails(vapid.subject, vapid.publicKey, vapid.privateKey);
} catch (err) {
  console.error('VAPID initialization warning:', err);
}

export function getVapidPublicKey(): string {
  return vapid.publicKey;
}

// Active Server-Sent Events (SSE) connections indexed by userId for instant real-time delivery
const sseClients = new Map<string, Set<Response>>();

export function registerSseClient(userId: string, res: Response): () => void {
  let set = sseClients.get(userId);
  if (!set) {
    set = new Set();
    sseClients.set(userId, set);
  }
  set.add(res);

  return () => {
    const current = sseClients.get(userId);
    if (!current) return;
    current.delete(res);
    if (current.size === 0) {
      sseClients.delete(userId);
    }
  };
}

function broadcastSseNotification(userId: string, notification: NotificationItem): void {
  const clients = sseClients.get(userId);
  if (!clients || clients.size === 0) return;

  const payload = `event: notification\ndata: ${JSON.stringify(notification)}\n\n`;
  for (const res of clients) {
    try {
      res.write(payload);
    } catch {
      clients.delete(res);
    }
  }
}

export function mapNotification(row: Record<string, unknown>): NotificationItem {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    storeId: row.store_id ? String(row.store_id) : null,
    storeName: row.store_name ? String(row.store_name) : undefined,
    orderId: row.order_id ? String(row.order_id) : null,
    orderNumber: row.order_number ? String(row.order_number) : undefined,
    type: row.type as NotificationType,
    title: String(row.title),
    body: String(row.body),
    targetView: (row.target_view as NotificationItem['targetView']) || 'notifications',
    isRead: Boolean(row.is_read),
    createdAt: String(row.created_at),
  };
}

export function formatAmountArabic(amount: number, currency: string): string {
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: amount % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(amount);
  const unitLabel = currency === 'د.ع' ? 'دينار' : currency;
  return `${formatted} ${unitLabel}`;
}

export interface CreateNotificationInput {
  userId: string;
  storeId?: string | null;
  orderId?: string | null;
  type: NotificationType;
  title: string;
  body: string;
  targetView: 'merchant' | 'orders' | 'admin' | 'courier' | 'notifications' | 'support' | 'subscription';
}

interface PushSubRow {
  id: string;
  channel: 'web_push' | 'expo' | 'fcm';
  endpoint: string;
  p256dh: string;
  auth: string;
  push_token: string;
}

async function deliverPushToUserDevices(
  userId: string,
  notification: NotificationItem
): Promise<{ sent: number; failed: number }> {
  const subs = db
    .prepare(
      'SELECT id, channel, endpoint, p256dh, auth, push_token FROM push_subscriptions WHERE user_id = ? AND is_active = 1'
    )
    .all(userId) as PushSubRow[];

  if (subs.length === 0) {
    return { sent: 0, failed: 0 };
  }

  const deepLinkUrl = notification.orderId
    ? `/?view=${encodeURIComponent(notification.targetView)}&openOrder=${encodeURIComponent(notification.orderId)}`
    : `/?view=${encodeURIComponent(notification.targetView)}`;

  let sent = 0;
  let failed = 0;

  const webPushPayload = JSON.stringify({
    title: notification.title,
    body: notification.body,
    orderId: notification.orderId || '',
    storeId: notification.storeId || '',
    targetView: notification.targetView,
    url: deepLinkUrl,
    tag: notification.orderId ? `souqna-order-${notification.orderId}` : `souqna-${notification.id}`,
  });

  const expoTokens: string[] = [];

  for (const sub of subs) {
    if (sub.channel === 'web_push' && sub.endpoint && sub.p256dh && sub.auth) {
      try {
        await webpush.sendNotification(
          {
            endpoint: sub.endpoint,
            keys: { p256dh: sub.p256dh, auth: sub.auth },
          },
          webPushPayload,
          { TTL: 60 * 60 * 12 }
        );
        sent += 1;
      } catch (err: unknown) {
        failed += 1;
        const statusCode =
          typeof err === 'object' && err !== null && 'statusCode' in err
            ? Number((err as { statusCode?: number }).statusCode)
            : 0;
        if (statusCode === 404 || statusCode === 410) {
          db.prepare('UPDATE push_subscriptions SET is_active = 0 WHERE id = ?').run(sub.id);
        }
      }
    } else if (sub.channel === 'expo' && sub.push_token) {
      expoTokens.push(sub.push_token);
    }
  }

  // Real Expo Push API relay for Expo / React Native mobile builds
  if (expoTokens.length > 0) {
    try {
      const headers: Record<string, string> = {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      };
      if (process.env.EXPO_ACCESS_TOKEN?.trim()) {
        headers.Authorization = `Bearer ${process.env.EXPO_ACCESS_TOKEN.trim()}`;
      }
      const messages = expoTokens.map((to) => ({
        to,
        sound: 'default',
        title: notification.title,
        body: notification.body,
        data: {
          orderId: notification.orderId,
          storeId: notification.storeId,
          targetView: notification.targetView,
          url: deepLinkUrl,
        },
        priority: 'high',
      }));
      const resp = await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers,
        body: JSON.stringify(messages),
      });
      if (resp.ok) {
        sent += expoTokens.length;
      } else {
        failed += expoTokens.length;
      }
    } catch {
      failed += expoTokens.length;
    }
  }

  return { sent, failed };
}

/**
 * Persists a notification in SQLite, broadcasts immediately over live SSE,
 * and dispatches real background Push Notifications to all registered devices of the user.
 */
export function createAndDispatchNotification(input: CreateNotificationInput): NotificationItem {
  const id = generateId('ntf');
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO notifications (id, user_id, store_id, order_id, type, title, body, target_view, is_read, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
  ).run(
    id,
    input.userId,
    input.storeId ?? null,
    input.orderId ?? null,
    input.type,
    input.title,
    input.body,
    input.targetView,
    now
  );

  const row = db
    .prepare(
      `SELECT n.*, s.name AS store_name, o.order_number AS order_number
       FROM notifications n
       LEFT JOIN stores s ON s.id = n.store_id
       LEFT JOIN orders o ON o.id = n.order_id
       WHERE n.id = ?`
    )
    .get(id) as Record<string, unknown>;

  const notification = mapNotification(row);

  // Instant in-app SSE delivery
  broadcastSseNotification(input.userId, notification);

  // Background Web Push + Expo Push delivery (non-blocking)
  void deliverPushToUserDevices(input.userId, notification);

  return notification;
}

export async function dispatchTestPush(
  userId: string,
  title: string,
  body: string,
  targetView: NotificationItem['targetView'] = 'notifications'
): Promise<{ notification: NotificationItem; pushDelivery: { sent: number; failed: number } }> {
  const id = generateId('ntf');
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO notifications (id, user_id, store_id, order_id, type, title, body, target_view, is_read, created_at)
     VALUES (?, ?, NULL, NULL, 'system', ?, ?, ?, 0, ?)`
  ).run(id, userId, title, body, targetView, now);

  const row = db.prepare('SELECT * FROM notifications WHERE id = ?').get(id) as Record<
    string,
    unknown
  >;
  const notification = mapNotification(row);
  broadcastSseNotification(userId, notification);
  const pushDelivery = await deliverPushToUserDevices(userId, notification);
  return { notification, pushDelivery };
}

export function getUserNotifications(userId: string): {
  notifications: NotificationItem[];
  unreadCount: number;
} {
  const rows = db
    .prepare(
      `SELECT n.*, s.name AS store_name, o.order_number AS order_number
       FROM notifications n
       LEFT JOIN stores s ON s.id = n.store_id
       LEFT JOIN orders o ON o.id = n.order_id
       WHERE n.user_id = ?
       ORDER BY n.created_at DESC
       LIMIT 100`
    )
    .all(userId) as Record<string, unknown>[];

  const unread = db
    .prepare('SELECT COUNT(*) AS cnt FROM notifications WHERE user_id = ? AND is_read = 0')
    .get(userId) as { cnt: number };

  return {
    notifications: rows.map(mapNotification),
    unreadCount: Number(unread.cnt || 0),
  };
}
