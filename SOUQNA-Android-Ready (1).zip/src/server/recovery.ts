import { db } from './db.ts';
import { isEmailDeliveryConfigured, sendPasswordResetEmail } from './mailer.ts';
import { createAndDispatchNotification } from './notifications.ts';
import {
  generateId,
  generateResetToken,
  generateTemporaryResetCode,
  hashPassword,
  hashSessionToken,
  isValidEmail,
  isValidPhone,
  normalizeResetCode,
  sanitizeText,
} from './security.ts';
import { logAdminAction } from './subscriptions.ts';
import type {
  AccountRecoveryRequest,
  AccountRecoveryStatus,
  IssuedPasswordReset,
  User,
  UserRole,
} from '../types.ts';

const RESET_TOKEN_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours single-use window for admin-issued resets
const EMAIL_RESET_TOKEN_TTL_MS = 30 * 60 * 1000; // 30 minutes single-use window for self-service email resets

function normalizePhoneDigits(phone: string): string {
  return phone.replace(/[\s\-()+]/g, '');
}

function mapRecoveryRequest(row: Record<string, unknown>): AccountRecoveryRequest {
  return {
    id: String(row.id),
    matchedUserId: row.matched_user_id ? String(row.matched_user_id) : null,
    matchedUserName: row.matched_user_name ? String(row.matched_user_name) : undefined,
    matchedUserEmail: row.matched_user_email ? String(row.matched_user_email) : undefined,
    matchedUserPhone: row.matched_user_phone ? String(row.matched_user_phone) : undefined,
    matchedUserRole: row.matched_user_role ? (row.matched_user_role as UserRole) : undefined,
    requesterName: String(row.requester_name || ''),
    requesterPhone: String(row.requester_phone || ''),
    requesterEmail: String(row.requester_email || ''),
    accountType: String(row.account_type || 'customer'),
    proofDetails: String(row.proof_details || ''),
    status: row.status as AccountRecoveryStatus,
    adminNotes: String(row.admin_notes || ''),
    rejectionReason: String(row.rejection_reason || ''),
    reviewedById: row.reviewed_by_id ? String(row.reviewed_by_id) : null,
    reviewedAt: String(row.reviewed_at || ''),
    createdAt: String(row.created_at || ''),
    updatedAt: String(row.updated_at || ''),
  };
}

function findMatchingUserId(email: string, phone: string): string | null {
  if (email) {
    const byEmail = db
      .prepare('SELECT id FROM users WHERE LOWER(email) = ?')
      .get(email.toLowerCase()) as { id: string } | undefined;
    if (byEmail) return byEmail.id;
  }

  if (phone) {
    const exactPhone = db.prepare('SELECT id FROM users WHERE phone = ?').get(phone) as
      | { id: string }
      | undefined;
    if (exactPhone) return exactPhone.id;

    const targetDigits = normalizePhoneDigits(phone);
    if (targetDigits.length >= 7) {
      const candidates = db.prepare('SELECT id, phone FROM users').all() as Array<{
        id: string;
        phone: string;
      }>;
      const found = candidates.find((c) => normalizePhoneDigits(c.phone) === targetDigits);
      if (found) return found.id;
    }
  }
  return null;
}

export function submitAccountRecoveryRequest(params: {
  requesterName: string;
  requesterPhone: string;
  requesterEmail?: string;
  accountType: string;
  proofDetails: string;
}): { ok: true; requestId: string } | { ok: false; status: number; error: string } {
  const requesterName = sanitizeText(params.requesterName, 120);
  const requesterPhone = sanitizeText(params.requesterPhone, 28);
  const requesterEmail = sanitizeText(params.requesterEmail || '', 160).toLowerCase();
  const validAccountTypes = ['customer', 'merchant', 'courier', 'super_admin', 'other'];
  const accountType = validAccountTypes.includes(params.accountType)
    ? params.accountType
    : 'customer';
  const proofDetails = sanitizeText(params.proofDetails, 1200);

  if (requesterName.length < 2) {
    return { ok: false, status: 400, error: 'يرجى إدخال اسم صاحب الحساب بشكل واضح.' };
  }
  if (!isValidPhone(requesterPhone)) {
    return { ok: false, status: 400, error: 'يرجى إدخال رقم هاتف صحيح للتواصل والتحقق.' };
  }
  if (proofDetails.length < 8) {
    return {
      ok: false,
      status: 400,
      error: 'يرجى كتابة معلومات كافية تثبت ملكيتك للحساب (مثل اسم المتجر، المدينة، أو آخر نشاط).',
    };
  }

  const matchedUserId = findMatchingUserId(requesterEmail, requesterPhone);
  const id = generateId('rec');
  const now = new Date().toISOString();

  db.prepare(
    `INSERT INTO account_recovery_requests
      (id, matched_user_id, requester_name, requester_phone, requester_email, account_type, proof_details, status, admin_notes, rejection_reason, reviewed_by_id, reviewed_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', '', '', NULL, '', ?, ?)`
  ).run(
    id,
    matchedUserId,
    requesterName,
    requesterPhone,
    requesterEmail,
    accountType,
    proofDetails,
    now,
    now
  );

  // Notify all active Super Admins immediately
  const admins = db
    .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
    .all() as Array<{ id: string }>;
  for (const adm of admins) {
    createAndDispatchNotification({
      userId: adm.id,
      storeId: null,
      orderId: null,
      type: 'account_recovery',
      title: `طلب استعادة حساب جديد — ${requesterName}`,
      body: `الهاتف: ${requesterPhone} · نوع الحساب: ${accountType} · يرجى المراجعة والتحقق من الهوية.`,
      targetView: 'admin',
    });
  }

  return { ok: true, requestId: id };
}

export async function requestEmailPasswordReset(params: {
  email: string;
  appOrigin: string;
}): Promise<
  | { ok: true; deliveryMode: 'sent' | 'not_configured'; message: string }
  | { ok: false; status: number; error: string }
> {
  const email = sanitizeText(params.email || '', 160).toLowerCase();
  if (!isValidEmail(email)) {
    return { ok: false, status: 400, error: 'يرجى إدخال بريد إلكتروني صحيح.' };
  }

  // If SMTP/Resend isn't configured on server, inform clearly without pretending to send an email
  if (!isEmailDeliveryConfigured()) {
    return {
      ok: true,
      deliveryMode: 'not_configured',
      message:
        'خدمة إرسال البريد الإلكتروني غير مهيأة حالياً على الخادم، ولم يتم إرسال أي رسالة بريدية. يمكنك استعادة حسابك فوراً عبر تبويب «طلب عبر المدير» ليقوم المدير الرئيسي بالتحقق من هويتك وإصدار رمز استعادة مؤقت.',
    };
  }

  // Non-enumerating neutral success response regardless of whether the email exists
  const neutralResponse = {
    ok: true as const,
    deliveryMode: 'sent' as const,
    message:
      'إذا كان البريد الإلكتروني مسجلاً لدينا، فقد تم إرسال رابط ورمز مؤقت لإعادة تعيين كلمة المرور إلى بريدك (صالح لمدة 30 دقيقة لمرة واحدة).',
  };

  const userRow = db
    .prepare('SELECT id, full_name, email, is_active FROM users WHERE LOWER(email) = ?')
    .get(email) as { id: string; full_name: string; email: string; is_active: number } | undefined;

  if (!userRow || !Boolean(userRow.is_active)) {
    return neutralResponse;
  }

  const resetToken = generateResetToken();
  const tempCode = generateTemporaryResetCode();
  const tokenHash = hashSessionToken(resetToken);
  const codeHash = hashSessionToken(normalizeResetCode(tempCode));
  const nowDate = new Date();
  const now = nowDate.toISOString();
  const expiresAt = new Date(nowDate.getTime() + EMAIL_RESET_TOKEN_TTL_MS).toISOString();
  const tokenId = generateId('rst');

  const tx = db.transaction(() => {
    db.prepare(
      "UPDATE password_reset_tokens SET used_at = ? WHERE user_id = ? AND used_at = ''"
    ).run(now, userRow.id);

    db.prepare(
      `INSERT INTO password_reset_tokens
        (id, user_id, recovery_request_id, token_hash, code_hash, issued_by_admin_id, expires_at, used_at, created_at)
       VALUES (?, ?, NULL, ?, ?, NULL, ?, '', ?)`
    ).run(tokenId, userRow.id, tokenHash, codeHash, expiresAt, now);
  });
  tx();

  const cleanOrigin = params.appOrigin.replace(/\/+$/, '');
  const resetUrl = `${cleanOrigin}/?view=auth&resetToken=${encodeURIComponent(resetToken)}`;

  const sendRes = await sendPasswordResetEmail({
    to: userRow.email,
    fullName: userRow.full_name,
    resetUrl,
    tempCode,
    expiresMinutes: 30,
  });

  if (sendRes.ok === false) {
    // Invalidate token if delivery failed so unused tokens don't linger
    db.prepare('UPDATE password_reset_tokens SET used_at = ? WHERE id = ?').run(now, tokenId);
    return {
      ok: false,
      status: 503,
      error:
        'تعذر إرسال رسالة البريد الإلكتروني حالياً. يمكنك استخدام خيار «طلب استعادة عبر المدير» بدلاً من ذلك.',
    };
  }

  const auditAdmin = db
    .prepare("SELECT id, full_name FROM users WHERE role = 'super_admin' LIMIT 1")
    .get() as { id: string; full_name: string } | undefined;
  if (auditAdmin) {
    logAdminAction({
      admin: { id: auditAdmin.id, fullName: auditAdmin.full_name },
      actionType: 'password_reset_email_sent',
      targetType: 'user',
      targetId: userRow.id,
      targetLabel: `${userRow.full_name} (${userRow.email})`,
      details: `تم إرسال رابط ورمز إعادة تعيين مؤقت عبر البريد الإلكتروني (${sendRes.provider})`,
    });
  }

  return neutralResponse;
}

export function getAllAccountRecoveryRequests(limit = 150): AccountRecoveryRequest[] {
  const rows = db
    .prepare(
      `SELECT r.*,
              u.full_name AS matched_user_name,
              u.email AS matched_user_email,
              u.phone AS matched_user_phone,
              u.role AS matched_user_role
       FROM account_recovery_requests r
       LEFT JOIN users u ON u.id = r.matched_user_id
       ORDER BY CASE WHEN r.status = 'pending' THEN 0 ELSE 1 END, r.created_at DESC
       LIMIT ?`
    )
    .all(Math.max(1, Math.min(300, limit))) as Record<string, unknown>[];
  return rows.map(mapRecoveryRequest);
}

export function issueOneTimePasswordResetForUser(params: {
  admin: Pick<User, 'id' | 'fullName'>;
  targetUserId: string;
  recoveryRequestId?: string | null;
  notes?: string;
}): { ok: true; issued: IssuedPasswordReset } | { ok: false; status: number; error: string } {
  const targetUser = db
    .prepare('SELECT id, full_name, email, phone, role FROM users WHERE id = ?')
    .get(params.targetUserId) as
    | { id: string; full_name: string; email: string; phone: string; role: UserRole }
    | undefined;

  if (!targetUser) {
    return { ok: false, status: 404, error: 'الحساب المطلوب غير موجود في قاعدة البيانات.' };
  }

  const resetToken = generateResetToken();
  const tempCode = generateTemporaryResetCode();
  const tokenHash = hashSessionToken(resetToken);
  const codeHash = hashSessionToken(normalizeResetCode(tempCode));
  const nowDate = new Date();
  const now = nowDate.toISOString();
  const expiresAt = new Date(nowDate.getTime() + RESET_TOKEN_TTL_MS).toISOString();
  const tokenId = generateId('rst');

  const tx = db.transaction(() => {
    // Invalidate any previous unused reset tokens for this user
    db.prepare(
      "UPDATE password_reset_tokens SET used_at = ? WHERE user_id = ? AND used_at = ''"
    ).run(now, targetUser.id);

    db.prepare(
      `INSERT INTO password_reset_tokens
        (id, user_id, recovery_request_id, token_hash, code_hash, issued_by_admin_id, expires_at, used_at, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, '', ?)`
    ).run(
      tokenId,
      targetUser.id,
      params.recoveryRequestId ?? null,
      tokenHash,
      codeHash,
      params.admin.id,
      expiresAt,
      now
    );
  });
  tx();

  logAdminAction({
    admin: params.admin,
    actionType: 'password_reset_issued',
    targetType: 'user',
    targetId: targetUser.id,
    targetLabel: `${targetUser.full_name} (${targetUser.email})`,
    details: `إصدار رابط ورمز إعادة تعيين مؤقت (صالح لساعتين)${
      params.recoveryRequestId ? ` · طلب استعادة: ${params.recoveryRequestId}` : ''
    }${params.notes ? ` · ${sanitizeText(params.notes, 200)}` : ''}`,
  });

  return {
    ok: true,
    issued: {
      userId: targetUser.id,
      userName: targetUser.full_name,
      userEmail: targetUser.email,
      userPhone: targetUser.phone,
      resetToken,
      tempCode,
      resetPath: `/?view=auth&resetToken=${resetToken}`,
      expiresAt,
    },
  };
}

export function reviewAccountRecoveryRequest(params: {
  admin: Pick<User, 'id' | 'fullName'>;
  requestId: string;
  decision: 'approve' | 'reject';
  targetUserId?: string;
  rejectionReason?: string;
  adminNotes?: string;
}):
  | { ok: true; request: AccountRecoveryRequest; issuedReset?: IssuedPasswordReset }
  | { ok: false; status: number; error: string } {
  const row = db
    .prepare('SELECT * FROM account_recovery_requests WHERE id = ?')
    .get(params.requestId) as Record<string, unknown> | undefined;

  if (!row) {
    return { ok: false, status: 404, error: 'طلب استعادة الحساب غير موجود.' };
  }

  const currentStatus = String(row.status);
  if (currentStatus === 'completed' || currentStatus === 'rejected') {
    return { ok: false, status: 409, error: 'تم إغلاق هذا الطلب مسبقاً.' };
  }

  const now = new Date().toISOString();
  const adminNotes = sanitizeText(params.adminNotes || '', 400);

  if (params.decision === 'reject') {
    const rejectionReason = sanitizeText(params.rejectionReason || '', 400);
    if (rejectionReason.length < 3) {
      return { ok: false, status: 400, error: 'يرجى إدخال سبب واضح لرفض طلب الاستعادة.' };
    }

    db.prepare(
      `UPDATE account_recovery_requests
       SET status = 'rejected', rejection_reason = ?, admin_notes = ?, reviewed_by_id = ?, reviewed_at = ?, updated_at = ?
       WHERE id = ?`
    ).run(rejectionReason, adminNotes, params.admin.id, now, now, params.requestId);

    logAdminAction({
      admin: params.admin,
      actionType: 'account_recovery_rejected',
      targetType: 'account_recovery',
      targetId: params.requestId,
      targetLabel: `${String(row.requester_name)} (${String(row.requester_phone)})`,
      details: `رفض طلب الاستعادة — السبب: ${rejectionReason}`,
    });

    const updated = db
      .prepare(
        `SELECT r.*, u.full_name AS matched_user_name, u.email AS matched_user_email,
                u.phone AS matched_user_phone, u.role AS matched_user_role
         FROM account_recovery_requests r
         LEFT JOIN users u ON u.id = r.matched_user_id
         WHERE r.id = ?`
      )
      .get(params.requestId) as Record<string, unknown>;

    return { ok: true, request: mapRecoveryRequest(updated) };
  }

  // Approve: resolve target user ID
  const resolvedUserId = sanitizeText(params.targetUserId || '', 60) || (row.matched_user_id ? String(row.matched_user_id) : '');
  if (!resolvedUserId) {
    return {
      ok: false,
      status: 400,
      error: 'يرجى تحديد الحساب المطابق من قائمة المستخدمين قبل الموافقة وإصدار رمز الاستعادة.',
    };
  }

  const issuedRes = issueOneTimePasswordResetForUser({
    admin: params.admin,
    targetUserId: resolvedUserId,
    recoveryRequestId: params.requestId,
    notes: adminNotes,
  });
  if (issuedRes.ok === false) {
    return issuedRes;
  }

  db.prepare(
    `UPDATE account_recovery_requests
     SET matched_user_id = ?, status = 'approved', admin_notes = ?, reviewed_by_id = ?, reviewed_at = ?, updated_at = ?
     WHERE id = ?`
  ).run(resolvedUserId, adminNotes, params.admin.id, now, now, params.requestId);

  logAdminAction({
    admin: params.admin,
    actionType: 'account_recovery_approved',
    targetType: 'account_recovery',
    targetId: params.requestId,
    targetLabel: `${issuedRes.issued.userName} (${issuedRes.issued.userEmail})`,
    details: `الموافقة على طلب الاستعادة وإصدار رابط ورمز مؤقت لإعادة تعيين كلمة المرور${
      adminNotes ? ` · ${adminNotes}` : ''
    }`,
  });

  const updated = db
    .prepare(
      `SELECT r.*, u.full_name AS matched_user_name, u.email AS matched_user_email,
              u.phone AS matched_user_phone, u.role AS matched_user_role
       FROM account_recovery_requests r
       LEFT JOIN users u ON u.id = r.matched_user_id
       WHERE r.id = ?`
    )
    .get(params.requestId) as Record<string, unknown>;

  return {
    ok: true,
    request: mapRecoveryRequest(updated),
    issuedReset: issuedRes.issued,
  };
}

export function completePasswordReset(params: {
  token?: string;
  code?: string;
  newPassword: string;
}): { ok: true; userEmail: string } | { ok: false; status: number; error: string } {
  const token = typeof params.token === 'string' ? params.token.trim() : '';
  const code = typeof params.code === 'string' ? normalizeResetCode(params.code) : '';
  const newPassword = typeof params.newPassword === 'string' ? params.newPassword : '';

  if (!token && !code) {
    return {
      ok: false,
      status: 400,
      error: 'يرجى إدخال رمز الاستعادة المؤقت أو فتح رابط إعادة التعيين المرسل من الإدارة.',
    };
  }
  if (newPassword.length < 6) {
    return { ok: false, status: 400, error: 'كلمة المرور الجديدة يجب أن لا تقل عن 6 أحرف.' };
  }

  const now = new Date().toISOString();
  let tokenRow: Record<string, unknown> | undefined;

  if (token) {
    const tokenHash = hashSessionToken(token);
    tokenRow = db
      .prepare(
        `SELECT t.*, u.full_name, u.email, u.role, u.is_active
         FROM password_reset_tokens t
         JOIN users u ON u.id = t.user_id
         WHERE t.token_hash = ? AND t.used_at = '' AND t.expires_at > ?`
      )
      .get(tokenHash, now) as Record<string, unknown> | undefined;
  } else {
    const codeHash = hashSessionToken(code);
    tokenRow = db
      .prepare(
        `SELECT t.*, u.full_name, u.email, u.role, u.is_active
         FROM password_reset_tokens t
         JOIN users u ON u.id = t.user_id
         WHERE t.code_hash = ? AND t.used_at = '' AND t.expires_at > ?
         ORDER BY t.created_at DESC
         LIMIT 1`
      )
      .get(codeHash, now) as Record<string, unknown> | undefined;
  }

  if (!tokenRow) {
    return {
      ok: false,
      status: 400,
      error: 'رابط أو رمز إعادة التعيين غير صالح أو منتهي الصلاحية أو تم استخدامه مسبقاً.',
    };
  }

  const userId = String(tokenRow.user_id);
  const userRole = String(tokenRow.role);
  const userEmail = String(tokenRow.email);
  const userName = String(tokenRow.full_name);

  if (userRole === 'super_admin' && newPassword.length < 8) {
    return {
      ok: false,
      status: 400,
      error: 'كلمة مرور المدير العام يجب أن لا تقل عن 8 أحرف.',
    };
  }

  const nextPasswordHash = hashPassword(newPassword);
  const tokenId = String(tokenRow.id);
  const recoveryRequestId = tokenRow.recovery_request_id
    ? String(tokenRow.recovery_request_id)
    : null;
  const issuedByAdminId = tokenRow.issued_by_admin_id
    ? String(tokenRow.issued_by_admin_id)
    : null;

  const tx = db.transaction(() => {
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(nextPasswordHash, userId);
    db.prepare('UPDATE password_reset_tokens SET used_at = ? WHERE id = ?').run(now, tokenId);
    // Security: invalidate all previous active sessions so old devices must re-authenticate
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);

    if (recoveryRequestId) {
      db.prepare(
        "UPDATE account_recovery_requests SET status = 'completed', updated_at = ? WHERE id = ?"
      ).run(now, recoveryRequestId);
    }
  });
  tx();

  // Log audit record under the issuing admin (or any active super_admin)
  const auditAdmin = issuedByAdminId
    ? (db.prepare('SELECT id, full_name FROM users WHERE id = ?').get(issuedByAdminId) as
        | { id: string; full_name: string }
        | undefined)
    : (db
        .prepare("SELECT id, full_name FROM users WHERE role = 'super_admin' LIMIT 1")
        .get() as { id: string; full_name: string } | undefined);

  if (auditAdmin) {
    logAdminAction({
      admin: { id: auditAdmin.id, fullName: auditAdmin.full_name },
      actionType: 'password_reset_completed',
      targetType: 'user',
      targetId: userId,
      targetLabel: `${userName} (${userEmail})`,
      details: `أتم المستخدم إعادة تعيين كلمة المرور بنجاح وتم إنهاء جميع الجلسات القديمة${
        recoveryRequestId ? ` · طلب استعادة: ${recoveryRequestId}` : ''
      }`,
    });
  }

  createAndDispatchNotification({
    userId,
    storeId: null,
    orderId: null,
    type: 'system',
    title: 'تم تحديث كلمة المرور بنجاح',
    body: 'تمت إعادة تعيين كلمة مرور حسابك بأمان وإغلاق الجلسات السابقة. يمكنك تسجيل الدخول بكلمتك الجديدة الآن.',
    targetView: 'notifications',
  });

  return { ok: true, userEmail };
}
