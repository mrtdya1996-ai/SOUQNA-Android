import { db, getPlatformSetting, setPlatformSetting } from './db.ts';
import { createAndDispatchNotification, formatAmountArabic } from './notifications.ts';
import { generateId, sanitizeText } from './security.ts';
import {
  DEFAULT_PAYMENT_METHODS,
  PAYMENT_METHOD_LABELS,
  SUBSCRIPTION_STATUS_LABELS,
  type AdminAuditLog,
  type CourierVerificationStatus,
  type PaymentMethodCode,
  type StoreStatus,
  type StoreSubscriptionStatus,
  type StoreType,
  type SubscriberType,
  type SubscriptionActionType,
  type SubscriptionLog,
  type SubscriptionPaymentMethodsConfig,
  type SubscriptionPaymentRequest,
  type SubscriptionPaymentRequestStatus,
  type SubscriptionPlan,
  type SubscriptionSummaryStats,
  type User,
  type UserSubscription,
} from '../types.ts';

export const DEFAULT_TRIAL_DAYS = 30;
export const EXPIRING_SOON_DAYS = 5;
const DAY_MS = 24 * 60 * 60 * 1000;

export function addDaysIso(baseDate: Date, days: number): string {
  return new Date(baseDate.getTime() + days * DAY_MS).toISOString();
}

export function logAdminAction(params: {
  admin: Pick<User, 'id' | 'fullName'>;
  actionType: string;
  targetType: string;
  targetId: string;
  targetLabel?: string;
  details?: string;
}): void {
  const id = generateId('aud');
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO admin_audit_logs
      (id, admin_id, admin_name, action_type, target_type, target_id, target_label, details, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    params.admin.id,
    sanitizeText(params.admin.fullName, 120),
    sanitizeText(params.actionType, 80),
    sanitizeText(params.targetType, 60),
    sanitizeText(params.targetId, 80),
    sanitizeText(params.targetLabel || '', 160),
    sanitizeText(params.details || '', 600),
    now
  );
}

export function getAdminAuditLogs(limit = 120): AdminAuditLog[] {
  const rows = db
    .prepare(
      `SELECT * FROM admin_audit_logs
       ORDER BY created_at DESC
       LIMIT ?`
    )
    .all(Math.max(1, Math.min(300, limit))) as Record<string, unknown>[];

  return rows.map((row) => ({
    id: String(row.id),
    adminId: String(row.admin_id),
    adminName: String(row.admin_name || ''),
    actionType: String(row.action_type || ''),
    targetType: String(row.target_type || ''),
    targetId: String(row.target_id || ''),
    targetLabel: String(row.target_label || ''),
    details: String(row.details || ''),
    createdAt: String(row.created_at || ''),
  }));
}

export function logSubscriptionAction(params: {
  subscriptionId: string;
  userId: string;
  actionType: SubscriptionActionType;
  amountPaid?: number;
  durationDays?: number;
  previousStatus?: string;
  newStatus?: string;
  previousExpiresAt?: string;
  newExpiresAt?: string;
  actorId?: string | null;
  actorName?: string;
  actorRole?: string;
  notes?: string;
}): void {
  const id = generateId('sublog');
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO subscription_logs
      (id, subscription_id, user_id, action_type, amount_paid, duration_days, previous_status, new_status, previous_expires_at, new_expires_at, actor_id, actor_name, actor_role, notes, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    params.subscriptionId,
    params.userId,
    params.actionType,
    Math.max(0, Number(params.amountPaid) || 0),
    Math.max(0, Math.floor(Number(params.durationDays) || 0)),
    params.previousStatus || '',
    params.newStatus || '',
    params.previousExpiresAt || '',
    params.newExpiresAt || '',
    params.actorId ?? null,
    sanitizeText(params.actorName || 'النظام', 120),
    sanitizeText(params.actorRole || 'system', 40),
    sanitizeText(params.notes || '', 400),
    now
  );
}

function mapSubscriptionLog(row: Record<string, unknown>): SubscriptionLog {
  return {
    id: String(row.id),
    subscriptionId: String(row.subscription_id),
    userId: String(row.user_id),
    userName: row.user_name ? String(row.user_name) : undefined,
    subscriberType: row.subscriber_type ? (row.subscriber_type as SubscriberType) : undefined,
    storeName: row.store_name ? String(row.store_name) : undefined,
    actionType: row.action_type as SubscriptionActionType,
    amountPaid: Number(row.amount_paid || 0),
    durationDays: Number(row.duration_days || 0),
    previousStatus: String(row.previous_status || ''),
    newStatus: String(row.new_status || ''),
    previousExpiresAt: String(row.previous_expires_at || ''),
    newExpiresAt: String(row.new_expires_at || ''),
    actorId: row.actor_id ? String(row.actor_id) : null,
    actorName: String(row.actor_name || ''),
    actorRole: String(row.actor_role || ''),
    notes: String(row.notes || ''),
    createdAt: String(row.created_at || ''),
  };
}

function syncLegacyStoreSubscription(
  storeId: string | null,
  status: StoreSubscriptionStatus,
  monthlyFee: number,
  expiresAt: string,
  notes: string
): void {
  if (!storeId) return;
  const now = new Date().toISOString();
  const legacyPlan = status === 'trial' ? 'free' : monthlyFee > 0 ? 'pro' : 'basic';
  db.prepare(
    `INSERT INTO store_subscriptions (store_id, plan_name, status, monthly_fee, expires_at, notes, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(store_id) DO UPDATE SET
       plan_name = excluded.plan_name,
       status = excluded.status,
       monthly_fee = excluded.monthly_fee,
       expires_at = excluded.expires_at,
       notes = excluded.notes,
       updated_at = excluded.updated_at`
  ).run(storeId, legacyPlan, status, monthlyFee, expiresAt, notes, now);
}

export function getConfiguredTrialDays(): number {
  const raw = Number(getPlatformSetting('trial_days', String(DEFAULT_TRIAL_DAYS)));
  if (!Number.isFinite(raw)) return DEFAULT_TRIAL_DAYS;
  return Math.max(0, Math.min(365, Math.floor(raw)));
}

/**
 * Ensures an eligible merchant or courier has a subscription record.
 * Automatically grants the Super Admin configured free trial period upon first enrollment.
 * Regular customers are never required to have a subscription.
 */
export function ensureUserSubscription(
  userId: string,
  subscriberType: SubscriberType,
  storeId?: string | null
): Record<string, unknown> {
  const existing = db
    .prepare('SELECT * FROM user_subscriptions WHERE user_id = ?')
    .get(userId) as Record<string, unknown> | undefined;

  if (existing) {
    if (storeId && !existing.store_id) {
      db.prepare('UPDATE user_subscriptions SET store_id = ?, updated_at = ? WHERE id = ?').run(
        storeId,
        new Date().toISOString(),
        String(existing.id)
      );
      existing.store_id = storeId;
      syncLegacyStoreSubscription(
        storeId,
        existing.status as StoreSubscriptionStatus,
        Number(existing.monthly_fee || 0),
        String(existing.expires_at || ''),
        String(existing.notes || '')
      );
    }
    return existing;
  }

  let resolvedStoreId = storeId ?? null;
  if (!resolvedStoreId && subscriberType === 'merchant') {
    const owned = db.prepare('SELECT id FROM stores WHERE owner_id = ?').get(userId) as
      | { id: string }
      | undefined;
    if (owned) resolvedStoreId = owned.id;
  }

  const trialDays = getConfiguredTrialDays();
  const nowDate = new Date();
  const now = nowDate.toISOString();
  const expiresAt = addDaysIso(nowDate, trialDays);
  const id = generateId('sub');
  const initialStatus: StoreSubscriptionStatus = trialDays > 0 ? 'trial' : 'expired';
  const trialNote =
    trialDays > 0
      ? `فترة تجريبية مجانية لمدة ${trialDays} يوماً للمشترك الجديد`
      : 'لا توجد فترة تجريبية مجانية — يتطلب تفعيل اشتراك مدفوع';

  db.prepare(
    `INSERT INTO user_subscriptions
      (id, user_id, subscriber_type, store_id, plan_name, status, starts_at, expires_at, monthly_fee, total_paid, renewal_requested, renewal_note, renewal_requested_at, expiring_notified_at, expired_notified_at, notes, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, '', '', '', '', ?, ?, ?)`
  ).run(
    id,
    userId,
    subscriberType,
    resolvedStoreId,
    trialDays > 0 ? `trial_${trialDays}` : 'pending_activation',
    initialStatus,
    now,
    expiresAt,
    trialNote,
    now,
    now
  );

  logSubscriptionAction({
    subscriptionId: id,
    userId,
    actionType: 'trial_started',
    amountPaid: 0,
    durationDays: trialDays,
    previousStatus: '',
    newStatus: initialStatus,
    previousExpiresAt: '',
    newExpiresAt: expiresAt,
    actorId: null,
    actorName: 'نظام سوقنا',
    actorRole: 'system',
    notes: trialNote,
  });

  syncLegacyStoreSubscription(resolvedStoreId, initialStatus, 0, expiresAt, trialNote);

  return db.prepare('SELECT * FROM user_subscriptions WHERE id = ?').get(id) as Record<
    string,
    unknown
  >;
}

/**
 * Non-destructive backfill so any pre-existing merchants or couriers receive a 30-day trial record.
 * Customers and super_admins are untouched.
 */
export function backfillMissingSubscriptions(): void {
  const missingUsers = db
    .prepare(
      `SELECT u.id, u.role, s.id AS store_id
       FROM users u
       LEFT JOIN user_subscriptions us ON us.user_id = u.id
       LEFT JOIN stores s ON s.owner_id = u.id
       WHERE u.role IN ('merchant', 'courier') AND us.id IS NULL`
    )
    .all() as Array<{ id: string; role: SubscriberType; store_id: string | null }>;

  for (const row of missingUsers) {
    ensureUserSubscription(row.id, row.role, row.store_id);
  }
}

function mapRichSubscriptionRow(
  row: Record<string, unknown>,
  logs?: SubscriptionLog[]
): UserSubscription {
  const status = row.status as StoreSubscriptionStatus;
  const expiresAt = String(row.expires_at || '');
  const nowMs = Date.now();
  const expiresMs = expiresAt ? new Date(expiresAt).getTime() : 0;
  const diffMs = Number.isFinite(expiresMs) ? expiresMs - nowMs : 0;
  const daysRemaining =
    status === 'expired' || status === 'suspended'
      ? 0
      : Math.max(0, Math.ceil(diffMs / DAY_MS));
  const isCommercialActive = (status === 'trial' || status === 'active') && diffMs > 0;
  const isExpiringSoon = isCommercialActive && daysRemaining > 0 && daysRemaining <= EXPIRING_SOON_DAYS;

  return {
    id: String(row.id),
    userId: String(row.user_id),
    userName: row.user_name ? String(row.user_name) : undefined,
    userEmail: row.user_email ? String(row.user_email) : undefined,
    userPhone: row.user_phone ? String(row.user_phone) : undefined,
    userActive: row.user_active === undefined ? undefined : Boolean(row.user_active),
    subscriberType: row.subscriber_type as SubscriberType,
    storeId: row.store_id ? String(row.store_id) : null,
    storeName: row.store_name ? String(row.store_name) : undefined,
    storeType: row.store_type ? (row.store_type as StoreType) : undefined,
    storeStatus: row.store_status ? (row.store_status as StoreStatus) : undefined,
    courierId: row.courier_id ? String(row.courier_id) : null,
    courierStatus: row.courier_status ? (row.courier_status as CourierVerificationStatus) : undefined,
    planName: String(row.plan_name || 'trial_30'),
    status,
    startsAt: String(row.starts_at || ''),
    expiresAt,
    daysRemaining,
    isExpiringSoon,
    isCommercialActive,
    monthlyFee: Number(row.monthly_fee || 0),
    totalPaid: Number(row.total_paid || 0),
    renewalRequested: Boolean(row.renewal_requested),
    renewalNote: String(row.renewal_note || ''),
    renewalRequestedAt: String(row.renewal_requested_at || ''),
    notes: String(row.notes || ''),
    createdAt: String(row.created_at || ''),
    updatedAt: String(row.updated_at || ''),
    logs,
  };
}

function getRichSubscriptionRow(userId: string): Record<string, unknown> | undefined {
  return db
    .prepare(
      `SELECT us.*,
              u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone, u.is_active AS user_active,
              s.id AS joined_store_id, s.name AS store_name, s.store_type AS store_type, s.status AS store_status,
              c.id AS courier_id, c.verification_status AS courier_status
       FROM user_subscriptions us
       JOIN users u ON u.id = us.user_id
       LEFT JOIN stores s ON s.owner_id = us.user_id
       LEFT JOIN couriers c ON c.user_id = us.user_id
       WHERE us.user_id = ?`
    )
    .get(userId) as Record<string, unknown> | undefined;
}

/**
 * Evaluates a user's subscription in real time:
 * - Automatically transitions expired trial/active subscriptions to 'expired' (preserving all data).
 * - Sends proactive expiring-soon and expired alerts once per billing cycle.
 * - Returns null for regular customers and super_admins (no subscription required).
 */
export function evaluateUserSubscription(
  userId: string,
  options?: { includeLogs?: boolean }
): UserSubscription | null {
  const userRow = db.prepare('SELECT id, role FROM users WHERE id = ?').get(userId) as
    | { id: string; role: string }
    | undefined;
  if (!userRow || (userRow.role !== 'merchant' && userRow.role !== 'courier')) {
    return null;
  }

  ensureUserSubscription(userId, userRow.role as SubscriberType);

  let row = getRichSubscriptionRow(userId);
  if (!row) return null;

  const subId = String(row.id);
  const currentStatus = row.status as StoreSubscriptionStatus;
  const expiresAt = String(row.expires_at || '');
  const nowDate = new Date();
  const now = nowDate.toISOString();
  const expiresMs = expiresAt ? new Date(expiresAt).getTime() : 0;
  const diffMs = Number.isFinite(expiresMs) ? expiresMs - nowDate.getTime() : 0;
  const storeId = (row.store_id || row.joined_store_id) ? String(row.store_id || row.joined_store_id) : null;

  if (storeId && !row.store_id) {
    db.prepare('UPDATE user_subscriptions SET store_id = ?, updated_at = ? WHERE id = ?').run(
      storeId,
      now,
      subId
    );
  }

  // Transition expired trial or active subscription automatically
  if ((currentStatus === 'trial' || currentStatus === 'active') && diffMs <= 0) {
    db.prepare(
      `UPDATE user_subscriptions
       SET status = 'expired', expired_notified_at = ?, updated_at = ?
       WHERE id = ?`
    ).run(now, now, subId);

    if (row.subscriber_type === 'courier') {
      db.prepare(
        `UPDATE couriers
         SET is_available = 0, latitude = NULL, longitude = NULL, location_updated_at = '', updated_at = ?
         WHERE user_id = ?`
      ).run(now, userId);
    }

    logSubscriptionAction({
      subscriptionId: subId,
      userId,
      actionType: 'expired',
      previousStatus: currentStatus,
      newStatus: 'expired',
      previousExpiresAt: expiresAt,
      newExpiresAt: expiresAt,
      actorName: 'نظام الاشتراكات',
      actorRole: 'system',
      notes: 'انتهت مدة الاشتراك وتم تعليق الميزات التجارية مؤقتاً مع الحفاظ الكامل على جميع البيانات',
    });

    syncLegacyStoreSubscription(
      storeId,
      'expired',
      Number(row.monthly_fee || 0),
      expiresAt,
      String(row.notes || '')
    );

    if (!String(row.expired_notified_at || '')) {
      createAndDispatchNotification({
        userId,
        storeId,
        orderId: null,
        type: 'subscription_alert',
        title: 'انتهت مدة اشتراكك في سوقنا',
        body: 'تم إيقاف الميزات التجارية مؤقتاً لانتهاء الاشتراك مع الحفاظ الكامل على متجرك وبياناتك وطلباتك. تواصل مع الإدارة لتجديد الاشتراك.',
        targetView: 'subscription',
      });
    }

    row = getRichSubscriptionRow(userId)!;
  } else if (
    (currentStatus === 'trial' || currentStatus === 'active') &&
    diffMs > 0 &&
    Math.ceil(diffMs / DAY_MS) <= EXPIRING_SOON_DAYS &&
    !String(row.expiring_notified_at || '')
  ) {
    const daysLeft = Math.max(1, Math.ceil(diffMs / DAY_MS));
    db.prepare('UPDATE user_subscriptions SET expiring_notified_at = ?, updated_at = ? WHERE id = ?').run(
      now,
      now,
      subId
    );
    createAndDispatchNotification({
      userId,
      storeId,
      orderId: null,
      type: 'subscription_alert',
      title: `تنبيه: اشتراكك ينتهي خلال ${daysLeft} ${daysLeft === 1 ? 'يوم' : 'أيام'}`,
      body: 'يرجى طلب التجديد والتواصل مع الإدارة قبل انتهاء المدة لضمان استمرار نشاطك التجاري دون انقطاع.',
      targetView: 'subscription',
    });
    row = getRichSubscriptionRow(userId)!;
  }

  let logs: SubscriptionLog[] | undefined;
  if (options?.includeLogs) {
    const logRows = db
      .prepare(
        `SELECT * FROM subscription_logs
         WHERE user_id = ?
         ORDER BY created_at DESC
         LIMIT 50`
      )
      .all(userId) as Record<string, unknown>[];
    logs = logRows.map(mapSubscriptionLog);
  }

  return mapRichSubscriptionRow(row, logs);
}

export function checkMerchantCommercialAccess(ownerId: string): {
  allowed: boolean;
  subscription: UserSubscription | null;
  error?: string;
} {
  const sub = evaluateUserSubscription(ownerId);
  if (!sub) return { allowed: true, subscription: null };
  if (sub.isCommercialActive) {
    return { allowed: true, subscription: sub };
  }
  const msg =
    sub.status === 'suspended'
      ? 'اشتراك متجرك متوقف حالياً من قِبل الإدارة. جميع بياناتك ومنتجاتك محفوظة، يرجى التواصل مع الدعم الفني أو المدير لإعادة التفعيل.'
      : 'انتهت مدة اشتراك متجرك. جميع بياناتك ومنتجاتك وطلباتك محفوظة بأمان، يرجى تجديد الاشتراك للاستمرار في النشر واستقبال الطلبات.';
  return { allowed: false, subscription: sub, error: msg };
}

export function checkCourierCommercialAccess(userId: string): {
  allowed: boolean;
  subscription: UserSubscription | null;
  error?: string;
} {
  const sub = evaluateUserSubscription(userId);
  if (!sub) return { allowed: true, subscription: null };
  if (sub.isCommercialActive) {
    return { allowed: true, subscription: sub };
  }
  const msg =
    sub.status === 'suspended'
      ? 'اشتراك المندوب متوقف حالياً من قِبل الإدارة. بياناتك وسجلك محفوظان، يرجى التواصل مع الدعم الفني لإعادة التفعيل.'
      : 'انتهت مدة اشتراك المندوب. حسابك وسجلك محفوظان بأمان، يرجى تجديد الاشتراك لتفعيل التوفر واستلام طلبات التوصيل.';
  return { allowed: false, subscription: sub, error: msg };
}

export function getAllAdminSubscriptions(): UserSubscription[] {
  backfillMissingSubscriptions();
  const userRows = db
    .prepare("SELECT user_id FROM user_subscriptions ORDER BY updated_at DESC")
    .all() as Array<{ user_id: string }>;

  const result: UserSubscription[] = [];
  for (const r of userRows) {
    const sub = evaluateUserSubscription(r.user_id);
    if (sub) result.push(sub);
  }
  return result;
}

export function getSubscriptionSummaryStats(): SubscriptionSummaryStats {
  const all = getAllAdminSubscriptions();
  const revenueRow = db
    .prepare('SELECT COALESCE(SUM(amount_paid), 0) AS total FROM subscription_logs')
    .get() as { total: number };

  let merchantSubscribers = 0;
  let courierSubscribers = 0;
  let activeCount = 0;
  let trialCount = 0;
  let expiringSoonCount = 0;
  let expiredCount = 0;
  let suspendedCount = 0;
  let renewalRequestsCount = 0;

  for (const s of all) {
    if (s.subscriberType === 'merchant') merchantSubscribers++;
    else courierSubscribers++;

    if (s.status === 'active') activeCount++;
    else if (s.status === 'trial') trialCount++;
    else if (s.status === 'expired') expiredCount++;
    else if (s.status === 'suspended') suspendedCount++;

    if (s.isExpiringSoon) expiringSoonCount++;
    if (s.renewalRequested) renewalRequestsCount++;
  }

  const pendingPayRow = db
    .prepare("SELECT COUNT(*) AS cnt FROM subscription_payment_requests WHERE status = 'pending'")
    .get() as { cnt: number };

  return {
    totalSubscribers: all.length,
    merchantSubscribers,
    courierSubscribers,
    activeCount,
    trialCount,
    expiringSoonCount,
    expiredCount,
    suspendedCount,
    renewalRequestsCount,
    pendingPaymentRequestsCount: Number(pendingPayRow.cnt || 0),
    totalRecordedRevenue: Math.round(Number(revenueRow.total || 0) * 100) / 100,
  };
}

export function getRecentSubscriptionLogs(limit = 120): SubscriptionLog[] {
  const rows = db
    .prepare(
      `SELECT l.*, u.full_name AS user_name, us.subscriber_type, s.name AS store_name
       FROM subscription_logs l
       JOIN users u ON u.id = l.user_id
       LEFT JOIN user_subscriptions us ON us.id = l.subscription_id
       LEFT JOIN stores s ON s.owner_id = l.user_id
       ORDER BY l.created_at DESC
       LIMIT ?`
    )
    .all(Math.max(1, Math.min(300, limit))) as Record<string, unknown>[];

  return rows.map(mapSubscriptionLog);
}

export interface AdminSubscriptionActionPayload {
  action: 'activate' | 'extend' | 'suspend' | 'reactivate' | 'record_payment' | 'set_dates';
  durationDays?: number;
  amountPaid?: number;
  monthlyFee?: number;
  planName?: string;
  startsAt?: string;
  expiresAt?: string;
  notes?: string;
}

export function applyAdminSubscriptionAction(params: {
  admin: Pick<User, 'id' | 'fullName' | 'role'>;
  targetUserId: string;
  payload: AdminSubscriptionActionPayload;
  currency: string;
}): { ok: true; subscription: UserSubscription } | { ok: false; status: number; error: string } {
  const targetUser = db
    .prepare('SELECT id, full_name, role FROM users WHERE id = ?')
    .get(params.targetUserId) as { id: string; full_name: string; role: string } | undefined;

  if (!targetUser) {
    return { ok: false, status: 404, error: 'الحساب المطلوب غير موجود.' };
  }
  if (targetUser.role !== 'merchant' && targetUser.role !== 'courier') {
    return {
      ok: false,
      status: 400,
      error: 'نظام الاشتراكات ينطبق فقط على أصحاب المتاجر والأنشطة التجارية والمندوبين. الزبائن مجانيون دائماً.',
    };
  }

  const current = evaluateUserSubscription(targetUser.id);
  if (!current) {
    return { ok: false, status: 404, error: 'تعذر العثور على سجل الاشتراك.' };
  }

  const nowDate = new Date();
  const now = nowDate.toISOString();
  const action = params.payload.action;
  const durationDays = Math.max(
    1,
    Math.min(730, Math.floor(Number(params.payload.durationDays) || 30))
  );
  const amountPaid = Math.max(0, Math.round((Number(params.payload.amountPaid) || 0) * 100) / 100);
  const nextMonthlyFee =
    params.payload.monthlyFee !== undefined && Number.isFinite(Number(params.payload.monthlyFee))
      ? Math.max(0, Math.round(Number(params.payload.monthlyFee) * 100) / 100)
      : amountPaid > 0
      ? amountPaid
      : current.monthlyFee;
  const notes = sanitizeText(params.payload.notes ?? '', 350);

  let nextStatus: StoreSubscriptionStatus = current.status;
  let nextStartsAt = current.startsAt || now;
  let nextExpiresAt = current.expiresAt || now;
  let nextPlanName = sanitizeText(params.payload.planName || '', 40) || current.planName;
  let logAction: SubscriptionActionType = 'updated';
  let logDuration = 0;
  let notifTitle = '';
  let notifBody = '';
  let clearNotifFlags = false;
  let clearRenewalRequest = false;

  if (action === 'activate') {
    nextStatus = 'active';
    nextStartsAt = now;
    nextExpiresAt = addDaysIso(nowDate, durationDays);
    if (!params.payload.planName) {
      nextPlanName =
        durationDays >= 360
          ? 'annual'
          : durationDays >= 180
          ? 'semi_annual'
          : durationDays >= 85
          ? 'quarterly'
          : 'monthly';
    }
    logAction = 'activated';
    logDuration = durationDays;
    clearNotifFlags = true;
    clearRenewalRequest = true;
    notifTitle = 'تم تفعيل اشتراكك في سوقنا بنجاح';
    notifBody = `تم تفعيل الاشتراك لمدة ${durationDays} يوماً${
      amountPaid > 0 ? ` · المبلغ المسجل: ${formatAmountArabic(amountPaid, params.currency)}` : ''
    }. جميع الميزات التجارية مفعلة الآن.`;
  } else if (action === 'extend') {
    const currentExpMs = current.expiresAt ? new Date(current.expiresAt).getTime() : 0;
    const baseDate = currentExpMs > nowDate.getTime() ? new Date(currentExpMs) : nowDate;
    nextStatus = 'active';
    nextExpiresAt = addDaysIso(baseDate, durationDays);
    if (nextPlanName === 'trial_30') {
      nextPlanName = durationDays >= 85 ? 'quarterly' : 'monthly';
    }
    logAction = 'extended';
    logDuration = durationDays;
    clearNotifFlags = true;
    clearRenewalRequest = true;
    notifTitle = 'تم تمديد اشتراكك في سوقنا';
    notifBody = `تمت إضافة ${durationDays} يوماً إلى اشتراكك${
      amountPaid > 0 ? ` · الدفعة المسجلة: ${formatAmountArabic(amountPaid, params.currency)}` : ''
    }.`;
  } else if (action === 'suspend') {
    nextStatus = 'suspended';
    logAction = 'suspended';
    notifTitle = 'تم إيقاف اشتراكك مؤقتاً من قِبل الإدارة';
    notifBody = notes
      ? `السبب: ${notes} — بياناتك محفوظة بالكامل ويمكنك التواصل مع الدعم الفني.`
      : 'تم إيقاف الاشتراك مؤقتاً مع الحفاظ الكامل على بياناتك ومتجرك. يرجى التواصل مع الدعم الفني.';
    if (current.subscriberType === 'courier') {
      db.prepare(
        `UPDATE couriers
         SET is_available = 0, latitude = NULL, longitude = NULL, location_updated_at = '', updated_at = ?
         WHERE user_id = ?`
      ).run(now, targetUser.id);
    }
  } else if (action === 'reactivate') {
    const currentExpMs = current.expiresAt ? new Date(current.expiresAt).getTime() : 0;
    if (currentExpMs <= nowDate.getTime()) {
      nextExpiresAt = addDaysIso(nowDate, durationDays);
      logDuration = durationDays;
    }
    nextStatus = 'active';
    logAction = 'reactivated';
    clearNotifFlags = true;
    clearRenewalRequest = true;
    notifTitle = 'تمت إعادة تفعيل اشتراكك في سوقنا';
    notifBody = 'أصبح اشتراكك فعالاً الآن ويمكنك استخدام جميع الميزات التجارية فوراً.';
  } else if (action === 'record_payment') {
    if (amountPaid <= 0) {
      return { ok: false, status: 400, error: 'يرجى إدخال مبلغ دفع صحيح أكبر من صفر.' };
    }
    logAction = 'payment_recorded';
    notifTitle = 'تم تسجيل دفعة اشتراكك بنجاح';
    notifBody = `تم توثيق مبلغ ${formatAmountArabic(amountPaid, params.currency)} من قِبل الإدارة${
      notes ? ` · ${notes}` : ''
    }.`;
  } else if (action === 'set_dates') {
    const parsedStart = params.payload.startsAt ? new Date(params.payload.startsAt) : new Date(current.startsAt || now);
    const parsedEnd = params.payload.expiresAt ? new Date(params.payload.expiresAt) : null;
    if (!parsedEnd || !Number.isFinite(parsedEnd.getTime()) || !Number.isFinite(parsedStart.getTime())) {
      return { ok: false, status: 400, error: 'يرجى إدخال تاريخ بداية ونهاية صالحين للاشتراك.' };
    }
    if (parsedEnd.getTime() <= parsedStart.getTime()) {
      return { ok: false, status: 400, error: 'تاريخ نهاية الاشتراك يجب أن يكون بعد تاريخ البداية.' };
    }
    nextStartsAt = parsedStart.toISOString();
    nextExpiresAt = parsedEnd.toISOString();
    nextStatus = parsedEnd.getTime() > nowDate.getTime() ? 'active' : 'expired';
    logDuration = Math.max(1, Math.round((parsedEnd.getTime() - parsedStart.getTime()) / DAY_MS));
    logAction = 'dates_updated';
    clearNotifFlags = true;
    clearRenewalRequest = parsedEnd.getTime() > nowDate.getTime();
    notifTitle = 'تم تحديث تواريخ اشتراكك في سوقنا';
    notifBody = `تم ضبط صلاحية الاشتراك حتى ${parsedEnd.toLocaleDateString('ar-IQ')}${
      notes ? ` · ${notes}` : ''
    }.`;
  } else {
    return { ok: false, status: 400, error: 'إجراء الاشتراك المطلوب غير مدعوم.' };
  }

  const nextTotalPaid = Math.round((current.totalPaid + amountPaid) * 100) / 100;

  db.prepare(
    `UPDATE user_subscriptions
     SET plan_name = ?,
         status = ?,
         starts_at = ?,
         expires_at = ?,
         monthly_fee = ?,
         total_paid = ?,
         renewal_requested = CASE WHEN ? = 1 THEN 0 ELSE renewal_requested END,
         renewal_note = CASE WHEN ? = 1 THEN '' ELSE renewal_note END,
         expiring_notified_at = CASE WHEN ? = 1 THEN '' ELSE expiring_notified_at END,
         expired_notified_at = CASE WHEN ? = 1 THEN '' ELSE expired_notified_at END,
         notes = CASE WHEN ? != '' THEN ? ELSE notes END,
         updated_at = ?
     WHERE id = ?`
  ).run(
    nextPlanName,
    nextStatus,
    nextStartsAt,
    nextExpiresAt,
    nextMonthlyFee,
    nextTotalPaid,
    clearRenewalRequest ? 1 : 0,
    clearRenewalRequest ? 1 : 0,
    clearNotifFlags ? 1 : 0,
    clearNotifFlags ? 1 : 0,
    notes,
    notes,
    now,
    current.id
  );

  logSubscriptionAction({
    subscriptionId: current.id,
    userId: targetUser.id,
    actionType: logAction,
    amountPaid,
    durationDays: logDuration,
    previousStatus: current.status,
    newStatus: nextStatus,
    previousExpiresAt: current.expiresAt,
    newExpiresAt: nextExpiresAt,
    actorId: params.admin.id,
    actorName: params.admin.fullName,
    actorRole: params.admin.role,
    notes:
      notes ||
      `${SUBSCRIPTION_STATUS_LABELS[nextStatus]}${
        logDuration > 0 ? ` (${logDuration} يوماً)` : ''
      }`,
  });

  syncLegacyStoreSubscription(
    current.storeId,
    nextStatus,
    nextMonthlyFee,
    nextExpiresAt,
    notes || current.notes
  );

  logAdminAction({
    admin: params.admin,
    actionType: `subscription_${action}`,
    targetType: current.subscriberType,
    targetId: targetUser.id,
    targetLabel: current.storeName
      ? `${current.storeName} (${targetUser.full_name})`
      : targetUser.full_name,
    details: `${action} | الحالة: ${SUBSCRIPTION_STATUS_LABELS[nextStatus]}${
      logDuration > 0 ? ` | المدة: ${logDuration} يوم` : ''
    }${amountPaid > 0 ? ` | المبلغ: ${amountPaid}` : ''}${notes ? ` | ${notes}` : ''}`,
  });

  if (notifTitle) {
    createAndDispatchNotification({
      userId: targetUser.id,
      storeId: current.storeId,
      orderId: null,
      type: 'subscription_alert',
      title: notifTitle,
      body: notifBody,
      targetView: 'subscription',
    });
  }

  const refreshed = evaluateUserSubscription(targetUser.id, { includeLogs: true })!;
  return { ok: true, subscription: refreshed };
}

// =========================================================================
// EDITABLE SUBSCRIPTION PLANS & PAYMENT METHODS CONFIG
// =========================================================================
function mapPlan(row: Record<string, unknown>): SubscriptionPlan {
  return {
    id: String(row.id),
    code: String(row.code),
    name: String(row.name),
    durationMonths: Number(row.duration_months),
    durationDays: Number(row.duration_days),
    priceIqd: Number(row.price_iqd),
    isActive: Boolean(row.is_active),
    sortOrder: Number(row.sort_order || 0),
    updatedAt: String(row.updated_at || ''),
  };
}

export function getSubscriptionPlans(options?: { onlyActive?: boolean }): SubscriptionPlan[] {
  const sql = options?.onlyActive
    ? 'SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY sort_order ASC, duration_days ASC'
    : 'SELECT * FROM subscription_plans ORDER BY sort_order ASC, duration_days ASC';
  const rows = db.prepare(sql).all() as Record<string, unknown>[];
  return rows.map(mapPlan);
}

export function getPaymentMethodsConfig(): SubscriptionPaymentMethodsConfig {
  return {
    zaincashNumber: getPlatformSetting(
      'payment_zaincash_number',
      DEFAULT_PAYMENT_METHODS.zaincashNumber
    ),
    mastercardNumber: getPlatformSetting(
      'payment_mastercard_number',
      DEFAULT_PAYMENT_METHODS.mastercardNumber
    ),
  };
}

export function updateSubscriptionPlansAndMethods(params: {
  admin: Pick<User, 'id' | 'fullName'>;
  plans?: Array<{
    id: string;
    name?: string;
    priceIqd: number;
    durationDays?: number;
    isActive?: boolean;
  }>;
  paymentMethods?: Partial<SubscriptionPaymentMethodsConfig>;
}): { plans: SubscriptionPlan[]; paymentMethods: SubscriptionPaymentMethodsConfig } {
  const now = new Date().toISOString();
  const changes: string[] = [];

  if (Array.isArray(params.plans) && params.plans.length > 0) {
    const updateStmt = db.prepare(
      `UPDATE subscription_plans
       SET name = COALESCE(?, name),
           price_iqd = ?,
           duration_days = COALESCE(?, duration_days),
           is_active = COALESCE(?, is_active),
           updated_at = ?
       WHERE id = ?`
    );

    const tx = db.transaction(() => {
      for (const item of params.plans!) {
        const planId = sanitizeText(item.id, 60);
        if (!planId) continue;
        const existing = db
          .prepare('SELECT * FROM subscription_plans WHERE id = ?')
          .get(planId) as Record<string, unknown> | undefined;
        if (!existing) continue;

        const price = Math.max(0, Math.min(100_000_000, Math.round(Number(item.priceIqd) || 0)));
        const nextName = item.name ? sanitizeText(item.name, 80) : null;
        const nextDays =
          item.durationDays !== undefined
            ? Math.max(1, Math.min(1095, Math.floor(Number(item.durationDays) || 30)))
            : null;
        const nextActive = item.isActive === undefined ? null : item.isActive ? 1 : 0;

        updateStmt.run(nextName, price, nextDays, nextActive, now, planId);
        changes.push(`${nextName || String(existing.name)}: ${price} د.ع`);
      }
    });
    tx();
  }

  if (params.paymentMethods) {
    const zc = sanitizeText(params.paymentMethods.zaincashNumber, 40);
    const mc = sanitizeText(params.paymentMethods.mastercardNumber, 40);
    if (zc) {
      setPlatformSetting('payment_zaincash_number', zc);
      changes.push(`زين كاش: ${zc}`);
    }
    if (mc) {
      setPlatformSetting('payment_mastercard_number', mc);
      changes.push(`ماستر كارد: ${mc}`);
    }
  }

  if (changes.length > 0) {
    logAdminAction({
      admin: params.admin,
      actionType: 'subscription_plans_updated',
      targetType: 'subscription_plans',
      targetId: 'plans',
      targetLabel: 'أسعار باقات الاشتراك ووسائل الدفع',
      details: changes.join(' | '),
    });
  }

  return {
    plans: getSubscriptionPlans(),
    paymentMethods: getPaymentMethodsConfig(),
  };
}

// =========================================================================
// SUBSCRIPTION PAYMENT PROOF REQUESTS (MANUAL ADMIN APPROVAL ONLY)
// =========================================================================
function mapPaymentRequest(row: Record<string, unknown>): SubscriptionPaymentRequest {
  return {
    id: String(row.id),
    subscriptionId: String(row.subscription_id),
    userId: String(row.user_id),
    userName: row.user_name ? String(row.user_name) : undefined,
    userEmail: row.user_email ? String(row.user_email) : undefined,
    userPhone: row.user_phone ? String(row.user_phone) : undefined,
    subscriberType: row.subscriber_type as SubscriberType,
    storeId: row.store_id ? String(row.store_id) : null,
    storeName: row.store_name ? String(row.store_name) : undefined,
    storeType: row.store_type ? (row.store_type as StoreType) : undefined,
    planId: String(row.plan_id),
    planCode: String(row.plan_code),
    planName: String(row.plan_name),
    durationDays: Number(row.duration_days),
    amountIqd: Number(row.amount_iqd),
    paymentMethod: row.payment_method as PaymentMethodCode,
    transferReference: String(row.transfer_reference || ''),
    transferDetails: String(row.transfer_details || ''),
    paymentProofDoc: String(row.payment_proof_doc),
    status: row.status as SubscriptionPaymentRequestStatus,
    rejectionReason: String(row.rejection_reason || ''),
    adminNotes: String(row.admin_notes || ''),
    reviewedById: row.reviewed_by_id ? String(row.reviewed_by_id) : null,
    reviewedByName: String(row.reviewed_by_name || ''),
    reviewedAt: String(row.reviewed_at || ''),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function getUserPaymentRequests(userId: string): SubscriptionPaymentRequest[] {
  const rows = db
    .prepare(
      `SELECT r.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone,
              s.name AS store_name, s.store_type AS store_type
       FROM subscription_payment_requests r
       JOIN users u ON u.id = r.user_id
       LEFT JOIN stores s ON s.owner_id = r.user_id
       WHERE r.user_id = ?
       ORDER BY r.created_at DESC
       LIMIT 30`
    )
    .all(userId) as Record<string, unknown>[];
  return rows.map(mapPaymentRequest);
}

export function getAllAdminPaymentRequests(limit = 150): SubscriptionPaymentRequest[] {
  const rows = db
    .prepare(
      `SELECT r.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone,
              s.name AS store_name, s.store_type AS store_type
       FROM subscription_payment_requests r
       JOIN users u ON u.id = r.user_id
       LEFT JOIN stores s ON s.owner_id = r.user_id
       ORDER BY CASE WHEN r.status = 'pending' THEN 0 ELSE 1 END, r.created_at DESC
       LIMIT ?`
    )
    .all(Math.max(1, Math.min(300, limit))) as Record<string, unknown>[];
  return rows.map(mapPaymentRequest);
}

export function submitSubscriptionPaymentRequest(params: {
  user: User;
  planId: string;
  paymentMethod: PaymentMethodCode;
  transferReference: string;
  transferDetails: string;
  paymentProofFilename: string;
  currency: string;
}): { ok: true; request: SubscriptionPaymentRequest; subscription: UserSubscription } | { ok: false; status: number; error: string } {
  if (params.user.role !== 'merchant' && params.user.role !== 'courier') {
    return {
      ok: false,
      status: 403,
      error: 'نظام الاشتراكات خاص بأصحاب المتاجر والمندوبين فقط. حساب الزبون مجاني بالكامل.',
    };
  }

  const planRow = db
    .prepare('SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1')
    .get(params.planId) as Record<string, unknown> | undefined;
  if (!planRow) {
    return { ok: false, status: 400, error: 'الباقة المختارة غير متاحة حالياً.' };
  }

  const sub = evaluateUserSubscription(params.user.id);
  if (!sub) {
    return { ok: false, status: 404, error: 'تعذر العثور على سجل الاشتراك.' };
  }

  const plan = mapPlan(planRow);
  const now = new Date().toISOString();
  const id = generateId('payreq');
  const transferRef = sanitizeText(params.transferReference, 120);
  const transferDetails = sanitizeText(params.transferDetails, 500);

  db.prepare(
    `INSERT INTO subscription_payment_requests
      (id, subscription_id, user_id, subscriber_type, store_id, plan_id, plan_code, plan_name, duration_days, amount_iqd, payment_method, transfer_reference, transfer_details, payment_proof_doc, status, rejection_reason, admin_notes, reviewed_by_id, reviewed_by_name, reviewed_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', '', '', NULL, '', '', ?, ?)`
  ).run(
    id,
    sub.id,
    params.user.id,
    params.user.role,
    sub.storeId,
    plan.id,
    plan.code,
    plan.name,
    plan.durationDays,
    plan.priceIqd,
    params.paymentMethod,
    transferRef,
    transferDetails,
    params.paymentProofFilename,
    now,
    now
  );

  const summaryNote = `${plan.name} (${formatAmountArabic(plan.priceIqd, params.currency)}) عبر ${
    PAYMENT_METHOD_LABELS[params.paymentMethod]
  }${transferRef ? ` · رقم العملية: ${transferRef}` : ''}`;

  // Mark renewal requested (NEVER activate subscription automatically!)
  db.prepare(
    `UPDATE user_subscriptions
     SET renewal_requested = 1, renewal_note = ?, renewal_requested_at = ?, updated_at = ?
     WHERE id = ?`
  ).run(summaryNote, now, now, sub.id);

  logSubscriptionAction({
    subscriptionId: sub.id,
    userId: params.user.id,
    actionType: 'renewal_requested',
    amountPaid: 0,
    durationDays: 0,
    previousStatus: sub.status,
    newStatus: sub.status,
    previousExpiresAt: sub.expiresAt,
    newExpiresAt: sub.expiresAt,
    actorId: params.user.id,
    actorName: params.user.fullName,
    actorRole: params.user.role,
    notes: `تم إرسال إثبات تحويل (${summaryNote}) وبانتظار مراجعة المدير الرئيسي`,
  });

  // Notify all active Super Admins
  const admins = db
    .prepare("SELECT id FROM users WHERE role = 'super_admin' AND is_active = 1")
    .all() as Array<{ id: string }>;
  const roleAr = params.user.role === 'merchant' ? 'صاحب متجر' : 'مندوب توصيل';
  for (const adm of admins) {
    createAndDispatchNotification({
      userId: adm.id,
      storeId: sub.storeId,
      orderId: null,
      type: 'subscription_alert',
      title: `طلب اشتراك جديد مع إثبات تحويل — ${sub.storeName || params.user.fullName}`,
      body: `${roleAr}: ${params.user.fullName} · ${summaryNote}`,
      targetView: 'admin',
    });
  }

  const createdRow = db
    .prepare(
      `SELECT r.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone,
              s.name AS store_name, s.store_type AS store_type
       FROM subscription_payment_requests r
       JOIN users u ON u.id = r.user_id
       LEFT JOIN stores s ON s.owner_id = r.user_id
       WHERE r.id = ?`
    )
    .get(id) as Record<string, unknown>;

  return {
    ok: true,
    request: mapPaymentRequest(createdRow),
    subscription: evaluateUserSubscription(params.user.id, { includeLogs: true })!,
  };
}

export function reviewSubscriptionPaymentRequest(params: {
  admin: Pick<User, 'id' | 'fullName' | 'role'>;
  requestId: string;
  decision: 'approve' | 'reject';
  rejectionReason?: string;
  adminNotes?: string;
  startsAt?: string;
  expiresAt?: string;
  currency: string;
}):
  | { ok: true; request: SubscriptionPaymentRequest; subscription: UserSubscription }
  | { ok: false; status: number; error: string } {
  const row = db
    .prepare(
      `SELECT r.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone,
              s.name AS store_name, s.store_type AS store_type
       FROM subscription_payment_requests r
       JOIN users u ON u.id = r.user_id
       LEFT JOIN stores s ON s.owner_id = r.user_id
       WHERE r.id = ?`
    )
    .get(params.requestId) as Record<string, unknown> | undefined;

  if (!row) {
    return { ok: false, status: 404, error: 'طلب الاشتراك غير موجود.' };
  }
  const existingReq = mapPaymentRequest(row);
  if (existingReq.status !== 'pending') {
    return { ok: false, status: 409, error: 'تمت مراجعة هذا الطلب مسبقاً ولا يمكن تغييره.' };
  }

  const rejectionReason = sanitizeText(params.rejectionReason || '', 400);
  const adminNotes = sanitizeText(params.adminNotes || '', 400);
  if (params.decision === 'reject' && rejectionReason.length < 3) {
    return { ok: false, status: 400, error: 'يرجى كتابة سبب واضح لرفض طلب الاشتراك.' };
  }

  const sub = evaluateUserSubscription(existingReq.userId);
  if (!sub) {
    return { ok: false, status: 404, error: 'تعذر العثور على سجل اشتراك المستخدم.' };
  }

  const nowDate = new Date();
  const now = nowDate.toISOString();

  if (params.decision === 'approve') {
    const currentExpMs = sub.expiresAt ? new Date(sub.expiresAt).getTime() : 0;
    const isStillRunning =
      (sub.status === 'active' || sub.status === 'trial') && currentExpMs > nowDate.getTime();
    const baseDate = isStillRunning ? new Date(currentExpMs) : nowDate;
    let nextStartsAt = isStillRunning ? sub.startsAt || now : now;
    let nextExpiresAt = addDaysIso(baseDate, existingReq.durationDays);

    if (params.startsAt && params.startsAt.trim()) {
      const parsedStart = new Date(params.startsAt.trim());
      if (Number.isNaN(parsedStart.getTime())) {
        return { ok: false, status: 400, error: 'تاريخ بداية الاشتراك غير صالح.' };
      }
      nextStartsAt = parsedStart.toISOString();
    }
    if (params.expiresAt && params.expiresAt.trim()) {
      const parsedEnd = new Date(params.expiresAt.trim());
      if (Number.isNaN(parsedEnd.getTime())) {
        return { ok: false, status: 400, error: 'تاريخ انتهاء الاشتراك غير صالح.' };
      }
      nextExpiresAt = parsedEnd.toISOString();
    }
    if (new Date(nextExpiresAt).getTime() <= new Date(nextStartsAt).getTime()) {
      return {
        ok: false,
        status: 400,
        error: 'يجب أن يكون تاريخ انتهاء الاشتراك بعد تاريخ البداية.',
      };
    }

    const effectiveDurationDays = Math.max(
      1,
      Math.round((new Date(nextExpiresAt).getTime() - new Date(nextStartsAt).getTime()) / DAY_MS)
    );
    const startLabel = nextStartsAt.slice(0, 10);
    const endLabel = nextExpiresAt.slice(0, 10);
    const nextTotalPaid = Math.round((sub.totalPaid + existingReq.amountIqd) * 100) / 100;

    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE subscription_payment_requests
         SET status = 'approved', admin_notes = ?, reviewed_by_id = ?, reviewed_by_name = ?, reviewed_at = ?, updated_at = ?
         WHERE id = ?`
      ).run(adminNotes, params.admin.id, params.admin.fullName, now, now, existingReq.id);

      db.prepare(
        `UPDATE user_subscriptions
         SET plan_name = ?,
             status = 'active',
             starts_at = ?,
             expires_at = ?,
             monthly_fee = ?,
             total_paid = ?,
             renewal_requested = 0,
             renewal_note = '',
             expiring_notified_at = '',
             expired_notified_at = '',
             notes = CASE WHEN ? != '' THEN ? ELSE notes END,
             updated_at = ?
         WHERE id = ?`
      ).run(
        existingReq.planCode,
        nextStartsAt,
        nextExpiresAt,
        existingReq.amountIqd,
        nextTotalPaid,
        adminNotes,
        adminNotes,
        now,
        sub.id
      );

      logSubscriptionAction({
        subscriptionId: sub.id,
        userId: existingReq.userId,
        actionType: 'payment_approved',
        amountPaid: existingReq.amountIqd,
        durationDays: effectiveDurationDays,
        previousStatus: sub.status,
        newStatus: 'active',
        previousExpiresAt: sub.expiresAt,
        newExpiresAt: nextExpiresAt,
        actorId: params.admin.id,
        actorName: params.admin.fullName,
        actorRole: params.admin.role,
        notes: `قبول طلب الاشتراك (${existingReq.planName}) عبر ${
          PAYMENT_METHOD_LABELS[existingReq.paymentMethod]
        } · الفترة: ${startLabel} إلى ${endLabel}${
          existingReq.transferReference ? ` · رقم العملية: ${existingReq.transferReference}` : ''
        }${adminNotes ? ` · ${adminNotes}` : ''}`,
      });

      syncLegacyStoreSubscription(
        sub.storeId,
        'active',
        existingReq.amountIqd,
        nextExpiresAt,
        adminNotes || existingReq.planName
      );
    });
    tx();

    logAdminAction({
      admin: params.admin,
      actionType: 'subscription_payment_approved',
      targetType: existingReq.subscriberType,
      targetId: existingReq.userId,
      targetLabel: existingReq.storeName
        ? `${existingReq.storeName} (${existingReq.userName || existingReq.userId})`
        : existingReq.userName || existingReq.userId,
      details: `قبول طلب ${existingReq.id} | الباقة: ${existingReq.planName} (${startLabel} → ${endLabel}) | المبلغ: ${existingReq.amountIqd} د.ع`,
    });

    createAndDispatchNotification({
      userId: existingReq.userId,
      storeId: sub.storeId,
      orderId: null,
      type: 'subscription_alert',
      title: 'تمت الموافقة على اشتراكك وتفعيله بنجاح',
      body: `تم قبول إثبات التحويل لباقة ${existingReq.planName} (${formatAmountArabic(
        existingReq.amountIqd,
        params.currency
      )}) وتفعيل اشتراكك من ${startLabel} حتى ${endLabel}.`,
      targetView: 'subscription',
    });
  } else {
    const tx = db.transaction(() => {
      db.prepare(
        `UPDATE subscription_payment_requests
         SET status = 'rejected', rejection_reason = ?, admin_notes = ?, reviewed_by_id = ?, reviewed_by_name = ?, reviewed_at = ?, updated_at = ?
         WHERE id = ?`
      ).run(
        rejectionReason,
        adminNotes,
        params.admin.id,
        params.admin.fullName,
        now,
        now,
        existingReq.id
      );

      const otherPending = db
        .prepare(
          "SELECT COUNT(*) AS cnt FROM subscription_payment_requests WHERE user_id = ? AND status = 'pending'"
        )
        .get(existingReq.userId) as { cnt: number };

      if (Number(otherPending.cnt || 0) === 0) {
        db.prepare(
          `UPDATE user_subscriptions
           SET renewal_requested = 0, renewal_note = '', updated_at = ?
           WHERE id = ?`
        ).run(now, sub.id);
      }

      logSubscriptionAction({
        subscriptionId: sub.id,
        userId: existingReq.userId,
        actionType: 'payment_rejected',
        amountPaid: 0,
        durationDays: 0,
        previousStatus: sub.status,
        newStatus: sub.status,
        previousExpiresAt: sub.expiresAt,
        newExpiresAt: sub.expiresAt,
        actorId: params.admin.id,
        actorName: params.admin.fullName,
        actorRole: params.admin.role,
        notes: `رفض طلب الاشتراك (${existingReq.planName}) — السبب: ${rejectionReason}`,
      });
    });
    tx();

    logAdminAction({
      admin: params.admin,
      actionType: 'subscription_payment_rejected',
      targetType: existingReq.subscriberType,
      targetId: existingReq.userId,
      targetLabel: existingReq.storeName
        ? `${existingReq.storeName} (${existingReq.userName || existingReq.userId})`
        : existingReq.userName || existingReq.userId,
      details: `رفض طلب ${existingReq.id} | السبب: ${rejectionReason}`,
    });

    createAndDispatchNotification({
      userId: existingReq.userId,
      storeId: sub.storeId,
      orderId: null,
      type: 'subscription_alert',
      title: 'تم رفض طلب الاشتراك',
      body: `عذراً، تم رفض طلب اشتراكك (${existingReq.planName}). السبب: ${rejectionReason}. يمكنك إعادة رفع إثبات تحويل واضح من صفحة الاشتراك.`,
      targetView: 'subscription',
    });
  }

  const updatedRow = db
    .prepare(
      `SELECT r.*, u.full_name AS user_name, u.email AS user_email, u.phone AS user_phone,
              s.name AS store_name, s.store_type AS store_type
       FROM subscription_payment_requests r
       JOIN users u ON u.id = r.user_id
       LEFT JOIN stores s ON s.owner_id = r.user_id
       WHERE r.id = ?`
    )
    .get(existingReq.id) as Record<string, unknown>;

  return {
    ok: true,
    request: mapPaymentRequest(updatedRow),
    subscription: evaluateUserSubscription(existingReq.userId, { includeLogs: true })!,
  };
}

export function sendExpiringSubscriptionReminders(params: {
  admin: Pick<User, 'id' | 'fullName' | 'role'>;
  targetUserId?: string;
}): { notifiedCount: number } {
  const all = getAllAdminSubscriptions();
  const targets = params.targetUserId
    ? all.filter((s) => s.userId === params.targetUserId)
    : all.filter((s) => s.isExpiringSoon || s.status === 'expired');

  const now = new Date().toISOString();
  let notifiedCount = 0;

  for (const sub of targets) {
    const title =
      sub.status === 'expired'
        ? 'تذكير من الإدارة: اشتراكك منتهٍ — جدّد الآن'
        : `تذكير من الإدارة: اشتراكك ينتهي خلال ${sub.daysRemaining} ${
            sub.daysRemaining === 1 ? 'يوم' : 'أيام'
          }`;
    const body =
      sub.status === 'expired'
        ? 'بياناتك محفوظة بالكامل. يرجى اختيار باقة الاشتراك ورفع إثبات التحويل لإعادة تفعيل الميزات التجارية فوراً.'
        : 'يرجى تجديد اشتراكك قبل انتهاء المدة لضمان استمرار ظهور متجرك وعملك على منصة سوقنا دون توقف.';

    createAndDispatchNotification({
      userId: sub.userId,
      storeId: sub.storeId,
      orderId: null,
      type: 'subscription_alert',
      title,
      body,
      targetView: 'subscription',
    });

    db.prepare('UPDATE user_subscriptions SET expiring_notified_at = ?, updated_at = ? WHERE id = ?').run(
      now,
      now,
      sub.id
    );

    logSubscriptionAction({
      subscriptionId: sub.id,
      userId: sub.userId,
      actionType: 'reminder_sent',
      previousStatus: sub.status,
      newStatus: sub.status,
      previousExpiresAt: sub.expiresAt,
      newExpiresAt: sub.expiresAt,
      actorId: params.admin.id,
      actorName: params.admin.fullName,
      actorRole: params.admin.role,
      notes: 'إرسال إشعار تذكير بتجديد الاشتراك من قِبل المدير الرئيسي',
    });

    notifiedCount++;
  }

  if (notifiedCount > 0) {
    logAdminAction({
      admin: params.admin,
      actionType: 'subscription_reminders_sent',
      targetType: 'subscription',
      targetId: params.targetUserId || 'bulk_expiring',
      targetLabel: params.targetUserId ? targets[0]?.userName || params.targetUserId : 'الحسابات القريبة من الانتهاء والمنتهية',
      details: `تم إرسال ${notifiedCount} إشعار تذكير بتجديد الاشتراك`,
    });
  }

  return { notifiedCount };
}
