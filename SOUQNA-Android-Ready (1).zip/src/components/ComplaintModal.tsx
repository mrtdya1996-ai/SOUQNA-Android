import React, { useState } from 'react';
import { AlertTriangle, Send, X } from 'lucide-react';
import { api } from '../lib/api';
import { useApp } from '../context/AppContext';
import { COMPLAINT_CATEGORIES, type ComplaintTargetType } from '../types';

interface ComplaintModalProps {
  targetType: ComplaintTargetType;
  targetId: string;
  targetName: string;
  orderId?: string | null;
  deliveryId?: string | null;
  onClose: () => void;
  onSubmitted?: () => void;
}

export const ComplaintModal: React.FC<ComplaintModalProps> = ({
  targetType,
  targetId,
  targetName,
  orderId,
  deliveryId,
  onClose,
  onSubmitted,
}) => {
  const { notify } = useApp();
  const [category, setCategory] = useState(COMPLAINT_CATEGORIES[0]);
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (description.trim().length < 5) {
      notify('يرجى كتابة تفاصيل الشكوى بوضوح (5 أحرف على الأقل).', 'error');
      return;
    }
    setSubmitting(true);
    try {
      await api.submitComplaint({
        targetType,
        targetId,
        targetName,
        orderId: orderId ?? null,
        deliveryId: deliveryId ?? null,
        category,
        description: description.trim(),
      });
      notify('تم إرسال الشكوى إلى المدير العام للمراجعة والمتابعة.', 'success');
      onSubmitted?.();
      onClose();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال الشكوى.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="تقديم شكوى للإدارة"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-sq-border bg-sq-surface p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-sq-border pb-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-sq-danger-text" />
            <div>
              <h3 className="font-display text-base font-bold text-sq-ink">
                تقديم شكوى للمدير العام
              </h3>
              <p className="text-xs text-sq-ink-muted">الجهة المعنية: {targetName}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-border text-sq-ink-muted hover:bg-sq-muted"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
              تصنيف الشكوى
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
            >
              {COMPLAINT_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
              تفاصيل الشكوى أو المخالفة *
            </label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="اشرح ما حدث بدقة ليتمكن المدير العام من المراجعة واتخاذ الإجراء المناسب..."
              className="w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 py-2.5 text-sm text-sq-ink outline-none focus:border-sq-gold focus:bg-sq-surface"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[42px] rounded-xl border border-sq-border bg-sq-surface px-4 py-2 text-xs font-semibold text-sq-ink-muted hover:bg-sq-elevated"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-[#B42318] px-4 py-2 text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
            >
              <Send className="h-3.5 w-3.5" />
              <span>{submitting ? 'جاري الإرسال...' : 'إرسال الشكوى'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
