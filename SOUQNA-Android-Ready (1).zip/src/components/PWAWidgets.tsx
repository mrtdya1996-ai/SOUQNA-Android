import React, { useState } from 'react';
import { Download, Smartphone, WifiOff, X } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ variant?: 'compact' | 'full' }> = ({
  variant = 'full',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return variant === 'full' ? (
      <div className="flex items-center justify-between gap-3 rounded-xl border border-sq-border bg-sq-muted px-4 py-3 text-sm text-sq-ink">
        <div className="flex items-center gap-2.5">
          <Smartphone className="h-4 w-4 text-sq-gold-text" />
          <span>التطبيق مثبّت ويعمل بوضع الهاتف المستقل.</span>
        </div>
      </div>
    ) : null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className={
          variant === 'compact'
            ? 'inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink transition-colors hover:bg-sq-muted whitespace-nowrap shrink-0'
            : 'inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl btn-gold px-5 py-3 text-sm font-semibold transition-colors '
        }
      >
        <Download className="h-4 w-4" />
        <span>تثبيت تطبيق سوقنا على الهاتف</span>
      </button>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setShowGuide(true)}
        className={
          variant === 'compact'
            ? 'inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink transition-colors hover:bg-sq-muted whitespace-nowrap shrink-0'
            : 'inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl border border-sq-border bg-sq-surface px-5 py-3 text-sm font-semibold text-sq-ink transition-colors hover:bg-sq-muted'
        }
      >
        <Smartphone className="h-4 w-4 text-sq-gold-text" />
        <span>{isIOS ? 'تثبيت على iPhone / iPad' : 'طريقة التثبيت على الهاتف (PWA / APK)'}</span>
      </button>

      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-2xl bg-sq-surface p-6 shadow-xl">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-sq-ink">
                تثبيت SOUQNA | سوقنا على الهاتف
              </h3>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="إغلاق"
                className="flex h-10 w-10 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {isIOS ? (
              <ol className="space-y-2.5 text-sm leading-relaxed text-sq-ink-muted">
                <li>1. اضغط على زر المشاركة في أسفل متصفح Safari.</li>
                <li>2. مرر للأسفل واختر «إضافة إلى الشاشة الرئيسية».</li>
                <li>3. اضغط «إضافة» ليعمل تطبيق سوقنا كتطبيق هاتف مستقل.</li>
              </ol>
            ) : (
              <div className="space-y-3 text-sm leading-relaxed text-sq-ink-muted">
                <p>
                  التطبيق مجهّز بالكامل كـ Progressive Web App مع ملف{' '}
                  <span className="font-mono text-xs text-sq-ink">capacitor.config.json</span>{' '}
                  للتحويل المباشر إلى حزمة Android APK.
                </p>
                <p>
                  للتثبيت المباشر على هاتف أندرويد: افتح قائمة المتصفح (⋮) واختر «تثبيت التطبيق» أو
                  «إضافة إلى الشاشة الرئيسية».
                </p>
              </div>
            )}
            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-5 min-h-[44px] w-full rounded-xl btn-gold py-2.5 text-sm font-semibold"
            >
              فهمت
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 md:bottom-4 right-4 z-50 flex items-center gap-2 rounded-xl bg-[#111312] border border-[#D4AF37]/30 px-4 py-2.5 text-xs font-medium text-white shadow-lg"
    >
      <WifiOff className="h-4 w-4 text-[#D9BD92]" />
      <span>لا يوجد اتصال بالإنترنت — يتم عرض النسخة المخزنة مؤقتاً</span>
    </div>
  );
};
