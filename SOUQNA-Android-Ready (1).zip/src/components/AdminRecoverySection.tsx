import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Copy,
  KeyRound,
  Link2,
  Loader2,
  Mail,
  Phone,
  Search,
  ShieldCheck,
  UserCheck,
  XCircle,
} from 'lucide-react';
import { formatDateAr, getConfiguredApiBaseUrl } from '../lib/api';
import {
  RECOVERY_STATUS_LABELS,
  ROLE_LABELS,
  type AccountRecoveryRequest,
  type AccountRecoveryStatus,
  type IssuedPasswordReset,
  type User,
} from '../types';

interface AdminRecoverySectionProps {
  requests: AccountRecoveryRequest[];
  users: User[];
  onReview: (
    requestId: string,
    payload: {
      decision: 'approve' | 'reject';
      targetUserId?: string;
      rejectionReason?: string;
      adminNotes?: string;
    }
  ) => Promise<IssuedPasswordReset | undefined>;
  onIssueDirectReset: (userId: string, notes?: string) => Promise<IssuedPasswordReset | undefined>;
}

const ACCOUNT_TYPE_LABELS: Record<string, string> = {
  customer: 'زبون',
  merchant: 'صاحب متجر / سوق / مول',
  courier: 'مندوب توصيل',
  super_admin: 'مدير',
  other: 'حساب آخر',
};

export const AdminRecoverySection: React.FC<AdminRecoverySectionProps> = ({
  requests,
  users,
  onReview,
  onIssueDirectReset,
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | AccountRecoveryStatus>('all');
  const [search, setSearch] = useState('');
  const [selectedUserMap, setSelectedUserMap] = useState<Record<string, string>>({});
  const [adminNoteMap, setAdminNoteMap] = useState<Record<string, string>>({});
  const [rejectReasonMap, setRejectReasonMap] = useState<Record<string, string>>({});
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  // Issued one-time reset banner (shown once to Admin so they can copy & send)
  const [latestIssued, setLatestIssued] = useState<IssuedPasswordReset | null>(null);
  const [copiedKey, setCopiedKey] = useState<'code' | 'link' | null>(null);

  // Direct reset tool for verified users
  const [showDirectTool, setShowDirectTool] = useState(false);
  const [directUserSearch, setDirectUserSearch] = useState('');
  const [directUserId, setDirectUserId] = useState('');
  const [directNotes, setDirectNotes] = useState('');
  const [issuingDirect, setIssuingDirect] = useState(false);

  const nonAdminUsers = useMemo(
    () => users.filter((u) => u.role !== 'super_admin'),
    [users]
  );

  const filteredDirectUsers = useMemo(() => {
    const q = directUserSearch.trim().toLowerCase();
    if (!q) return nonAdminUsers.slice(0, 50);
    return nonAdminUsers
      .filter(
        (u) =>
          u.fullName.toLowerCase().includes(q) ||
          u.phone.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q)
      )
      .slice(0, 50);
  }, [nonAdminUsers, directUserSearch]);

  const filteredRequests = useMemo(() => {
    const q = search.trim().toLowerCase();
    return requests.filter((req) => {
      if (statusFilter !== 'all' && req.status !== statusFilter) return false;
      if (!q) return true;
      return (
        req.requesterName.toLowerCase().includes(q) ||
        req.requesterPhone.toLowerCase().includes(q) ||
        (req.requesterEmail || '').toLowerCase().includes(q) ||
        (req.matchedUserName || '').toLowerCase().includes(q) ||
        (req.matchedUserEmail || '').toLowerCase().includes(q) ||
        req.proofDetails.toLowerCase().includes(q)
      );
    });
  }, [requests, statusFilter, search]);

  const pendingCount = useMemo(
    () => requests.filter((r) => r.status === 'pending').length,
    [requests]
  );

  const handleCopy = async (text: string, key: 'code' | 'link') => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey((prev) => (prev === key ? null : prev)), 2200);
    } catch {
      // Fallback ignored silently
    }
  };

  const handleApprove = async (req: AccountRecoveryRequest) => {
    const targetUserId = selectedUserMap[req.id] ?? req.matchedUserId ?? '';
    if (!targetUserId) {
      return;
    }
    setBusyId(req.id);
    try {
      const issued = await onReview(req.id, {
        decision: 'approve',
        targetUserId,
        adminNotes: (adminNoteMap[req.id] || '').trim() || undefined,
      });
      if (issued) {
        setLatestIssued(issued);
      }
      setRejectingId(null);
    } finally {
      setBusyId(null);
    }
  };

  const handleReject = async (req: AccountRecoveryRequest) => {
    const reason = (rejectReasonMap[req.id] || '').trim();
    if (reason.length < 3) return;
    setBusyId(req.id);
    try {
      await onReview(req.id, {
        decision: 'reject',
        rejectionReason: reason,
        adminNotes: (adminNoteMap[req.id] || '').trim() || undefined,
      });
      setRejectingId(null);
      setRejectReasonMap((prev) => ({ ...prev, [req.id]: '' }));
    } finally {
      setBusyId(null);
    }
  };

  const handleDirectIssue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!directUserId) return;
    setIssuingDirect(true);
    try {
      const issued = await onIssueDirectReset(directUserId, directNotes.trim() || undefined);
      if (issued) {
        setLatestIssued(issued);
        setDirectNotes('');
        setShowDirectTool(false);
      }
    } finally {
      setIssuingDirect(false);
    }
  };

  const resetBaseOrigin =
    getConfiguredApiBaseUrl() || (typeof window !== 'undefined' ? window.location.origin : '');
  const fullResetUrl = latestIssued ? `${resetBaseOrigin}${latestIssued.resetPath}` : '';

  return (
    <div className="space-y-5">
      {/* Security Principle Banner */}
      <div className="rounded-2xl border border-sq-gold/35 bg-sq-gold-soft/40 p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-sq-gold/40 bg-sq-surface text-sq-gold-text">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div className="space-y-0.5 text-xs">
            <p className="font-display text-sm font-bold text-sq-ink">
              إدارة استعادة الحسابات وإعادة تعيين كلمة المرور الآمنة
            </p>
            <p className="text-sq-ink-muted leading-relaxed">
              تُحفظ كلمات المرور مشفّرة بالكامل ولا يمكن عرض كلمة المرور القديمة لأي طرف. بعد التحقق من هوية صاحب الحساب، يصدر النظام رابطاً مؤقتاً ورمزاً للاستخدام لمرة واحدة صالحاً لمدة ساعتين فقط.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowDirectTool((prev) => !prev)}
          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold shrink-0"
        >
          <KeyRound className="h-4 w-4" />
          <span>{showDirectTool ? 'إغلاق الإصدار المباشر' : 'إصدار رمز استعادة مباشر لحساب'}</span>
        </button>
      </div>

      {/* Latest Issued One-Time Reset Token & Code Box */}
      {latestIssued && (
        <div className="rounded-2xl border-2 border-sq-gold bg-sq-surface p-5 space-y-4 shadow-lg">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="h-6 w-6 text-sq-gold-text shrink-0" />
              <div>
                <h3 className="font-display text-base font-extrabold text-sq-ink">
                  تم إصدار رابط ورمز إعادة تعيين لمرة واحدة بنجاح
                </h3>
                <p className="text-xs text-sq-ink-muted">
                  للحساب: <strong className="text-sq-ink">{latestIssued.userName}</strong> (
                  <span dir="ltr" className="font-mono">
                    {latestIssued.userPhone}
                  </span>{' '}
                  · {latestIssued.userEmail}) — صالح حتى {formatDateAr(latestIssued.expiresAt)}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setLatestIssued(null)}
              className="rounded-lg border border-sq-border px-2.5 py-1 text-xs font-semibold text-sq-ink-muted hover:text-sq-ink"
            >
              إغلاق
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {/* Temporary One-Time Code */}
            <div className="rounded-xl border border-sq-gold/40 bg-sq-elevated p-3.5 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[11px] font-bold text-sq-gold-text">
                  الرمز المؤقت (للاستخدام لمرة واحدة)
                </span>
                <button
                  type="button"
                  onClick={() => void handleCopy(latestIssued.tempCode, 'code')}
                  className="inline-flex items-center gap-1 rounded-lg bg-sq-gold px-2.5 py-1 text-[11px] font-bold text-[#0B0C0C]"
                >
                  {copiedKey === 'code' ? (
                    <>
                      <Check className="h-3 w-3" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3" />
                      <span>نسخ الرمز</span>
                    </>
                  )}
                </button>
              </div>
              <p
                dir="ltr"
                className="font-mono text-lg font-extrabold tracking-widest text-sq-ink select-all"
              >
                {latestIssued.tempCode}
              </p>
            </div>

            {/* One-Time Reset Link */}
            <div className="rounded-xl border border-sq-border bg-sq-elevated p-3.5 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-sq-ink">
                  <Link2 className="h-3.5 w-3.5 text-sq-gold-text" />
                  <span>رابط إعادة التعيين المباشر</span>
                </span>
                <button
                  type="button"
                  onClick={() => void handleCopy(fullResetUrl, 'link')}
                  className="inline-flex items-center gap-1 rounded-lg border border-sq-gold/40 bg-sq-gold-soft px-2.5 py-1 text-[11px] font-bold text-sq-gold-text"
                >
                  {copiedKey === 'link' ? (
                    <>
                      <Check className="h-3 w-3" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3" />
                      <span>نسخ الرابط</span>
                    </>
                  )}
                </button>
              </div>
              <p
                dir="ltr"
                className="truncate font-mono text-xs text-sq-ink-muted select-all"
                title={fullResetUrl}
              >
                {fullResetUrl}
              </p>
            </div>
          </div>

          <p className="text-[11px] text-sq-warning-text flex items-center gap-1.5">
            <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
            <span>
              يظهر هذا الرمز والرابط مرة واحدة فقط لأمان الحساب (يُحفظ مشفّراً بـ SHA-256). أرسله لصاحب الحساب بعد التأكد من هويته، وعند استخدامه تُلغى جميع الجلسات القديمة تلقائياً.
            </span>
          </p>
        </div>
      )}

      {/* Direct Issue Tool */}
      {showDirectTool && (
        <form
          onSubmit={handleDirectIssue}
          className="rounded-2xl border border-sq-border bg-sq-surface p-5 space-y-3.5"
        >
          <h3 className="font-display text-sm font-extrabold text-sq-ink">
            إصدار رمز ورابط إعادة تعيين مباشر لحساب مستخدم موثّق
          </h3>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <div>
              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                بحث عن المستخدم (الاسم / الهاتف / البريد)
              </label>
              <input
                type="search"
                value={directUserSearch}
                onChange={(e) => setDirectUserSearch(e.target.value)}
                placeholder="اكتب للبحث..."
                className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                اختر الحساب المقصود *
              </label>
              <select
                value={directUserId}
                onChange={(e) => setDirectUserId(e.target.value)}
                required
                className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
              >
                <option value="">— اختر حساب المستخدم —</option>
                {filteredDirectUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.fullName} — {u.phone} ({ROLE_LABELS[u.role]})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                ملاحظة التحقق (تُسجّل في سجل التدقيق)
              </label>
              <input
                type="text"
                value={directNotes}
                onChange={(e) => setDirectNotes(e.target.value)}
                placeholder="مثال: تم التحقق هاتفياً من مالك المتجر"
                className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={issuingDirect || !directUserId}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-5 text-xs font-bold disabled:opacity-50"
            >
              {issuingDirect ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <KeyRound className="h-4 w-4" />
              )}
              <span>توليد رمز ورابط لمرة واحدة</span>
            </button>
          </div>
        </form>
      )}

      {/* Filters & Search */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {(
            [
              { key: 'all', label: `الكل (${requests.length})` },
              { key: 'pending', label: `بانتظار المراجعة (${pendingCount})` },
              {
                key: 'approved',
                label: `صدر لها رمز (${requests.filter((r) => r.status === 'approved').length})`,
              },
              {
                key: 'completed',
                label: `مكتملة (${requests.filter((r) => r.status === 'completed').length})`,
              },
              {
                key: 'rejected',
                label: `مرفوضة (${requests.filter((r) => r.status === 'rejected').length})`,
              },
            ] as const
          ).map((chip) => (
            <button
              key={chip.key}
              type="button"
              onClick={() => setStatusFilter(chip.key)}
              className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                statusFilter === chip.key
                  ? 'bg-sq-gold text-[#0B0C0C]'
                  : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم، الهاتف، البريد، التفاصيل..."
            className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface pr-10 pl-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
          />
        </div>
      </div>

      {/* Requests List */}
      {filteredRequests.length === 0 ? (
        <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
          لا توجد طلبات استعادة حساب مطابقة حالياً.
        </div>
      ) : (
        <div className="space-y-3.5">
          {filteredRequests.map((req) => {
            const selectedUserId = selectedUserMap[req.id] ?? req.matchedUserId ?? '';
            const isBusy = busyId === req.id;
            const isRejectOpen = rejectingId === req.id;

            return (
              <div
                key={req.id}
                className={`rounded-2xl border bg-sq-surface p-5 space-y-3.5 ${
                  req.status === 'pending'
                    ? 'border-sq-gold/50 shadow-sm'
                    : req.status === 'rejected'
                    ? 'border-sq-danger-border/60'
                    : 'border-sq-border'
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span
                        className={`rounded-lg border px-2.5 py-0.5 font-bold ${
                          req.status === 'pending'
                            ? 'border-sq-warning-border bg-sq-warning-bg text-sq-warning-text'
                            : req.status === 'approved'
                            ? 'border-sq-gold/40 bg-sq-gold-soft text-sq-gold-text'
                            : req.status === 'completed'
                            ? 'border-sq-success-border bg-sq-success-bg text-sq-success-text'
                            : 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
                        }`}
                      >
                        {RECOVERY_STATUS_LABELS[req.status]}
                      </span>
                      <span className="rounded-lg border border-sq-border bg-sq-elevated px-2 py-0.5 font-semibold text-sq-ink-muted">
                        {ACCOUNT_TYPE_LABELS[req.accountType] || req.accountType}
                      </span>
                      <span className="text-[11px] text-sq-ink-muted">
                        {formatDateAr(req.createdAt)}
                      </span>
                    </div>

                    <h3 className="font-display text-base font-extrabold text-sq-ink">
                      {req.requesterName}
                    </h3>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-sq-ink-muted">
                      <span className="inline-flex items-center gap-1" dir="ltr">
                        <Phone className="h-3.5 w-3.5 text-sq-gold-text" />
                        <span className="font-mono">{req.requesterPhone}</span>
                      </span>
                      {req.requesterEmail && (
                        <span className="inline-flex items-center gap-1">
                          <Mail className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>{req.requesterEmail}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {req.matchedUserId && (
                    <div className="rounded-xl border border-sq-gold/30 bg-sq-gold-soft/40 px-3 py-2 text-xs">
                      <div className="flex items-center gap-1.5 font-bold text-sq-gold-text">
                        <UserCheck className="h-3.5 w-3.5" />
                        <span>حساب مطابق تلقائياً</span>
                      </div>
                      <p className="mt-0.5 font-semibold text-sq-ink">
                        {req.matchedUserName}{' '}
                        {req.matchedUserRole ? `(${ROLE_LABELS[req.matchedUserRole]})` : ''}
                      </p>
                      <p className="text-[11px] text-sq-ink-muted">
                        {req.matchedUserEmail} ·{' '}
                        <span dir="ltr" className="font-mono">
                          {req.matchedUserPhone}
                        </span>
                      </p>
                    </div>
                  )}
                </div>

                {/* Proof Details */}
                <div className="rounded-xl border border-sq-border bg-sq-elevated p-3.5 text-xs space-y-1">
                  <p className="font-bold text-sq-ink">تفاصيل إثبات ملكية الحساب من المستخدم:</p>
                  <p className="text-sq-ink-muted whitespace-pre-line leading-relaxed">
                    {req.proofDetails}
                  </p>
                </div>

                {req.adminNotes && (
                  <p className="text-xs text-sq-ink-muted">
                    <strong className="text-sq-ink">ملاحظة الإدارة:</strong> {req.adminNotes}
                  </p>
                )}

                {req.status === 'rejected' && req.rejectionReason && (
                  <div className="rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 py-2.5 text-xs text-sq-danger-text">
                    <strong>سبب الرفض:</strong> {req.rejectionReason}
                  </div>
                )}

                {/* Pending / Re-issue Action Controls */}
                {(req.status === 'pending' || req.status === 'approved') && (
                  <div className="rounded-xl border border-sq-gold/25 bg-sq-elevated/70 p-4 space-y-3">
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                      <div>
                        <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                          تأكيد أو اختيار الحساب المطابق لإصدار رمز الاستعادة *
                        </label>
                        <select
                          value={selectedUserId}
                          onChange={(e) =>
                            setSelectedUserMap((prev) => ({ ...prev, [req.id]: e.target.value }))
                          }
                          className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                        >
                          <option value="">— اختر حساب المستخدم المطابق —</option>
                          {nonAdminUsers.map((u) => (
                            <option key={u.id} value={u.id}>
                              {u.fullName} — {u.phone} — {u.email} ({ROLE_LABELS[u.role]})
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                          ملاحظة إدارية (تُسجّل في سجل التدقيق)
                        </label>
                        <input
                          type="text"
                          value={adminNoteMap[req.id] || ''}
                          onChange={(e) =>
                            setAdminNoteMap((prev) => ({ ...prev, [req.id]: e.target.value }))
                          }
                          placeholder="مثال: تم التحقق من ملكية المتجر ورقم الهاتف"
                          className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        disabled={isBusy || !selectedUserId}
                        onClick={() => void handleApprove(req)}
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold disabled:opacity-50"
                      >
                        {isBusy ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <KeyRound className="h-3.5 w-3.5" />
                        )}
                        <span>
                          {req.status === 'approved'
                            ? 'إعادة إصدار رمز ورابط جديد (لمرة واحدة)'
                            : 'موافقة وإصدار رابط ورمز إعادة التعيين'}
                        </span>
                      </button>

                      {req.status === 'pending' && (
                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => setRejectingId(isRejectOpen ? null : req.id)}
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 text-xs font-bold text-sq-danger-text"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          <span>رفض الطلب</span>
                        </button>
                      )}
                    </div>

                    {isRejectOpen && (
                      <div className="flex flex-wrap items-center gap-2 border-t border-sq-border pt-3">
                        <input
                          type="text"
                          value={rejectReasonMap[req.id] || ''}
                          onChange={(e) =>
                            setRejectReasonMap((prev) => ({
                              ...prev,
                              [req.id]: e.target.value,
                            }))
                          }
                          placeholder="اكتب سبب الرفض بوضوح (مطلوب)..."
                          className="min-h-[40px] flex-1 min-w-[220px] rounded-xl border border-sq-danger-border bg-sq-surface px-3 text-xs text-sq-ink focus:outline-none"
                        />
                        <button
                          type="button"
                          disabled={isBusy || (rejectReasonMap[req.id] || '').trim().length < 3}
                          onClick={() => void handleReject(req)}
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-sq-danger px-4 text-xs font-bold text-white disabled:opacity-50"
                        >
                          <span>تأكيد الرفض</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
