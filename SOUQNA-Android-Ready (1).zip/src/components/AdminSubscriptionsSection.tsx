import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Banknote,
  BellRing,
  Bike,
  CalendarCog,
  CalendarPlus,
  CheckCircle2,
  Clock,
  CreditCard,
  Crown,
  FileCheck2,
  History,
  Loader2,
  PauseCircle,
  PlayCircle,
  Save,
  Search,
  Settings2,
  Store as StoreIcon,
  XCircle,
} from 'lucide-react';
import { formatDateAr, formatPrice, normalizeArabicDigits } from '../lib/api';
import {
  DEFAULT_PAYMENT_METHODS,
  PAYMENT_METHOD_LABELS,
  PAYMENT_REQUEST_STATUS_LABELS,
  STORE_TYPE_LABELS,
  SUBSCRIPTION_ACTION_LABELS,
  SUBSCRIPTION_PLAN_LABELS,
  SUBSCRIPTION_STATUS_LABELS,
  type SubscriptionLog,
  type SubscriptionPaymentMethodsConfig,
  type SubscriptionPaymentRequest,
  type SubscriptionPaymentRequestStatus,
  type SubscriptionPlan,
  type SubscriptionSummaryStats,
  type UserSubscription,
} from '../types';
import { PrivatePaymentProofImage } from './PrivatePaymentProofImage';

type SubFilter =
  | 'all'
  | 'merchant'
  | 'courier'
  | 'active'
  | 'trial'
  | 'expiring_soon'
  | 'expired'
  | 'suspended'
  | 'renewal_requested';

type SubViewMode = 'requests' | 'subscribers' | 'plans' | 'ledger';

interface AdminSubscriptionsSectionProps {
  subscriptions: UserSubscription[];
  stats: SubscriptionSummaryStats | null;
  logs: SubscriptionLog[];
  plans: SubscriptionPlan[];
  paymentMethods: SubscriptionPaymentMethodsConfig;
  paymentRequests: SubscriptionPaymentRequest[];
  currency: string;
  onRunAction: (
    userId: string,
    payload: {
      action: 'activate' | 'extend' | 'suspend' | 'reactivate' | 'record_payment' | 'set_dates';
      durationDays?: number;
      amountPaid?: number;
      monthlyFee?: number;
      planName?: string;
      startsAt?: string;
      expiresAt?: string;
      notes?: string;
    }
  ) => Promise<void>;
  onReviewPaymentRequest: (
    requestId: string,
    payload: {
      decision: 'approve' | 'reject';
      rejectionReason?: string;
      adminNotes?: string;
      startsAt?: string;
      expiresAt?: string;
    }
  ) => Promise<void>;
  onUpdatePlans: (payload: {
    plans: Array<{
      id: string;
      name: string;
      priceIqd: number;
      durationDays: number;
      isActive: boolean;
    }>;
    paymentMethods: SubscriptionPaymentMethodsConfig;
  }) => Promise<void>;
  onNotifyExpiring: (userId?: string) => Promise<void>;
}

const PRESET_DAYS = [30, 60, 90, 180, 365];

function toDateInputValue(iso: string): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const AdminSubscriptionsSection: React.FC<AdminSubscriptionsSectionProps> = ({
  subscriptions,
  stats,
  logs,
  plans,
  paymentMethods,
  paymentRequests,
  currency,
  onRunAction,
  onReviewPaymentRequest,
  onUpdatePlans,
  onNotifyExpiring,
}) => {
  const pendingReqCount = useMemo(
    () => paymentRequests.filter((r) => r.status === 'pending').length,
    [paymentRequests]
  );

  const [viewMode, setViewMode] = useState<SubViewMode>(
    pendingReqCount > 0 ? 'requests' : 'subscribers'
  );
  const [filter, setFilter] = useState<SubFilter>('all');
  const [reqFilter, setReqFilter] = useState<'all' | SubscriptionPaymentRequestStatus>('all');
  const [search, setSearch] = useState('');
  const [expandedUserId, setExpandedUserId] = useState<string | null>(null);
  const [daysInput, setDaysInput] = useState<Record<string, string>>({});
  const [amountInput, setAmountInput] = useState<Record<string, string>>({});
  const [noteInput, setNoteInput] = useState<Record<string, string>>({});
  const [startsAtInput, setStartsAtInput] = useState<Record<string, string>>({});
  const [expiresAtInput, setExpiresAtInput] = useState<Record<string, string>>({});
  const [busyUserId, setBusyUserId] = useState<string | null>(null);
  const [sendingBulkReminder, setSendingBulkReminder] = useState(false);

  // Payment Request review states
  const [busyRequestId, setBusyRequestId] = useState<string | null>(null);
  const [rejectingRequestId, setRejectingRequestId] = useState<string | null>(null);
  const [reqRejectionReason, setReqRejectionReason] = useState<Record<string, string>>({});
  const [reqAdminNote, setReqAdminNote] = useState<Record<string, string>>({});
  const [reqStartsAt, setReqStartsAt] = useState<Record<string, string>>({});
  const [reqExpiresAt, setReqExpiresAt] = useState<Record<string, string>>({});

  type EditablePlanDraft = Omit<SubscriptionPlan, 'priceIqd' | 'durationDays'> & {
    priceIqd: string;
    durationDays: string;
  };
  const toPlanDrafts = (list: SubscriptionPlan[]): EditablePlanDraft[] =>
    list.map((p) => ({
      ...p,
      priceIqd: String(p.priceIqd ?? 0),
      durationDays: String(p.durationDays ?? 30),
    }));

  // Plans & Payment Methods Editor state
  const [editablePlans, setEditablePlans] = useState<EditablePlanDraft[]>(() => toPlanDrafts(plans));
  const [zaincashNumber, setZaincashNumber] = useState(
    paymentMethods?.zaincashNumber || DEFAULT_PAYMENT_METHODS.zaincashNumber
  );
  const [mastercardNumber, setMastercardNumber] = useState(
    paymentMethods?.mastercardNumber || DEFAULT_PAYMENT_METHODS.mastercardNumber
  );
  const [savingPlans, setSavingPlans] = useState(false);

  useEffect(() => {
    setEditablePlans(toPlanDrafts(plans));
  }, [plans]);

  useEffect(() => {
    setZaincashNumber(paymentMethods?.zaincashNumber || DEFAULT_PAYMENT_METHODS.zaincashNumber);
    setMastercardNumber(
      paymentMethods?.mastercardNumber || DEFAULT_PAYMENT_METHODS.mastercardNumber
    );
  }, [paymentMethods]);

  const filteredSubs = useMemo(() => {
    const q = search.trim().toLowerCase();
    return subscriptions.filter((sub) => {
      if (filter === 'merchant' && sub.subscriberType !== 'merchant') return false;
      if (filter === 'courier' && sub.subscriberType !== 'courier') return false;
      if (filter === 'active' && sub.status !== 'active') return false;
      if (filter === 'trial' && sub.status !== 'trial') return false;
      if (filter === 'expiring_soon' && !sub.isExpiringSoon) return false;
      if (filter === 'expired' && sub.status !== 'expired') return false;
      if (filter === 'suspended' && sub.status !== 'suspended') return false;
      if (filter === 'renewal_requested' && !sub.renewalRequested) return false;
      if (!q) return true;
      return (
        (sub.userName || '').toLowerCase().includes(q) ||
        (sub.userPhone || '').toLowerCase().includes(q) ||
        (sub.userEmail || '').toLowerCase().includes(q) ||
        (sub.storeName || '').toLowerCase().includes(q)
      );
    });
  }, [subscriptions, filter, search]);

  const filteredPaymentRequests = useMemo(() => {
    const q = search.trim().toLowerCase();
    return paymentRequests.filter((r) => {
      if (reqFilter !== 'all' && r.status !== reqFilter) return false;
      if (!q) return true;
      return (
        (r.userName || '').toLowerCase().includes(q) ||
        (r.userPhone || '').toLowerCase().includes(q) ||
        (r.storeName || '').toLowerCase().includes(q) ||
        (r.planName || '').toLowerCase().includes(q) ||
        (r.transferReference || '').toLowerCase().includes(q) ||
        (r.transferDetails || '').toLowerCase().includes(q)
      );
    });
  }, [paymentRequests, reqFilter, search]);

  const executeAction = async (
    sub: UserSubscription,
    action: 'activate' | 'extend' | 'suspend' | 'reactivate' | 'record_payment' | 'set_dates'
  ) => {
    setBusyUserId(sub.userId);
    try {
      const durationDays = Math.max(1, Number(daysInput[sub.userId] ?? 30) || 30);
      const amountPaid = Math.max(0, Number(amountInput[sub.userId] ?? 0) || 0);
      const notes = (noteInput[sub.userId] || '').trim();
      const planName =
        durationDays >= 360
          ? 'yearly'
          : durationDays >= 180
          ? '6_months'
          : durationDays >= 85
          ? '3_months'
          : durationDays >= 55
          ? '2_months'
          : '1_month';

      const customStartsAt = startsAtInput[sub.userId] ?? toDateInputValue(sub.startsAt);
      const customExpiresAt = expiresAtInput[sub.userId] ?? toDateInputValue(sub.expiresAt);

      await onRunAction(sub.userId, {
        action,
        durationDays: action === 'activate' || action === 'extend' ? durationDays : undefined,
        amountPaid,
        monthlyFee: amountPaid > 0 ? amountPaid : undefined,
        planName: action === 'activate' || action === 'extend' ? planName : undefined,
        startsAt: action === 'set_dates' && customStartsAt ? `${customStartsAt}T00:00:00.000Z` : undefined,
        expiresAt:
          action === 'set_dates' && customExpiresAt ? `${customExpiresAt}T23:59:59.000Z` : undefined,
        notes: notes || undefined,
      });
      setAmountInput((prev) => ({ ...prev, [sub.userId]: '' }));
      setNoteInput((prev) => ({ ...prev, [sub.userId]: '' }));
    } finally {
      setBusyUserId(null);
    }
  };

  const handleApproveRequest = async (req: SubscriptionPaymentRequest) => {
    setBusyRequestId(req.id);
    try {
      const customStart = (reqStartsAt[req.id] || '').trim();
      const customEnd = (reqExpiresAt[req.id] || '').trim();
      await onReviewPaymentRequest(req.id, {
        decision: 'approve',
        adminNotes: (reqAdminNote[req.id] || '').trim() || undefined,
        startsAt: customStart ? `${customStart}T00:00:00.000Z` : undefined,
        expiresAt: customEnd ? `${customEnd}T23:59:59.000Z` : undefined,
      });
      setRejectingRequestId(null);
    } finally {
      setBusyRequestId(null);
    }
  };

  const handleRejectRequest = async (req: SubscriptionPaymentRequest) => {
    const reason = (reqRejectionReason[req.id] || '').trim();
    if (reason.length < 3) return;
    setBusyRequestId(req.id);
    try {
      await onReviewPaymentRequest(req.id, {
        decision: 'reject',
        rejectionReason: reason,
        adminNotes: (reqAdminNote[req.id] || '').trim() || undefined,
      });
      setRejectingRequestId(null);
      setReqRejectionReason((prev) => ({ ...prev, [req.id]: '' }));
    } finally {
      setBusyRequestId(null);
    }
  };

  const handleSavePlansAndMethods = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPlans(true);
    try {
      await onUpdatePlans({
        plans: editablePlans.map((p) => ({
          id: p.id,
          name: p.name.trim(),
          priceIqd: Math.max(0, Math.round(Number(p.priceIqd) || 0)),
          durationDays: Math.max(1, Math.round(Number(p.durationDays) || 30)),
          isActive: p.isActive,
        })),
        paymentMethods: {
          zaincashNumber: zaincashNumber.trim(),
          mastercardNumber: mastercardNumber.trim(),
        },
      });
    } finally {
      setSavingPlans(false);
    }
  };

  const handleBulkNotifyExpiring = async () => {
    setSendingBulkReminder(true);
    try {
      await onNotifyExpiring();
    } finally {
      setSendingBulkReminder(false);
    }
  };

  const handleSingleNotify = async (userId: string) => {
    setBusyUserId(userId);
    try {
      await onNotifyExpiring(userId);
    } finally {
      setBusyUserId(null);
    }
  };

  return (
    <div className="space-y-5">
      {/* Executive Subscriptions KPI Strip */}
      {stats && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-[11px] text-sq-ink-muted">إجمالي المشتركين</p>
            <p className="mt-1 font-mono text-2xl font-bold text-sq-ink tabular-nums">
              {stats.totalSubscribers}
            </p>
            <p className="mt-0.5 text-[11px] text-sq-ink-muted tabular-nums">
              {stats.merchantSubscribers} تاجر · {stats.courierSubscribers} مندوب
            </p>
          </div>
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-[11px] text-sq-ink-muted">فعال / تجريبي</p>
            <p className="mt-1 font-mono text-2xl font-bold text-sq-gold-text tabular-nums">
              {stats.activeCount + stats.trialCount}
            </p>
            <p className="mt-0.5 text-[11px] text-sq-ink-muted tabular-nums">
              {stats.activeCount} مدفوع · {stats.trialCount} تجريبي
            </p>
          </div>
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-[11px] text-sq-ink-muted">قريب الانتهاء (≤ 5 أيام)</p>
            <p
              className={`mt-1 font-mono text-2xl font-bold tabular-nums ${
                stats.expiringSoonCount > 0 ? 'text-sq-warning-text' : 'text-sq-ink'
              }`}
            >
              {stats.expiringSoonCount}
            </p>
          </div>
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-4">
            <p className="text-[11px] text-sq-ink-muted">منتهي / متوقف</p>
            <p
              className={`mt-1 font-mono text-2xl font-bold tabular-nums ${
                stats.expiredCount + stats.suspendedCount > 0
                  ? 'text-sq-danger-text'
                  : 'text-sq-ink'
              }`}
            >
              {stats.expiredCount + stats.suspendedCount}
            </p>
            <p className="mt-0.5 text-[11px] text-sq-ink-muted tabular-nums">
              {stats.expiredCount} منتهي · {stats.suspendedCount} متوقف
            </p>
          </div>
          <button
            type="button"
            onClick={() => setViewMode('requests')}
            className="rounded-2xl border border-sq-gold/45 bg-sq-surface p-4 text-right hover:border-sq-gold transition-colors"
          >
            <p className="text-[11px] font-semibold text-sq-gold-text">إثباتات دفع بانتظار المراجعة</p>
            <p
              className={`mt-1 font-mono text-2xl font-bold tabular-nums ${
                pendingReqCount > 0 ? 'text-sq-warning-text' : 'text-sq-ink'
              }`}
            >
              {pendingReqCount}
            </p>
            <p className="mt-0.5 text-[10px] text-sq-ink-muted">
              إجمالي الطلبات: {paymentRequests.length}
            </p>
          </button>
          <div className="rounded-2xl border border-sq-gold/35 bg-sq-gold-soft/40 p-4">
            <p className="text-[11px] font-semibold text-sq-gold-text">إيرادات الاشتراكات المسجلة</p>
            <p className="mt-1 font-mono text-lg font-extrabold text-sq-ink tabular-nums">
              {formatPrice(stats.totalRecordedRevenue, currency)}
            </p>
            <p className="mt-0.5 text-[10px] text-sq-ink-muted">مراجعة وتفعيل عبر الإدارة</p>
          </div>
        </div>
      )}

      {/* Sub-mode Toggle: Requests / Subscribers / Plans & Methods / Ledger */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto rounded-xl bg-sq-muted p-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setViewMode('requests')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg px-3.5 text-xs font-bold whitespace-nowrap ${
              viewMode === 'requests'
                ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                : 'text-sq-ink-muted'
            }`}
          >
            <FileCheck2 className="h-3.5 w-3.5" />
            <span>طلبات الدفع وإثباتات التحويل ({paymentRequests.length})</span>
            {pendingReqCount > 0 && (
              <span className="rounded-md bg-sq-gold px-1.5 py-0.5 font-mono text-[10px] font-extrabold text-[#0B0C0C]">
                {pendingReqCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setViewMode('subscribers')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg px-3.5 text-xs font-bold whitespace-nowrap ${
              viewMode === 'subscribers'
                ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                : 'text-sq-ink-muted'
            }`}
          >
            <Crown className="h-3.5 w-3.5" />
            <span>قائمة المشتركين ({subscriptions.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('plans')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg px-3.5 text-xs font-bold whitespace-nowrap ${
              viewMode === 'plans'
                ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                : 'text-sq-ink-muted'
            }`}
          >
            <Settings2 className="h-3.5 w-3.5" />
            <span>الباقات والأسعار ووسائل الدفع</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('ledger')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg px-3.5 text-xs font-bold whitespace-nowrap ${
              viewMode === 'ledger'
                ? 'bg-sq-surface text-sq-gold-text shadow-xs'
                : 'text-sq-ink-muted'
            }`}
          >
            <History className="h-3.5 w-3.5" />
            <span>سجل العمليات ({logs.length})</span>
          </button>
        </div>

        {(viewMode === 'subscribers' || viewMode === 'requests') && (
          <div className="relative w-full sm:w-72">
            <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-sq-ink-muted" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث باسم التاجر، المتجر، المندوب، رقم الحوالة..."
              className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface pr-10 pl-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
            />
          </div>
        )}
      </div>

      {/* VIEW 1: Payment Proof Requests Review */}
      {viewMode === 'requests' ? (
        <div className="space-y-4">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {(
              [
                { key: 'all', label: `الكل (${paymentRequests.length})` },
                {
                  key: 'pending',
                  label: `قيد المراجعة (${paymentRequests.filter((r) => r.status === 'pending').length})`,
                },
                {
                  key: 'approved',
                  label: `مقبول ومفعّل (${paymentRequests.filter((r) => r.status === 'approved').length})`,
                },
                {
                  key: 'rejected',
                  label: `مرفوض (${paymentRequests.filter((r) => r.status === 'rejected').length})`,
                },
              ] as const
            ).map((chip) => (
              <button
                key={chip.key}
                type="button"
                onClick={() => setReqFilter(chip.key)}
                className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                  reqFilter === chip.key
                    ? 'bg-sq-gold text-[#0B0C0C]'
                    : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                }`}
              >
                {chip.label}
              </button>
            ))}
          </div>

          {filteredPaymentRequests.length === 0 ? (
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
              لا توجد طلبات دفع اشتراك مطابقة حالياً.
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPaymentRequests.map((req) => {
                const isBusy = busyRequestId === req.id;
                const isRejecting = rejectingRequestId === req.id;

                return (
                  <div
                    key={req.id}
                    className={`rounded-2xl border bg-sq-surface p-5 space-y-4 ${
                      req.status === 'pending'
                        ? 'border-sq-gold/60 shadow-sm'
                        : req.status === 'rejected'
                        ? 'border-sq-danger-border/60'
                        : 'border-sq-border'
                    }`}
                  >
                    <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
                      {/* Request Metadata */}
                      <div className="lg:col-span-8 space-y-2.5">
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span
                            className={`rounded-lg border px-2.5 py-0.5 font-bold ${
                              req.status === 'pending'
                                ? 'border-sq-warning-border bg-sq-warning-bg text-sq-warning-text'
                                : req.status === 'approved'
                                ? 'border-sq-success-border bg-sq-success-bg text-sq-success-text'
                                : 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
                            }`}
                          >
                            {PAYMENT_REQUEST_STATUS_LABELS[req.status]}
                          </span>
                          <span className="inline-flex items-center gap-1 rounded-lg border border-sq-gold/30 bg-sq-gold-soft px-2 py-0.5 font-bold text-sq-gold-text">
                            {req.subscriberType === 'merchant' ? (
                              <StoreIcon className="h-3.5 w-3.5" />
                            ) : (
                              <Bike className="h-3.5 w-3.5" />
                            )}
                            <span>{req.subscriberType === 'merchant' ? 'صاحب متجر' : 'مندوب توصيل'}</span>
                          </span>
                          <span className="text-[11px] text-sq-ink-muted">
                            {formatDateAr(req.createdAt)}
                          </span>
                        </div>

                        <h3 className="font-display text-base font-extrabold text-sq-ink">
                          {req.userName || req.userId}
                          {req.storeName && (
                            <span className="mr-2 text-xs font-bold text-sq-gold-text">
                              — {req.storeName}
                              {req.storeType ? ` (${STORE_TYPE_LABELS[req.storeType]})` : ''}
                            </span>
                          )}
                        </h3>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-sq-ink-muted">
                          {req.userPhone && (
                            <span dir="ltr" className="font-mono">
                              {req.userPhone}
                            </span>
                          )}
                          {req.userEmail && <span>{req.userEmail}</span>}
                        </div>

                        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3 rounded-xl border border-sq-border bg-sq-elevated p-3 text-xs">
                          <div>
                            <p className="text-[11px] text-sq-ink-muted">الباقة المطلوبة</p>
                            <p className="font-bold text-sq-ink">
                              {req.planName} ({req.durationDays} يوم)
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-sq-ink-muted">المبلغ المعتمد</p>
                            <p className="font-mono font-extrabold text-sq-gold-text tabular-nums">
                              {formatPrice(req.amountIqd, currency)}
                            </p>
                          </div>
                          <div>
                            <p className="text-[11px] text-sq-ink-muted">وسيلة الدفع</p>
                            <p className="font-bold text-sq-ink">
                              {PAYMENT_METHOD_LABELS[req.paymentMethod] || req.paymentMethod}
                            </p>
                          </div>
                        </div>

                        {(req.transferReference || req.transferDetails) && (
                          <div className="rounded-xl border border-sq-border bg-sq-elevated/60 px-3.5 py-2.5 text-xs space-y-1">
                            {req.transferReference && (
                              <p>
                                <strong className="text-sq-ink">رقم المرجع / الحوالة:</strong>{' '}
                                <span dir="ltr" className="font-mono text-sq-gold-text">
                                  {req.transferReference}
                                </span>
                              </p>
                            )}
                            {req.transferDetails && (
                              <p className="text-sq-ink-muted">
                                <strong className="text-sq-ink">تفاصيل التحويل:</strong>{' '}
                                {req.transferDetails}
                              </p>
                            )}
                          </div>
                        )}

                        {req.status === 'rejected' && req.rejectionReason && (
                          <div className="rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3.5 py-2.5 text-xs text-sq-danger-text">
                            <strong>سبب الرفض المسجل:</strong> {req.rejectionReason}
                          </div>
                        )}

                        {req.status !== 'pending' && req.reviewedAt && (
                          <p className="text-[11px] text-sq-ink-muted">
                            تمت المراجعة بواسطة <strong>{req.reviewedByName || 'المدير العام'}</strong>{' '}
                            بتاريخ {formatDateAr(req.reviewedAt)}
                            {req.adminNotes ? ` — ملاحظة: ${req.adminNotes}` : ''}
                          </p>
                        )}
                      </div>

                      {/* Protected Payment Proof Image Preview */}
                      <div className="lg:col-span-4 space-y-1.5">
                        <p className="text-[11px] font-bold text-sq-ink-muted">
                          صورة إثبات التحويل (محمية — انقر للتكبير)
                        </p>
                        <PrivatePaymentProofImage
                          filename={req.paymentProofDoc}
                          alt={`إثبات تحويل ${req.userName || req.id}`}
                        />
                      </div>
                    </div>

                    {/* Pending Request Review Controls */}
                    {req.status === 'pending' && (() => {
                      const defaultStartIso = new Date().toISOString();
                      const defaultEndIso = new Date(
                        Date.now() + Math.max(1, req.durationDays) * 24 * 60 * 60 * 1000
                      ).toISOString();
                      const startVal = reqStartsAt[req.id] ?? toDateInputValue(defaultStartIso);
                      const endVal = reqExpiresAt[req.id] ?? toDateInputValue(defaultEndIso);
                      return (
                      <div className="rounded-xl border border-sq-gold/30 bg-sq-elevated p-4 space-y-3">
                        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                          <div>
                            <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                              تاريخ بداية الاشتراك عند التفعيل
                            </label>
                            <input
                              type="date"
                              dir="ltr"
                              value={startVal}
                              onChange={(e) =>
                                setReqStartsAt((prev) => ({ ...prev, [req.id]: e.target.value }))
                              }
                              className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                              تاريخ انتهاء الاشتراك ({req.durationDays} يوم تلقائياً أو مخصص)
                            </label>
                            <input
                              type="date"
                              dir="ltr"
                              value={endVal}
                              onChange={(e) =>
                                setReqExpiresAt((prev) => ({ ...prev, [req.id]: e.target.value }))
                              }
                              className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                            />
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-2.5">
                          <input
                            type="text"
                            value={reqAdminNote[req.id] || ''}
                            onChange={(e) =>
                              setReqAdminNote((prev) => ({ ...prev, [req.id]: e.target.value }))
                            }
                            placeholder="ملاحظة إدارية اختيارية (تُسجّل في سجل التدقيق)..."
                            className="min-h-[40px] flex-1 min-w-[220px] rounded-xl border border-sq-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                          />
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void handleApproveRequest(req)}
                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold disabled:opacity-50"
                          >
                            {isBusy ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            )}
                            <span>قبول الطلب وتفعيل الاشتراك ({req.durationDays} يوم)</span>
                          </button>

                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() =>
                              setRejectingRequestId(isRejecting ? null : req.id)
                            }
                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 text-xs font-bold text-sq-danger-text"
                          >
                            <XCircle className="h-3.5 w-3.5" />
                            <span>رفض الطلب</span>
                          </button>
                        </div>

                        {isRejecting && (
                          <div className="flex flex-wrap items-center gap-2 border-t border-sq-border pt-3">
                            <input
                              type="text"
                              value={reqRejectionReason[req.id] || ''}
                              onChange={(e) =>
                                setReqRejectionReason((prev) => ({
                                  ...prev,
                                  [req.id]: e.target.value,
                                }))
                              }
                              placeholder="اكتب سبب الرفض بوضوح (سيظهر للمستخدم في إشعار وحالة الطلب)..."
                              className="min-h-[40px] flex-1 min-w-[240px] rounded-xl border border-sq-danger-border bg-sq-surface px-3 text-xs text-sq-ink focus:outline-none"
                            />
                            <button
                              type="button"
                              disabled={
                                isBusy || (reqRejectionReason[req.id] || '').trim().length < 3
                              }
                              onClick={() => void handleRejectRequest(req)}
                              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-sq-danger px-4 text-xs font-bold text-white disabled:opacity-50"
                            >
                              <span>تأكيد الرفض وإشعار المستخدم</span>
                            </button>
                          </div>
                        )}
                      </div>
                      );
                    })()}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : viewMode === 'plans' ? (
        /* VIEW 2: Dynamic Editable Subscription Plans & Payment Methods */
        <form onSubmit={handleSavePlansAndMethods} className="space-y-5">
          <div className="rounded-2xl border border-sq-gold/35 bg-sq-surface p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-base font-extrabold text-sq-ink">
                  تعديل أسعار ومدد باقات الاشتراك (تحديث فوري دون تعديل الكود)
                </h3>
                <p className="mt-0.5 text-xs text-sq-ink-muted">
                  أي تعديل هنا يظهر فوراً لجميع أصحاب المحلات والمتاجر والأسواق والمولات والمندوبين في صفحة الاشتراك.
                </p>
              </div>
              <button
                type="submit"
                disabled={savingPlans}
                className="inline-flex min-h-[42px] items-center gap-2 rounded-xl btn-gold px-5 text-xs font-bold disabled:opacity-50"
              >
                {savingPlans ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                <span>حفظ الباقات ووسائل الدفع</span>
              </button>
            </div>

            <div className="grid grid-cols-1 gap-3.5 md:grid-cols-2">
              {editablePlans.map((plan, idx) => (
                <div
                  key={plan.id}
                  className="rounded-2xl border border-sq-border bg-sq-elevated p-4 space-y-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[11px] font-bold text-sq-gold-text">
                      {plan.code}
                    </span>
                    <label className="inline-flex items-center gap-2 text-xs font-semibold text-sq-ink cursor-pointer">
                      <input
                        type="checkbox"
                        checked={plan.isActive}
                        onChange={(e) =>
                          setEditablePlans((prev) =>
                            prev.map((p, i) =>
                              i === idx ? { ...p, isActive: e.target.checked } : p
                            )
                          )
                        }
                        className="h-4 w-4 accent-[#D4AF37]"
                      />
                      <span>باقة مفعّلة للعرض</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
                    <div className="sm:col-span-3">
                      <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                        اسم الباقة
                      </label>
                      <input
                        type="text"
                        value={plan.name}
                        onChange={(e) =>
                          setEditablePlans((prev) =>
                            prev.map((p, i) => (i === idx ? { ...p, name: e.target.value } : p))
                          )
                        }
                        required
                        className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-bold text-sq-ink focus:border-sq-gold focus:outline-none"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                        السعر ({currency})
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        dir="ltr"
                        value={plan.priceIqd}
                        onChange={(e) => {
                          const digits = normalizeArabicDigits(e.target.value).replace(/\D/g, '');
                          setEditablePlans((prev) =>
                            prev.map((p, i) => (i === idx ? { ...p, priceIqd: digits } : p))
                          );
                        }}
                        onBlur={() =>
                          setEditablePlans((prev) =>
                            prev.map((p, i) =>
                              i === idx
                                ? { ...p, priceIqd: String(Math.max(0, parseInt(p.priceIqd, 10) || 0)) }
                                : p
                            )
                          )
                        }
                        required
                        className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs font-bold text-sq-gold-text focus:border-sq-gold focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                        المدة (يوم)
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        dir="ltr"
                        value={plan.durationDays}
                        onChange={(e) => {
                          const digits = normalizeArabicDigits(e.target.value).replace(/\D/g, '').slice(0, 4);
                          setEditablePlans((prev) =>
                            prev.map((p, i) => (i === idx ? { ...p, durationDays: digits } : p))
                          );
                        }}
                        onBlur={() =>
                          setEditablePlans((prev) =>
                            prev.map((p, i) =>
                              i === idx
                                ? {
                                    ...p,
                                    durationDays: String(
                                      Math.min(3650, Math.max(1, parseInt(p.durationDays, 10) || 30))
                                    ),
                                  }
                                : p
                            )
                          )
                        }
                        required
                        className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Official Payment Methods Numbers */}
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-5 space-y-4">
            <div className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-sq-gold-text" />
              <h3 className="font-display text-base font-extrabold text-sq-ink">
                أرقام وسائل الدفع الرسمية المعتمدة
              </h3>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  رقم محفظة زين كاش (ZainCash)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={zaincashNumber}
                  onChange={(e) => setZaincashNumber(e.target.value)}
                  required
                  className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm font-bold text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  رقم بطاقة ماستر كارد (MasterCard)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={mastercardNumber}
                  onChange={(e) => setMastercardNumber(e.target.value)}
                  required
                  className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm font-bold text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>
            </div>
          </div>
        </form>
      ) : viewMode === 'ledger' ? (
        /* VIEW 3: Ledger */
        logs.length === 0 ? (
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
            لا توجد عمليات اشتراك مسجلة حتى الآن.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-sq-border bg-sq-surface">
            <table className="w-full text-right text-xs">
              <thead className="border-b border-sq-border bg-sq-elevated text-sq-ink-muted">
                <tr>
                  <th className="px-4 py-3 font-semibold">العملية</th>
                  <th className="px-4 py-3 font-semibold">المشترك</th>
                  <th className="px-4 py-3 font-semibold">المدة المضافة</th>
                  <th className="px-4 py-3 font-semibold">المبلغ المسجل</th>
                  <th className="px-4 py-3 font-semibold">المنفّذ والملاحظة</th>
                  <th className="px-4 py-3 font-semibold">التاريخ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sq-border">
                {logs.map((log) => (
                  <tr key={log.id}>
                    <td className="px-4 py-3 font-bold text-sq-gold-text whitespace-nowrap">
                      {SUBSCRIPTION_ACTION_LABELS[log.actionType] || log.actionType}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-sq-ink">{log.userName || log.userId}</div>
                      <div className="text-[11px] text-sq-ink-muted">
                        {log.subscriberType === 'merchant' ? 'صاحب متجر' : 'مندوب توصيل'}
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono tabular-nums text-sq-ink">
                      {log.durationDays > 0 ? `+${log.durationDays} يوم` : '—'}
                    </td>
                    <td className="px-4 py-3 font-mono font-bold tabular-nums text-sq-gold-text">
                      {log.amountPaid > 0 ? formatPrice(log.amountPaid, currency) : '—'}
                    </td>
                    <td className="px-4 py-3 text-sq-ink-muted">
                      {log.actorName && (
                        <span className="font-semibold text-sq-ink">{log.actorName}: </span>
                      )}
                      {log.notes || '—'}
                    </td>
                    <td className="px-4 py-3 text-[11px] text-sq-ink-muted whitespace-nowrap">
                      {formatDateAr(log.createdAt)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      ) : (
        /* VIEW 4: Subscribers List with Custom Dates & Expiry Reminders */
        <>
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            {/* Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {(
                [
                  { key: 'all', label: `الكل (${subscriptions.length})` },
                  {
                    key: 'expiring_soon',
                    label: `قريب الانتهاء (${subscriptions.filter((s) => s.isExpiringSoon).length})`,
                  },
                  {
                    key: 'expired',
                    label: `منتهي (${subscriptions.filter((s) => s.status === 'expired').length})`,
                  },
                  {
                    key: 'suspended',
                    label: `متوقف (${subscriptions.filter((s) => s.status === 'suspended').length})`,
                  },
                  {
                    key: 'renewal_requested',
                    label: `طلبات تجديد (${subscriptions.filter((s) => s.renewalRequested).length})`,
                  },
                  {
                    key: 'merchant',
                    label: `أصحاب المتاجر (${subscriptions.filter((s) => s.subscriberType === 'merchant').length})`,
                  },
                  {
                    key: 'courier',
                    label: `المندوبون (${subscriptions.filter((s) => s.subscriberType === 'courier').length})`,
                  },
                  {
                    key: 'active',
                    label: `فعال (${subscriptions.filter((s) => s.status === 'active').length})`,
                  },
                  {
                    key: 'trial',
                    label: `تجريبي (${subscriptions.filter((s) => s.status === 'trial').length})`,
                  },
                ] as const
              ).map((chip) => (
                <button
                  key={chip.key}
                  type="button"
                  onClick={() => setFilter(chip.key)}
                  className={`min-h-[38px] rounded-xl px-3.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    filter === chip.key
                      ? 'bg-sq-gold text-[#0B0C0C]'
                      : 'border border-sq-border bg-sq-surface text-sq-ink-muted hover:text-sq-ink'
                  }`}
                >
                  {chip.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              disabled={sendingBulkReminder}
              onClick={() => void handleBulkNotifyExpiring()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3.5 text-xs font-bold text-sq-warning-text hover:opacity-90 disabled:opacity-50 shrink-0"
            >
              {sendingBulkReminder ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <BellRing className="h-3.5 w-3.5" />
              )}
              <span>إرسال تنبيهات للمشتركين القريبة من الانتهاء والمنتهية</span>
            </button>
          </div>

          {filteredSubs.length === 0 ? (
            <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
              لا يوجد مشتركون مطابقون لهذا التصنيف أو البحث حالياً.
            </div>
          ) : (
            <div className="space-y-3.5">
              {filteredSubs.map((sub) => {
                const isExpanded = expandedUserId === sub.userId;
                const isBusy = busyUserId === sub.userId;
                const currentDays = daysInput[sub.userId] ?? '30';
                const currentAmount = amountInput[sub.userId] ?? '';
                const currentNote = noteInput[sub.userId] ?? '';
                const currentStartsAt = startsAtInput[sub.userId] ?? toDateInputValue(sub.startsAt);
                const currentExpiresAt =
                  expiresAtInput[sub.userId] ?? toDateInputValue(sub.expiresAt);

                return (
                  <div
                    key={sub.id}
                    className={`rounded-2xl border bg-sq-surface p-5 space-y-3.5 ${
                      sub.renewalRequested
                        ? 'border-sq-gold/60 shadow-sm'
                        : sub.status === 'expired' || sub.status === 'suspended'
                        ? 'border-sq-danger-border/70'
                        : 'border-sq-border'
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span className="inline-flex items-center gap-1 rounded-lg border border-sq-gold/30 bg-sq-gold-soft px-2 py-0.5 font-bold text-sq-gold-text">
                            {sub.subscriberType === 'merchant' ? (
                              <StoreIcon className="h-3.5 w-3.5" />
                            ) : (
                              <Bike className="h-3.5 w-3.5" />
                            )}
                            <span>
                              {sub.subscriberType === 'merchant' ? 'صاحب متجر' : 'مندوب توصيل'}
                            </span>
                          </span>

                          <span
                            className={`rounded-lg border px-2.5 py-0.5 font-bold ${
                              sub.status === 'active'
                                ? 'border-sq-success-border bg-sq-success-bg text-sq-success-text'
                                : sub.status === 'trial'
                                ? 'border-sq-gold/40 bg-sq-gold-soft text-sq-gold-text'
                                : 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
                            }`}
                          >
                            {SUBSCRIPTION_STATUS_LABELS[sub.status]}
                          </span>

                          {sub.isExpiringSoon && (
                            <span className="inline-flex items-center gap-1 font-bold text-sq-warning-text">
                              <Clock className="h-3.5 w-3.5" />
                              <span>ينتهي خلال {sub.daysRemaining} يوم</span>
                            </span>
                          )}

                          {sub.renewalRequested && (
                            <span className="inline-flex items-center gap-1 rounded-lg border border-sq-warning-border bg-sq-warning-bg px-2 py-0.5 font-bold text-sq-warning-text">
                              <AlertTriangle className="h-3 w-3" />
                              <span>طلب تجديد وارد</span>
                            </span>
                          )}
                        </div>

                        <h3 className="font-display text-base font-extrabold text-sq-ink">
                          {sub.userName || sub.userId}
                          {sub.storeName && (
                            <span className="mr-2 text-xs font-bold text-sq-gold-text">
                              — {sub.storeName}
                              {sub.storeType ? ` (${STORE_TYPE_LABELS[sub.storeType]})` : ''}
                            </span>
                          )}
                        </h3>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-sq-ink-muted">
                          {sub.userPhone && (
                            <span dir="ltr" className="font-mono">
                              {sub.userPhone}
                            </span>
                          )}
                          {sub.userEmail && <span>{sub.userEmail}</span>}
                          <span>·</span>
                          <span>{SUBSCRIPTION_PLAN_LABELS[sub.planName] || sub.planName}</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2.5">
                        <div className="text-left text-xs ml-1">
                          <p className="text-sq-ink-muted">المتبقي</p>
                          <p className="font-mono text-lg font-extrabold text-sq-gold-text tabular-nums">
                            {sub.daysRemaining} يوم
                          </p>
                          <p className="text-[11px] text-sq-ink-muted">
                            حتى {formatDateAr(sub.expiresAt)}
                          </p>
                        </div>

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => void handleSingleNotify(sub.userId)}
                          title="إرسال تنبيه تجديد لهذا المشترك"
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs font-semibold text-sq-ink hover:border-sq-gold disabled:opacity-50"
                        >
                          <BellRing className="h-3.5 w-3.5 text-sq-gold-text" />
                          <span>تنبيه</span>
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            setExpandedUserId(isExpanded ? null : sub.userId)
                          }
                          className="min-h-[40px] rounded-xl btn-gold px-4 text-xs font-bold"
                        >
                          {isExpanded ? 'إغلاق الإدارة' : 'إدارة وتجديد الاشتراك'}
                        </button>
                      </div>
                    </div>

                    {sub.renewalRequested && sub.renewalNote && (
                      <div className="rounded-xl border border-sq-warning-border bg-sq-warning-bg px-3.5 py-2.5 text-xs text-sq-warning-text">
                        <strong>ملاحظة طلب التجديد من المستخدم:</strong> {sub.renewalNote}
                        {sub.renewalRequestedAt
                          ? ` (${formatDateAr(sub.renewalRequestedAt)})`
                          : ''}
                      </div>
                    )}

                    <div className="flex flex-wrap items-center gap-4 text-[11px] text-sq-ink-muted border-t border-sq-border pt-2.5">
                      <span>البداية: {formatDateAr(sub.startsAt)}</span>
                      <span>
                        إجمالي المدفوع:{' '}
                        <strong className="font-mono text-sq-ink">
                          {formatPrice(sub.totalPaid, currency)}
                        </strong>
                      </span>
                      {sub.monthlyFee > 0 && (
                        <span>الرسوم المسجلة: {formatPrice(sub.monthlyFee, currency)}</span>
                      )}
                      {sub.notes && <span>ملاحظة: {sub.notes}</span>}
                    </div>

                    {/* Expanded Admin Subscription Controls */}
                    {isExpanded && (
                      <div className="rounded-2xl border border-sq-gold/30 bg-sq-elevated p-4 space-y-4">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-xs font-bold text-sq-ink ml-2">مدة سريعة:</span>
                          {PRESET_DAYS.map((d) => (
                            <button
                              key={d}
                              type="button"
                              onClick={() =>
                                setDaysInput((prev) => ({ ...prev, [sub.userId]: String(d) }))
                              }
                              className={`min-h-[34px] rounded-lg px-3 text-xs font-bold ${
                                Number(currentDays) === d
                                  ? 'bg-sq-gold text-[#0B0C0C]'
                                  : 'border border-sq-border bg-sq-surface text-sq-ink'
                              }`}
                            >
                              {d} يوم
                            </button>
                          ))}
                        </div>

                        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                          <div>
                            <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                              المدة بالأيام
                            </label>
                            <input
                              type="number"
                              min={1}
                              max={3650}
                              value={currentDays}
                              onChange={(e) =>
                                setDaysInput((prev) => ({
                                  ...prev,
                                  [sub.userId]: e.target.value,
                                }))
                              }
                              className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                              مبلغ الدفعة المستلمة ({currency})
                            </label>
                            <input
                              type="number"
                              min={0}
                              step="500"
                              value={currentAmount}
                              onChange={(e) =>
                                setAmountInput((prev) => ({
                                  ...prev,
                                  [sub.userId]: e.target.value,
                                }))
                              }
                              placeholder="مثال: 5000"
                              className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                              ملاحظة إدارية / رقم الإيصال
                            </label>
                            <input
                              type="text"
                              value={currentNote}
                              onChange={(e) =>
                                setNoteInput((prev) => ({
                                  ...prev,
                                  [sub.userId]: e.target.value,
                                }))
                              }
                              placeholder="مثال: تم الاستلام زين كاش / ماستر كارد"
                              className="min-h-[40px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                            />
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void executeAction(sub, 'activate')}
                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold disabled:opacity-60"
                          >
                            {isBusy ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <CheckCircle2 className="h-3.5 w-3.5" />
                            )}
                            <span>تفعيل الاشتراك ({currentDays} يوم)</span>
                          </button>

                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void executeAction(sub, 'extend')}
                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-gold/45 bg-sq-gold-soft px-4 text-xs font-bold text-sq-gold-text hover:border-sq-gold disabled:opacity-60"
                          >
                            <CalendarPlus className="h-3.5 w-3.5" />
                            <span>تمديد المدة (+{currentDays} يوم)</span>
                          </button>

                          <button
                            type="button"
                            disabled={isBusy || Number(currentAmount) <= 0}
                            onClick={() => void executeAction(sub, 'record_payment')}
                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-surface px-4 text-xs font-semibold text-sq-ink hover:bg-sq-muted disabled:opacity-50"
                          >
                            <Banknote className="h-3.5 w-3.5 text-sq-gold-text" />
                            <span>تسجيل دفعة فقط</span>
                          </button>

                          {sub.status !== 'suspended' ? (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => void executeAction(sub, 'suspend')}
                              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-4 text-xs font-bold text-sq-danger-text disabled:opacity-60"
                            >
                              <PauseCircle className="h-3.5 w-3.5" />
                              <span>إيقاف الاشتراك مؤقتاً</span>
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => void executeAction(sub, 'reactivate')}
                              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sq-success-border bg-sq-success-bg px-4 text-xs font-bold text-sq-success-text disabled:opacity-60"
                            >
                              <PlayCircle className="h-3.5 w-3.5" />
                              <span>إعادة التفعيل</span>
                            </button>
                          )}
                        </div>

                        {/* Custom Start / End Date Control */}
                        <div className="border-t border-sq-border pt-3.5 space-y-2.5">
                          <p className="text-xs font-bold text-sq-ink flex items-center gap-1.5">
                            <CalendarCog className="h-4 w-4 text-sq-gold-text" />
                            <span>تحديد تاريخ بداية ونهاية الاشتراك يدوياً</span>
                          </p>
                          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 items-end">
                            <div>
                              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                                تاريخ البداية
                              </label>
                              <input
                                type="date"
                                value={currentStartsAt}
                                onChange={(e) =>
                                  setStartsAtInput((prev) => ({
                                    ...prev,
                                    [sub.userId]: e.target.value,
                                  }))
                                }
                                className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                              />
                            </div>
                            <div>
                              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                                تاريخ الانتهاء
                              </label>
                              <input
                                type="date"
                                value={currentExpiresAt}
                                onChange={(e) =>
                                  setExpiresAtInput((prev) => ({
                                    ...prev,
                                    [sub.userId]: e.target.value,
                                  }))
                                }
                                className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                              />
                            </div>
                            <button
                              type="button"
                              disabled={isBusy || !currentExpiresAt}
                              onClick={() => void executeAction(sub, 'set_dates')}
                              className="inline-flex min-h-[38px] items-center justify-center gap-1.5 rounded-xl border border-sq-gold/45 bg-sq-surface px-4 text-xs font-bold text-sq-gold-text hover:bg-sq-gold-soft disabled:opacity-50"
                            >
                              <CalendarCog className="h-3.5 w-3.5" />
                              <span>حفظ التواريخ المخصصة</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
};
