import React, { useRef, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  ExternalLink,
  Images,
  Loader2,
  Megaphone,
  Plus,
  Trash2,
  X,
} from 'lucide-react';
import { StorePostCard } from './StorePostCard';
import { api, compressImageFile, resolveMediaUrl } from '../lib/api';
import {
  STORE_POST_TYPE_LABELS,
  type Store,
  type StorePost,
  type StorePostType,
} from '../types';

interface MerchantPostsSectionProps {
  store: Store;
  posts: StorePost[];
  onRefresh: () => Promise<void>;
  onOpenStore: (storeId: string) => void;
  notify: (msg: string, tone?: 'success' | 'error' | 'info') => void;
}

const POST_TYPES: StorePostType[] = ['offer', 'announcement', 'new_arrival', 'update'];

export const MerchantPostsSection: React.FC<MerchantPostsSectionProps> = ({
  store,
  posts,
  onRefresh,
  onOpenStore,
  notify,
}) => {
  const [showComposer, setShowComposer] = useState(false);
  const [editingPost, setEditingPost] = useState<StorePost | null>(null);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [postType, setPostType] = useState<StorePostType>('offer');
  const [offerBadge, setOfferBadge] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [uploadingImages, setUploadingImages] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<StorePost | null>(null);
  const [deleting, setDeleting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const openCreateForm = () => {
    setEditingPost(null);
    setTitle('');
    setContent('');
    setPostType('offer');
    setOfferBadge('');
    setImages([]);
    setShowComposer(true);
  };

  const openEditForm = (post: StorePost) => {
    setEditingPost(post);
    setTitle(post.title);
    setContent(post.content);
    setPostType(post.postType);
    setOfferBadge(post.offerBadge || '');
    setImages(post.images || []);
    setShowComposer(true);
  };

  const handleSelectImages = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (files.length === 0) return;

    const remainingSlots = Math.max(0, 6 - images.length);
    if (remainingSlots === 0) {
      notify('الحد الأقصى 6 صور لكل منشور.', 'info');
      return;
    }

    const toProcess = files.slice(0, remainingSlots);
    setUploadingImages(true);
    try {
      const uploadedUrls: string[] = [];
      for (const file of toProcess) {
        const compressed = await compressImageFile(file, 1280);
        const res = await api.uploadImage(compressed);
        if (res.url) uploadedUrls.push(res.url);
      }
      setImages((prev) => [...prev, ...uploadedUrls].slice(0, 6));
      notify(`تم رفع ${uploadedUrls.length} صورة بنجاح.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر رفع الصور المختارة.', 'error');
    } finally {
      setUploadingImages(false);
    }
  };

  const removeImage = (idx: number) => {
    setImages((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim().length < 3) {
      notify('يرجى كتابة عنوان واضح للمنشور (3 أحرف على الأقل).', 'error');
      return;
    }
    if (!content.trim() && images.length === 0) {
      notify('يرجى كتابة وصف للمنشور أو إرفاق صورة واحدة على الأقل.', 'error');
      return;
    }

    setSaving(true);
    try {
      if (editingPost) {
        await api.updateMerchantPost(editingPost.id, {
          title: title.trim(),
          content: content.trim(),
          postType,
          offerBadge: offerBadge.trim(),
          images,
        });
        notify('تم تحديث المنشور بنجاح.', 'success');
      } else {
        await api.createMerchantPost({
          title: title.trim(),
          content: content.trim(),
          postType,
          offerBadge: offerBadge.trim(),
          images,
        });
        notify('تم نشر المنشور في صفحة متجرك بنجاح.', 'success');
      }
      setShowComposer(false);
      setEditingPost(null);
      await onRefresh();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حفظ المنشور.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.deleteMerchantPost(deleteTarget.id);
      notify('تم حذف المنشور بنجاح.', 'success');
      setDeleteTarget(null);
      await onRefresh();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حذف المنشور.', 'error');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="flex flex-col gap-3 rounded-2xl border border-[#C9A24B]/35 bg-[#121413] p-5 text-white sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#EBD18E]">
            <Megaphone className="h-4 w-4 text-[#D4AF37]" />
            <span>منشورات وعروض {store.name}</span>
          </div>
          <h2 className="mt-1 font-display text-lg sm:text-xl font-extrabold text-white">
            انشر عروضك وصور متجرك مباشرة للزبائن
          </h2>
          <p className="mt-1 text-xs text-[#CFCAC0]">
            تظهر منشوراتك في صفحة متجرك الخاصة كما يظهر أحدث عرض في بطاقة متجرك داخل دليل «المتاجر والأسواق».
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => onOpenStore(store.id)}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-white/20 bg-white/5 px-3.5 py-2 text-xs font-bold text-white hover:bg-white/10"
          >
            <ExternalLink className="h-4 w-4 text-[#EBD18E]" />
            <span>معاينة صفحة المتجر</span>
          </button>
          <button
            type="button"
            onClick={openCreateForm}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl bg-[#C9A24B] px-4 py-2 text-xs sm:text-sm font-extrabold text-[#101211] hover:bg-[#D8B563]"
          >
            <Plus className="h-4 w-4" />
            <span>إنشاء منشور جديد</span>
          </button>
        </div>
      </div>

      {store.status !== 'active' && (
        <div className="rounded-xl border border-sq-warning-border bg-sq-warning-bg px-4 py-3 text-xs text-sq-warning-text">
          ملاحظة: يمكنك تجهيز ونشر منشورات متجرك من الآن، وستظهر تلقائياً للجمهور في دليل «المتاجر والأسواق» فور موافقة الإدارة العامة على تفعيل المتجر.
        </div>
      )}

      {/* Posts List */}
      {posts.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-sq-border bg-sq-surface p-10 text-center">
          <Megaphone className="mx-auto h-10 w-10 text-[#C9A24B]" />
          <h3 className="mt-3 font-display text-base font-extrabold text-sq-ink">
            لم تنشر أي إعلان أو عرض بعد
          </h3>
          <p className="mx-auto mt-1 max-w-md text-xs text-sq-ink-muted">
            أضف منشورات تعريفية، صور بضاعة جديدة، أو عروض يومية مع صورة أو عدة صور لجذب المزيد من الزبائن لصفحة متجرك.
          </p>
          <button
            type="button"
            onClick={openCreateForm}
            className="mt-4 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#121413] px-5 py-2 text-sm font-bold text-[#EBD18E] hover:bg-[#1E2220]"
          >
            <Plus className="h-4 w-4" />
            <span>أنشئ أول منشور لمتجرك</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {posts.map((post) => (
            <StorePostCard
              key={post.id}
              post={post}
              canManage
              onEdit={openEditForm}
              onDelete={(p) => setDeleteTarget(p)}
            />
          ))}
        </div>
      )}

      {/* Post Create / Edit Modal */}
      {showComposer && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={editingPost ? 'تعديل منشور المتجر' : 'إنشاء منشور جديد للمتجر'}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto"
        >
          <div className="my-auto w-full max-w-xl rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#F0ECE0] pb-3">
              <div>
                <h3 className="font-display text-lg font-extrabold text-sq-ink">
                  {editingPost ? 'تعديل المنشور' : 'إنشاء منشور أو عرض جديد'}
                </h3>
                <p className="text-xs text-sq-ink-muted">
                  أضف عنواناً ووصفاً وصورة أو عدة صور (حتى 6 صور)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowComposer(false)}
                aria-label="إغلاق"
                className="flex h-10 w-10 items-center justify-center rounded-xl hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Post Type */}
              <div>
                <label className="mb-1.5 block text-xs font-bold text-sq-ink">
                  نوع المنشور
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {POST_TYPES.map((type) => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setPostType(type)}
                      className={`min-h-[42px] rounded-xl border px-3 py-2 text-xs font-bold transition-colors ${
                        postType === type
                          ? 'border-[#C9A24B] bg-[#121413] text-[#EBD18E]'
                          : 'border-sq-border bg-sq-elevated text-sq-ink-muted hover:text-sq-ink'
                      }`}
                    >
                      {STORE_POST_TYPE_LABELS[type]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Title + Offer Badge */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-xs font-bold text-sq-ink">
                    عنوان المنشور *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={140}
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="مثال: عروض نهاية الأسبوع على المواد الغذائية الطازجة"
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm outline-none focus:border-[#C9A24B] focus:bg-sq-surface"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-bold text-sq-ink">
                    شارة العرض (اختياري)
                  </label>
                  <input
                    type="text"
                    maxLength={40}
                    value={offerBadge}
                    onChange={(e) => setOfferBadge(e.target.value)}
                    placeholder="مثال: خصم 20%"
                    className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm outline-none focus:border-[#C9A24B] focus:bg-sq-surface"
                  />
                </div>
              </div>

              {/* Content */}
              <div>
                <label className="mb-1 block text-xs font-bold text-sq-ink">
                  تفاصيل ووصف المنشور
                </label>
                <textarea
                  rows={4}
                  maxLength={1600}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="اكتب تفاصيل العرض، الأسعار، أوقات التوفر، أو نبذة عن المنتجات الجديدة في متجرك..."
                  className="w-full rounded-xl border border-sq-border bg-sq-elevated p-3 text-sm leading-relaxed outline-none focus:border-[#C9A24B] focus:bg-sq-surface"
                />
              </div>

              {/* Multi-Image Uploader (up to 6 images) */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-sq-ink">
                    صور المنشور ({images.length} / 6)
                  </label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleSelectImages}
                    className="hidden"
                  />
                  <button
                    type="button"
                    disabled={uploadingImages || images.length >= 6}
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[#C9A24B] bg-sq-gold-soft px-3 py-1.5 text-xs font-bold text-[#8A6518] hover:bg-sq-gold-soft disabled:opacity-50"
                  >
                    {uploadingImages ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Camera className="h-4 w-4" />
                    )}
                    <span>{uploadingImages ? 'جاري رفع الصور...' : 'إضافة صورة أو عدة صور'}</span>
                  </button>
                </div>

                {images.length > 0 ? (
                  <div className="grid grid-cols-3 gap-2">
                    {images.map((url, idx) => (
                      <div
                        key={`upload-${idx}-${url}`}
                        className="relative aspect-4/3 overflow-hidden rounded-xl border border-sq-border bg-sq-muted"
                      >
                        <img
                          src={resolveMediaUrl(url)}
                          alt={`صورة ${idx + 1}`}
                          className="h-full w-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(idx)}
                          aria-label="إزالة الصورة"
                          className="absolute top-1.5 left-1.5 flex h-7 w-7 items-center justify-center rounded-full bg-black/75 text-white hover:bg-[#B42318]"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={uploadingImages}
                    onClick={() => fileInputRef.current?.click()}
                    className="flex w-full flex-col items-center justify-center gap-1.5 rounded-2xl border border-dashed border-sq-gold/35 bg-sq-elevated py-6 text-xs text-sq-ink-muted hover:border-[#C9A24B] hover:text-sq-ink"
                  >
                    <Images className="h-6 w-6 text-[#C9A24B]" />
                    <span className="font-semibold">اضغط لاختيار صور من الهاتف أو الجهاز</span>
                    <span className="text-[11px]">يمكنك اختيار حتى 6 صور في المنشور الواحد</span>
                  </button>
                )}
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 border-t border-[#F0ECE0] pt-4">
                <button
                  type="button"
                  onClick={() => setShowComposer(false)}
                  className="min-h-[44px] rounded-xl border border-sq-border px-4 text-xs font-bold text-sq-ink"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={saving || uploadingImages}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#121413] px-5 text-xs sm:text-sm font-extrabold text-[#EBD18E] hover:bg-[#1E2220] disabled:opacity-50"
                >
                  {saving ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4" />
                  )}
                  <span>{editingPost ? 'حفظ التعديلات' : 'نشر المنشور الآن'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteTarget && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4"
        >
          <div className="w-full max-w-sm rounded-2xl bg-sq-surface p-5 shadow-2xl space-y-4">
            <h3 className="font-display text-base font-extrabold text-sq-danger-text">
              تأكيد حذف المنشور
            </h3>
            <p className="text-xs leading-relaxed text-sq-ink-muted">
              هل أنت متأكد من حذف المنشور <strong>«{deleteTarget.title}»</strong>؟ لا يمكن التراجع عن هذه العملية.
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="min-h-[42px] rounded-xl border border-sq-border px-4 text-xs font-bold text-sq-ink"
              >
                تراجع
              </button>
              <button
                type="button"
                disabled={deleting}
                onClick={confirmDelete}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-[#B42318] px-4 text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-50"
              >
                {deleting ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Trash2 className="h-4 w-4" />
                )}
                <span>حذف المنشور</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
