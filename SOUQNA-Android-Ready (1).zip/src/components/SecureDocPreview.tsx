import React, { useEffect, useState } from 'react';
import { Eye, FileText, Lock, X } from 'lucide-react';
import { api } from '../lib/api';

interface SecureDocPreviewProps {
  filename: string;
  label: string;
}

export const SecureDocPreview: React.FC<SecureDocPreviewProps> = ({ filename, label }) => {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [mime, setMime] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [openModal, setOpenModal] = useState(false);

  useEffect(() => {
    return () => {
      if (blobUrl) {
        URL.revokeObjectURL(blobUrl);
      }
    };
  }, [blobUrl]);

  if (!filename) {
    return (
      <div className="rounded-xl border border-dashed border-sq-border bg-sq-elevated px-3 py-2.5 text-xs text-sq-ink-muted">
        {label}: غير مرفق
      </div>
    );
  }

  const handleLoadAndOpen = async () => {
    if (blobUrl) {
      setOpenModal(true);
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await api.fetchPrivateDocBlob(filename);
      setBlobUrl(res.blobUrl);
      setMime(res.mime);
      setOpenModal(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل المستمسك الآمن.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="rounded-xl border border-sq-border bg-sq-elevated p-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Lock className="h-3.5 w-3.5 text-sq-gold-text shrink-0" />
            <span className="truncate text-xs font-semibold text-sq-ink">{label}</span>
          </div>
          <button
            type="button"
            disabled={loading}
            onClick={() => void handleLoadAndOpen()}
            className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-sq-gold/30 bg-sq-surface px-2.5 py-1 text-xs font-semibold text-sq-gold-text hover:bg-sq-gold-soft disabled:opacity-60"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>{loading ? 'جاري التحميل...' : 'معاينة آمنة'}</span>
          </button>
        </div>
        {error && <p className="mt-1.5 text-[11px] font-medium text-sq-danger-text">{error}</p>}
      </div>

      {openModal && blobUrl && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={label}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4 backdrop-blur-xs"
          onClick={() => setOpenModal(false)}
        >
          <div
            className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-sq-border bg-sq-surface shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-sq-border px-4 py-3">
              <div className="flex items-center gap-2">
                <Lock className="h-4 w-4 text-sq-gold-text" />
                <h3 className="text-sm font-bold text-sq-ink">{label}</h3>
              </div>
              <button
                type="button"
                onClick={() => setOpenModal(false)}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-border text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="max-h-[75vh] overflow-auto bg-sq-muted p-4 flex items-center justify-center">
              {mime === 'application/pdf' ? (
                <div className="w-full space-y-3 text-center">
                  <FileText className="mx-auto h-10 w-10 text-sq-gold-text" />
                  <p className="text-xs text-sq-ink-muted">ملف PDF محفوظ بصورة خاصة ومشفرة الصلاحية</p>
                  <iframe
                    src={blobUrl}
                    title={label}
                    className="h-[60vh] w-full rounded-xl border border-sq-border bg-sq-surface"
                  />
                </div>
              ) : (
                <img
                  src={blobUrl}
                  alt={label}
                  className="max-h-[68vh] w-auto rounded-xl border border-sq-border object-contain shadow-sm"
                />
              )}
            </div>
            <div className="border-t border-sq-border bg-sq-elevated px-4 py-2.5 text-[11px] text-sq-ink-muted">
              مستند رسمي محمي — يظهر حصراً للمدير العام المصرح له أو لصاحب المستند فقط.
            </div>
          </div>
        </div>
      )}
    </>
  );
};
