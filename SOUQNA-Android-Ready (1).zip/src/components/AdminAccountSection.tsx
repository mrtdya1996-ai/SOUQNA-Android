import React, { useCallback, useEffect, useState } from 'react';
import {
  CheckCircle2,
  KeyRound,
  Loader2,
  LogOut,
  MonitorSmartphone,
  Save,
  ShieldCheck,
  UserCog,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { api, formatDateAr } from '../lib/api';
import type { AdminAccountSummary } from '../types';

export const AdminAccountSection: React.FC = () => {
  const { user, updateUser, logout, notify } = useApp();
  const [summary, setSummary] = useState<AdminAccountSummary | null>(null);
  const [loading, setLoading] = useState(true);

  // Profile form state
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [governorate, setGovernorate] = useState(user?.governorate || '');
  const [city, setCity] = useState(user?.city || '');
  const [address, setAddress] = useState(user?.address || '');
  const [savingProfile, setSavingProfile] = useState(false);

  // Password form state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);

  // Session revocation state
  const [revokingSessions, setRevokingSessions] = useState(false);

  const loadAccount = useCallback(async () => {
    if (!user || user.role !== 'super_admin') return;
    setLoading(true);
    try {
      const { account } = await api.getAdminAccount();
      setSummary(account);
      setFullName(account.user.fullName);
      setEmail(account.user.email);
      setPhone(account.user.phone);
      setGovernorate(account.user.governorate || '');
      setCity(account.user.city || '');
      setAddress(account.user.address || '');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحميل بيانات حساب المدير العام.', 'error');
    } finally {
      setLoading(false);
    }
  }, [user, notify]);

  useEffect(() => {
    void loadAccount();
  }, [loadAccount]);

  // Strict guard: only visible to verified Super Admin
  if (!user || user.role !== 'super_admin') {
    return null;
  }

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const { user: updated } = await api.updateAdminAccount({
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        governorate: governorate.trim(),
        city: city.trim(),
        address: address.trim(),
      });
      updateUser(updated);
      notify('تم حفظ بيانات حساب المدير العام بنجاح.', 'success');
      await loadAccount();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث بيانات الحساب.', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      notify('كلمة المرور الجديدة يجب أن لا تقل عن 8 أحرف.', 'error');
      return;
    }
    if (newPassword !== confirmPassword) {
      notify('تأكيد كلمة المرور غير مطابق لكلمة المرور الجديدة.', 'error');
      return;
    }
    setSavingPassword(true);
    try {
      const res = await api.updateAdminPassword({
        currentPassword,
        newPassword,
      });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      notify(
        res.revokedOtherSessions > 0
          ? `تم تغيير كلمة مرور المدير العام وإنهاء ${res.revokedOtherSessions} جلسة أخرى بنجاح.`
          : 'تم تغيير كلمة مرور المدير العام بنجاح مع إبقاء جلستك الحالية نشطة.',
        'success'
      );
      await loadAccount();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تغيير كلمة المرور.', 'error');
    } finally {
      setSavingPassword(false);
    }
  };

  const handleRevokeOtherSessions = async () => {
    setRevokingSessions(true);
    try {
      const res = await api.revokeOtherAdminSessions();
      notify(
        res.revokedCount > 0
          ? `تم تسجيل الخروج من ${res.revokedCount} جهاز/جلسة أخرى بنجاح.`
          : 'لا توجد جلسات أخرى نشطة غير جلستك الحالية.',
        'success'
      );
      await loadAccount();
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إنهاء الجلسات الأخرى.', 'error');
    } finally {
      setRevokingSessions(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[200px] items-center justify-center gap-2 text-sm text-sq-ink-muted">
        <Loader2 className="h-5 w-5 animate-spin text-sq-gold-text" />
        <span>جاري تحميل صفحة حساب المدير العام...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Verified Super Admin Identity Banner */}
      <div className="rounded-3xl border border-[#D4AF37]/45 bg-[#0C0E0D] p-5 sm:p-6 text-white shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#D4AF37]/50 bg-[#151817] text-[#E8CB73]">
              <UserCog className="h-6 w-6" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#E8CB73]">
                <ShieldCheck className="h-4 w-4" />
                <span>صلاحية Super Admin موثّقة من قاعدة البيانات</span>
              </div>
              <h2 className="mt-0.5 font-display text-xl font-extrabold text-white">
                {user.fullName}
              </h2>
              <p className="text-xs text-white/70 font-mono" dir="ltr">
                {user.email} · {user.phone}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void logout()}
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl border border-red-500/40 bg-red-950/40 px-4 text-xs font-bold text-red-200 hover:bg-red-900/50"
          >
            <LogOut className="h-4 w-4" />
            <span>تسجيل الخروج من هذا الجهاز</span>
          </button>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5">
            <p className="text-[11px] text-white/65">الجلسات النشطة حالياً</p>
            <p className="mt-1 font-mono text-2xl font-bold text-[#E8CB73] tabular-nums">
              {summary?.activeSessionsCount ?? 1}
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5">
            <p className="text-[11px] text-white/65">إجمالي العمليات الإدارية المسجلة</p>
            <p className="mt-1 font-mono text-2xl font-bold text-white tabular-nums">
              {summary?.totalAuditActions ?? 0}
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3.5">
            <p className="text-[11px] text-white/65">آخر إجراء إداري موثّق</p>
            <p className="mt-1 text-xs font-bold text-white/90">
              {summary?.lastAuditAt ? formatDateAr(summary.lastAuditAt) : 'لم تُسجّل عمليات بعد'}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Super Admin Profile Form */}
        <form
          onSubmit={handleSaveProfile}
          className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-4"
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-sq-gold-text" />
            <div>
              <h3 className="font-display text-base font-extrabold text-sq-ink">
                تعديل بيانات حساب المدير العام
              </h3>
              <p className="text-xs text-sq-ink-muted">
                الاسم والبريد الإلكتروني ورقم الهاتف المستخدمة لتسجيل الدخول
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-sq-ink">الاسم الكامل</label>
              <input
                type="text"
                required
                minLength={2}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  required
                  dir="ltr"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">رقم الهاتف</label>
                <input
                  type="tel"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">المحافظة</label>
                <input
                  type="text"
                  value={governorate}
                  onChange={(e) => setGovernorate(e.target.value)}
                  placeholder="مثال: بغداد"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">المدينة</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="المركز الرئيسي"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="mb-1 block text-xs font-semibold text-sq-ink">
                العنوان الإداري (اختياري)
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="مقر الإدارة أو ملاحظة عنوان"
                className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={savingProfile}
            className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl btn-gold text-xs font-bold disabled:opacity-60"
          >
            {savingProfile ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            <span>حفظ بيانات المدير العام</span>
          </button>
        </form>

        {/* Security: Password Change & Active Sessions */}
        <div className="space-y-5">
          <form
            onSubmit={handleChangePassword}
            className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-4"
          >
            <div className="flex items-center gap-2">
              <KeyRound className="h-5 w-5 text-sq-gold-text" />
              <div>
                <h3 className="font-display text-base font-extrabold text-sq-ink">
                  تغيير كلمة مرور المدير العام
                </h3>
                <p className="text-xs text-sq-ink-muted">
                  تغيير كلمة المرور ينهي تلقائياً أي جلسات مفتوحة على الأجهزة الأخرى
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  كلمة المرور الحالية
                </label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  كلمة المرور الجديدة (8 أحرف على الأقل)
                </label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  تأكيد كلمة المرور الجديدة
                </label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={savingPassword}
              className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl btn-gold text-xs font-bold disabled:opacity-60"
            >
              {savingPassword ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <KeyRound className="h-4 w-4" />
              )}
              <span>تحديث كلمة المرور</span>
            </button>
          </form>

          <div className="rounded-3xl border border-sq-border bg-sq-surface p-5 space-y-3">
            <div className="flex items-center gap-2">
              <MonitorSmartphone className="h-5 w-5 text-sq-gold-text" />
              <div>
                <h3 className="font-display text-sm font-extrabold text-sq-ink">
                  إدارة جلسات الأجهزة الأخرى
                </h3>
                <p className="text-xs text-sq-ink-muted">
                  جلستك الحالية محفوظة تلقائياً. يمكنك إنهاء جميع الجلسات المفتوحة على أي هاتف أو
                  متصفح آخر بضغطة واحدة.
                </p>
              </div>
            </div>

            <button
              type="button"
              disabled={revokingSessions}
              onClick={() => void handleRevokeOtherSessions()}
              className="inline-flex min-h-[42px] w-full items-center justify-center gap-2 rounded-xl border border-sq-gold/45 bg-sq-gold-soft px-4 text-xs font-bold text-sq-gold-text hover:border-sq-gold disabled:opacity-60"
            >
              {revokingSessions ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <ShieldCheck className="h-4 w-4" />
              )}
              <span>تسجيل الخروج من جميع الأجهزة الأخرى</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
