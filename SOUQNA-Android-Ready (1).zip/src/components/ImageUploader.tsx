import React, { useRef, useState } from 'react';
import { Camera, ImagePlus, Loader2, Trash2 } from 'lucide-react';
import { api, compressImageFile, resolveMediaUrl } from '../lib/api';

interface ImageUploaderProps {
  label: string;
  value: string;
  onChange: (url: string) => void;
  aspect?: 'square' | 'wide';
  helperText?: string;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  label,
  value,
  onChange,
  aspect = 'wide',
  helperText,
}) => {
  const galleryRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setError(null);
    setUploading(true);
    try {
      const compressedDataUrl = await compressImageFile(file);
      const { url } = await api.uploadImage(compressedDataUrl);
      onChange(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر رفع الصورة، يرجى المحاولة مجدداً.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <label className="text-sm font-semibold text-sq-ink">{label}</label>
        {value && (
          <button
            type="button"
            onClick={() => onChange('')}
            className="inline-flex items-center gap-1 text-xs font-medium text-sq-danger-text hover:underline"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>إزالة الصورة</span>
          </button>
        )}
      </div>

      <div
        className={`relative overflow-hidden rounded-xl border border-dashed border-sq-border bg-sq-muted ${
          aspect === 'square' ? 'h-40 w-40' : 'h-44 w-full'
        }`}
      >
        {value ? (
          <img
            src={resolveMediaUrl(value)}
            alt={label}
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center p-4 text-center text-sq-ink-muted">
            <ImagePlus className="mb-2 h-7 w-7 text-sq-gold-text" />
            <p className="text-xs font-medium">
              {helperText || 'التقط صورة مباشرة بكاميرا الهاتف أو اختر من المعرض'}
            </p>
          </div>
        )}

        {uploading && (
          <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/50 text-xs font-medium text-white">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span>جاري ضغط ورفع الصورة...</span>
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={uploading}
          onClick={() => cameraRef.current?.click()}
          className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink transition-colors hover:bg-sq-muted disabled:opacity-50 whitespace-nowrap"
        >
          <Camera className="h-4 w-4 text-sq-gold-text" />
          <span>تصوير بالكاميرا</span>
        </button>

        <button
          type="button"
          disabled={uploading}
          onClick={() => galleryRef.current?.click()}
          className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl border border-sq-border bg-sq-surface px-3.5 py-2 text-xs font-semibold text-sq-ink transition-colors hover:bg-sq-muted disabled:opacity-50 whitespace-nowrap"
        >
          <ImagePlus className="h-4 w-4 text-sq-gold-text" />
          <span>اختيار من الهاتف</span>
        </button>
      </div>

      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFile}
        className="hidden"
      />
      <input
        ref={galleryRef}
        type="file"
        accept="image/*"
        onChange={handleFile}
        className="hidden"
      />

      {error && <p className="text-xs font-medium text-sq-danger-text">{error}</p>}
    </div>
  );
};
