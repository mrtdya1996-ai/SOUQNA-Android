import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, Copy, RefreshCw, X } from 'lucide-react';
import { getConfiguredApiBaseUrl, isNativeCapacitorApp } from '../lib/api';
import {
  clearConnectionDiagnostic,
  formatConnectionDiagnosticReport,
  getLastConnectionDiagnostic,
  runLiveConnectivityProbe,
  subscribeConnectionDiagnostic,
  type ConnectionDiagnostic,
  type LiveProbeReport,
} from '../lib/diagnostics';

export const ConnectionDiagnosticBanner: React.FC = () => {
  const [diag, setDiag] = useState<ConnectionDiagnostic | null>(() => getLastConnectionDiagnostic());
  const [probing, setProbing] = useState(false);
  const [probe, setProbe] = useState<LiveProbeReport | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    return subscribeConnectionDiagnostic((next) => {
      setDiag(next);
      if (!next) {
        setProbe(null);
        setCopied(false);
      }
    });
  }, []);

  if (!diag) return null;

  const handleRunProbe = async () => {
    setProbing(true);
    setCopied(false);
    try {
      const report = await runLiveConnectivityProbe(
        getConfiguredApiBaseUrl(),
        isNativeCapacitorApp()
      );
      setProbe(report);
    } finally {
      setProbing(false);
    }
  };

  const handleCopy = () => {
    const text = formatConnectionDiagnosticReport(diag, probe);
    const markCopied = () => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    };
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        void navigator.clipboard.writeText(text).then(markCopied).catch(() => {});
        return;
      }
    } catch {
      // fallback below
    }
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      markCopied();
    } catch {
      // ignore
    }
  };

  return (
    <div
      role="alert"
      className="mb-5 rounded-2xl border border-sq-danger-border bg-sq-surface p-4 sm:p-5 shadow-lg space-y-3"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sq-danger-bg text-sq-danger-text">
            <AlertTriangle className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <h2 className="font-display text-sm sm:text-base font-extrabold text-sq-ink">
              {diag.titleAr}
            </h2>
            <p className="text-xs sm:text-sm text-sq-ink-muted leading-relaxed">
              {diag.messageAr}
            </p>
            <p className="text-xs font-medium text-sq-gold-text leading-relaxed">
              {diag.hintAr}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => clearConnectionDiagnostic()}
          aria-label="إغلاق تنبيه التشخيص"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div
        dir="ltr"
        className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 rounded-xl border border-sq-border bg-sq-muted p-3 font-mono text-[11px] text-sq-ink-muted"
      >
        <div className="truncate">
          <span className="text-sq-ink font-semibold">Code:</span> {diag.code}
        </div>
        <div className="truncate">
          <span className="text-sq-ink font-semibold">HTTP:</span> {diag.status || 'Network/CORS (0)'}
        </div>
        <div className="truncate">
          <span className="text-sq-ink font-semibold">Endpoint:</span> {diag.endpoint}
        </div>
        <div className="truncate">
          <span className="text-sq-ink font-semibold">API Host:</span> {diag.targetOrigin || '(same-origin)'}
        </div>
      </div>

      {probe && (
        <div className="rounded-xl border border-sq-border bg-sq-elevated p-3 space-y-1.5 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-sq-ink">
            {probe.allPassed ? (
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-sq-danger-text" />
            )}
            <span>نتيجة فحص الاتصال المباشر:</span>
          </div>
          {probe.steps.map((step) => (
            <div key={step.name} className="flex flex-wrap items-center justify-between gap-2 text-sq-ink-muted">
              <span className="font-mono text-[11px] text-sq-ink" dir="ltr">
                [{step.ok ? 'OK' : 'FAIL'}] {step.name} ({step.status} · {step.latencyMs}ms)
              </span>
              <span>{step.summary}</span>
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2 pt-0.5">
        <button
          type="button"
          disabled={probing}
          onClick={() => void handleRunProbe()}
          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-bold disabled:opacity-60"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${probing ? 'animate-spin' : ''}`} />
          <span>{probing ? 'جاري فحص الخادم...' : 'إعادة فحص الاتصال بالخادم'}</span>
        </button>
        <button
          type="button"
          onClick={handleCopy}
          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-xs font-semibold text-sq-ink hover:bg-sq-muted"
        >
          <Copy className="h-3.5 w-3.5" />
          <span>{copied ? 'تم نسخ التقرير' : 'نسخ تقرير التشخيص'}</span>
        </button>
      </div>
    </div>
  );
};
