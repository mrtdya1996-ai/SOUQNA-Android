import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Edit3,
  Eye,
  EyeOff,
  FolderKanban,
  Loader2,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import {
  ALL_STORE_TYPES,
  STORE_TYPE_LABELS,
  type MarketplaceCategory,
  type StoreType,
} from '../types';

interface AdminCategoriesSectionProps {
  categories: MarketplaceCategory[];
  onCreateCategory: (payload: {
    name: string;
    description: string;
    storeType: StoreType | 'all';
    sortOrder: number;
    isActive: boolean;
  }) => Promise<boolean>;
  onUpdateCategory: (
    categoryId: string,
    payload: Partial<{
      name: string;
      description: string;
      storeType: StoreType | 'all';
      sortOrder: number;
      isActive: boolean;
    }>
  ) => Promise<boolean>;
  onDeleteCategory: (categoryId: string) => Promise<void>;
}

export const AdminCategoriesSection: React.FC<AdminCategoriesSectionProps> = ({
  categories,
  onCreateCategory,
  onUpdateCategory,
  onDeleteCategory,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  // New Category Form
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newStoreType, setNewStoreType] = useState<StoreType | 'all'>('all');
  const [newSortOrder, setNewSortOrder] = useState(String((categories.length + 1) * 10));
  const [newActive, setNewActive] = useState(true);
  const [creating, setCreating] = useState(false);

  // Edit Modal State
  const [editing, setEditing] = useState<MarketplaceCategory | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editStoreType, setEditStoreType] = useState<StoreType | 'all'>('all');
  const [editSortOrder, setEditSortOrder] = useState('0');
  const [editActive, setEditActive] = useState(true);
  const [savingEdit, setSavingEdit] = useState(false);

  // Delete Confirmation Modal
  const [confirmDelete, setConfirmDelete] = useState<MarketplaceCategory | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return categories.filter((c) => {
      if (statusFilter === 'active' && !c.isActive) return false;
      if (statusFilter === 'inactive' && c.isActive) return false;
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        (c.description || '').toLowerCase().includes(q) ||
        (c.storeType !== 'all' && STORE_TYPE_LABELS[c.storeType].toLowerCase().includes(q))
      );
    });
  }, [categories, search, statusFilter]);

  const activeCount = categories.filter((c) => c.isActive).length;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim().length < 2) return;
    setCreating(true);
    try {
      const ok = await onCreateCategory({
        name: newName.trim(),
        description: newDesc.trim(),
        storeType: newStoreType,
        sortOrder: Math.max(0, Number(newSortOrder) || 0),
        isActive: newActive,
      });
      if (ok) {
        setNewName('');
        setNewDesc('');
        setNewStoreType('all');
        setNewSortOrder(String((categories.length + 2) * 10));
        setNewActive(true);
      }
    } finally {
      setCreating(false);
    }
  };

  const openEditModal = (cat: MarketplaceCategory) => {
    setEditing(cat);
    setEditName(cat.name);
    setEditDesc(cat.description || '');
    setEditStoreType(cat.storeType || 'all');
    setEditSortOrder(String(cat.sortOrder ?? 0));
    setEditActive(cat.isActive);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing || editName.trim().length < 2) return;
    setSavingEdit(true);
    try {
      const ok = await onUpdateCategory(editing.id, {
        name: editName.trim(),
        description: editDesc.trim(),
        storeType: editStoreType,
        sortOrder: Math.max(0, Number(editSortOrder) || 0),
        isActive: editActive,
      });
      if (ok) {
        setEditing(null);
      }
    } finally {
      setSavingEdit(false);
    }
  };

  const handleToggleActive = async (cat: MarketplaceCategory) => {
    setTogglingId(cat.id);
    try {
      await onUpdateCategory(cat.id, { isActive: !cat.isActive });
    } finally {
      setTogglingId(null);
    }
  };

  const handleConfirmDelete = async () => {
    if (!confirmDelete) return;
    setDeleting(true);
    try {
      await onDeleteCategory(confirmDelete.id);
      setConfirmDelete(null);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Summary */}
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-5 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sq-gold-soft text-sq-gold-text">
              <FolderKanban className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-lg font-extrabold text-sq-ink">
                إدارة أقسام وتصنيفات المنتجات
              </h2>
              <p className="text-xs text-sq-ink-muted">
                أضف أقساماً جديدة، عدّل أسماءها وترتيبها، أو عطّلها واحذفها — تظهر تلقائياً في
                الكتالوج ولوحة التجار
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold">
            <span className="rounded-xl border border-sq-gold/40 bg-sq-gold-soft px-3 py-1.5 text-sq-gold-text tabular-nums">
              {activeCount} مفعّل
            </span>
            <span className="rounded-xl border border-sq-border bg-sq-elevated px-3 py-1.5 text-sq-ink-muted tabular-nums">
              الإجمالي: {categories.length}
            </span>
          </div>
        </div>

        {/* Add New Category Form */}
        <form
          onSubmit={handleCreate}
          className="rounded-2xl border border-sq-gold/30 bg-sq-elevated p-4 space-y-3"
        >
          <div className="flex items-center gap-1.5 text-xs font-bold text-sq-gold-text">
            <Plus className="h-4 w-4" />
            <span>إضافة قسم جديد</span>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                اسم القسم *
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="مثال: عطور ومستحضرات فاخرة"
                className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                النشاط التجاري المرتبط
              </label>
              <select
                value={newStoreType}
                onChange={(e) => setNewStoreType(e.target.value as StoreType | 'all')}
                className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
              >
                <option value="all">عام (لجميع المتاجر)</option>
                {ALL_STORE_TYPES.map((st) => (
                  <option key={st} value={st}>
                    {STORE_TYPE_LABELS[st]}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                وصف مختصر (اختياري)
              </label>
              <input
                type="text"
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="وصف يظهر للتوضيح الإداري"
                className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                ترتيب الظهور
              </label>
              <input
                type="number"
                min={0}
                max={9999}
                value={newSortOrder}
                onChange={(e) => setNewSortOrder(e.target.value)}
                className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <label className="inline-flex cursor-pointer items-center gap-2 text-xs font-semibold text-sq-ink">
              <input
                type="checkbox"
                checked={newActive}
                onChange={(e) => setNewActive(e.target.checked)}
                className="h-4 w-4 accent-[#D4AF37]"
              />
              <span>تفعيل القسم فوراً للعرض في التطبيق</span>
            </label>

            <button
              type="submit"
              disabled={creating || newName.trim().length < 2}
              className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl btn-gold px-5 text-xs font-bold disabled:opacity-60"
            >
              {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              <span>إضافة القسم</span>
            </button>
          </div>
        </form>
      </div>

      {/* Filter & List */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 rounded-xl bg-sq-muted p-1">
            {(
              [
                { id: 'all', label: `الكل (${categories.length})` },
                { id: 'active', label: `المفعّلة (${activeCount})` },
                { id: 'inactive', label: `المعطّلة (${categories.length - activeCount})` },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setStatusFilter(opt.id)}
                className={`min-h-[36px] rounded-lg px-3 text-xs font-semibold transition-colors ${
                  statusFilter === opt.id
                    ? 'bg-sq-surface text-sq-ink shadow-xs'
                    : 'text-sq-ink-muted hover:text-sq-ink'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-sq-ink-muted" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث باسم القسم أو النشاط..."
              className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface pr-9 pl-3 text-xs focus:border-sq-gold focus:outline-none"
            />
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-sq-border bg-sq-surface p-8 text-center text-sm text-sq-ink-muted">
            لا توجد أقسام مطابقة لخيارات البحث الحالية.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {filtered.map((cat) => (
              <div
                key={cat.id}
                className={`rounded-2xl border p-4 transition-colors ${
                  cat.isActive
                    ? 'border-sq-border bg-sq-surface'
                    : 'border-sq-border/70 bg-sq-elevated/70 opacity-80'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-display text-sm sm:text-base font-bold text-sq-ink">
                        {cat.name}
                      </h3>
                      <span
                        className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                          cat.isActive
                            ? 'bg-sq-gold-soft text-sq-gold-text'
                            : 'bg-sq-muted text-sq-ink-muted'
                        }`}
                      >
                        {cat.isActive ? 'مفعّل' : 'معطّل'}
                      </span>
                    </div>
                    {cat.description && (
                      <p className="text-xs text-sq-ink-muted leading-relaxed">{cat.description}</p>
                    )}
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-sq-ink-muted tabular-nums">
                      <span>
                        النشاط:{' '}
                        <strong className="text-sq-ink">
                          {cat.storeType === 'all'
                            ? 'عام للجميع'
                            : STORE_TYPE_LABELS[cat.storeType]}
                        </strong>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>المنتجات المرتبطة: {cat.productCount ?? 0}</span>
                      <span aria-hidden="true">·</span>
                      <span>الترتيب: #{cat.sortOrder}</span>
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-1.5">
                    <button
                      type="button"
                      disabled={togglingId === cat.id}
                      onClick={() => void handleToggleActive(cat)}
                      title={cat.isActive ? 'تعطيل القسم' : 'تفعيل القسم'}
                      className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-border bg-sq-elevated text-sq-ink hover:border-sq-gold hover:text-sq-gold-text disabled:opacity-50"
                    >
                      {togglingId === cat.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : cat.isActive ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4 text-sq-gold-text" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => openEditModal(cat)}
                      title="تعديل القسم"
                      className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-border bg-sq-elevated text-sq-ink hover:border-sq-gold hover:text-sq-gold-text"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setConfirmDelete(cat)}
                      title="حذف القسم"
                      className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-danger-border bg-sq-danger-bg/50 text-sq-danger-text hover:bg-sq-danger-bg"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Edit Category Modal */}
      {editing && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 p-0 sm:p-4 backdrop-blur-xs"
        >
          <form
            onSubmit={handleSaveEdit}
            className="w-full max-w-md rounded-t-3xl sm:rounded-2xl border border-sq-border bg-sq-surface p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-sq-border pb-3">
              <h3 className="font-display text-base font-extrabold text-sq-ink">
                تعديل القسم: {editing.name}
              </h3>
              <button
                type="button"
                onClick={() => setEditing(null)}
                aria-label="إغلاق"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-sq-ink-muted hover:bg-sq-muted"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">اسم القسم *</label>
                <input
                  type="text"
                  required
                  minLength={2}
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
                />
                <p className="mt-1 text-[11px] text-sq-ink-muted">
                  تعديل الاسم يحدّث تلقائياً تصنيف المنتجات المرتبطة به.
                </p>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">
                  النشاط التجاري المرتبط
                </label>
                <select
                  value={editStoreType}
                  onChange={(e) => setEditStoreType(e.target.value as StoreType | 'all')}
                  className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs font-semibold text-sq-ink focus:border-sq-gold focus:outline-none"
                >
                  <option value="all">عام (لجميع المتاجر)</option>
                  {ALL_STORE_TYPES.map((st) => (
                    <option key={st} value={st}>
                      {STORE_TYPE_LABELS[st]}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-sq-ink">الوصف</label>
                <input
                  type="text"
                  value={editDesc}
                  onChange={(e) => setEditDesc(e.target.value)}
                  className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 items-end">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-sq-ink">
                    ترتيب الظهور
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={9999}
                    value={editSortOrder}
                    onChange={(e) => setEditSortOrder(e.target.value)}
                    className="min-h-[42px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3 font-mono text-xs text-sq-ink focus:border-sq-gold focus:outline-none"
                  />
                </div>
                <label className="flex min-h-[42px] cursor-pointer items-center gap-2 rounded-xl border border-sq-border bg-sq-elevated px-3 text-xs font-semibold text-sq-ink">
                  <input
                    type="checkbox"
                    checked={editActive}
                    onChange={(e) => setEditActive(e.target.checked)}
                    className="h-4 w-4 accent-[#D4AF37]"
                  />
                  <span>القسم مفعّل</span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink"
              >
                إلغاء
              </button>
              <button
                type="submit"
                disabled={savingEdit}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl btn-gold text-xs font-bold disabled:opacity-60"
              >
                {savingEdit ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" />
                )}
                <span>حفظ التعديلات</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Confirm Delete Category Modal */}
      {confirmDelete && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 p-0 sm:p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-sm rounded-t-3xl sm:rounded-2xl border border-sq-border bg-sq-surface p-6 shadow-2xl space-y-4">
            <h3 className="font-display text-base font-extrabold text-sq-danger-text">
              تأكيد حذف القسم
            </h3>
            <p className="text-xs leading-relaxed text-sq-ink-muted">
              هل أنت متأكد من حذف قسم «<strong>{confirmDelete.name}</strong>»؟
              {(confirmDelete.productCount ?? 0) > 0 && (
                <>
                  {' '}
                  علماً أنه مرتبط حالياً بـ <strong>{confirmDelete.productCount}</strong> منتج (لن
                  تُحذف المنتجات نفسها).
                </>
              )}
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setConfirmDelete(null)}
                className="min-h-[44px] rounded-xl border border-sq-border bg-sq-surface text-xs font-semibold text-sq-ink"
              >
                إلغاء
              </button>
              <button
                type="button"
                disabled={deleting}
                onClick={() => void handleConfirmDelete()}
                className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl bg-[#B42318] text-xs font-bold text-white hover:bg-[#912018] disabled:opacity-60"
              >
                {deleting && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>تأكيد الحذف</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
