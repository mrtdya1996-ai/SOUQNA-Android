import React, { useMemo, useState } from 'react';
import { CheckCircle2, Gamepad2, ShoppingCart, UserCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { formatPrice } from '../lib/api';
import type { Product, Store } from '../types';

interface GameTopupPanelProps {
  store: Store;
  products: Product[];
  isOwnStore: boolean;
}

export const GameTopupPanel: React.FC<GameTopupPanelProps> = ({ store, products, isOwnStore }) => {
  const { bootstrapStatus, addToCart, navigate, notify } = useApp();
  const currency = bootstrapStatus.currency;

  const gameGroups = useMemo(() => {
    const map = new Map<string, Product[]>();
    for (const p of products) {
      const g = (p.gameName || p.category || 'ألعاب أخرى').trim();
      const arr = map.get(g) || [];
      arr.push(p);
      map.set(g, arr);
    }
    return Array.from(map.entries());
  }, [products]);

  const [selectedGame, setSelectedGame] = useState<string>(gameGroups[0]?.[0] || '');
  const activeGame = gameGroups.some(([g]) => g === selectedGame)
    ? selectedGame
    : gameGroups[0]?.[0] || '';

  const activePackages = useMemo(
    () => gameGroups.find(([g]) => g === activeGame)?.[1] || [],
    [gameGroups, activeGame]
  );

  const [selectedPkgId, setSelectedPkgId] = useState<string>('');
  const selectedPkg = useMemo(
    () => activePackages.find((p) => p.id === selectedPkgId) || activePackages[0] || null,
    [activePackages, selectedPkgId]
  );

  const [playerId, setPlayerId] = useState('');
  const [playerNickname, setPlayerNickname] = useState('');

  if (products.length === 0) {
    return (
      <section className="bg-sq-surface border border-stone-200 rounded-2xl p-6 text-center space-y-2">
        <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-800 flex items-center justify-center mx-auto">
          <Gamepad2 className="w-6 h-6" />
        </div>
        <h2 className="text-base font-extrabold text-stone-900">
          لم يقم المتجر بإضافة باقات شحن الألعاب بعد
        </h2>
        <p className="text-xs sm:text-sm text-stone-500">
          عند إضافة باقات PUBG Mobile أو Free Fire من قِبل صاحب المتجر ستظهر هنا للطلب المباشر عبر معرّف اللاعب (ID).
        </p>
      </section>
    );
  }

  const handleAction = (goToCheckout: boolean) => {
    if (!selectedPkg) {
      notify('يرجى اختيار باقة الشحن المطلوبة.', 'error');
      return;
    }
    if (selectedPkg.stockQty <= 0) {
      notify('عذراً، هذه الباقة غير متوفرة حالياً.', 'error');
      return;
    }
    const cleanId = playerId.trim();
    if (cleanId.length < 4) {
      notify('يرجى إدخال معرّف اللاعب (Player ID) بشكل صحيح (4 أحرف أو أرقام على الأقل).', 'error');
      return;
    }

    addToCart(
      selectedPkg,
      {
        id: store.id,
        name: store.name,
        deliveryFee: store.deliveryFee,
        address: [store.city, store.district, store.address].filter(Boolean).join('، '),
      },
      'unit',
      {
        gameName: selectedPkg.gameName || activeGame,
        playerId: cleanId,
        ...(playerNickname.trim() ? { selectedOption: `اسم الحساب: ${playerNickname.trim()}` } : {}),
      }
    );

    if (goToCheckout) {
      navigate('cart');
    }
  };

  return (
    <section className="bg-sq-surface border border-stone-200 rounded-2xl p-4 sm:p-6 space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-100 pb-4">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
            <Gamepad2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-stone-900">شحن الألعاب الإلكترونية المباشر</h2>
            <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
              اختر اللعبة والباقة المناسبة، أدخل معرّف اللاعب (Player ID)، وراجع السعر قبل تأكيد الطلب
            </p>
          </div>
        </div>
      </div>

      {/* Step 1: Select Game */}
      <div className="space-y-2">
        <label className="block text-sm font-bold text-stone-800">1. اختر اللعبة</label>
        <div className="flex flex-wrap gap-2">
          {gameGroups.map(([gameName, list]) => (
            <button
              key={gameName}
              type="button"
              onClick={() => {
                setSelectedGame(gameName);
                setSelectedPkgId(list[0]?.id || '');
              }}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold border transition ${
                activeGame === gameName
                  ? 'bg-emerald-800 text-white border-emerald-800'
                  : 'bg-stone-50 text-stone-800 border-stone-200 hover:border-emerald-700'
              }`}
            >
              {gameName} ({list.length})
            </button>
          ))}
        </div>
      </div>

      {/* Step 2: Select Package */}
      <div className="space-y-2">
        <label className="block text-sm font-bold text-stone-800">2. اختر الباقة المطلوبة</label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {activePackages.map((pkg) => {
            const isSelected = selectedPkg?.id === pkg.id;
            const outOfStock = pkg.stockQty <= 0;
            return (
              <button
                key={pkg.id}
                type="button"
                disabled={outOfStock}
                onClick={() => setSelectedPkgId(pkg.id)}
                className={`p-3.5 rounded-xl border text-right transition flex items-center justify-between gap-3 disabled:opacity-50 ${
                  isSelected
                    ? 'border-emerald-700 bg-emerald-50/60 ring-2 ring-emerald-700/15'
                    : 'border-stone-200 bg-sq-surface hover:border-stone-300'
                }`}
              >
                <div className="min-w-0">
                  <p className="text-sm font-extrabold text-stone-900 truncate">{pkg.name}</p>
                  {pkg.description && (
                    <p className="text-xs text-stone-500 line-clamp-1 mt-0.5">{pkg.description}</p>
                  )}
                  <p className="text-[11px] font-semibold text-stone-500 mt-1">
                    {outOfStock ? 'غير متوفرة حالياً' : `متوفرة (${pkg.stockQty})`}
                  </p>
                </div>
                <div className="text-left shrink-0">
                  <p className="text-sm sm:text-base font-extrabold text-emerald-800">
                    {formatPrice(pkg.price, currency)}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Step 3: Player ID + Pre-confirmation Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 pt-3 border-t border-stone-100">
        <div className="lg:col-span-7 space-y-3">
          <label className="block text-sm font-bold text-stone-800">
            3. أدخل بيانات حساب اللعبة
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-600 mb-1">
                معرّف اللاعب (Player ID) <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                value={playerId}
                onChange={(e) => setPlayerId(e.target.value)}
                placeholder="مثال: 5123456789"
                dir="ltr"
                className="w-full h-11 rounded-xl border border-stone-200 px-3 text-sm font-mono text-right bg-sq-surface focus:border-emerald-700 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-600 mb-1">
                اسم اللاعب داخل اللعبة (اختياري للتأكيد)
              </label>
              <input
                type="text"
                value={playerNickname}
                onChange={(e) => setPlayerNickname(e.target.value)}
                placeholder="مثال: Ahmed_IQ"
                className="w-full h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
              />
            </div>
          </div>
          <p className="text-xs text-stone-500 flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>يرجى التأكد من صحة رقم الـ ID بدقة قبل إرسال الطلب لضمان وصول الشحن لحسابك الصحيح.</span>
          </p>
        </div>

        <div className="lg:col-span-5 bg-stone-50 border border-stone-200 rounded-2xl p-4 flex flex-col justify-between gap-3">
          <div className="space-y-1.5 text-sm">
            <p className="text-xs font-bold text-stone-500">ملخص طلب الشحن قبل التأكيد</p>
            <div className="flex justify-between">
              <span className="text-stone-600">اللعبة:</span>
              <span className="font-bold text-stone-900">{activeGame || '—'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-600">الباقة:</span>
              <span className="font-bold text-stone-900">{selectedPkg?.name || '—'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-600">معرّف اللاعب (ID):</span>
              <span className="font-mono font-bold text-stone-900" dir="ltr">
                {playerId.trim() || 'لم يُدخل بعد'}
              </span>
            </div>
            <div className="border-t border-stone-200 pt-2 flex justify-between items-center">
              <span className="font-extrabold text-stone-900">السعر (الدفع نقداً):</span>
              <span className="text-lg font-extrabold text-emerald-800">
                {selectedPkg ? formatPrice(selectedPkg.price, currency) : '—'}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              disabled={isOwnStore || !selectedPkg || selectedPkg.stockQty <= 0}
              onClick={() => handleAction(true)}
              className="flex-1 min-h-[44px] bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-1.5 transition disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>تأكيد الطلب الآن</span>
            </button>
            <button
              type="button"
              disabled={isOwnStore || !selectedPkg || selectedPkg.stockQty <= 0}
              onClick={() => handleAction(false)}
              className="min-h-[44px] px-3.5 bg-sq-surface border border-stone-200 hover:border-emerald-700 text-stone-800 font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-1.5 transition disabled:opacity-50"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>أضف للسلة</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
