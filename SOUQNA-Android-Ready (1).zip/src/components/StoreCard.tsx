import React, { useState } from 'react';
import {
  ArrowLeft,
  BadgeCheck,
  Clock,
  MapPin,
  Megaphone,
  Store as StoreIcon,
} from 'lucide-react';
import { formatPrice, resolveMediaUrl } from '../lib/api';
import { STORE_CATEGORY_META } from '../lib/storeCategories';
import { STORE_POST_TYPE_LABELS, STORE_TYPE_LABELS, type Store } from '../types';

interface StoreCardProps {
  store: Store;
  currency: string;
  isOwnStore?: boolean;
  onOpen: (storeId: string) => void;
}

export const StoreCard: React.FC<StoreCardProps> = ({
  store,
  currency,
  isOwnStore,
  onOpen,
}) => {
  const [imgError, setImgError] = useState(false);
  const [logoError, setLogoError] = useState(false);
  const categoryMeta = STORE_CATEGORY_META[store.storeType] || STORE_CATEGORY_META.shop;
  const CategoryIcon = categoryMeta.icon;
  const displayCover =
    store.coverUrl && !imgError ? resolveMediaUrl(store.coverUrl) : categoryMeta.imageUrl;
  const latestPost = store.latestPost;
  const postCount = store.postCount ?? 0;

  return (
    <button
      type="button"
      onClick={() => onOpen(store.id)}
      className="group flex flex-col overflow-hidden rounded-2xl border border-sq-border bg-sq-surface text-right shadow-xs transition-all duration-200 hover:-translate-y-0.5 hover:border-sq-gold/60 hover:shadow-xl active:scale-[0.988] focus-visible:outline-2 focus-visible:outline-sq-gold"
    >
      {/* Post-Style Store Header Bar (Logo + Store Name + Category) */}
      <div className="flex items-center justify-between gap-3 border-b border-sq-border/70 px-4 py-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-[#D4AF37]/60 bg-[#121413]">
            {store.logoUrl && !logoError ? (
              <img
                src={resolveMediaUrl(store.logoUrl)}
                alt={`شعار ${store.name}`}
                referrerPolicy="no-referrer"
                onError={() => setLogoError(true)}
                className="h-full w-full object-cover"
              />
            ) : (
              <StoreIcon className="h-5 w-5 text-[#D4AF37]" />
            )}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h3 className="font-display text-base font-extrabold text-sq-ink truncate">
                {store.name}
              </h3>
              {store.isVerified && (
                <BadgeCheck
                  className="h-4 w-4 shrink-0 text-sq-gold"
                  aria-label="متجر موثق"
                />
              )}
            </div>
            <p className="mt-0.5 flex items-center gap-1.5 text-[11px] text-sq-ink-muted truncate">
              <span className="font-semibold text-sq-gold-text">
                {STORE_TYPE_LABELS[store.storeType]}
              </span>
              <span aria-hidden="true">·</span>
              <span className="truncate">
                {store.city}
                {store.district ? ` — ${store.district}` : ''}
              </span>
            </p>
          </div>
        </div>

        {isOwnStore && (
          <span className="shrink-0 rounded-lg bg-sq-gold-soft border border-sq-gold/40 px-2 py-0.5 text-[10px] font-extrabold text-sq-gold-text">
            متجرك
          </span>
        )}
      </div>

      {/* Full-Bleed Luxury Store Cover Image */}
      <div className="relative aspect-16/10 w-full overflow-hidden bg-[#121413]">
        <img
          src={displayCover}
          alt={store.name}
          referrerPolicy="no-referrer"
          onError={() => {
            if (!imgError) setImgError(true);
          }}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#090A0A]/75 via-transparent to-transparent" />
        <div className="absolute bottom-2.5 right-3 left-3 flex items-center justify-between gap-2 text-[11px] text-white">
          <span className="inline-flex items-center gap-1 truncate font-medium">
            <MapPin className="h-3.5 w-3.5 shrink-0 text-[#D4AF37]" />
            <span className="truncate">{store.address}</span>
          </span>
          <span className="inline-flex items-center gap-1 shrink-0 font-semibold text-[#E8CB73]">
            <CategoryIcon className="h-3.5 w-3.5" />
            <span>{categoryMeta.shortTitle}</span>
          </span>
        </div>
      </div>

      {/* Post-Style Body: Intro + Latest Post Preview */}
      <div className="flex flex-1 flex-col p-4 space-y-3">
        <p className="text-xs leading-relaxed text-sq-secondary line-clamp-2">
          {store.description || categoryMeta.subtitle}
        </p>

        {latestPost ? (
          <div className="rounded-xl border border-sq-gold/30 bg-sq-gold-soft p-3 space-y-1">
            <div className="flex items-center justify-between gap-2 text-[11px]">
              <span className="inline-flex items-center gap-1 font-bold text-sq-gold-text">
                <Megaphone className="h-3.5 w-3.5 shrink-0" />
                <span>{STORE_POST_TYPE_LABELS[latestPost.postType]}</span>
              </span>
              <span className="font-bold text-sq-gold-text tabular-nums">
                {latestPost.offerBadge || `${postCount} منشور`}
              </span>
            </div>
            <p className="text-xs font-extrabold text-sq-ink line-clamp-1">{latestPost.title}</p>
            {latestPost.content && (
              <p className="text-[11px] text-sq-ink-muted line-clamp-1">{latestPost.content}</p>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-between text-[11px] text-sq-ink-muted">
            <span className="inline-flex items-center gap-1 truncate">
              <Clock className="h-3.5 w-3.5 shrink-0 text-sq-gold-text" />
              <span className="truncate">{store.openingHours || 'مفتوح يومياً'}</span>
            </span>
            <span className="shrink-0 font-bold text-sq-ink tabular-nums">
              {store.deliveryFee > 0 ? `توصيل ${formatPrice(store.deliveryFee, currency)}` : 'توصيل مجاني'}
            </span>
          </div>
        )}

        <div className="mt-auto pt-2.5 border-t border-sq-border flex items-center justify-between gap-2 text-xs">
          <span className="text-[11px] text-sq-ink-muted tabular-nums">
            {postCount > 0 ? `${postCount} منشور وعرض` : store.openingHours || 'مفتوح يومياً'}
          </span>

          <span className="inline-flex shrink-0 items-center gap-1 font-extrabold text-sq-gold-text">
            <span>زيارة صفحة المتجر</span>
            <ArrowLeft className="h-3.5 w-3.5 transition-transform group-hover:-translate-x-0.5" />
          </span>
        </div>
      </div>
    </button>
  );
};
