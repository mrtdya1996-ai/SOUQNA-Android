import React, { useEffect, useState } from 'react';
import { CreditCard, Layers, Loader2, Save, Settings2, Sparkles } from 'lucide-react';
import { formatPrice } from '../lib/api';
import {
  ALL_STORE_TYPES,
  CURRENCY_OPTIONS,
  STORE_PLAN_LABELS,
  STORE_TYPE_LABELS,
  SUBSCRIPTION_STATUS_LABELS,
  type PlatformOverview,
  type Store,
  type StorePlanName,
  type StoreSubscription,
  type StoreSubscriptionStatus,
  type StoreType,
} from '../types';

interface AdminSettingsSectionProps {
  overview: PlatformOverview | null;
  stores: Store[];
  subscriptions: StoreSubscription[];
  currency: string;
  savingSettings: boolean;
  onUpdateSettings: (payload: {
    requireStoreApproval?: boolean;
    requireCourierApproval?: boolean;
    currency?: string;
    enabledStoreTypes?: StoreType[];
    trialDays?: number;
    appName?: string;
    supportPhone?: string;
    supportTelegram?: string;
    announcementText?: string;
  }) => Promise<void>;
  onUpdateSubscription: (
    storeId: string,
    payload: {
      planName: StorePlanName;
      status: StoreSubscriptionStatus;
      monthlyFee: number;
      expiresAt?: string;
      notes?: string;
    }
  ) => Promise<void>;
}

interface SubDraft {
  planName: StorePlanName;
  status: StoreSubscriptionStatus;
  monthlyFee: string;
  expiresAt: string;
  notes: string;
}

export const AdminSettingsSection: React.FC<AdminSettingsSectionProps> = ({
  overview,
  stores,
  subscriptions,
  currency,
  savingSettings,
  onUpdateSettings,
  onUpdateSubscription,
}) => {
  const [enabledTypes, setEnabledTypes] = useState<StoreType[]>(
    overview?.enabledStoreTypes && overview.enabledStoreTypes.length > 0
      ? overview.enabledStoreTypes
      : ALL_STORE_TYPES
  );
  const [trialDaysInput, setTrialDaysInput] = useState(String(overview?.trialDays ?? 30));
  const [appNameInput, setAppNameInput] = useState(overview?.appName || 'سوقنا | SOUQNA');
  const [supportPhoneInput, setSupportPhoneInput] = useState(
    overview?.supportPhone || '07764327688'
  );
  const [supportTelegramInput, setSupportTelegramInput] = useState(
    overview?.supportTelegram || '@murtadaa1996'
  );
  const [announcementInput, setAnnouncementInput] = useState(overview?.announcementText || '');
  const [drafts, setDrafts] = useState<Record<string, SubDraft>>({});
  const [savingSubId, setSavingSubId] = useState<string | null>(null);

  useEffect(() => {
    if (overview?.enabledStoreTypes && overview.enabledStoreTypes.length > 0) {
      setEnabledTypes(overview.enabledStoreTypes);
    }
    if (overview?.trialDays !== undefined) {
      setTrialDaysInput(String(overview.trialDays));
    }
    if (overview?.appName) {
      setAppNameInput(overview.appName);
    }
    if (overview?.supportPhone !== undefined) {
      setSupportPhoneInput(overview.supportPhone);
    }
    if (overview?.supportTelegram !== undefined) {
      setSupportTelegramInput(overview.supportTelegram);
    }
    if (overview?.announcementText !== undefined) {
      setAnnouncementInput(overview.announcementText);
    }
  }, [overview]);

  const getDraft = (store: Store): SubDraft => {
    if (drafts[store.id]) return drafts[store.id];
    const sub = subscriptions.find((s) => s.storeId === store.id) || store.subscription;
    return {
      planName: sub?.planName || 'free',
      status: sub?.status || 'active',
      monthlyFee: String(sub?.monthlyFee ?? 0),
      expiresAt: sub?.expiresAt ? sub.expiresAt.slice(0, 10) : '',
      notes: sub?.notes || '',
    };
  };

  const setStoreDraft = (store: Store, patch: Partial<SubDraft>) => {
    const base = getDraft(store);
    setDrafts((prev) => ({ ...prev, [store.id]: { ...base, ...patch } }));
  };

  const toggleCategory = (typeKey: StoreType) => {
    setEnabledTypes((prev) => {
      if (prev.includes(typeKey)) {
        if (prev.length <= 1) return prev; // Keep at least 1 category active
        return prev.filter((x) => x !== typeKey);
      }
      return [...prev, typeKey];
    });
  };

  const handleSaveSubscription = async (store: Store) => {
    const d = getDraft(store);
    setSavingSubId(store.id);
    try {
      await onUpdateSubscription(store.id, {
        planName: d.planName,
        status: d.status,
        monthlyFee: Math.max(0, Number(d.monthlyFee) || 0),
        expiresAt: d.expiresAt.trim() ? `${d.expiresAt.trim()}T23:59:59Z` : undefined,
        notes: d.notes.trim(),
      });
    } finally {
      setSavingSubId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* General Settings & Approval Policies */}
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-6 space-y-5">
        <div className="flex items-center gap-2">
          <Settings2 className="h-5 w-5 text-sq-gold-text" />
          <h2 className="font-display text-lg font-bold text-sq-ink">
            إعدادات المنصة وسياسات الموافقة
          </h2>
        </div>

        <div className="max-w-md">
          <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
            العملة الافتراضية للأسعار النقدية
          </label>
          <select
            disabled={savingSettings}
            value={currency}
            onChange={(e) => void onUpdateSettings({ currency: e.target.value })}
            className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm focus:border-sq-gold focus:outline-none"
          >
            {CURRENCY_OPTIONS.map((opt) => (
              <option key={opt.code} value={opt.code}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <label className="flex cursor-pointer items-start gap-3 rounded-2xl border border-sq-border bg-sq-elevated p-4">
            <input
              type="checkbox"
              disabled={savingSettings}
              checked={Boolean(overview?.requireStoreApproval)}
              onChange={(e) =>
                void onUpdateSettings({ requireStoreApproval: e.target.checked })
              }
              className="mt-1 h-4 w-4 accent-[#D4AF37]"
            />
            <span className="text-xs sm:text-sm leading-relaxed text-sq-ink">
              <strong>اشتراط موافقة المدير العام قبل نشر المتاجر الجديدة</strong>
              <span className="mt-0.5 block text-xs text-sq-ink-muted">
                عند التفعيل، يدخل كل متجر جديد بحالة «قيد المراجعة» حتى تقوم بقبوله.
              </span>
            </span>
          </label>

          <label className="flex cursor-pointer items-start gap-3 rounded-2xl border border-sq-border bg-sq-elevated p-4">
            <input
              type="checkbox"
              disabled={savingSettings}
              checked={Boolean(overview?.requireCourierApproval ?? true)}
              onChange={(e) =>
                void onUpdateSettings({ requireCourierApproval: e.target.checked })
              }
              className="mt-1 h-4 w-4 accent-[#D4AF37]"
            />
            <span className="text-xs sm:text-sm leading-relaxed text-sq-ink">
              <strong>اشتراط توثيق المدير العام قبل تفعيل المندوبين</strong>
              <span className="mt-0.5 block text-xs text-sq-ink-muted">
                يمنع المندوب الجديد من استقبال طلبات التوصيل حتى مراجعة هويته والموافقة عليه.
              </span>
            </span>
          </label>
        </div>
      </div>

      {/* App Identity, Free Trial Duration & Support Settings */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const parsedDays = Math.max(0, Math.min(365, Math.floor(Number(trialDaysInput) || 0)));
          void onUpdateSettings({
            trialDays: parsedDays,
            appName: appNameInput.trim() || 'سوقنا | SOUQNA',
            supportPhone: supportPhoneInput.trim(),
            supportTelegram: supportTelegramInput.trim(),
            announcementText: announcementInput.trim(),
          });
        }}
        className="rounded-3xl border border-sq-border bg-sq-surface p-6 space-y-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-sq-gold-text" />
            <div>
              <h2 className="font-display text-lg font-bold text-sq-ink">
                مدة التجربة المجانية وإعدادات التطبيق والدعم
              </h2>
              <p className="text-xs text-sq-ink-muted">
                تحكّم بمدة التجربة المجانية للحسابات التجارية الجديدة (المتاجر والمندوبون) وبيانات
                التواصل الرسمية — الزبون العادي مجاني دائماً
              </p>
            </div>
          </div>

          <button
            type="submit"
            disabled={savingSettings}
            className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold disabled:opacity-60"
          >
            {savingSettings ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            <span>حفظ إعدادات التطبيق</span>
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
              مدة التجربة المجانية للمتاجر والمندوبين الجدد (بالأيام)
            </label>
            <input
              type="number"
              min={0}
              max={365}
              value={trialDaysInput}
              onChange={(e) => setTrialDaysInput(e.target.value)}
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 font-mono text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
            />
            <p className="mt-1 text-[11px] text-sq-ink-muted">
              القيمة الافتراضية 30 يوماً. إدخال 0 يعني اشتراك مدفوع مباشرة دون فترة تجريبية.
            </p>
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
              اسم التطبيق الرسمي
            </label>
            <input
              type="text"
              minLength={2}
              maxLength={80}
              value={appNameInput}
              onChange={(e) => setAppNameInput(e.target.value)}
              placeholder="سوقنا | SOUQNA"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
              رقم الدعم الفني / واتساب
            </label>
            <input
              type="text"
              dir="ltr"
              value={supportPhoneInput}
              onChange={(e) => setSupportPhoneInput(e.target.value)}
              placeholder="07764327688"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
              حساب تيليجرام الدعم الرسمي
            </label>
            <input
              type="text"
              dir="ltr"
              value={supportTelegramInput}
              onChange={(e) => setSupportTelegramInput(e.target.value)}
              placeholder="@murtadaa1996"
              className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-left font-mono text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="mb-1.5 block text-xs font-semibold text-sq-ink">
            رسالة تنبيه أو إعلان إداري عام (اختياري)
          </label>
          <input
            type="text"
            maxLength={240}
            value={announcementInput}
            onChange={(e) => setAnnouncementInput(e.target.value)}
            placeholder="مثال: أهلاً بكم في سوقنا — التوصيل متاح طوال أيام الأسبوع"
            className="min-h-[44px] w-full rounded-xl border border-sq-border bg-sq-elevated px-3.5 text-sm text-sq-ink focus:border-sq-gold focus:outline-none"
          />
        </div>
      </form>

      {/* Store Categories Management */}
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Layers className="h-5 w-5 text-sq-gold-text" />
            <div>
              <h2 className="font-display text-lg font-bold text-sq-ink">
                إدارة تصنيفات المتاجر المفعّلة
              </h2>
              <p className="text-xs text-sq-ink-muted">
                تحكّم بأنواع الأنشطة التجارية المتاحة للتسجيل والعرض على منصة سوقنا
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={savingSettings}
            onClick={() => void onUpdateSettings({ enabledStoreTypes: enabledTypes })}
            className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl btn-gold px-4 text-xs font-bold disabled:opacity-60"
          >
            {savingSettings ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            <span>حفظ التصنيفات ({enabledTypes.length})</span>
          </button>
        </div>

        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {ALL_STORE_TYPES.map((typeKey) => {
            const checked = enabledTypes.includes(typeKey);
            return (
              <label
                key={typeKey}
                className={`flex cursor-pointer items-center gap-2.5 rounded-xl border px-3.5 py-3 text-xs font-semibold transition-colors ${
                  checked
                    ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                    : 'border-sq-border bg-sq-elevated text-sq-ink-muted'
                }`}
              >
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => toggleCategory(typeKey)}
                  className="h-4 w-4 accent-[#D4AF37]"
                />
                <span>{STORE_TYPE_LABELS[typeKey]}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* Store Subscriptions Management */}
      <div className="rounded-3xl border border-sq-border bg-sq-surface p-6 space-y-4">
        <div className="flex items-center gap-2">
          <CreditCard className="h-5 w-5 text-sq-gold-text" />
          <div>
            <h2 className="font-display text-lg font-bold text-sq-ink">
              إدارة اشتراكات المتاجر
            </h2>
            <p className="text-xs text-sq-ink-muted">
              تحديد الباقة، حالة الاشتراك، الرسوم الشهرية النقدية، وتاريخ الانتهاء لكل متجر
            </p>
          </div>
        </div>

        {stores.length === 0 ? (
          <p className="rounded-2xl border border-sq-border bg-sq-elevated p-6 text-center text-xs text-sq-ink-muted">
            لا توجد متاجر مسجلة لإدارة اشتراكاتها بعد.
          </p>
        ) : (
          <div className="space-y-3">
            {stores.map((store) => {
              const d = getDraft(store);
              const isSaving = savingSubId === store.id;
              return (
                <div
                  key={store.id}
                  className="rounded-2xl border border-sq-border bg-sq-elevated p-4 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="font-display text-sm font-bold text-sq-ink">
                        {store.name}
                      </div>
                      <div className="text-[11px] text-sq-ink-muted">
                        {STORE_TYPE_LABELS[store.storeType]} · المالك: {store.ownerName || '—'} ·
                        الحالي: {STORE_PLAN_LABELS[d.planName]} ({SUBSCRIPTION_STATUS_LABELS[d.status]}
                        ) · {formatPrice(Number(d.monthlyFee) || 0, currency)}
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={() => void handleSaveSubscription(store)}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-bold disabled:opacity-60"
                    >
                      {isSaving ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Save className="h-3.5 w-3.5" />
                      )}
                      <span>حفظ الاشتراك</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-4">
                    <div>
                      <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                        الباقة
                      </label>
                      <select
                        value={d.planName}
                        onChange={(e) =>
                          setStoreDraft(store, { planName: e.target.value as StorePlanName })
                        }
                        className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-2.5 text-xs font-semibold focus:border-sq-gold focus:outline-none"
                      >
                        {(Object.keys(STORE_PLAN_LABELS) as StorePlanName[]).map((p) => (
                          <option key={p} value={p}>
                            {STORE_PLAN_LABELS[p]}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                        الحالة
                      </label>
                      <select
                        value={d.status}
                        onChange={(e) =>
                          setStoreDraft(store, {
                            status: e.target.value as StoreSubscriptionStatus,
                          })
                        }
                        className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-2.5 text-xs font-semibold focus:border-sq-gold focus:outline-none"
                      >
                        {(Object.keys(SUBSCRIPTION_STATUS_LABELS) as StoreSubscriptionStatus[]).map(
                          (st) => (
                            <option key={st} value={st}>
                              {SUBSCRIPTION_STATUS_LABELS[st]}
                            </option>
                          )
                        )}
                      </select>
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                        الرسوم الشهرية ({currency})
                      </label>
                      <input
                        type="number"
                        min={0}
                        value={d.monthlyFee}
                        onChange={(e) => setStoreDraft(store, { monthlyFee: e.target.value })}
                        className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-3 font-mono text-xs focus:border-sq-gold focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-[11px] font-semibold text-sq-ink-muted">
                        تاريخ الانتهاء (اختياري)
                      </label>
                      <input
                        type="date"
                        dir="ltr"
                        value={d.expiresAt}
                        onChange={(e) => setStoreDraft(store, { expiresAt: e.target.value })}
                        className="min-h-[38px] w-full rounded-xl border border-sq-border bg-sq-surface px-2.5 font-mono text-xs focus:border-sq-gold focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
