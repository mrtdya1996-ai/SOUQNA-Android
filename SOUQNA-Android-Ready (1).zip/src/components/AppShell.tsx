import React from 'react';
import {
  Bell,
  Headphones,
  Home,
  Moon,
  Package,
  ShieldCheck,
  ShoppingBag,
  Store,
  Sun,
  Truck,
  Undo2,
  User as UserIcon,
  X,
} from 'lucide-react';
import { useApp, type AppView } from '../context/AppContext';
import { ConnectionDiagnosticBanner } from './ConnectionDiagnosticBanner';
import { OfflineIndicator } from './PWAWidgets';
import { SouqnaLogo } from './SouqnaLogo';

interface NavTab {
  id: AppView;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
}

export const AppShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    theme,
    toggleTheme,
    user,
    bootstrapStatus,
    activeView,
    cartCount,
    unreadNotificationCount,
    navigate,
    toasts,
    dismissToast,
  } = useApp();

  // Desktop Top Bar: strictly 5 clean single-line text links (Zone 2)
  const desktopLinks: Array<{ id: AppView; label: string }> = [
    { id: 'home', label: 'الرئيسية' },
    { id: 'stores', label: 'المتاجر والأسواق' },
    { id: 'products', label: 'المنتجات' },
  ];

  if (user?.role === 'merchant') {
    desktopLinks.push({ id: 'merchant', label: 'لوحة متجري' });
  } else if (user?.role === 'courier') {
    desktopLinks.push({ id: 'courier', label: 'لوحة المندوب' });
  } else if (user?.role === 'super_admin') {
    desktopLinks.push({ id: 'admin', label: 'لوحة المدير العام' });
  } else {
    desktopLinks.push({ id: 'orders', label: 'طلباتي' });
  }

  desktopLinks.push({
    id: user ? 'account' : 'auth',
    label: user ? 'حسابي' : 'تسجيل الدخول',
  });

  // Mobile Fixed Bottom Tab Bar: 5 ergonomic thumb-zone tabs
  const fourthMobileTab: NavTab =
    user?.role === 'super_admin'
      ? { id: 'admin', label: 'الإدارة', icon: ShieldCheck }
      : user?.role === 'courier'
      ? { id: 'courier', label: 'التوصيل', icon: Truck }
      : { id: 'cart', label: 'السلة', icon: ShoppingBag, badge: cartCount };

  const mobileTabs: NavTab[] = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'stores', label: 'المتاجر', icon: Store },
    { id: 'products', label: 'المنتجات', icon: Package },
    fourthMobileTab,
    {
      id: user ? 'account' : 'auth',
      label: user ? 'حسابي' : 'الدخول',
      icon: UserIcon,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-sq-canvas text-sq-ink transition-colors duration-200">
      {/* Top Navigation Bar (Obsidian/Ivory Glass + Brushed Gold Hairline) */}
      <header className="sticky top-0 z-30 border-b border-sq-border bg-sq-surface/92 backdrop-blur-md pt-safe">
        <div className="mx-auto flex h-14 md:h-16 max-w-7xl items-center justify-between gap-2 md:gap-8 px-3 sm:px-6 lg:px-8">
          {/* Zone 1: Custom SOUQNA Architectural Emblem & Wordmark */}
          <button
            type="button"
            onClick={() => navigate('home')}
            className="whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-sq-gold rounded-xl active:scale-[0.98] transition-transform"
          >
            <SouqnaLogo size="sm" />
          </button>

          {/* Zone 2: 5 clean single-line text nav links (Desktop) */}
          <nav
            aria-label="التنقل الرئيسي"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-sq-ink-muted"
          >
            {desktopLinks.map((link) => {
              const active =
                activeView === link.id || (link.id === 'stores' && activeView === 'store');
              return (
                <button
                  key={link.id}
                  type="button"
                  onClick={() => navigate(link.id)}
                  className={`py-1.5 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                    active
                      ? 'border-sq-gold text-sq-ink font-bold'
                      : 'border-transparent hover:text-sq-ink'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Theme Switch, Notifications & Gold Cart CTA */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={theme === 'dark' ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن'}
              title={theme === 'dark' ? 'الوضع الفاتح (العاجي والذهبي)' : 'الوضع الداكن (الأسود والذهبي)'}
              className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl border border-sq-border bg-sq-elevated text-sq-gold-text transition-all hover:border-sq-gold/60 active:scale-95 shrink-0"
            >
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>

            <button
              type="button"
              onClick={() => navigate('support')}
              aria-label="الدعم الفني والشكاوى"
              title="الدعم الفني والشكاوى"
              className={`flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl border transition-all active:scale-95 shrink-0 ${
                activeView === 'support'
                  ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                  : 'border-sq-border bg-sq-elevated text-sq-gold-text hover:border-sq-gold/60'
              }`}
            >
              <Headphones className="h-4 w-4" />
            </button>

            {user && (
              <button
                type="button"
                onClick={() => navigate('notifications')}
                aria-label="مركز الإشعارات"
                className={`relative flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-xl border transition-all active:scale-95 shrink-0 ${
                  activeView === 'notifications'
                    ? 'border-sq-gold bg-sq-gold-soft text-sq-gold-text'
                    : 'border-sq-border bg-sq-elevated text-sq-ink hover:border-sq-gold/50'
                }`}
              >
                <Bell className="h-4 w-4" />
                {unreadNotificationCount > 0 && (
                  <span className="absolute -top-1.5 -left-1.5 flex h-4.5 min-w-[18px] items-center justify-center rounded-full bg-[#B42318] px-1 font-mono text-[10px] font-bold text-white tabular-nums">
                    {unreadNotificationCount > 99 ? '99+' : unreadNotificationCount}
                  </span>
                )}
              </button>
            )}

            {user?.role === 'merchant' && (
              <button
                type="button"
                onClick={() => navigate('merchant')}
                className="inline-flex md:hidden min-h-[36px] sm:min-h-[40px] items-center gap-1 rounded-xl border border-sq-gold/40 bg-sq-gold-soft px-2.5 sm:px-3 py-1.5 text-xs font-bold text-sq-gold-text whitespace-nowrap shrink-0 active:scale-95"
              >
                <Store className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                <span>متجري</span>
              </button>
            )}
            {user?.role === 'courier' && (
              <button
                type="button"
                onClick={() => navigate('courier')}
                className="inline-flex md:hidden min-h-[36px] sm:min-h-[40px] items-center gap-1 rounded-xl border border-sq-gold/40 bg-sq-gold-soft px-2.5 sm:px-3 py-1.5 text-xs font-bold text-sq-gold-text whitespace-nowrap shrink-0 active:scale-95"
              >
                <Truck className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                <span>المندوب</span>
              </button>
            )}
            {(user?.role === 'super_admin' || (!user && !bootstrapStatus.hasSuperAdmin)) && (
              <button
                type="button"
                onClick={() => navigate(user?.role === 'super_admin' ? 'admin' : 'auth')}
                className={`inline-flex min-h-[36px] sm:min-h-[40px] items-center gap-1.5 rounded-xl border px-2.5 sm:px-3.5 py-1.5 text-xs font-bold whitespace-nowrap shrink-0 transition-all active:scale-95 ${
                  activeView === 'admin'
                    ? 'border-sq-gold bg-sq-gold text-[#0B0C0C] shadow-sm'
                    : 'border-sq-gold/55 bg-sq-gold-soft text-sq-gold-text hover:border-sq-gold'
                }`}
              >
                <ShieldCheck className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                <span>{user?.role === 'super_admin' ? 'لوحة المدير' : 'تهيئة المدير'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => navigate('cart')}
              className="btn-gold hidden md:inline-flex min-h-[40px] items-center gap-2 rounded-xl px-4 py-2 text-sm whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="h-4 w-4" />
              <span>السلة</span>
              {cartCount > 0 && (
                <span className="font-mono text-xs tabular-nums">({cartCount})</span>
              )}
            </button>

            {user?.role === 'customer' && (
              <button
                type="button"
                onClick={() => navigate('orders')}
                className="inline-flex md:hidden min-h-[36px] sm:min-h-[40px] items-center rounded-xl border border-sq-border bg-sq-elevated px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-sq-ink whitespace-nowrap shrink-0 active:scale-95"
              >
                طلباتي
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 pb-24 pt-5 sm:px-6 md:pb-14 md:pt-8 lg:px-8">
        <ConnectionDiagnosticBanner />
        {children}
      </main>

      {/* Quiet Luxury Desktop Footer */}
      <footer className="hidden md:block border-t border-sq-border bg-sq-surface">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-6 text-xs text-sq-ink-muted lg:px-8">
          <div className="flex items-center gap-3">
            <SouqnaLogo size="sm" />
            <span aria-hidden="true">·</span>
            <span>منصة المحلات والأسواق والمولات التجارية — الدفع نقداً عند الاستلام</span>
          </div>
          <div className="flex items-center gap-5">
            <button type="button" onClick={() => navigate('stores')} className="hover:text-sq-gold-text transition-colors">
              المتاجر والأسواق
            </button>
            <button type="button" onClick={() => navigate('products')} className="hover:text-sq-gold-text transition-colors">
              المنتجات والأسعار
            </button>
            <button type="button" onClick={() => navigate('orders')} className="hover:text-sq-gold-text transition-colors">
              طلباتي
            </button>
            <button
              type="button"
              onClick={() => navigate('courier_register')}
              className="hover:text-sq-gold-text transition-colors"
            >
              التسجيل كمندوب
            </button>
            {user?.role === 'super_admin' && (
              <button
                type="button"
                onClick={() => navigate('admin')}
                className="hover:text-sq-gold-text transition-colors"
              >
                لوحة المدير العام
              </button>
            )}
            <button
              type="button"
              onClick={() => navigate('support')}
              className="hover:text-sq-gold-text transition-colors"
            >
              الدعم الفني
            </button>
            <button
              type="button"
              onClick={() => navigate(user ? 'account' : 'auth')}
              className="hover:text-sq-gold-text transition-colors"
            >
              الحساب والإعدادات
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Fixed Bottom Tab Bar (Obsidian/Ivory Glass, >=44px Thumb Zone) */}
      <nav
        aria-label="شريط التنقل السفلي"
        className="fixed bottom-0 left-0 right-0 z-40 border-t border-sq-border bg-sq-surface/95 backdrop-blur-md md:hidden pb-safe"
      >
        <div className="grid h-16 grid-cols-5 items-center">
          {mobileTabs.map((tab) => {
            const Icon = tab.icon;
            const active =
              activeView === tab.id || (tab.id === 'stores' && activeView === 'store');
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => navigate(tab.id)}
                className={`relative flex min-h-[48px] flex-col items-center justify-center gap-1 transition-all active:scale-95 ${
                  active ? 'text-sq-gold-text' : 'text-sq-ink-muted'
                }`}
              >
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute top-0 h-0.5 w-8 rounded-full bg-sq-gold"
                  />
                )}
                <div className="relative">
                  <Icon className="h-5 w-5" />
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="absolute -top-1.5 -left-2.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-sq-gold px-1 font-mono text-[10px] font-extrabold text-[#0B0C0C] tabular-nums">
                      {tab.badge}
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-bold leading-none whitespace-nowrap">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Toast Notifications with Undo / Quick Action Support */}
      {toasts.length > 0 && (
        <div
          aria-live="polite"
          className="fixed top-16 left-4 right-4 sm:left-auto sm:right-6 z-50 flex flex-col gap-2 sm:max-w-md"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`flex items-center justify-between gap-2.5 rounded-xl border px-4 py-3 text-sm font-semibold shadow-xl backdrop-blur-md ${
                toast.tone === 'error'
                  ? 'border-sq-danger-border bg-sq-danger-bg text-sq-danger-text'
                  : toast.tone === 'success'
                  ? 'border-sq-gold/40 bg-sq-surface text-sq-ink'
                  : 'border-sq-border bg-sq-surface text-sq-ink'
              }`}
            >
              <span className="flex-1 leading-snug">{toast.text}</span>
              {toast.action && (
                <button
                  type="button"
                  onClick={() => {
                    toast.action?.onClick();
                    dismissToast(toast.id);
                  }}
                  className="btn-gold inline-flex min-h-[34px] shrink-0 items-center gap-1 rounded-lg px-3 py-1 text-xs whitespace-nowrap"
                >
                  {toast.action.label.includes('تراجع') && <Undo2 className="h-3.5 w-3.5" />}
                  <span>{toast.action.label}</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => dismissToast(toast.id)}
                aria-label="إغلاق التنبيه"
                className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg hover:bg-sq-muted"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      <OfflineIndicator />
    </div>
  );
};
