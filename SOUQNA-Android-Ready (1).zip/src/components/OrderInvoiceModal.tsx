import React from 'react';
import { Banknote, MapPin, Phone, Printer, ReceiptText, Store as StoreIcon, X } from 'lucide-react';
import { formatDateAr, formatPrice } from '../lib/api';
import {
  FULFILLMENT_LABELS,
  ORDER_STATUS_LABELS,
  ROLE_LABELS,
  formatOrderItemOptionsSummary,
  type Order,
} from '../types';

interface OrderInvoiceModalProps {
  order: Order;
  currency: string;
  onClose: () => void;
}

export const OrderInvoiceModal: React.FC<OrderInvoiceModalProps> = ({
  order,
  currency,
  onClose,
}) => {
  const fullAddress = [
    order.governorate,
    order.city,
    order.district,
    order.neighborhood,
    order.deliveryAddress,
  ]
    .filter(Boolean)
    .join(' — ');

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="order-invoice-title"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/55 p-0 sm:p-4 backdrop-blur-xs"
    >
      <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-3xl sm:rounded-2xl border border-sq-gold-hairline bg-sq-surface shadow-2xl print:max-h-none print:rounded-none print:border-0 print:bg-white print:text-black print:shadow-none">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-sq-border bg-sq-elevated px-5 py-4 print:hidden">
          <div className="flex items-center gap-2">
            <ReceiptText className="h-5 w-5 text-sq-gold-text" />
            <h2
              id="order-invoice-title"
              className="font-display text-base sm:text-lg font-extrabold text-sq-ink"
            >
              فاتورة الطلب المفصلة
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl btn-gold px-3.5 text-xs font-semibold"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>طباعة الفاتورة</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق الفاتورة"
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-sq-border bg-sq-surface text-sq-ink-muted hover:bg-sq-muted"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Content */}
        <div className="p-5 sm:p-7 space-y-5">
          {/* Brand & Order Meta */}
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-sq-border pb-5">
            <div>
              <div className="font-display text-xl font-extrabold text-sq-gold-text">
                SOUQNA | سوقنا
              </div>
              <p className="mt-0.5 text-xs text-sq-ink-muted">
                فاتورة شراء نقدي رسمية — الدفع نقداً فقط عند الاستلام
              </p>
            </div>
            <div className="text-left space-y-1 text-xs">
              <div className="font-mono text-base font-extrabold text-sq-ink">
                {order.orderNumber}
              </div>
              <div className="text-sq-ink-muted">{formatDateAr(order.createdAt)}</div>
              <div
                className={`font-bold ${
                  order.status === 'cancelled' || order.status === 'rejected'
                    ? 'text-sq-danger-text'
                    : order.status === 'delivered'
                    ? 'text-sq-gold-text'
                    : 'text-sq-warning-text'
                }`}
              >
                الحالة: {ORDER_STATUS_LABELS[order.status]}
              </div>
            </div>
          </div>

          {/* Store & Customer Blocks */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 text-xs">
            <div className="rounded-2xl border border-sq-border bg-sq-elevated p-4 space-y-1.5">
              <div className="flex items-center gap-1.5 font-bold text-sq-gold-text">
                <StoreIcon className="h-3.5 w-3.5" />
                <span>بيانات المتجر</span>
              </div>
              <div className="text-sm font-bold text-sq-ink">{order.storeName}</div>
              {order.storePhone && (
                <div className="flex items-center gap-1.5 text-sq-ink-muted">
                  <Phone className="h-3.5 w-3.5 text-sq-gold-text" />
                  <span dir="ltr" className="font-mono text-sq-ink">
                    {order.storePhone}
                  </span>
                </div>
              )}
              {order.storeAddress && (
                <div className="flex items-start gap-1.5 text-sq-ink-muted">
                  <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sq-gold-text" />
                  <span>{order.storeAddress}</span>
                </div>
              )}
            </div>

            <div className="rounded-2xl border border-sq-border bg-sq-elevated p-4 space-y-1.5">
              <div className="font-bold text-sq-gold-text">بيانات الزبون والاستلام</div>
              <div className="text-sm font-bold text-sq-ink">{order.customerName}</div>
              <div className="flex items-center gap-1.5 text-sq-ink-muted">
                <Phone className="h-3.5 w-3.5 text-sq-gold-text" />
                <span dir="ltr" className="font-mono text-sq-ink">
                  {order.customerPhone}
                </span>
              </div>
              <div className="text-sq-ink">
                <strong>الاستلام:</strong> {FULFILLMENT_LABELS[order.fulfillmentMethod]}
              </div>
              {fullAddress && (
                <div className="text-sq-ink-muted">
                  <strong>العنوان:</strong> {fullAddress}
                </div>
              )}
              {order.latitude !== null && order.longitude !== null && (
                <div dir="ltr" className="font-mono text-[11px] text-sq-gold-text">
                  GPS: {order.latitude.toFixed(5)}, {order.longitude.toFixed(5)}
                </div>
              )}
              {order.notes && (
                <div className="text-sq-ink-muted">
                  <strong>ملاحظات:</strong> {order.notes}
                </div>
              )}
            </div>
          </div>

          {/* Cancellation / Rejection Notice if applicable */}
          {(order.status === 'cancelled' || order.status === 'rejected') && (
            <div className="rounded-2xl border border-sq-danger-border bg-sq-danger-bg p-4 text-xs text-sq-danger-text space-y-1">
              <div className="font-bold">
                {order.status === 'rejected' ? 'تم رفض الطلب' : 'تم إلغاء الطلب'} (المبلغ المستحق: 0)
              </div>
              {order.cancelReason && (
                <div>
                  <strong>السبب:</strong> {order.cancelReason}
                </div>
              )}
              {order.cancelledByName && (
                <div className="text-[11px] opacity-90">
                  بواسطة: {order.cancelledByName}
                  {order.cancelledByRole &&
                  ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]
                    ? ` (${ROLE_LABELS[order.cancelledByRole as keyof typeof ROLE_LABELS]})`
                    : ''}
                  {order.cancelledAt ? ` · ${formatDateAr(order.cancelledAt)}` : ''}
                </div>
              )}
            </div>
          )}

          {/* Itemized Products Table */}
          <div className="overflow-x-auto rounded-2xl border border-sq-border">
            <table className="w-full text-right text-xs sm:text-sm">
              <thead className="border-b border-sq-border bg-sq-elevated text-[11px] text-sq-ink-muted">
                <tr>
                  <th className="px-4 py-3 font-semibold">المنتج</th>
                  <th className="px-3 py-3 font-semibold">الوحدة</th>
                  <th className="px-3 py-3 font-semibold">سعر الوحدة</th>
                  <th className="px-3 py-3 font-semibold text-center">الكمية</th>
                  <th className="px-4 py-3 font-semibold text-left">المجموع</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sq-border">
                {order.items.map((item) => {
                  const optTags = formatOrderItemOptionsSummary(item.selectedOptions);
                  const printFile = item.selectedOptions?.printJob?.fileName;
                  return (
                    <tr key={item.id}>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-sq-ink">{item.productName}</div>
                        {optTags.length > 0 && (
                          <div className="mt-1 flex flex-wrap gap-1 text-[11px] font-normal text-sq-gold-text">
                            {optTags.map((tag, idx) => (
                              <span
                                key={idx}
                                className="rounded bg-sq-gold-soft px-1.5 py-0.5"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        )}
                        {printFile && (
                          <div className="mt-1 text-[11px] text-sq-ink-muted">
                            الملف المرفق: {printFile}
                          </div>
                        )}
                      </td>
                      <td className="px-3 py-3 text-sq-ink-muted">{item.unit}</td>
                      <td className="px-3 py-3 font-mono text-xs tabular-nums text-sq-ink">
                        {formatPrice(item.unitPrice, currency)}
                      </td>
                      <td className="px-3 py-3 font-mono text-xs font-bold tabular-nums text-center text-sq-ink">
                        {item.quantity}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs font-bold tabular-nums text-left text-sq-ink">
                        {formatPrice(item.lineTotal, currency)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Totals Summary */}
          <div className="rounded-2xl border border-sq-gold/35 bg-sq-gold-soft p-4 sm:p-5 space-y-2 text-xs sm:text-sm">
            <div className="flex items-center justify-between text-sq-ink">
              <span>المجموع الفرعي للمنتجات ({order.items.reduce((s, i) => s + i.quantity, 0)} قطعة/كارتون)</span>
              <span className="font-mono font-semibold tabular-nums">
                {formatPrice(order.subtotal, currency)}
              </span>
            </div>
            <div className="flex items-center justify-between text-sq-ink">
              <span>
                {order.fulfillmentMethod === 'pickup' ? 'رسوم الاستلام من المحل' : 'أجور التوصيل'}
              </span>
              <span className="font-mono font-semibold tabular-nums">
                {order.deliveryFee > 0 ? formatPrice(order.deliveryFee, currency) : 'مجاني (0)'}
              </span>
            </div>
            <div className="flex items-center justify-between border-t border-sq-gold/35 pt-2.5 text-base font-extrabold text-sq-gold-text">
              <span className="inline-flex items-center gap-1.5">
                <Banknote className="h-4 w-4" />
                <span>الإجمالي النهائي (نقداً)</span>
              </span>
              <span className="font-mono tabular-nums">
                {formatPrice(order.totalAmount, currency)}
              </span>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1 print:hidden">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[42px] rounded-xl border border-sq-border bg-sq-surface px-5 text-xs font-semibold text-sq-ink hover:bg-sq-elevated"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
