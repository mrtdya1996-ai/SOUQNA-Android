import React, { useEffect, useState } from 'react';
import { Eye, Loader2, ShieldAlert, X } from 'lucide-react';
import { api } from '../lib/api';

interface PrivatePaymentProofImageProps {
  filename: string;
  alt?: string;
  compact?: boolean;
}

export const PrivatePaymentProofImage: React.FC<PrivatePaymentProofImageProps> = ({
  filename,
  alt = 'صورة إثبات التحويل',
  compact = false,
}) => {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [zoomed, setZoomed] = useState(false);

  useEffect(() => {
    let active = true;
    let createdUrl: string | null = null;
    setLoading(true);
    setError(null);

    api
      .fetchPrivatePaymentProofBlob(filename)
      .then((res) => {
        if (!active) {
          URL.revokeObjectURL(res.blobUrl);
          return;
        }
        createdUrl = res.blobUrl;
        setBlobUrl(res.blobUrl);
      })
      .catch((err) => {
        if (active) {
          setError(err instanceof Error ? err.message : 'تعذر تحميل صورة التحويل.');
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
      if (createdUrl) URL.revokeObjectURL(createdUrl);
    };
  }, [filename]);

  if (loading) {
    return (
      <div
        className={`flex items-center justify-center gap-2 rounded-xl border border-sq-border bg-sq-elevated text-xs text-sq-ink-muted ${
          compact ? 'h-20 w-24' : 'h-36 w-full'
        }`}
      >
        <Loader2 className="h-4 w-4 animate-spin text-sq-gold-text" />
        {!compact && <span>جاري تحميل الإثبات المحمي...</span>}
      </div>
    );
  }

  if (error || !blobUrl) {
    return (
      <div className="flex items-center gap-2 rounded-xl border border-sq-danger-border bg-sq-danger-bg px-3 py-2 text-xs text-sq-danger-text">
        <ShieldAlert className="h-4 w-4 shrink-0" />
        <span>{error || 'تعذر عرض الصورة.'}</span>
      </div>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setZoomed(true)}
        className={`group relative overflow-hidden rounded-xl border border-sq-gold/40 bg-black/40 transition-all hover:border-sq-gold ${
          compact ? 'h-20 w-24 shrink-0' : 'h-44 w-full'
        }`}
        title="اضغط لتكبير صورة إثبات التحويل"
      >
        <img
          src={blobUrl}
          alt={alt}
          className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-105"
        />
        <span className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1 bg-black/75 py-1 text-[10px] font-bold text-[#E8CB73]">
          <Eye className="h-3 w-3" />
          <span>{compact ? 'تكبير' : 'معاينة الإيصال بالحجم الكامل'}</span>
        </span>
      </button>

      {zoomed && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-xs"
          onClick={() => setZoomed(false)}
        >
          <div
            className="relative max-h-[90vh] max-w-3xl overflow-hidden rounded-2xl border border-sq-gold/50 bg-[#0B0C0C] p-2 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setZoomed(false)}
              aria-label="إغلاق المعاينة"
              className="absolute top-3 left-3 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-black/80 text-white hover:bg-sq-gold hover:text-black"
            >
              <X className="h-5 w-5" />
            </button>
            <img
              src={blobUrl}
              alt={alt}
              className="max-h-[84vh] w-auto max-w-full rounded-xl object-contain"
            />
          </div>
        </div>
      )}
    </>
  );
};
