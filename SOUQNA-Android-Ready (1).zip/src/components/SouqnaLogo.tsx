import React from 'react';

interface SouqnaLogoProps {
  compact?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const SouqnaLogo: React.FC<SouqnaLogoProps> = ({ compact = false, size = 'md' }) => {
  const iconBox =
    size === 'sm' ? 'h-8 w-8 rounded-lg' : size === 'lg' ? 'h-12 w-12 rounded-2xl' : 'h-9 w-9 rounded-xl';
  const titleSize =
    size === 'sm'
      ? 'text-base'
      : size === 'lg'
      ? 'text-2xl sm:text-3xl'
      : 'text-lg sm:text-xl';

  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 select-none">
      {/* Independent Architectural Geometric Monogram for SOUQNA */}
      <span
        aria-hidden="true"
        className={`relative flex ${iconBox} items-center justify-center bg-[#0C0E0D] border border-[#D4AF37]/60 shadow-sm shrink-0 overflow-hidden`}
      >
        <svg viewBox="0 0 40 40" className="h-[72%] w-[72%]" fill="none">
          <defs>
            <linearGradient id="sqGoldGrad" x1="4" y1="4" x2="36" y2="36" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#F3DC92" />
              <stop offset="50%" stopColor="#D4AF37" />
              <stop offset="100%" stopColor="#9C7316" />
            </linearGradient>
          </defs>
          {/* Architectural Diamond Frame */}
          <path
            d="M20 3.5L35.5 12.5V27.5L20 36.5L4.5 27.5V12.5L20 3.5Z"
            stroke="url(#sqGoldGrad)"
            strokeWidth="2.2"
          />
          {/* Stylized Bag / Crest Crown S-Mark */}
          <path
            d="M14.5 15.5C14.5 12.6 17 10.5 20 10.5C23 10.5 25.5 12.6 25.5 15.5"
            stroke="url(#sqGoldGrad)"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          <path
            d="M12.5 16.5H27.5L26 27.5H14L12.5 16.5Z"
            stroke="url(#sqGoldGrad)"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <path
            d="M20 20L22.2 22.2L20 24.4L17.8 22.2L20 20Z"
            fill="url(#sqGoldGrad)"
          />
        </svg>
      </span>

      {!compact && (
        <span className={`font-display ${titleSize} font-black tracking-tight leading-none`}>
          <span className="bg-gradient-to-l from-[#E8CA6E] via-[#D4AF37] to-[#B68B22] bg-clip-text text-transparent">
            SOUQNA
          </span>
          <span className="mx-1.5 text-sq-ink-muted font-normal">|</span>
          <span className="text-sq-ink">سوقنا</span>
        </span>
      )}
    </span>
  );
};
