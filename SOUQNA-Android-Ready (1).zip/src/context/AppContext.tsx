import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { api, isCrossOriginApi, resolveApiUrl, setAuthToken } from '../lib/api';
import {
  clearPersistedSessionToken,
  loadPersistedSessionToken,
  savePersistedSessionToken,
} from '../lib/sessionPersistence';
import {
  ALL_STORE_TYPES,
  buildOptionSignature,
  type BootstrapStatus,
  type CartItem,
  type CourierProfile,
  type NotificationItem,
  type OrderItemOptions,
  type PricingType,
  type Product,
  type Store,
  type StoreType,
  type User,
  type UserSubscription,
} from '../types';

export type AppView =
  | 'home'
  | 'stores'
  | 'products'
  | 'store'
  | 'cart'
  | 'orders'
  | 'merchant'
  | 'courier'
  | 'courier_register'
  | 'admin'
  | 'account'
  | 'notifications'
  | 'support'
  | 'subscription'
  | 'auth';

export interface ToastAction {
  label: string;
  onClick: () => void;
}

export type AppTheme = 'dark' | 'light';

export interface ToastMessage {
  id: string;
  text: string;
  tone: 'success' | 'error' | 'info';
  action?: ToastAction;
}

interface AppContextValue {
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  toggleTheme: () => void;
  user: User | null;
  ownedStore: Store | null;
  courierProfile: CourierProfile | null;
  mySubscription: UserSubscription | null;
  authReady: boolean;
  bootstrapStatus: BootstrapStatus;
  activeView: AppView;
  selectedStoreId: string | null;
  selectedStoreTypeFilter: StoreType | 'all';
  focusedOrderId: string | null;
  pendingResetToken: string | null;
  clearPendingResetToken: () => void;
  forgotPasswordRequested: boolean;
  clearForgotPasswordRequested: () => void;
  cart: CartItem[];
  cartCount: number;
  cartSubtotal: number;
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  toasts: ToastMessage[];
  navigate: (view: AppView, storeId?: string | null) => void;
  openStore: (storeId: string) => void;
  openCategoryStores: (storeType: StoreType | 'all') => void;
  setSelectedStoreTypeFilter: (storeType: StoreType | 'all') => void;
  openOrderFromNotification: (orderId: string | null, targetView: AppView) => void;
  clearFocusedOrder: () => void;
  setSession: (
    token: string,
    user: User,
    store: Store | null,
    courier?: CourierProfile | null,
    subscription?: UserSubscription | null
  ) => void;
  updateOwnedStore: (store: Store | null) => void;
  updateCourierProfile: (courier: CourierProfile | null) => void;
  updateUser: (user: User) => void;
  logout: () => Promise<void>;
  refreshBootstrap: () => Promise<void>;
  refreshMySubscription: () => Promise<void>;
  refreshCart: () => Promise<void>;
  refreshNotifications: () => Promise<void>;
  markNotificationRead: (notificationId: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  deleteNotification: (notificationId: string) => Promise<void>;
  clearReadNotifications: () => Promise<void>;
  addToCart: (
    product: Product,
    store: { id: string; name: string; deliveryFee: number; address?: string },
    pricingType?: PricingType,
    selectedOptions?: OrderItemOptions
  ) => void;
  updateCartQty: (itemKey: string, delta: number) => void;
  removeFromCart: (itemKey: string) => void;
  clearStoreFromCart: (storeId: string, options?: { allowUndo?: boolean }) => void;
  notify: (text: string, tone?: 'success' | 'error' | 'info', action?: ToastAction) => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const DEFAULT_BOOTSTRAP: BootstrapStatus = {
  hasSuperAdmin: true,
  requireSetupCode: false,
  emailResetConfigured: false,
  currency: 'د.ع',
  requireStoreApproval: true,
  requireCourierApproval: true,
  enabledStoreTypes: ALL_STORE_TYPES,
};

const VALID_VIEWS: AppView[] = [
  'home',
  'stores',
  'products',
  'store',
  'cart',
  'orders',
  'merchant',
  'courier',
  'courier_register',
  'admin',
  'account',
  'notifications',
  'support',
  'subscription',
  'auth',
];

function unitsNeeded(product: Product, pricingType: PricingType, qty: number): number {
  if (pricingType === 'carton') {
    const perCarton = Math.max(1, product.cartonUnits || 1);
    return qty * perCarton;
  }
  return qty;
}

function safeScrollToTop(): void {
  try {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch {
    try {
      window.scrollTo(0, 0);
    } catch {
      // ignore
    }
  }
}

function safeReplaceUrlToRoot(): void {
  try {
    if (window.history && typeof window.history.replaceState === 'function') {
      window.history.replaceState({}, '', '/');
    }
  } catch {
    // Ignore SecurityError in restricted WebView origins
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<AppTheme>(() => {
    try {
      const saved = localStorage.getItem('souqna_theme');
      return saved === 'light' ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });
  const [user, setUser] = useState<User | null>(null);

  const setTheme = useCallback((next: AppTheme) => {
    setThemeState(next);
    try {
      localStorage.setItem('souqna_theme', next);
    } catch {
      // ignore storage quota errors
    }
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeState((prev) => {
      const next: AppTheme = prev === 'dark' ? 'light' : 'dark';
      try {
        localStorage.setItem('souqna_theme', next);
      } catch {
        // ignore storage quota errors
      }
      return next;
    });
  }, []);

  useEffect(() => {
    try {
      const root = document.documentElement;
      if (theme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) {
        meta.setAttribute('content', theme === 'dark' ? '#090A0A' : '#F9F7F2');
      }
    } catch {
      // Ignore DOM mutation errors in restricted WebView environments
    }
  }, [theme]);
  const [ownedStore, setOwnedStore] = useState<Store | null>(null);
  const [courierProfile, setCourierProfile] = useState<CourierProfile | null>(null);
  const [mySubscription, setMySubscription] = useState<UserSubscription | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [cookieSessionActive, setCookieSessionActive] = useState(false);
  const [bootstrapStatus, setBootstrapStatus] = useState<BootstrapStatus>(DEFAULT_BOOTSTRAP);
  const [activeView, setActiveView] = useState<AppView>('home');
  const [selectedStoreId, setSelectedStoreId] = useState<string | null>(null);
  const [selectedStoreTypeFilter, setSelectedStoreTypeFilter] = useState<StoreType | 'all'>('all');
  const [focusedOrderId, setFocusedOrderId] = useState<string | null>(null);
  const [pendingResetToken, setPendingResetToken] = useState<string | null>(null);
  const clearPendingResetToken = useCallback(() => setPendingResetToken(null), []);
  const [forgotPasswordRequested, setForgotPasswordRequested] = useState(false);
  const clearForgotPasswordRequested = useCallback(() => setForgotPasswordRequested(false), []);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadNotificationCount, setUnreadNotificationCount] = useState(0);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const cartRef = useRef<CartItem[]>(cart);
  cartRef.current = cart;

  const userRef = useRef<User | null>(user);
  userRef.current = user;

  const notify = useCallback(
    (text: string, tone: 'success' | 'error' | 'info' = 'info', action?: ToastAction) => {
      const id = `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev.slice(-3), { id, text, tone, action }]);
      const duration = action ? 6500 : 3800;
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, duration);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const refreshBootstrap = useCallback(async () => {
    try {
      const status = await api.getBootstrapStatus();
      if (status && typeof status === 'object') {
        setBootstrapStatus({
          ...DEFAULT_BOOTSTRAP,
          ...status,
          currency: typeof status.currency === 'string' && status.currency ? status.currency : DEFAULT_BOOTSTRAP.currency,
          enabledStoreTypes: Array.isArray(status.enabledStoreTypes) && status.enabledStoreTypes.length > 0
            ? status.enabledStoreTypes
            : DEFAULT_BOOTSTRAP.enabledStoreTypes,
        });
      }
    } catch {
      // Keep default fallback when offline
    }
  }, []);

  const refreshMySubscription = useCallback(async () => {
    if (!userRef.current) return;
    try {
      const res = await api.getMySubscription();
      setMySubscription(res?.subscription ?? null);
    } catch {
      // Non-fatal
    }
  }, []);

  const refreshCart = useCallback(async () => {
    try {
      const res = await api.getCart();
      setCart(Array.isArray(res?.items) ? res.items : []);
    } catch {
      // Ignore if unauthenticated or temporarily offline
    }
  }, []);

  const refreshNotifications = useCallback(async () => {
    if (!userRef.current) return;
    try {
      const res = await api.getNotifications();
      setNotifications(Array.isArray(res?.notifications) ? res.notifications : []);
      setUnreadNotificationCount(Number(res?.unreadCount) || 0);
    } catch {
      // Ignore transient offline errors
    }
  }, []);

  const navigate = useCallback((view: AppView, storeId?: string | null) => {
    setActiveView(view);
    if (storeId !== undefined) {
      setSelectedStoreId(storeId);
    }
    safeScrollToTop();
  }, []);

  const openStore = useCallback((storeId: string) => {
    setSelectedStoreId(storeId);
    setActiveView('store');
    safeScrollToTop();
  }, []);

  const openCategoryStores = useCallback((storeType: StoreType | 'all') => {
    setSelectedStoreTypeFilter(storeType);
    setActiveView('stores');
    safeScrollToTop();
  }, []);

  const openOrderFromNotification = useCallback((orderId: string | null, targetView: AppView) => {
    const safeView = VALID_VIEWS.includes(targetView) ? targetView : 'orders';
    setFocusedOrderId(orderId);
    setActiveView(safeView);
    safeScrollToTop();
  }, []);

  const clearFocusedOrder = useCallback(() => {
    setFocusedOrderId(null);
  }, []);

  // Restore persistent session (HttpOnly cookie primary + encrypted IndexedDB vault fallback), DB cart, and deep-links on startup
  useEffect(() => {
    let active = true;
    let networkFailedOnBoot = false;

    const verifyPersistedSession = async () => {
      // Step 1: Try server HttpOnly cookie session first
      let res = await api.getSession();
      if (res.authenticated && res.user) {
        return res;
      }

      // Step 2: If third-party/iframe cookies were blocked or unavailable, restore encrypted device session token from IndexedDB
      const persistedToken = await loadPersistedSessionToken();
      if (!persistedToken) {
        return res;
      }

      setAuthToken(persistedToken);
      res = await api.getSession();
      if (!res.authenticated || !res.user) {
        // Server explicitly confirmed the session expired or was revoked — clear stale local vault
        setAuthToken(null);
        await clearPersistedSessionToken();
      }
      return res;
    };

    const hydrateAuthenticatedUser = async (
      res: Awaited<ReturnType<typeof api.getSession>>,
      options?: {
        deepView?: AppView | null;
        deepOrder?: string | null;
        skipNavigation?: boolean;
      }
    ) => {
      if (!active || !res.authenticated || !res.user) return;
      setUser(res.user);
      setOwnedStore(res.store);
      setCourierProfile(res.courier ?? null);
      setMySubscription(res.subscription ?? null);
      setCookieSessionActive(res.authSource === 'cookie');

      try {
        const [cartRes, notifRes] = await Promise.all([api.getCart(), api.getNotifications()]);
        if (active) {
          setCart(Array.isArray(cartRes?.items) ? cartRes.items : []);
          setNotifications(Array.isArray(notifRes?.notifications) ? notifRes.notifications : []);
          setUnreadNotificationCount(Number(notifRes?.unreadCount) || 0);
        }
      } catch {
        // Non-fatal
      }

      if (options?.skipNavigation) return;

      const roleDefaultView: AppView =
        res.user.role === 'super_admin'
          ? 'admin'
          : res.user.role === 'merchant'
          ? 'merchant'
          : res.user.role === 'courier'
          ? 'courier'
          : 'home';

      const deepView = options?.deepView ?? null;
      const deepOrder = options?.deepOrder ?? null;
      if (deepView && VALID_VIEWS.includes(deepView) && deepView !== 'auth') {
        if (deepView === 'admin' && res.user.role !== 'super_admin') {
          setActiveView(roleDefaultView);
        } else {
          setActiveView(deepView);
          if (deepOrder) setFocusedOrderId(deepOrder);
        }
        safeReplaceUrlToRoot();
      } else {
        setActiveView(roleDefaultView);
        if (deepView === 'auth') {
          safeReplaceUrlToRoot();
        }
      }
    };

    const init = async () => {
      await refreshBootstrap();

      // Check URL deep-link params or path (/admin, /courier, /?view=admin)
      let deepView: AppView | null = null;
      let deepOrder: string | null = null;
      let deepResetToken: string | null = null;
      let isForgotPasswordLink = false;
      try {
        const params = new URLSearchParams(window.location?.search || '');
        const pathname = (window.location?.pathname || '/').replace(/\/+$/, '');
        const pathView: AppView | null =
          pathname === '/admin'
            ? 'admin'
            : pathname === '/courier'
            ? 'courier'
            : pathname === '/courier-register'
            ? 'courier_register'
            : pathname === '/support'
            ? 'support'
            : pathname === '/subscription'
            ? 'subscription'
            : null;
        isForgotPasswordLink =
          pathname === '/forgot-password' || params.get('view') === 'forgot_password';
        deepView = (params.get('view') as AppView | null) || pathView;
        deepOrder = params.get('openOrder');
        deepResetToken = params.get('resetToken');
      } catch {
        // Ignore malformed URL in restricted WebView
      }

      if (deepResetToken && deepResetToken.trim().length >= 16) {
        setPendingResetToken(deepResetToken.trim());
        setActiveView('auth');
        safeReplaceUrlToRoot();
      } else if (isForgotPasswordLink) {
        setForgotPasswordRequested(true);
        setActiveView('auth');
        safeReplaceUrlToRoot();
      }

      try {
        const res = await verifyPersistedSession();
        if (!active) return;
        if (res.authenticated && res.user) {
          await hydrateAuthenticatedUser(res, {
            deepView,
            deepOrder,
            skipNavigation: Boolean(deepResetToken || isForgotPasswordLink),
          });
        } else if (!deepResetToken && !isForgotPasswordLink && deepView && VALID_VIEWS.includes(deepView)) {
          if (deepOrder) setFocusedOrderId(deepOrder);
          setActiveView(
            deepView === 'merchant' ||
              deepView === 'admin' ||
              deepView === 'courier' ||
              deepView === 'orders' ||
              deepView === 'subscription'
              ? 'auth'
              : deepView
          );
        }
      } catch {
        // Network error — keep saved device session intact and retry when connectivity returns
        networkFailedOnBoot = true;
      } finally {
        if (active) setAuthReady(true);
      }
    };
    init();

    const handleReconnect = () => {
      if (!active || !networkFailedOnBoot) return;
      networkFailedOnBoot = false;
      void verifyPersistedSession()
        .then((res) => hydrateAuthenticatedUser(res))
        .catch(() => {
          networkFailedOnBoot = true;
        });
    };

    // Silently keep session & role synchronized when resuming the app from background
    const handleVisibilityResume = () => {
      if (!active || document.visibilityState !== 'visible') return;
      if (!userRef.current && !networkFailedOnBoot) return;
      void verifyPersistedSession()
        .then((res) => {
          if (!active) return;
          if (res.authenticated && res.user) {
            networkFailedOnBoot = false;
            setUser(res.user);
            setOwnedStore(res.store);
            setCourierProfile(res.courier ?? null);
            setMySubscription(res.subscription ?? null);
            setCookieSessionActive(res.authSource === 'cookie');
          } else if (userRef.current) {
            // Session was revoked remotely (e.g. password reset or admin suspension)
            setAuthToken(null);
            setCookieSessionActive(false);
            setUser(null);
            setOwnedStore(null);
            setCourierProfile(null);
            setMySubscription(null);
            setCart([]);
            setNotifications([]);
            setUnreadNotificationCount(0);
          }
        })
        .catch(() => {
          // Transient offline resume — never log out the user
        });
    };

    window.addEventListener('online', handleReconnect);
    document.addEventListener('visibilitychange', handleVisibilityResume);

    return () => {
      active = false;
      window.removeEventListener('online', handleReconnect);
      document.removeEventListener('visibilitychange', handleVisibilityResume);
    };
  }, [refreshBootstrap]);

  // Listen to Service Worker push notification click postMessages when app is already open
  useEffect(() => {
    let swContainer: ServiceWorkerContainer | null = null;
    try {
      if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator && navigator.serviceWorker) {
        swContainer = navigator.serviceWorker;
      }
    } catch {
      swContainer = null;
    }
    if (!swContainer) return;

    const handleSwMessage = (event: MessageEvent) => {
      const msg = event.data;
      if (msg && msg.type === 'SOUQNA_OPEN_NOTIFICATION') {
        const targetView = (msg.targetView || 'orders') as AppView;
        openOrderFromNotification(msg.orderId || null, targetView);
      }
    };
    try {
      swContainer.addEventListener('message', handleSwMessage);
    } catch {
      return;
    }
    return () => {
      try {
        swContainer?.removeEventListener('message', handleSwMessage);
      } catch {
        // ignore
      }
    };
  }, [openOrderFromNotification]);

  // Real-time Server-Sent Events (SSE) when HttpOnly cookies are active, with clean authenticated fallback when 3P cookies are restricted
  const currentUserId = user?.id ?? null;
  useEffect(() => {
    if (!currentUserId) {
      setNotifications([]);
      setUnreadNotificationCount(0);
      return;
    }

    let sse: EventSource | null = null;
    let pollTimer: number | null = null;
    let sseErrors = 0;

    const startFallbackSync = () => {
      if (pollTimer !== null) return;
      pollTimer = window.setInterval(() => {
        if (document.visibilityState !== 'visible') return;
        void api
          .getNotifications()
          .then((res) => {
            setNotifications(Array.isArray(res?.notifications) ? res.notifications : []);
            setUnreadNotificationCount(Number(res?.unreadCount) || 0);
          })
          .catch(() => {});
      }, 25000);
    };

    if (cookieSessionActive && !isCrossOriginApi() && typeof EventSource !== 'undefined') {
      try {
        sse = new EventSource(resolveApiUrl('/api/notifications/stream'), { withCredentials: true });
        sse.addEventListener('open', () => {
          sseErrors = 0;
        });
        sse.addEventListener('error', () => {
          sseErrors += 1;
          if (sseErrors >= 2) {
            sse?.close();
            sse = null;
            startFallbackSync();
          }
        });
        sse.addEventListener('notification', (event) => {
          try {
            const item = JSON.parse((event as MessageEvent).data) as NotificationItem;
            setNotifications((prev) => {
              if (prev.some((n) => n.id === item.id)) return prev;
              return [item, ...prev].slice(0, 80);
            });
            setUnreadNotificationCount((prev) => prev + 1);

            const targetView = (
              VALID_VIEWS.includes(item.targetView as AppView) ? item.targetView : 'notifications'
            ) as AppView;

            notify(
              item.title,
              item.type === 'order_cancelled' || item.type === 'order_cancel_requested'
                ? 'error'
                : item.type === 'store_visit'
                ? 'info'
                : 'success',
              item.orderId
                ? {
                    label: 'فتح الطلب',
                    onClick: () => {
                      void api.markNotificationRead(item.id).then((res) => {
                        setNotifications(res.notifications);
                        setUnreadNotificationCount(res.unreadCount);
                      }).catch(() => {});
                      openOrderFromNotification(item.orderId, targetView);
                    },
                  }
                : targetView === 'support' ||
                  targetView === 'subscription' ||
                  targetView === 'admin' ||
                  targetView === 'courier'
                ? {
                    label:
                      targetView === 'support'
                        ? 'فتح الدعم الفني'
                        : targetView === 'subscription'
                        ? 'فتح اشتراكي'
                        : targetView === 'admin'
                        ? 'فتح لوحة المدير'
                        : 'فتح لوحة المندوب',
                    onClick: () => {
                      void api.markNotificationRead(item.id).then((res) => {
                        setNotifications(res.notifications);
                        setUnreadNotificationCount(res.unreadCount);
                      }).catch(() => {});
                      if (targetView === 'subscription') void refreshMySubscription();
                      navigate(targetView);
                    },
                  }
                : {
                    label: 'عرض',
                    onClick: () => navigate('notifications'),
                  }
            );
          } catch {
            // Ignore malformed event payloads
          }
        });
      } catch {
        startFallbackSync();
      }
    } else {
      startFallbackSync();
    }

    return () => {
      sse?.close();
      if (pollTimer !== null) window.clearInterval(pollTimer);
    };
  }, [currentUserId, cookieSessionActive, notify, openOrderFromNotification, navigate, refreshMySubscription]);

  const markNotificationRead = useCallback(async (notificationId: string) => {
    try {
      const res = await api.markNotificationRead(notificationId);
      setNotifications(Array.isArray(res?.notifications) ? res.notifications : []);
      setUnreadNotificationCount(Number(res?.unreadCount) || 0);
    } catch {
      // ignore
    }
  }, []);

  const markAllNotificationsRead = useCallback(async () => {
    try {
      const res = await api.markAllNotificationsRead();
      setNotifications(Array.isArray(res?.notifications) ? res.notifications : []);
      setUnreadNotificationCount(Number(res?.unreadCount) || 0);
      notify('تم تحديد جميع الإشعارات كمقروءة.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر تحديث الإشعارات.', 'error');
    }
  }, [notify]);

  const deleteNotification = useCallback(
    async (notificationId: string) => {
      try {
        const res = await api.deleteNotification(notificationId);
        setNotifications(Array.isArray(res?.notifications) ? res.notifications : []);
        setUnreadNotificationCount(Number(res?.unreadCount) || 0);
        notify('تم حذف الإشعار.', 'info');
      } catch (err) {
        notify(err instanceof Error ? err.message : 'تعذر حذف الإشعار.', 'error');
      }
    },
    [notify]
  );

  const clearReadNotifications = useCallback(async () => {
    try {
      const res = await api.clearReadNotifications();
      setNotifications(Array.isArray(res?.notifications) ? res.notifications : []);
      setUnreadNotificationCount(Number(res?.unreadCount) || 0);
      notify('تم حذف الإشعارات المقروءة القديمة.', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر حذف الإشعارات المقروءة.', 'error');
    }
  }, [notify]);

  const setSession = useCallback(
    (
      token: string,
      nextUser: User,
      nextStore: Store | null,
      nextCourier: CourierProfile | null = null,
      nextSubscription: UserSubscription | null = null
    ) => {
      setAuthToken(token);
      void savePersistedSessionToken(token);
      setUser(nextUser);
      setOwnedStore(nextStore);
      setCourierProfile(nextCourier);
      setMySubscription(nextSubscription);

      const guestItems = cartRef.current.filter((item) => !item.id);
      const sync = async () => {
        for (const item of guestItems) {
          if (nextStore && item.storeId === nextStore.id) continue;
          try {
            await api.addCartItem({
              productId: item.product.id,
              pricingType: item.pricingType,
              quantity: item.quantity,
              selectedOptions: item.selectedOptions,
            });
          } catch {
            // Skip unavailable or out-of-stock guest items
          }
        }
        try {
          const [cartRes, notifRes, subRes] = await Promise.all([
            api.getCart(),
            api.getNotifications(),
            nextUser.role === 'merchant' || nextUser.role === 'courier'
              ? api.getMySubscription().catch(() => null)
              : Promise.resolve(null),
          ]);
          setCart(Array.isArray(cartRes?.items) ? cartRes.items : []);
          setNotifications(Array.isArray(notifRes?.notifications) ? notifRes.notifications : []);
          setUnreadNotificationCount(Number(notifRes?.unreadCount) || 0);
          if (subRes && 'subscription' in subRes) {
            setMySubscription(subRes.subscription ?? null);
          }
        } catch {
          // Keep current state on failure
        }
      };
      void sync();
    },
    []
  );

  const logout = useCallback(async () => {
    try {
      await api.logout();
    } catch {
      // Clear local session regardless
    }
    await clearPersistedSessionToken();
    setAuthToken(null);
    setCookieSessionActive(false);
    setUser(null);
    setOwnedStore(null);
    setCourierProfile(null);
    setMySubscription(null);
    setCart([]);
    setNotifications([]);
    setUnreadNotificationCount(0);
    setFocusedOrderId(null);
    setActiveView('home');
    notify('تم تسجيل الخروج بنجاح.', 'info');
  }, [notify]);

  const addToCart = useCallback(
    (
      product: Product,
      store: { id: string; name: string; deliveryFee: number; address?: string },
      pricingType: PricingType = 'unit',
      selectedOptions?: OrderItemOptions
    ) => {
      if (ownedStore && ownedStore.id === store.id) {
        notify('هذا المنتج تابع لمتجرك الخاص. يمكنك التسوق بحرية من بقية المتاجر.', 'info');
        return;
      }

      if (product.stockQty <= 0) {
        notify('عذراً، نفدت الكمية المتوفرة من هذا المنتج حالياً.', 'error');
        return;
      }

      if ((product.storeType === 'gaming_topup' || product.gameName) && !selectedOptions?.playerId?.trim()) {
        notify('يرجى إدخال معرّف اللاعب (Player ID) قبل إضافة باقة الشحن.', 'error');
        return;
      }

      const isCarton = pricingType === 'carton' && product.cartonPrice > 0;
      const appliedPricingType: PricingType = isCarton ? 'carton' : 'unit';
      const appliedUnitPrice = isCarton ? product.cartonPrice : product.price;
      const appliedUnitLabel = isCarton
        ? product.cartonUnits > 0
          ? `كارتون (${product.cartonUnits} ${product.unit})`
          : 'كارتون'
        : product.unit;

      const normalizedOptions: OrderItemOptions | undefined = selectedOptions
        ? {
            ...selectedOptions,
            ...(product.gameName && !selectedOptions.gameName ? { gameName: product.gameName } : {}),
          }
        : undefined;
      const optionSig = buildOptionSignature(normalizedOptions);
      const key = optionSig
        ? `${product.id}:${appliedPricingType}:${optionSig}`
        : `${product.id}:${appliedPricingType}`;

      if (user) {
        void (async () => {
          try {
            const res = await api.addCartItem({
              productId: product.id,
              pricingType: appliedPricingType,
              quantity: 1,
              selectedOptions: normalizedOptions,
            });
            setCart(res.items);
            const addedItem = res.items.find((i) => i.key === key);
            notify(
              `تمت إضافة "${product.name}" (${isCarton ? 'كارتون' : product.unit}) إلى السلة`,
              'success',
              addedItem?.id
                ? {
                    label: 'تراجع (Undo)',
                    onClick: () => {
                      void (async () => {
                        try {
                          const latest = cartRef.current.find((i) => i.key === key);
                          if (!latest?.id) return;
                          const nextQty = latest.quantity - 1;
                          const undoRes =
                            nextQty <= 0
                              ? await api.removeCartItem(latest.id)
                              : await api.updateCartItem(latest.id, nextQty);
                          setCart(undoRes.items);
                          notify(`تم التراجع عن إضافة "${product.name}".`, 'info');
                        } catch {
                          notify('تعذر التراجع عن الإضافة.', 'error');
                        }
                      })();
                    },
                  }
                : undefined
            );
          } catch (err) {
            notify(
              err instanceof Error ? err.message : 'تعذر إضافة المنتج إلى السلة.',
              'error'
            );
          }
        })();
        return;
      }

      const current = cartRef.current;
      const existingSameProductUnits = current
        .filter((i) => i.product.id === product.id)
        .reduce((sum, i) => sum + unitsNeeded(product, i.pricingType, i.quantity), 0);
      const addUnits = unitsNeeded(product, appliedPricingType, 1);
      if (existingSameProductUnits + addUnits > product.stockQty) {
        notify(
          `الكمية المطلوبة غير متوفرة. المتوفر في المخزون هو ${product.stockQty} ${product.unit}.`,
          'error'
        );
        return;
      }

      setCart((prev) => {
        const idx = prev.findIndex((item) => item.key === key);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = { ...next[idx], quantity: next[idx].quantity + 1 };
          return next;
        }
        return [
          ...prev,
          {
            key,
            product,
            pricingType: appliedPricingType,
            appliedUnitPrice,
            appliedUnitLabel,
            storeId: store.id,
            storeName: store.name,
            storeDeliveryFee: store.deliveryFee,
            storeAddress: store.address || product.storeAddress || '',
            quantity: 1,
            selectedOptions: normalizedOptions,
          },
        ];
      });

      notify(
        `تمت إضافة "${product.name}" (${isCarton ? 'كارتون' : product.unit}) إلى السلة`,
        'success',
        {
          label: 'تراجع (Undo)',
          onClick: () => {
            setCart((prev) =>
              prev
                .map((item) =>
                  item.key === key ? { ...item, quantity: item.quantity - 1 } : item
                )
                .filter((item) => item.quantity > 0)
            );
            notify(`تم التراجع عن إضافة "${product.name}".`, 'info');
          },
        }
      );
    },
    [notify, ownedStore, user]
  );

  // Restore helper for Undo actions on cart items
  const restoreCartItemExact = useCallback(
    async (snapshot: CartItem) => {
      if (userRef.current) {
        try {
          const currentMatch = cartRef.current.find((i) => i.key === snapshot.key);
          if (currentMatch?.id) {
            const res = await api.updateCartItem(currentMatch.id, snapshot.quantity);
            setCart(res.items);
          } else {
            const res = await api.addCartItem({
              productId: snapshot.product.id,
              pricingType: snapshot.pricingType,
              quantity: snapshot.quantity,
              selectedOptions: snapshot.selectedOptions,
            });
            setCart(res.items);
          }
          notify(`تم التراجع واستعادة "${snapshot.product.name}" (الكمية: ${snapshot.quantity}).`, 'success');
        } catch (err) {
          notify(err instanceof Error ? err.message : 'تعذر التراجع عن الإجراء.', 'error');
        }
        return;
      }

      setCart((prev) => {
        const exists = prev.some((i) => i.key === snapshot.key);
        if (exists) {
          return prev.map((i) =>
            i.key === snapshot.key ? { ...i, quantity: snapshot.quantity } : i
          );
        }
        return [...prev, snapshot];
      });
      notify(`تم التراجع واستعادة "${snapshot.product.name}" (الكمية: ${snapshot.quantity}).`, 'success');
    },
    [notify]
  );

  const updateCartQty = useCallback(
    (itemKey: string, delta: number) => {
      const target = cartRef.current.find((i) => i.key === itemKey);
      if (!target) return;
      const snapshot: CartItem = { ...target };
      const nextQty = target.quantity + delta;

      if (user && target.id) {
        const cartItemId = target.id;
        void (async () => {
          try {
            const res = await api.updateCartItem(cartItemId, nextQty);
            setCart(res.items);
            notify(
              nextQty <= 0
                ? `تمت إزالة "${snapshot.product.name}" من السلة`
                : `تم تعديل كمية "${snapshot.product.name}" إلى ${nextQty}`,
              'info',
              {
                label: 'تراجع (Undo)',
                onClick: () => {
                  void restoreCartItemExact(snapshot);
                },
              }
            );
          } catch (err) {
            notify(err instanceof Error ? err.message : 'تعذر تحديث الكمية.', 'error');
          }
        })();
        return;
      }

      if (delta > 0) {
        const otherUnits = cartRef.current
          .filter((i) => i.product.id === target.product.id && i.key !== itemKey)
          .reduce((sum, i) => sum + unitsNeeded(target.product, i.pricingType, i.quantity), 0);
        const needed = otherUnits + unitsNeeded(target.product, target.pricingType, nextQty);
        if (needed > target.product.stockQty) {
          notify(
            `الكمية المتوفرة في المخزون هي ${target.product.stockQty} ${target.product.unit} فقط.`,
            'error'
          );
          return;
        }
      }

      setCart((prev) =>
        prev
          .map((item) => (item.key === itemKey ? { ...item, quantity: nextQty } : item))
          .filter((item) => item.quantity > 0)
      );
      notify(
        nextQty <= 0
          ? `تمت إزالة "${snapshot.product.name}" من السلة`
          : `تم تعديل كمية "${snapshot.product.name}" إلى ${nextQty}`,
        'info',
        {
          label: 'تراجع (Undo)',
          onClick: () => {
            void restoreCartItemExact(snapshot);
          },
        }
      );
    },
    [user, notify, restoreCartItemExact]
  );

  const removeFromCart = useCallback(
    (itemKey: string) => {
      const target = cartRef.current.find((i) => i.key === itemKey);
      if (!target) return;
      const snapshot: CartItem = { ...target };

      if (user && target.id) {
        const cartItemId = target.id;
        void (async () => {
          try {
            const res = await api.removeCartItem(cartItemId);
            setCart(res.items);
            notify(`تم حذف "${snapshot.product.name}" من السلة`, 'info', {
              label: 'تراجع (Undo)',
              onClick: () => {
                void restoreCartItemExact(snapshot);
              },
            });
          } catch (err) {
            notify(err instanceof Error ? err.message : 'تعذر حذف المنتج من السلة.', 'error');
          }
        })();
        return;
      }

      setCart((prev) => prev.filter((item) => item.key !== itemKey));
      notify(`تم حذف "${snapshot.product.name}" من السلة`, 'info', {
        label: 'تراجع (Undo)',
        onClick: () => {
          void restoreCartItemExact(snapshot);
        },
      });
    },
    [user, notify, restoreCartItemExact]
  );

  const clearStoreFromCart = useCallback(
    (storeId: string, options?: { allowUndo?: boolean }) => {
      const removedItems = cartRef.current.filter((item) => item.storeId === storeId);
      setCart((prev) => prev.filter((item) => item.storeId !== storeId));
      if (user) {
        void api.clearStoreCart(storeId).then((res) => setCart(res.items)).catch(() => {});
      }

      if (options?.allowUndo && removedItems.length > 0) {
        const storeName = removedItems[0].storeName;
        notify(`تم إفراغ سلة "${storeName}"`, 'info', {
          label: 'تراجع (Undo)',
          onClick: () => {
            void (async () => {
              if (userRef.current) {
                for (const item of removedItems) {
                  try {
                    await api.addCartItem({
                      productId: item.product.id,
                      pricingType: item.pricingType,
                      quantity: item.quantity,
                      selectedOptions: item.selectedOptions,
                    });
                  } catch {
                    // skip if out of stock
                  }
                }
                const res = await api.getCart().catch(() => null);
                if (res) setCart(res.items);
              } else {
                setCart((prev) => [...prev, ...removedItems]);
              }
              notify(`تمت استعادة منتجات "${storeName}" إلى السلة.`, 'success');
            })();
          },
        });
      }
    },
    [user, notify]
  );

  const safeCart = Array.isArray(cart) ? cart : [];
  const cartCount = safeCart.reduce((sum, item) => sum + (Number(item?.quantity) || 0), 0);
  const cartSubtotal = safeCart.reduce(
    (sum, item) => sum + (Number(item?.appliedUnitPrice) || 0) * (Number(item?.quantity) || 0),
    0
  );

  return (
    <AppContext.Provider
      value={{
        theme,
        setTheme,
        toggleTheme,
        user,
        ownedStore,
        courierProfile,
        mySubscription,
        authReady,
        bootstrapStatus,
        activeView,
        selectedStoreId,
        selectedStoreTypeFilter,
        focusedOrderId,
        pendingResetToken,
        clearPendingResetToken,
        forgotPasswordRequested,
        clearForgotPasswordRequested,
        cart,
        cartCount,
        cartSubtotal,
        notifications,
        unreadNotificationCount,
        toasts,
        navigate,
        openStore,
        openCategoryStores,
        setSelectedStoreTypeFilter,
        openOrderFromNotification,
        clearFocusedOrder,
        setSession,
        updateOwnedStore: setOwnedStore,
        updateCourierProfile: setCourierProfile,
        updateUser: setUser,
        logout,
        refreshBootstrap,
        refreshMySubscription,
        refreshCart,
        refreshNotifications,
        markNotificationRead,
        markAllNotificationsRead,
        deleteNotification,
        clearReadNotifications,
        addToCart,
        updateCartQty,
        removeFromCart,
        clearStoreFromCart,
        notify,
        dismissToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return ctx;
}
