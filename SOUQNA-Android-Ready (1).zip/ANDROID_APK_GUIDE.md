# دليل بناء وتثبيت تطبيق سوقنا | SOUQNA بصيغة Android APK (نسخة الإنتاج)

تم تجهيز مشروع **Android Native (Capacitor + Gradle)** بالكامل داخل مجلد `android/` بالاسم الرسمي **`سوقنا | SOUQNA`** وأيقونة التصميم الأسود والذهبي الفاخر، بنمط **Bundled Production APK** (واجهة التطبيق تعمل محلياً وفورياً داخل الهاتف بدون Service Worker، وجميع طلبات `/api/*` والصور `/uploads/*` تتصل مباشرة بخادم الإنتاج عبر HTTPS + CORS + Bearer Session).

> **تنبيه هام جداً:** لا تستخدم أبداً روابط المعاينة المؤقتة لـ AI Studio (`ais-dev-*.run.app` أو `ais-pre-*.run.app`) ولا `localhost` عند بناء APK؛ لأن روابط المعاينة المؤقتة تتطلب جلسة Google خاصة بـ AI Studio وتعيد توجيه الهاتف إلى صفحة `/__cookie_check.html`. يجب نشر خادم SOUQNA على استضافة إنتاجية عامة (HTTPS) مثل Cloud Run العام أو VPS أو Railway/Render ثم تمرير رابطها العام أثناء بناء APK.

---

## الطريقة الأولى (عبر GitHub Actions — بدون Android Studio)

1. **ارفع المشروع إلى مستودع GitHub**.
2. افتح تبويب **Actions** واختر المسار: **`Build SOUQNA Android APK / AAB`**.
3. اضغط **Run workflow** وأدخل في حقل **`server_url`** رابط الخادم الإنتاجي العام (`https://your-souqna-domain.com`).
4. اختر صيغة **`apk`** ثم اضغط **Run workflow** وانتظر اكتمال البناء.
5. من قسم **Artifacts** نزّل **`SOUQNA-Android-apk`**، فك الضغط وثبّت **`SOUQNA-Android.apk`** على الهاتف.

---

## الطريقة الثانية (محلياً على الحاسوب مع Java 21 و Android SDK)

```bash
npm install
SOUQNA_SERVER_URL="https://YOUR-PUBLIC-PRODUCTION-SOUQNA-URL" npm run android:apk
```

سيتم تلقائياً:
- التحقق من أن الرابط عام وصالح للإنتاج (ورفض `localhost` أو روابط المعاينة المؤقتة).
- بناء الواجهة الإنتاجية بدون Service Worker (`CAPACITOR_BUILD=true`) مع تضمين `VITE_API_BASE_URL`.
- مزامنة ملفات `android/` عبر Capacitor وإنتاج ملف APK الجاهز في:
  `android/app/build/outputs/apk/debug/app-debug.apk`
