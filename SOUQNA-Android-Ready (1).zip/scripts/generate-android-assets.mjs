import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';

const ROOT = process.cwd();
const SOURCE_ICON = path.join(ROOT, 'src', 'assets', 'images', 'souqna_app_icon_1795263557992.jpg');
const PUBLIC_DIR = path.join(ROOT, 'public');
const ANDROID_RES_DIR = path.join(ROOT, 'android', 'app', 'src', 'main', 'res');
const OBSIDIAN_BG = { r: 9, g: 10, b: 10, alpha: 1 };

function createFeatheredMask(size) {
  return Buffer.from(
    `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="f" cx="50%" cy="50%" r="50%">
          <stop offset="72%" stop-color="#ffffff" stop-opacity="1" />
          <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
        </radialGradient>
      </defs>
      <rect width="${size}" height="${size}" fill="url(#f)" />
    </svg>`
  );
}

async function makeSquareIcon(targetPath, size, padRatio = 0) {
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  if (padRatio <= 0) {
    await sharp(SOURCE_ICON)
      .resize(size, size, { fit: 'cover' })
      .png({ compressionLevel: 9 })
      .toFile(targetPath);
    return;
  }

  const innerSize = Math.round(size * (1 - padRatio * 2));
  const innerBuf = await sharp(SOURCE_ICON)
    .resize(innerSize, innerSize, { fit: 'contain', background: OBSIDIAN_BG })
    .ensureAlpha()
    .composite([{ input: createFeatheredMask(innerSize), blend: 'dest-in' }])
    .png()
    .toBuffer();

  await sharp({
    create: { width: size, height: size, channels: 4, background: OBSIDIAN_BG },
  })
    .composite([{ input: innerBuf, gravity: 'center' }])
    .png({ compressionLevel: 9 })
    .toFile(targetPath);
}

async function makeRoundIcon(targetPath, size) {
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  const circleMask = Buffer.from(
    `<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="#fff"/></svg>`
  );
  await sharp(SOURCE_ICON)
    .resize(size, size, { fit: 'cover' })
    .composite([{ input: circleMask, blend: 'dest-in' }])
    .png({ compressionLevel: 9 })
    .toFile(targetPath);
}

async function makeSplash(targetPath, width, height) {
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  const emblemSize = Math.round(Math.min(width, height) * 0.42);
  const emblemBuf = await sharp(SOURCE_ICON)
    .resize(emblemSize, emblemSize, { fit: 'contain', background: OBSIDIAN_BG })
    .ensureAlpha()
    .composite([{ input: createFeatheredMask(emblemSize), blend: 'dest-in' }])
    .png()
    .toBuffer();

  await sharp({
    create: { width, height, channels: 4, background: OBSIDIAN_BG },
  })
    .composite([{ input: emblemBuf, gravity: 'center' }])
    .png({ compressionLevel: 9 })
    .toFile(targetPath);
}

async function run() {
  if (!fs.existsSync(SOURCE_ICON)) {
    throw new Error(`Master icon not found at ${SOURCE_ICON}`);
  }

  // 1. Upgrade Web/PWA icons to match luxury Black & Gold branding
  await makeSquareIcon(path.join(PUBLIC_DIR, 'pwa-192x192.png'), 192, 0.04);
  await makeSquareIcon(path.join(PUBLIC_DIR, 'pwa-512x512.png'), 512, 0.04);
  await makeSquareIcon(path.join(PUBLIC_DIR, 'pwa-maskable-512x512.png'), 512, 0.14);
  await makeSquareIcon(path.join(PUBLIC_DIR, 'apple-touch-icon.png'), 180, 0.04);
  console.log('Generated luxury Black & Gold PWA/Apple icons in public/');

  if (!fs.existsSync(ANDROID_RES_DIR)) {
    console.log('Android res directory not found yet; skipping native mipmap generation.');
    return;
  }

  // 2. Android Launcher Icons (legacy square, round, and adaptive foreground)
  const densities = [
    { dir: 'mipmap-mdpi', launcher: 48, foreground: 108 },
    { dir: 'mipmap-hdpi', launcher: 72, foreground: 162 },
    { dir: 'mipmap-xhdpi', launcher: 96, foreground: 216 },
    { dir: 'mipmap-xxhdpi', launcher: 144, foreground: 324 },
    { dir: 'mipmap-xxxhdpi', launcher: 192, foreground: 432 },
  ];

  for (const d of densities) {
    const dirPath = path.join(ANDROID_RES_DIR, d.dir);
    await makeSquareIcon(path.join(dirPath, 'ic_launcher.png'), d.launcher, 0.02);
    await makeRoundIcon(path.join(dirPath, 'ic_launcher_round.png'), d.launcher);
    // Adaptive icon foreground needs ~18% safe padding so circular/squircle OEM masks never clip the gold hexagon
    await makeSquareIcon(path.join(dirPath, 'ic_launcher_foreground.png'), d.foreground, 0.18);
  }

  // 3. Adaptive Icon Obsidian Background Color
  const icBgPath = path.join(ANDROID_RES_DIR, 'values', 'ic_launcher_background.xml');
  fs.writeFileSync(
    icBgPath,
    `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#090A0A</color>\n</resources>\n`,
    'utf8'
  );

  // Remove default vector foreground XML if present so Android uses our high-res metallic gold PNG foreground
  const defaultVectorFg = path.join(ANDROID_RES_DIR, 'drawable-v24', 'ic_launcher_foreground.xml');
  if (fs.existsSync(defaultVectorFg)) {
    fs.unlinkSync(defaultVectorFg);
  }
  const defaultBgXml = path.join(ANDROID_RES_DIR, 'drawable', 'ic_launcher_background.xml');
  if (fs.existsSync(defaultBgXml)) {
    fs.writeFileSync(
      defaultBgXml,
      `<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">\n    <solid android:color="#090A0A" />\n</shape>\n`,
      'utf8'
    );
  }

  // 4. Android Splash Screens (Obsidian Black + Centered Gold Emblem)
  const splashTargets = [
    { dir: 'drawable', w: 720, h: 1280 },
    { dir: 'drawable-port-mdpi', w: 320, h: 480 },
    { dir: 'drawable-port-hdpi', w: 480, h: 800 },
    { dir: 'drawable-port-xhdpi', w: 720, h: 1280 },
    { dir: 'drawable-port-xxhdpi', w: 960, h: 1600 },
    { dir: 'drawable-port-xxxhdpi', w: 1280, h: 1920 },
    { dir: 'drawable-land-mdpi', w: 480, h: 320 },
    { dir: 'drawable-land-hdpi', w: 800, h: 480 },
    { dir: 'drawable-land-xhdpi', w: 1280, h: 720 },
    { dir: 'drawable-land-xxhdpi', w: 1600, h: 960 },
    { dir: 'drawable-land-xxxhdpi', w: 1920, h: 1280 },
  ];

  for (const s of splashTargets) {
    const dirPath = path.join(ANDROID_RES_DIR, s.dir);
    if (fs.existsSync(dirPath) || s.dir === 'drawable') {
      await makeSplash(path.join(dirPath, 'splash.png'), s.w, s.h);
    }
  }

  console.log('Generated all Android mipmap icons and obsidian-gold splash screens!');
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
