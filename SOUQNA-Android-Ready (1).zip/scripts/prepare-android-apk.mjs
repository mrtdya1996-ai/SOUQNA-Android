import fs from 'node:fs';
import path from 'node:path';
import { resolveAndValidateProductionServerUrl } from './souqna-server-config.mjs';

const ROOT = process.cwd();
const CONFIG_PATH = path.join(ROOT, 'capacitor.config.json');
const ANDROID_ASSETS_DIR = path.join(ROOT, 'android', 'app', 'src', 'main', 'assets');
const ANDROID_CONFIG_PATH = path.join(ANDROID_ASSETS_DIR, 'capacitor.config.json');
const ANDROID_PUBLIC_DIR = path.join(ANDROID_ASSETS_DIR, 'public');
const DIST_DIR = path.join(ROOT, 'dist');

const syncAssetsOnly = process.argv.includes('--sync-assets-only');
const webviewMode = (process.env.SOUQNA_WEBVIEW_MODE || 'bundled').trim().toLowerCase();

const { cleanUrl, hostname, source } = resolveAndValidateProductionServerUrl(
  '',
  'SOUQNA Android Prepare'
);

// Remove any stale Service Worker / Workbox files from dist/ and Android WebView assets
for (const dir of [DIST_DIR, ANDROID_PUBLIC_DIR]) {
  if (fs.existsSync(dir)) {
    for (const entry of fs.readdirSync(dir)) {
      if (/^(sw\.js|push-sw\.js|workbox-.*\.js|registerSW\.js)$/i.test(entry)) {
        fs.rmSync(path.join(dir, entry), { force: true });
      }
    }
  }
}

const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
config.appId = 'com.souqna.marketplace';
config.appName = 'سوقنا | SOUQNA';
config.webDir = 'dist';
config.backgroundColor = '#090A0A';
config.server = {
  ...(config.server || {}),
  androidScheme: 'https',
};
config.android = {
  ...(config.android || {}),
  backgroundColor: '#090A0A',
  allowMixedContent: false,
  captureInput: false,
  webContentsDebuggingEnabled: false,
};

if (webviewMode === 'remote') {
  config.server.url = cleanUrl;
  config.server.cleartext = false;
  config.server.allowNavigation = [hostname];
  console.log(`[SOUQNA Android] Configured REMOTE WebView mode -> ${cleanUrl} (source: ${source})`);
} else {
  // Recommended production architecture: instant local bundled UI (https://localhost) + live HTTPS API (VITE_API_BASE_URL)
  delete config.server.url;
  delete config.server.cleartext;
  config.server.allowNavigation = [hostname];
  console.log(
    `[SOUQNA Android] Configured BUNDLED local UI + live production HTTPS API -> ${cleanUrl} (source: ${source})`
  );
}

const serialized = JSON.stringify(config, null, 2) + '\n';
if (!syncAssetsOnly) {
  fs.writeFileSync(CONFIG_PATH, serialized, 'utf8');
}
if (fs.existsSync(ANDROID_ASSETS_DIR)) {
  fs.writeFileSync(ANDROID_CONFIG_PATH, serialized, 'utf8');
}
