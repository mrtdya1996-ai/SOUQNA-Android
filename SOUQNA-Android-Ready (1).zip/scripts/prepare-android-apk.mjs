import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const CONFIG_PATH = path.join(ROOT, 'capacitor.config.json');
const DIST_DIR = path.join(ROOT, 'dist');

const rawUrl = (process.env.SOUQNA_SERVER_URL || process.env.VITE_API_BASE_URL || '').trim();
const webviewMode = (process.env.SOUQNA_WEBVIEW_MODE || 'bundled').trim().toLowerCase();

function validateProductionUrl(urlStr) {
  if (!urlStr) {
    throw new Error(
      'Missing SOUQNA_SERVER_URL / VITE_API_BASE_URL. Refusing to prepare Android APK without a real public HTTPS production server URL (e.g. https://souqna.up.railway.app).'
    );
  }
  let parsed;
  try {
    parsed = new URL(urlStr);
  } catch {
    throw new Error(`Invalid production server URL: ${urlStr}`);
  }
  if (parsed.protocol !== 'https:') {
    throw new Error(
      `Refusing non-HTTPS server URL "${urlStr}". Android production APK requires a public https:// server URL.`
    );
  }

  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host === '10.0.2.2' ||
    host.endsWith('.local')
  ) {
    throw new Error(
      `Refusing to build Android APK with local/loopback host "${host}". Provide a public production HTTPS server URL.`
    );
  }

  if (
    /^ais-(dev|pre)-[a-z0-9-]+\..*run\.app$/i.test(host) ||
    host.endsWith('.aistudio.google.com')
  ) {
    throw new Error(
      `Refusing to build Android APK with temporary AI Studio preview URL "${host}". AI Studio preview URLs require Google auth cookies (302 /__cookie_check.html) and fail on installed phones. Deploy SOUQNA to a public production HTTPS URL first.`
    );
  }

  return parsed;
}

const parsed = validateProductionUrl(rawUrl);
const cleanUrl = rawUrl.replace(/\/+$/, '');

// Remove any stale Service Worker / Workbox files from dist/ before syncing to Android WebView
if (fs.existsSync(DIST_DIR)) {
  for (const entry of fs.readdirSync(DIST_DIR)) {
    if (/^(sw\.js|push-sw\.js|workbox-.*\.js|registerSW\.js)$/i.test(entry)) {
      fs.rmSync(path.join(DIST_DIR, entry), { force: true });
    }
  }
}

const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
config.appId = 'com.souqna.marketplace';
config.appName = 'سوقنا | SOUQNA';
config.webDir = 'dist';
config.backgroundColor = '#090A0A';
config.server = {
  ...(config.server || {}),
  androidScheme: 'https',
};
config.android = {
  ...(config.android || {}),
  backgroundColor: '#090A0A',
  allowMixedContent: false,
  captureInput: false,
  webContentsDebuggingEnabled: false,
};

if (webviewMode === 'remote') {
  config.server.url = cleanUrl;
  config.server.cleartext = false;
  config.server.allowNavigation = [parsed.hostname];
  console.log(`[SOUQNA Android] Configured REMOTE WebView mode -> ${cleanUrl}`);
} else {
  // Recommended production architecture: instant local bundled UI (https://localhost) + live HTTPS API (VITE_API_BASE_URL)
  delete config.server.url;
  delete config.server.cleartext;
  config.server.allowNavigation = [parsed.hostname];
  console.log(
    `[SOUQNA Android] Configured BUNDLED local UI + live production HTTPS API -> ${cleanUrl}`
  );
}

fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2) + '\n', 'utf8');
