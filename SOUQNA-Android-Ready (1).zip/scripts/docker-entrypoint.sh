#!/bin/sh
set -e

STORAGE_ROOT="${STORAGE_DIR:-/data}"

mkdir -p \
  "$STORAGE_ROOT" \
  "$STORAGE_ROOT/uploads" \
  "$STORAGE_ROOT/private_uploads/courier_docs" \
  "$STORAGE_ROOT/private_uploads/payment_proofs"

if [ "$(id -u)" = "0" ]; then
  chown -R node:node "$STORAGE_ROOT"
  if command -v runuser >/dev/null 2>&1; then
    exec runuser -u node -- "$@"
  fi
  exec su -s /bin/sh node -c 'exec "$0" "$@"' -- "$@"
fi

exec "$@"
