import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const THIS_DIR = path.dirname(fileURLToPath(import.meta.url));
export const PROJECT_ROOT = path.resolve(THIS_DIR, '..');
export const PRODUCTION_CONFIG_PATH = path.join(PROJECT_ROOT, 'souqna.production.json');

export function readConfiguredProductionServerUrl(explicitUrl = '') {
  const fromArg = String(explicitUrl || '').trim();
  if (fromArg) return { url: fromArg, source: 'cli-argument' };

  const fromSouqnaEnv = String(process.env.SOUQNA_SERVER_URL || '').trim();
  if (fromSouqnaEnv) return { url: fromSouqnaEnv, source: 'env:SOUQNA_SERVER_URL' };

  const fromViteEnv = String(process.env.VITE_API_BASE_URL || '').trim();
  if (fromViteEnv) return { url: fromViteEnv, source: 'env:VITE_API_BASE_URL' };

  if (fs.existsSync(PRODUCTION_CONFIG_PATH)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(PRODUCTION_CONFIG_PATH, 'utf8'));
      const fromFile = String(parsed?.productionServerUrl || '').trim();
      if (fromFile) return { url: fromFile, source: 'souqna.production.json' };
    } catch {
      // Fall through to validation error if file is malformed
    }
  }

  return { url: '', source: 'none' };
}

export function validateProductionServerUrl(rawUrl, contextLabel = 'SOUQNA Android') {
  const cleanUrl = String(rawUrl || '')
    .trim()
    .replace(/\/+$/, '');

  if (!cleanUrl) {
    throw new Error(
      `[${contextLabel}] Missing production HTTPS server URL. Set SOUQNA_SERVER_URL (in GitHub Actions input / Repository Variables / Secrets) or set "productionServerUrl" in souqna.production.json to your live https:// server URL.`
    );
  }

  let parsed;
  try {
    parsed = new URL(cleanUrl);
  } catch {
    throw new Error(`[${contextLabel}] Invalid production server URL: "${cleanUrl}"`);
  }

  if (parsed.protocol !== 'https:') {
    throw new Error(
      `[${contextLabel}] Refusing non-HTTPS URL "${cleanUrl}". Android production APK requires a public https:// server URL.`
    );
  }

  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    !host ||
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host === '10.0.2.2' ||
    host.endsWith('.local')
  ) {
    throw new Error(
      `[${contextLabel}] Refusing local/loopback host "${host}". Provide a real public production HTTPS server URL.`
    );
  }

  if (
    /^ais-(dev|pre)-[a-z0-9-]+\..*run\.app$/i.test(host) ||
    host.endsWith('.aistudio.google.com')
  ) {
    throw new Error(
      `[${contextLabel}] Refusing temporary AI Studio preview host "${host}". AI Studio preview URLs require Google auth cookies and fail on installed Android phones.`
    );
  }

  return {
    cleanUrl,
    origin: parsed.origin,
    hostname: host,
    parsed,
  };
}

export function resolveAndValidateProductionServerUrl(explicitUrl = '', contextLabel = 'SOUQNA Android') {
  const { url, source } = readConfiguredProductionServerUrl(explicitUrl);
  const validated = validateProductionServerUrl(url, contextLabel);
  return { ...validated, source };
}
