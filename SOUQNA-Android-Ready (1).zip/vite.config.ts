import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

function validateCapacitorApiBaseUrl(rawUrl: string): string {
  const cleanUrl = rawUrl.trim().replace(/\/+$/, '');
  if (!cleanUrl) {
    throw new Error(
      '[SOUQNA Android Build Guard] Refusing to build Android APK bundle with empty VITE_API_BASE_URL / SOUQNA_SERVER_URL. Provide a live public HTTPS server URL (e.g. https://souqna.up.railway.app).'
    );
  }
  let parsed: URL;
  try {
    parsed = new URL(cleanUrl);
  } catch {
    throw new Error(`[SOUQNA Android Build Guard] Invalid production API URL: "${cleanUrl}"`);
  }
  if (parsed.protocol !== 'https:') {
    throw new Error(
      `[SOUQNA Android Build Guard] Android APK requires HTTPS (got "${parsed.protocol}" in "${cleanUrl}").`
    );
  }
  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host === '10.0.2.2' ||
    host.endsWith('.local')
  ) {
    throw new Error(
      `[SOUQNA Android Build Guard] Refusing localhost/private API host "${host}" inside Android APK bundle.`
    );
  }
  if (/^ais-(dev|pre)-[a-z0-9-]+\..*run\.app$/i.test(host) || host.endsWith('.aistudio.google.com')) {
    throw new Error(
      `[SOUQNA Android Build Guard] Refusing temporary AI Studio Preview host "${host}" inside Android APK bundle.`
    );
  }
  return cleanUrl;
}

export default defineConfig(() => {
  const isCapacitorBuild = process.env.CAPACITOR_BUILD === 'true';
  const validatedCapacitorApiUrl = isCapacitorBuild
    ? validateCapacitorApiBaseUrl(
        process.env.VITE_API_BASE_URL || process.env.SOUQNA_SERVER_URL || ''
      )
    : '';

  return {
    ...(isCapacitorBuild
      ? {
          define: {
            'import.meta.env.VITE_API_BASE_URL': JSON.stringify(validatedCapacitorApiUrl),
          },
        }
      : {}),
    plugins: [
      react(),
      tailwindcss(),
      ...(!isCapacitorBuild
        ? [
            VitePWA({
              registerType: 'prompt',
              injectRegister: null,
              includeAssets: ['icon.svg', 'apple-touch-icon.png', 'pwa-192x192.png', 'pwa-512x512.png', 'pwa-maskable-512x512.png', 'push-sw.js'],
        manifest: {
          id: '/',
          name: 'سوقنا | SOUQNA',
          short_name: 'سوقنا',
          description: 'منصة سوقنا التجارية الموحدة للمحلات والبقالات والأسواق الغذائية والسوبر ماركت والمولات بنظام الدفع نقداً فقط.',
          dir: 'rtl',
          lang: 'ar',
          theme_color: '#090A0A',
          background_color: '#090A0A',
          display: 'standalone',
          orientation: 'portrait',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          importScripts: ['/push-sw.js'],
          cleanupOutdatedCaches: true,
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          navigateFallbackDenylist: [/^\/api\//, /^\/uploads\//],
          runtimeCaching: [
            {
              urlPattern: /\/api\/.*/i,
              handler: 'NetworkOnly',
            },
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: false,
        },
            }),
          ]
        : []),
      // When DISABLE_HMR=true (server.ws=false & server.hmr=false), Vite 8 still injects
      // /@vite/client with a default hmrPort=24678 and calls transport.connect() without .catch(),
      // causing an uncaught WebSocket rejection ("WebSocket closed without opened.") on every load.
      // Skip only transport.connect() while preserving CSS updateStyle/removeStyle/HMRContext exports.
      ...(process.env.DISABLE_HMR === 'true'
        ? [
            {
              name: 'souqna-disable-hmr-client-ws',
              apply: 'serve' as const,
              enforce: 'post' as const,
              transform(code: string, id: string) {
                const normalizedId = id.replace(/\\/g, '/');
                if (
                  normalizedId.includes('vite/dist/client/client.mjs') &&
                  code.includes('transport.connect(createHMRHandler(handleMessage));')
                ) {
                  return {
                    code: code.replace(
                      'transport.connect(createHMRHandler(handleMessage));',
                      '/* HMR WebSocket connection disabled when DISABLE_HMR=true */'
                    ),
                    map: null,
                  };
                }
                return null;
              },
            },
          ]
        : []),
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(import.meta.dirname, 'dist');
          const srcAssets = path.resolve(import.meta.dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, { recursive: true, force: true });
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    build: {
      // Ensure full JS compatibility across Android WebView (Android 7–16)
      target: ['es2020', 'chrome80'],
    },
    optimizeDeps: {
      entries: ['index.html'],
    },
    server: {
      allowedHosts: true as const,
      hmr: process.env.DISABLE_HMR !== 'true',
      ...(process.env.DISABLE_HMR === 'true' ? { ws: false as const } : {}),
      watch:
        process.env.DISABLE_HMR === 'true'
          ? null
          : {
              ignored: [
                '**/android/**',
                '**/dist/**',
                '**/dev-dist/**',
                '**/data/**',
                '**/uploads/**',
                '**/private_uploads/**',
                '**/private_payment_proofs/**',
              ],
            },
    },
  };
});
