/* SOUQNA Background Push Notifications Service Worker Handler */
/* Runs inside the Workbox-generated PWA Service Worker even when the app is closed. */

self.addEventListener('push', (event) => {
  let payload = {
    title: 'إشعار جديد من سوقنا',
    body: 'لديك تحديث جديد على متجرك أو طلباتك في SOUQNA | سوقنا.',
    url: '/',
    orderId: '',
    targetView: 'notifications',
    tag: 'souqna-notification',
  };

  if (event.data) {
    try {
      const parsed = event.data.json();
      payload = {
        ...payload,
        ...parsed,
      };
    } catch {
      const text = event.data.text();
      if (text) payload.body = text;
    }
  }

  const options = {
    body: payload.body,
    icon: '/pwa-192x192.png',
    badge: '/pwa-192x192.png',
    dir: 'rtl',
    lang: 'ar',
    vibrate: [180, 90, 180],
    tag: payload.tag || (payload.orderId ? `souqna-order-${payload.orderId}` : 'souqna-general'),
    renotify: true,
    requireInteraction: true,
    data: {
      url: payload.url || '/',
      orderId: payload.orderId || '',
      targetView: payload.targetView || 'notifications',
    },
  };

  event.waitUntil(self.registration.showNotification(payload.title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const data = event.notification.data || {};
  const targetUrl = new URL(data.url || '/', self.location.origin).href;

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.startsWith(self.location.origin) && 'focus' in client) {
          client.postMessage({
            type: 'SOUQNA_OPEN_NOTIFICATION',
            orderId: data.orderId || '',
            targetView: data.targetView || 'notifications',
          });
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
      return undefined;
    })
  );
});
