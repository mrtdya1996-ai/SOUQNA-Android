import React, { useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  FileText,
  Image as ImageIcon,
  Loader2,
  MapPin,
  Printer,
  Store as StoreIcon,
  Trash2,
  Truck,
  Upload,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { api, formatPrice, normalizeArabicDigits, readDocumentAsDataUrl } from '../lib/api';
import {
  DEFAULT_PRINT_PRICING,
  PRINT_BINDING_LABELS,
  PRINT_COLOR_LABELS,
  PRINT_PAPER_LABELS,
  PRINT_SERVICE_TYPES,
  PRINT_SIDES_LABELS,
  calculatePrintJobPrice,
  type FulfillmentMethod,
  type PrintBindingType,
  type PrintColorMode,
  type PrintPaperSize,
  type PrintSides,
  type Store,
} from '../types';

interface PrintOrderPanelProps {
  store: Store;
  isOwnStore: boolean;
}

export const PrintOrderPanel: React.FC<PrintOrderPanelProps> = ({ store, isOwnStore }) => {
  const { user, bootstrapStatus, navigate, notify } = useApp();
  const currency = bootstrapStatus.currency;
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const pricing = store.serviceConfig?.printPricing || DEFAULT_PRINT_PRICING;

  const [serviceType, setServiceType] = useState<string>(PRINT_SERVICE_TYPES[0]);
  const [uploadedFile, setUploadedFile] = useState<{
    url: string;
    fileName: string;
    fileMime: string;
    sizeBytes: number;
  } | null>(null);
  const [uploading, setUploading] = useState(false);

  const [pages, setPages] = useState<number>(1);
  const [pagesInput, setPagesInput] = useState<string>('1');
  const [copies, setCopies] = useState<number>(1);
  const [copiesInput, setCopiesInput] = useState<string>('1');

  const commitPages = (next: number) => {
    const clamped = Math.max(1, Math.min(2000, Math.floor(next)));
    setPages(clamped);
    setPagesInput(String(clamped));
  };

  const commitCopies = (next: number) => {
    const clamped = Math.max(1, Math.min(500, Math.floor(next)));
    setCopies(clamped);
    setCopiesInput(String(clamped));
  };
  const [colorMode, setColorMode] = useState<PrintColorMode>('bw');
  const [paperSize, setPaperSize] = useState<PrintPaperSize>('A4');
  const [sides, setSides] = useState<PrintSides>('single');
  const [binding, setBinding] = useState<PrintBindingType>('none');
  const [printNotes, setPrintNotes] = useState('');

  const [fulfillmentMethod, setFulfillmentMethod] = useState<FulfillmentMethod>('pickup');
  const [customerName, setCustomerName] = useState(user?.fullName || '');
  const [customerPhone, setCustomerPhone] = useState(user?.phone || '');
  const [governorate, setGovernorate] = useState(user?.governorate || user?.city || '');
  const [city, setCity] = useState(user?.city || user?.governorate || '');
  const [district, setDistrict] = useState(user?.district || '');
  const [neighborhood, setNeighborhood] = useState(user?.neighborhood || '');
  const [deliveryAddress, setDeliveryAddress] = useState(user?.address || '');

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const calc = useMemo(
    () =>
      calculatePrintJobPrice(pricing, {
        pages,
        copies,
        colorMode,
        paperSize,
        sides,
        binding,
      }),
    [pricing, pages, copies, colorMode, paperSize, sides, binding]
  );

  const appliedDeliveryFee = fulfillmentMethod === 'pickup' ? 0 : store.deliveryFee;
  const finalTotal = Math.round((calc.grandTotal + appliedDeliveryFee) * 100) / 100;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    if (!user) {
      notify('يرجى تسجيل الدخول أولاً لرفع ملفات الطباعة.', 'info');
      navigate('auth');
      return;
    }

    setUploading(true);
    try {
      const dataUrl = await readDocumentAsDataUrl(file);
      const saved = await api.uploadDocument(dataUrl, file.name);
      setUploadedFile(saved);
      notify(`تم رفع الملف "${saved.fileName}" بنجاح.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر رفع الملف المختار.', 'error');
    } finally {
      setUploading(false);
    }
  };

  const handleReviewClick = () => {
    if (!user) {
      notify('يرجى تسجيل الدخول لإرسال طلب الطباعة.', 'info');
      navigate('auth');
      return;
    }
    if (isOwnStore) {
      notify('لا يمكنك إرسال طلب طباعة إلى مطبعتك الخاصة.', 'info');
      return;
    }
    if (!uploadedFile) {
      notify('يرجى رفع ملف PDF أو صورة للطباعة أولاً.', 'error');
      return;
    }
    if (!customerName.trim() || customerName.trim().length < 2) {
      notify('يرجى إدخال اسم الزبون الكامل.', 'error');
      return;
    }
    if (!customerPhone.trim() || customerPhone.trim().length < 7) {
      notify('يرجى إدخال رقم هاتف صحيح للتواصل.', 'error');
      return;
    }
    if (
      fulfillmentMethod === 'delivery' &&
      (!governorate.trim() || !city.trim() || deliveryAddress.trim().length < 3)
    ) {
      notify('يرجى إدخال المحافظة والمدينة والعنوان التفصيلي للتوصيل.', 'error');
      return;
    }
    if (store.minOrderAmount > 0 && calc.grandTotal < store.minOrderAmount) {
      notify(
        `الحد الأدنى للطلب في هذه المطبعة هو ${formatPrice(store.minOrderAmount, currency)}.`,
        'error'
      );
      return;
    }
    setConfirmOpen(true);
  };

  const handleSubmitOrder = async () => {
    if (!uploadedFile) return;
    setSubmitting(true);
    try {
      const res = await api.createOrder({
        storeId: store.id,
        fulfillmentMethod,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        governorate: governorate.trim(),
        city: city.trim(),
        district: district.trim(),
        neighborhood: neighborhood.trim(),
        deliveryAddress: deliveryAddress.trim(),
        latitude: user?.latitude ?? null,
        longitude: user?.longitude ?? null,
        notes: printNotes.trim(),
        items: [],
        printJob: {
          serviceType,
          fileUrl: uploadedFile.url,
          fileName: uploadedFile.fileName,
          fileMime: uploadedFile.fileMime,
          copies,
          pages,
          colorMode,
          paperSize,
          sides,
          binding,
          notes: printNotes.trim() || undefined,
        },
      });
      setConfirmOpen(false);
      notify(
        `تم إرسال طلب الطباعة رقم ${res.order.orderNumber} إلى "${store.name}" بنجاح.`,
        'success'
      );
      navigate('orders');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'تعذر إرسال طلب الطباعة.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <section className="bg-sq-surface border border-stone-200 rounded-2xl p-4 sm:p-6 space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-100 pb-4">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
            <Printer className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-stone-900">
              طلب طباعة واستنساخ مباشر
            </h2>
            <p className="text-xs sm:text-sm text-stone-500 mt-0.5">
              ارفع ملف PDF أو صورة من هاتفك، حدد المواصفات، واحصل على السعر الفوري تلقائياً
            </p>
          </div>
        </div>
        <div className="text-xs text-stone-600 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 space-y-0.5">
          <p className="font-bold text-stone-800">تسعيرة المطبعة (A4):</p>
          <p>
            أبيض وأسود: <strong className="text-emerald-800">{formatPrice(pricing.bwA4Price, currency)}</strong> · ملون:{' '}
            <strong className="text-emerald-800">{formatPrice(pricing.colorA4Price, currency)}</strong>
          </p>
        </div>
      </div>

      {/* Step 1: Service type & File upload */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-3">
          <label className="block text-sm font-bold text-stone-800">1. نوع الخدمة المطلوبة</label>
          <div className="grid grid-cols-2 gap-2">
            {PRINT_SERVICE_TYPES.map((srv) => (
              <button
                key={srv}
                type="button"
                onClick={() => {
                  setServiceType(srv);
                  if (srv === 'طباعة الصور') {
                    setPaperSize('photo');
                    setColorMode('color');
                  }
                }}
                className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-bold border text-right transition ${
                  serviceType === srv
                    ? 'bg-emerald-800 text-white border-emerald-800'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:border-emerald-700'
                }`}
              >
                {srv}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <label className="block text-sm font-bold text-stone-800">
            2. رفع الملف من الهاتف (PDF أو صورة حتى 15MB)
          </label>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf,image/jpeg,image/png,image/webp"
            onChange={handleFileChange}
            className="hidden"
          />

          {!uploadedFile ? (
            <button
              type="button"
              disabled={uploading || isOwnStore}
              onClick={() => fileInputRef.current?.click()}
              className="w-full min-h-[132px] border-2 border-dashed border-stone-300 hover:border-emerald-700 rounded-2xl bg-stone-50/70 hover:bg-emerald-50/40 p-4 flex flex-col items-center justify-center gap-2 transition disabled:opacity-60"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-7 h-7 text-emerald-700 animate-spin" />
                  <span className="text-sm font-bold text-emerald-800">جاري رفع الملف وفحصه...</span>
                </>
              ) : (
                <>
                  <div className="w-11 h-11 rounded-full bg-sq-surface border border-stone-200 flex items-center justify-center text-emerald-800">
                    <Upload className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-bold text-stone-900">
                    اضغط لاختيار ملف PDF أو صورة من جهازك
                  </span>
                  <span className="text-xs text-stone-500">
                    يدعم ملفات PDF وصور JPG و PNG و WebP بجودة عالية
                  </span>
                </>
              )}
            </button>
          ) : (
            <div className="border border-emerald-200 bg-emerald-50/40 rounded-2xl p-3.5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {uploadedFile.fileMime.startsWith('image/') ? (
                  <img
                    src={uploadedFile.url}
                    alt={uploadedFile.fileName}
                    className="w-14 h-14 rounded-xl object-cover border border-stone-200 shrink-0"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-xl bg-sq-surface border border-emerald-200 text-emerald-800 flex items-center justify-center shrink-0">
                    <FileText className="w-7 h-7" />
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-sm font-bold text-stone-900 truncate">{uploadedFile.fileName}</p>
                  <p className="text-xs text-emerald-800 font-semibold mt-0.5 flex items-center gap-1">
                    {uploadedFile.fileMime === 'application/pdf' ? (
                      <FileText className="w-3.5 h-3.5" />
                    ) : (
                      <ImageIcon className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {uploadedFile.fileMime === 'application/pdf' ? 'مستند PDF' : 'صورة جاهزة للطباعة'} ·{' '}
                      {formatFileSize(uploadedFile.sizeBytes)}
                    </span>
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="min-h-[40px] px-3 rounded-xl border border-stone-200 bg-sq-surface text-xs font-bold text-stone-700 hover:bg-stone-50"
                >
                  تغيير
                </button>
                <button
                  type="button"
                  onClick={() => setUploadedFile(null)}
                  className="min-h-[40px] w-10 rounded-xl border border-red-200 bg-sq-surface text-red-600 flex items-center justify-center hover:bg-red-50"
                  aria-label="إزالة الملف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Step 2: Print Options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2 border-t border-stone-100">
        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1.5">عدد الصفحات في الملف</label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => commitPages(pages - 1)}
              className="w-11 h-11 rounded-xl border border-stone-200 bg-stone-50 font-bold text-stone-800 hover:bg-stone-100"
            >
              -
            </button>
            <input
              type="text"
              inputMode="numeric"
              dir="ltr"
              value={pagesInput}
              onChange={(e) => {
                const digits = normalizeArabicDigits(e.target.value).replace(/\D/g, '').slice(0, 4);
                setPagesInput(digits);
                if (digits !== '') {
                  const parsed = Math.min(2000, Math.max(1, parseInt(digits, 10) || 1));
                  setPages(parsed);
                }
              }}
              onBlur={() => {
                const parsed = parseInt(pagesInput, 10);
                commitPages(Number.isFinite(parsed) && parsed > 0 ? parsed : 1);
              }}
              className="flex-1 h-11 rounded-xl border border-stone-200 px-3 text-center text-sm font-bold bg-sq-surface focus:border-emerald-700 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => commitPages(pages + 1)}
              className="w-11 h-11 rounded-xl border border-stone-200 bg-stone-50 font-bold text-stone-800 hover:bg-stone-100"
            >
              +
            </button>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1.5">عدد النسخ المطلوبة</label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => commitCopies(copies - 1)}
              className="w-11 h-11 rounded-xl border border-stone-200 bg-stone-50 font-bold text-stone-800 hover:bg-stone-100"
            >
              -
            </button>
            <input
              type="text"
              inputMode="numeric"
              dir="ltr"
              value={copiesInput}
              onChange={(e) => {
                const digits = normalizeArabicDigits(e.target.value).replace(/\D/g, '').slice(0, 3);
                setCopiesInput(digits);
                if (digits !== '') {
                  const parsed = Math.min(500, Math.max(1, parseInt(digits, 10) || 1));
                  setCopies(parsed);
                }
              }}
              onBlur={() => {
                const parsed = parseInt(copiesInput, 10);
                commitCopies(Number.isFinite(parsed) && parsed > 0 ? parsed : 1);
              }}
              className="flex-1 h-11 rounded-xl border border-stone-200 px-3 text-center text-sm font-bold bg-sq-surface focus:border-emerald-700 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => commitCopies(copies + 1)}
              className="w-11 h-11 rounded-xl border border-stone-200 bg-stone-50 font-bold text-stone-800 hover:bg-stone-100"
            >
              +
            </button>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1.5">نوع الطباعة</label>
          <div className="grid grid-cols-2 gap-2">
            {(['bw', 'color'] as PrintColorMode[]).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => setColorMode(mode)}
                className={`h-11 rounded-xl text-xs font-bold border transition ${
                  colorMode === mode
                    ? 'bg-emerald-800 text-white border-emerald-800'
                    : 'bg-stone-50 text-stone-700 border-stone-200'
                }`}
              >
                {PRINT_COLOR_LABELS[mode]}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1.5">حجم الورق</label>
          <select
            value={paperSize}
            onChange={(e) => setPaperSize(e.target.value as PrintPaperSize)}
            className="w-full h-11 rounded-xl border border-stone-200 px-3 text-sm font-semibold bg-sq-surface focus:border-emerald-700 focus:outline-none"
          >
            {(Object.keys(PRINT_PAPER_LABELS) as PrintPaperSize[]).map((sz) => (
              <option key={sz} value={sz}>
                {PRINT_PAPER_LABELS[sz]}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1.5">وجه الطباعة</label>
          <div className="grid grid-cols-2 gap-2">
            {(['single', 'double'] as PrintSides[]).map((sd) => (
              <button
                key={sd}
                type="button"
                disabled={paperSize === 'photo' && sd === 'double'}
                onClick={() => setSides(sd)}
                className={`h-11 rounded-xl text-xs font-bold border transition disabled:opacity-40 ${
                  sides === sd
                    ? 'bg-emerald-800 text-white border-emerald-800'
                    : 'bg-stone-50 text-stone-700 border-stone-200'
                }`}
              >
                {PRINT_SIDES_LABELS[sd]}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-stone-700 mb-1.5">التغليف والتجليد</label>
          <select
            value={binding}
            onChange={(e) => setBinding(e.target.value as PrintBindingType)}
            className="w-full h-11 rounded-xl border border-stone-200 px-3 text-sm font-semibold bg-sq-surface focus:border-emerald-700 focus:outline-none"
          >
            {(Object.keys(PRINT_BINDING_LABELS) as PrintBindingType[]).map((b) => {
              const extra =
                b === 'spiral'
                  ? pricing.bindingSpiralPrice
                  : b === 'thermal'
                  ? pricing.bindingThermalPrice
                  : b === 'lamination'
                  ? pricing.laminationPrice
                  : 0;
              return (
                <option key={b} value={b}>
                  {PRINT_BINDING_LABELS[b]} {extra > 0 ? `(+${formatPrice(extra, currency)})` : ''}
                </option>
              );
            })}
          </select>
        </div>
      </div>

      {/* Step 3: Fulfillment & Customer Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 pt-3 border-t border-stone-100">
        <div className="lg:col-span-7 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setFulfillmentMethod('pickup')}
              className={`min-h-[44px] flex-1 px-3 py-2 rounded-xl border text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition ${
                fulfillmentMethod === 'pickup'
                  ? 'bg-emerald-800 text-white border-emerald-800'
                  : 'bg-stone-50 text-stone-700 border-stone-200'
              }`}
            >
              <StoreIcon className="w-4 h-4" />
              <span>استلام من المطبعة (مجاناً)</span>
            </button>
            <button
              type="button"
              onClick={() => setFulfillmentMethod('delivery')}
              className={`min-h-[44px] flex-1 px-3 py-2 rounded-xl border text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition ${
                fulfillmentMethod === 'delivery'
                  ? 'bg-emerald-800 text-white border-emerald-800'
                  : 'bg-stone-50 text-stone-700 border-stone-200'
              }`}
            >
              <Truck className="w-4 h-4" />
              <span>
                توصيل ({store.deliveryFee > 0 ? formatPrice(store.deliveryFee, currency) : 'مجاني'})
              </span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="الاسم الثلاثي للزبون"
              className="h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
            />
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder="رقم الهاتف للتواصل"
              dir="ltr"
              className="h-11 rounded-xl border border-stone-200 px-3 text-sm text-right bg-sq-surface focus:border-emerald-700 focus:outline-none"
            />
          </div>

          {fulfillmentMethod === 'delivery' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={governorate}
                onChange={(e) => setGovernorate(e.target.value)}
                placeholder="المحافظة"
                className="h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
              />
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="المدينة / القضاء"
                className="h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
              />
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="المنطقة"
                className="h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
              />
              <input
                type="text"
                value={neighborhood}
                onChange={(e) => setNeighborhood(e.target.value)}
                placeholder="الحي"
                className="h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
              />
              <input
                type="text"
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                placeholder="العنوان التفصيلي وأقرب نقطة دالة"
                className="sm:col-span-2 h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
              />
            </div>
          )}

          <input
            type="text"
            value={printNotes}
            onChange={(e) => setPrintNotes(e.target.value)}
            placeholder="ملاحظات إضافية للمطبعة (مثال: طباعة من صفحة 1 إلى 20، غلاف شفاف...)"
            className="w-full h-11 rounded-xl border border-stone-200 px-3 text-sm bg-sq-surface focus:border-emerald-700 focus:outline-none"
          />
        </div>

        {/* Live Automatic Price Breakdown Card */}
        <div className="lg:col-span-5 bg-stone-50 border border-stone-200 rounded-2xl p-4 flex flex-col justify-between gap-4">
          <div className="space-y-2 text-sm">
            <h3 className="font-extrabold text-stone-900">ملخص التكلفة التلقائي</h3>
            <div className="flex items-center justify-between text-stone-600">
              <span>سعر الصفحة ({PRINT_COLOR_LABELS[colorMode]} · {paperSize})</span>
              <span className="font-bold text-stone-900">{formatPrice(calc.unitPagePrice, currency)}</span>
            </div>
            <div className="flex items-center justify-between text-stone-600">
              <span>عدد الصفحات × عدد النسخ</span>
              <span className="font-bold text-stone-900">
                {pages} × {copies} = {pages * copies} صفحة
              </span>
            </div>
            {calc.bindingPricePerCopy > 0 && (
              <div className="flex items-center justify-between text-stone-600">
                <span>التغليف والتجليد ({copies} نسخة)</span>
                <span className="font-bold text-stone-900">
                  {formatPrice(calc.bindingPricePerCopy * copies, currency)}
                </span>
              </div>
            )}
            <div className="flex items-center justify-between text-stone-600">
              <span>
                {fulfillmentMethod === 'pickup' ? 'الاستلام من المطبعة' : 'أجور التوصيل'}
              </span>
              <span className="font-bold text-stone-900">
                {appliedDeliveryFee > 0 ? formatPrice(appliedDeliveryFee, currency) : 'مجاني'}
              </span>
            </div>
            <div className="border-t border-stone-200 pt-2.5 flex items-center justify-between text-base">
              <span className="font-extrabold text-stone-900">الإجمالي (الدفع نقداً)</span>
              <span className="font-extrabold text-emerald-800 text-lg">
                {formatPrice(finalTotal, currency)}
              </span>
            </div>
          </div>

          <button
            type="button"
            disabled={isOwnStore || uploading}
            onClick={handleReviewClick}
            className="w-full min-h-[48px] bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>مراجعة وتأكيد طلب الطباعة</span>
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {confirmOpen && uploadedFile && (
        <div className="fixed inset-0 z-50 bg-stone-950/60 flex items-end sm:items-center justify-center p-4">
          <div className="bg-sq-surface rounded-2xl border border-stone-200 w-full max-w-md p-5 space-y-4">
            <h3 className="text-lg font-extrabold text-stone-900">تأكيد إرسال طلب الطباعة</h3>
            <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 text-sm space-y-1.5 text-stone-700">
              <p>
                <strong>المطبعة:</strong> {store.name}
              </p>
              <p>
                <strong>الخدمة:</strong> {serviceType}
              </p>
              <p className="truncate">
                <strong>الملف:</strong> {uploadedFile.fileName}
              </p>
              <p>
                <strong>المواصفات:</strong> {pages} صفحة × {copies} نسخة · {PRINT_COLOR_LABELS[colorMode]} ·{' '}
                {PRINT_PAPER_LABELS[paperSize]} · {PRINT_SIDES_LABELS[sides]}
              </p>
              {binding !== 'none' && (
                <p>
                  <strong>التغليف:</strong> {PRINT_BINDING_LABELS[binding]}
                </p>
              )}
              <p className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                <span>
                  {fulfillmentMethod === 'pickup' ? 'استلام من المطبعة' : `${governorate} - ${city} - ${deliveryAddress}`}
                </span>
              </p>
              <p className="pt-2 border-t border-stone-200 text-base font-extrabold text-emerald-800">
                المبلغ الإجمالي للدفع نقداً: {formatPrice(finalTotal, currency)}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={submitting}
                onClick={handleSubmitOrder}
                className="flex-1 min-h-[46px] bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>تأكيد وإرسال الطلب</span>
              </button>
              <button
                type="button"
                disabled={submitting}
                onClick={() => setConfirmOpen(false)}
                className="min-h-[46px] px-4 border border-stone-200 text-stone-700 font-bold rounded-xl text-sm hover:bg-stone-50"
              >
                تراجع
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
