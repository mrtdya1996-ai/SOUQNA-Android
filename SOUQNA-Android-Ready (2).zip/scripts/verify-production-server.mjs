import process from 'node:process';
import { resolveAndValidateProductionServerUrl } from './souqna-server-config.mjs';

let rawUrl;
try {
  const resolved = resolveAndValidateProductionServerUrl(
    process.argv[2] || '',
    'SOUQNA Server Verify'
  );
  rawUrl = resolved.cleanUrl;
  console.log(`Resolved server URL from ${resolved.source}: ${rawUrl}`);
} catch (err) {
  console.error(`FAIL: ${err instanceof Error ? err.message : String(err)}`);
  console.error('Usage: npm run server:verify -- https://your-production-server.example.com');
  process.exit(1);
}

async function fetchManual(url, init = {}) {
  const res = await fetch(url, { redirect: 'manual', ...init });
  const text = await res.text();
  return { res, text };
}

async function main() {
  console.log(`Verifying SOUQNA production server: ${rawUrl}`);

  // 1. /healthz (including Capacitor Android Origin CORS check)
  const health = await fetchManual(`${rawUrl}/healthz`, {
    headers: { Accept: 'application/json', Origin: 'https://localhost' },
  });
  if (health.res.status !== 200) {
    throw new Error(`/healthz returned HTTP ${health.res.status} (location: ${health.res.headers.get('location') || 'none'})`);
  }
  const healthJson = JSON.parse(health.text);
  if (!healthJson?.ok) {
    throw new Error(`/healthz JSON missing ok:true -> ${health.text}`);
  }
  const healthAcao = health.res.headers.get('access-control-allow-origin');
  if (healthAcao !== 'https://localhost') {
    throw new Error(
      `/healthz missing Capacitor CORS header (expected ACAO=https://localhost, got ${healthAcao}). Redeploy the latest server.ts to production first.`
    );
  }
  console.log('PASS [1/4] GET /healthz (Origin: https://localhost) -> 200 JSON { ok: true } + valid CORS');

  // 2. /api/bootstrap-status
  const boot = await fetchManual(`${rawUrl}/api/bootstrap-status`, {
    headers: { Accept: 'application/json' },
  });
  if (boot.res.status !== 200) {
    throw new Error(`/api/bootstrap-status returned HTTP ${boot.res.status}`);
  }
  if (/__cookie_check|_aistudio-iframe/i.test(boot.text)) {
    throw new Error('/api/bootstrap-status returned an AI Studio preview gate instead of SOUQNA JSON');
  }
  const bootJson = JSON.parse(boot.text);
  if (typeof bootJson?.hasSuperAdmin !== 'boolean') {
    throw new Error(`/api/bootstrap-status JSON malformed -> ${boot.text}`);
  }
  console.log(
    `PASS [2/4] GET /api/bootstrap-status -> 200 JSON (appName: ${bootJson.appName || 'SOUQNA'}, hasSuperAdmin: ${bootJson.hasSuperAdmin})`
  );

  // 3. Capacitor Android CORS preflight
  const preflight = await fetchManual(`${rawUrl}/api/stores`, {
    method: 'OPTIONS',
    headers: {
      Origin: 'https://localhost',
      'Access-Control-Request-Method': 'POST',
      'Access-Control-Request-Headers': 'Content-Type, Authorization, X-Requested-With',
    },
  });
  const acao = preflight.res.headers.get('access-control-allow-origin');
  const acac = preflight.res.headers.get('access-control-allow-credentials');
  if (preflight.res.status !== 204 || acao !== 'https://localhost' || acac !== 'true') {
    throw new Error(
      `CORS preflight failed: status=${preflight.res.status}, ACAO=${acao}, ACAC=${acac}`
    );
  }
  console.log('PASS [3/4] OPTIONS /api/stores (Origin: https://localhost) -> 204 with valid CORS headers');

  // 4. Capacitor Android GET /api/stores
  const stores = await fetchManual(`${rawUrl}/api/stores`, {
    headers: {
      Origin: 'https://localhost',
      Accept: 'application/json',
    },
  });
  if (stores.res.status !== 200) {
    throw new Error(`GET /api/stores returned HTTP ${stores.res.status}`);
  }
  const storesJson = JSON.parse(stores.text);
  if (!Array.isArray(storesJson?.stores)) {
    throw new Error(`GET /api/stores missing stores array -> ${stores.text}`);
  }
  console.log(`PASS [4/5] GET /api/stores (Origin: https://localhost) -> 200 JSON (${storesJson.stores.length} stores)`);

  // 5. Capacitor Android GET /api/auth/session
  const session = await fetchManual(`${rawUrl}/api/auth/session`, {
    headers: {
      Origin: 'https://localhost',
      Accept: 'application/json',
      'X-Requested-With': 'XMLHttpRequest',
    },
  });
  if (session.res.status !== 200) {
    throw new Error(`GET /api/auth/session returned HTTP ${session.res.status}`);
  }
  const sessionAcao = session.res.headers.get('access-control-allow-origin');
  if (sessionAcao !== 'https://localhost') {
    throw new Error(`GET /api/auth/session missing CORS header (got ${sessionAcao})`);
  }
  const sessionJson = JSON.parse(session.text);
  if (typeof sessionJson?.authenticated !== 'boolean') {
    throw new Error(`GET /api/auth/session malformed JSON -> ${session.text}`);
  }
  console.log('PASS [5/5] GET /api/auth/session (Origin: https://localhost) -> 200 JSON + valid CORS');

  console.log('\nALL CHECKS PASSED: Production server is live, public, and ready for Android APK linking.');
}

main().catch((err) => {
  console.error(`\nVERIFICATION FAILED: ${err instanceof Error ? err.message : String(err)}`);
  process.exit(1);
});
