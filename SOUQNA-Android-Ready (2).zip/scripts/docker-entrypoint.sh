#!/bin/sh
set -e

STORAGE_ROOT="${STORAGE_DIR:-/data}"

mkdir -p \
  "$STORAGE_ROOT" \
  "$STORAGE_ROOT/uploads" \
  "$STORAGE_ROOT/private_uploads/courier_docs" \
  "$STORAGE_ROOT/private_uploads/payment_proofs"

if [ "$(id -u)" = "0" ]; then
  chown node:node "$STORAGE_ROOT" 2>/dev/null || true
  chown -R node:node \
    "$STORAGE_ROOT/uploads" \
    "$STORAGE_ROOT/private_uploads" 2>/dev/null || true
  for dbfile in "$STORAGE_ROOT"/souqna.db*; do
    [ -e "$dbfile" ] && chown node:node "$dbfile" 2>/dev/null || true
  done
  if command -v runuser >/dev/null 2>&1; then
    exec runuser -u node -- "$@"
  fi
  exec su -s /bin/sh node -c 'exec "$0" "$@"' -- "$@"
fi

exec "$@"
